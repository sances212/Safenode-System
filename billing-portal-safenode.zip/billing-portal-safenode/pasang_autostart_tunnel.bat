@echo off
setlocal enabledelayedexpansion
title BENTANG RADIUS - Pasang Auto-Start Tunnel (Tanpa Windows Service)
cd /d "%~dp0"

echo ============================================================
echo  BENTANG RADIUS - Pasang Auto-Start Tunnel (versi anti-bug)
echo ============================================================
echo.
echo Windows Service "BentangRadiusTunnel" kena bug pywin32 klasik
echo ("not responding to the control function"). Script ini membuat
echo jalur lain yang TIDAK memakai pywin32 sama sekali -- persis pola
echo "Mode Sederhana" yang sudah terbukti berhasil untuk aplikasi
echo utama -- lewat Windows Task Scheduler.
echo.
echo Yang akan dilakukan:
echo   1. Menghapus service BentangRadiusTunnel yang bermasalah
echo   2. Membuat script loop yang menjaga cloudflared tetap menyala
echo   3. Mendaftarkan loop itu ke Task Scheduler (otomatis nyala saat
echo      Windows boot, tanpa jendela yang harus dibiarkan terbuka)
echo   4. Langsung menyalakan tunnel sekarang juga (tanpa perlu restart)
echo.
pause

REM ------------------------------------------------------------
REM  Minta akses Administrator kalau belum
REM ------------------------------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Meminta akses Administrator...
    set "VBS=%temp%\bentang_autostarttunnel_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "", "", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)

set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"
set "SVC_DIR=%APP_DIR%\windows_service"
set "TASK_NAME=BentangRadiusTunnelAutoStart"
set "LOOP_BAT=%SVC_DIR%\tunnel_loop.bat"
set "LOOP_VBS=%SVC_DIR%\tunnel_loop_hidden.vbs"
set "LOOP_LOG=%SVC_DIR%\tunnel_loop.log"

echo.
echo ------------------------------------------------------------
echo  LANGKAH 1/5 - Cek pengaturan tunnel (tunnel_info.txt)
echo ------------------------------------------------------------
if not exist "%APP_DIR%\tunnel_info.txt" (
    echo.
    echo [ERROR] tunnel_info.txt belum ada. Jalankan dulu
    echo setup_tunnel_pertama_kali.bat sampai selesai, baru jalankan
    echo ulang script ini.
    pause
    exit /b 1
)
set "HOSTNAME="
set "TUNNEL_NAME="
for /f "tokens=1,2 delims==" %%a in (%APP_DIR%\tunnel_info.txt) do (
    if "%%a"=="HOSTNAME" set "HOSTNAME=%%b"
    if "%%a"=="TUNNEL_NAME" set "TUNNEL_NAME=%%b"
)
if "%HOSTNAME%"=="" goto :info_kosong
if "%TUNNEL_NAME%"=="" goto :info_kosong
echo OK - Hostname: %HOSTNAME%
echo OK - Nama tunnel: %TUNNEL_NAME%
goto :lanjut_cari_cloudflared

:info_kosong
echo [ERROR] tunnel_info.txt ada tapi isinya tidak lengkap.
pause
exit /b 1

:lanjut_cari_cloudflared
set "CLOUDFLARED="
where cloudflared >nul 2>nul
if not errorlevel 1 (
    for /f "delims=" %%p in ('where cloudflared') do set "CLOUDFLARED=%%p" & goto :ketemu_cf
)
if exist "%APP_DIR%\cloudflared.exe" set "CLOUDFLARED=%APP_DIR%\cloudflared.exe"
:ketemu_cf
if "%CLOUDFLARED%"=="" (
    echo [ERROR] cloudflared.exe tidak ditemukan.
    pause
    exit /b 1
)
echo OK - cloudflared: %CLOUDFLARED%

echo.
echo ------------------------------------------------------------
echo  LANGKAH 2/5 - Menghapus Windows Service lama yang bermasalah
echo ------------------------------------------------------------
net stop BentangRadiusTunnel >nul 2>&1
sc delete BentangRadiusTunnel >nul 2>&1
echo (Selesai -- kalau tadinya tidak ada juga tidak apa-apa.)

echo.
echo ------------------------------------------------------------
echo  LANGKAH 3/5 - Membuat script penjaga tunnel (auto-reconnect)
echo ------------------------------------------------------------
(
    echo @echo off
    echo cd /d "%SVC_DIR%"
    echo :ulangi
    echo echo [%%date%% %%time%%] Menyalakan tunnel...^>^>"%LOOP_LOG%"
    echo "%CLOUDFLARED%" tunnel run --url http://127.0.0.1:80 %TUNNEL_NAME% ^>^>"%LOOP_LOG%" 2^>^&1
    echo echo [%%date%% %%time%%] Tunnel berhenti, mencoba lagi dalam 5 detik...^>^>"%LOOP_LOG%"
    echo timeout /t 5 /nobreak ^>nul
    echo goto :ulangi
) > "%LOOP_BAT%"
echo OK - dibuat: %LOOP_BAT%

(
    echo Set WshShell = CreateObject^("WScript.Shell"^)
    echo WshShell.Run """"^& "%LOOP_BAT%" ^&"""", 0, False
) > "%LOOP_VBS%"
echo OK - dibuat: %LOOP_VBS%

echo.
echo ------------------------------------------------------------
echo  LANGKAH 4/5 - Mendaftarkan ke Task Scheduler (auto-start)
echo ------------------------------------------------------------
schtasks /Create /TN "%TASK_NAME%" ^
    /TR "wscript.exe \"%LOOP_VBS%\"" ^
    /SC ONSTART /RU SYSTEM /RL HIGHEST /F
if errorlevel 1 (
    echo [ERROR] Gagal mendaftarkan Task Scheduler. Lihat pesan di atas.
    pause
    exit /b 1
)
echo OK - Task "%TASK_NAME%" terdaftar, akan otomatis jalan tiap Windows boot.

echo.
echo ------------------------------------------------------------
echo  LANGKAH 5/5 - Menyalakan tunnel sekarang juga
echo ------------------------------------------------------------
taskkill /IM cloudflared.exe /F >nul 2>&1
schtasks /Run /TN "%TASK_NAME%"
timeout /t 8 /nobreak >nul

echo.
echo ============================================================
echo  SELESAI!
echo ============================================================
echo.
tasklist | findstr /i cloudflared.exe >nul
if errorlevel 1 (
    echo [PERINGATAN] Proses cloudflared.exe belum terlihat berjalan.
    echo Cek isi log berikut untuk detail:
    echo   %LOOP_LOG%
) else (
    echo OK - cloudflared.exe terdeteksi sedang berjalan.
    echo Tunggu 10-20 detik lagi, lalu buka https://%HOSTNAME%
    echo ^(disarankan dari HP pakai kuota data^) untuk memastikan sudah online.
)
echo.
echo Mulai sekarang tunnel akan otomatis menyala sendiri setiap kali
echo Windows dinyalakan/restart, tanpa perlu buka jendela apa pun.
echo Kalau perlu menghapus auto-start ini nanti, jalankan:
echo   schtasks /Delete /TN "%TASK_NAME%" /F
echo.
pause
