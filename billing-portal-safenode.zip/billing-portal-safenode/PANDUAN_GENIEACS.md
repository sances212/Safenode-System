# Panduan Pasang GenieACS (untuk fitur Client Area WiFi & ONT)

Fitur **Pengaturan ONT** di Portal Pelanggan (ganti nama/password WiFi, restart ONT,
lihat redaman & device terhubung) butuh server **GenieACS** yang menjembatani billing
portal ini dengan ONT pelanggan lewat protokol **TR-069/CWMP**.

## 1. Apa itu GenieACS?

GenieACS adalah **ACS (Auto Configuration Server)** open-source. ONT yang mendukung
TR-069 secara berkala "lapor" (Inform) ke ACS ini, dan ACS bisa membaca/mengubah
parameter di ONT tersebut (nama WiFi, password, reboot, dll) — itulah yang dipakai
billing portal ini untuk fitur Client Area.

GenieACS terdiri dari beberapa service:
| Service | Port default | Fungsi |
|---|---|---|
| genieacs-cwmp | 7547 | Menerima koneksi TR-069 dari ONT (**ini yang diisi di ONT sebagai "ACS URL"**) |
| genieacs-nbi | 7557 | REST API (**ini yang diisi di billing portal, menu Pengaturan &gt; GenieACS**) |
| genieacs-fs | 7567 | File server (untuk firmware/config file, opsional) |
| genieacs-ui | 3000 | Dashboard web GenieACS (untuk cek device manual, bukan yang dipakai billing portal) |

## 2. Kebutuhan Server

- Linux (disarankan **Ubuntu 22.04 / 24.04 LTS**), bisa VM atau server fisik kecil
- RAM minimal 2GB (4GB lebih nyaman kalau ONU banyak)
- Server ini **harus satu jaringan / bisa dijangkau** oleh ONT pelanggan (biasanya
  dipasang di jaringan management OLT/inti ISP, bukan asal-asalan taruh di cloud
  publik kalau ONT tidak bisa keluar jaringan lokal)

## 3. Instalasi (Ubuntu)

```bash
# 1) Install Node.js (GenieACS butuh Node.js LTS)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2) Install MongoDB (tempat GenieACS menyimpan data device)
sudo apt-get install -y gnupg curl
curl -fsSL https://pgp.mongodb.com/server-7.0.asc | sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg --dearmor
echo "deb [signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg] https://repo.mongodb.org/apt/ubuntu $(lsb_release -cs)/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl enable --now mongod

# 3) Install GenieACS lewat npm
sudo npm install -g genieacs

# 4) Buat folder config & user khusus
sudo useradd --system --no-create-home --shell /usr/sbin/nologin genieacs
sudo mkdir -p /opt/genieacs/ext /var/log/genieacs
sudo chown -R genieacs:genieacs /opt/genieacs /var/log/genieacs
```

Buat file environment `/opt/genieacs/genieacs.env`:
```ini
GENIEACS_CWMP_ACCESS_LOG_FILE=/var/log/genieacs/cwmp-access.log
GENIEACS_NBI_ACCESS_LOG_FILE=/var/log/genieacs/nbi-access.log
GENIEACS_FS_ACCESS_LOG_FILE=/var/log/genieacs/fs-access.log
GENIEACS_UI_ACCESS_LOG_FILE=/var/log/genieacs/ui-access.log
GENIEACS_DEBUG_FILE=/var/log/genieacs/debug.yaml
GENIEACS_EXT_DIR=/opt/genieacs/ext
GENIEACS_UI_JWT_SECRET=ganti-dengan-teks-acak-panjang
```

Lalu buat 4 file service systemd (`genieacs-cwmp.service`, `genieacs-nbi.service`,
`genieacs-fs.service`, `genieacs-ui.service`) di `/etc/systemd/system/`, semuanya
mengikuti pola berikut (ganti `genieacs-cwmp` sesuai nama servicenya):

```ini
[Unit]
Description=GenieACS CWMP
After=network.target mongod.service

[Service]
User=genieacs
EnvironmentFile=/opt/genieacs/genieacs.env
ExecStart=/usr/bin/genieacs-cwmp
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Aktifkan semuanya:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now genieacs-cwmp genieacs-nbi genieacs-fs genieacs-ui
sudo systemctl status genieacs-cwmp genieacs-nbi
```

Kalau semua `active (running)`, GenieACS sudah siap. Cek NBI API sudah jalan:
```bash
curl http://localhost:7557/devices/?limit=1
```

## 4. Arahkan ONT ke GenieACS

Di halaman admin ONT (biasanya diakses lewat `http://<ip-ont>` dengan login default
vendor), cari menu **TR-069 / Remote Management / WAN Management Protocol**, lalu isi:
- **ACS URL**: `http://<ip-server-genieacs>:7547`
- **Periodic Inform**: aktifkan, interval 300 detik (5 menit) cukup untuk kebanyakan kasus
- Username/password TR-069: boleh dikosongkan kalau GenieACS belum diset auth

Setelah disimpan, ONT akan mulai "Inform" ke GenieACS. Cek di dashboard GenieACS UI
(`http://<ip-server>:3000`) apakah device sudah muncul dengan Serial Number yang sesuai.

> Kalau ONT banyak dan mau di-setting massal, biasanya dilakukan lewat **TR-069 di sisi
> OLT/provisioning otomatis** saat ONT baru terdaftar, atau lewat konfigurasi default
> pabrik (tanyakan ke vendor ONT/OLT kamu apakah bisa di-provisioning otomatis).

## 5. Hubungkan ke Billing Portal

1. Buka **Pengaturan &gt; Pengaturan GenieACS** di billing portal.
2. Isi **URL NBI GenieACS**: `http://<ip-server-genieacs>:7557`
3. Aktifkan togglenya, simpan.
4. Klik **Tes Koneksi** untuk memastikan billing portal bisa menghubungi GenieACS.
5. Pastikan tiap pelanggan sudah punya baris di menu **ONU** dengan **Serial Number**
   yang sama persis dengan yang tercatat di GenieACS (ini kunci pencocokan device ↔ pelanggan).

Setelah itu, menu **Pengaturan ONT** otomatis muncul di Portal Pelanggan untuk
pelanggan yang ONU-nya sudah punya Serial Number & device-nya sudah pernah Inform ke GenieACS.

## 6. Kalau Path Parameter Tidak Cocok dengan Merk ONT Kamu

Struktur parameter TR-069 **berbeda-beda antar merk ONT** (Huawei, ZTE, Fiberhome,
V-Solution, dll). Default yang dipakai billing portal ini gaya **TR-098**
(`InternetGatewayDevice.*`), paling umum. Kalau ONT kamu memakai model data **TR-181**
(`Device.*`) atau path custom vendor, sesuaikan di bagian "Path parameter TR-069
(lanjutan)" pada halaman Pengaturan GenieACS — cara termudah cari tahu path yang benar
adalah membuka device di **GenieACS UI** (`http://<ip-server>:3000`) → klik salah satu
device → jelajahi parameter tree-nya untuk menemukan path SSID, password, RX power,
uptime, dan daftar host yang sesuai ONT kamu, lalu salin path tersebut ke pengaturan.
