# -*- coding: utf-8 -*-
"""
translations.py - Kamus terjemahan multi-bahasa untuk Billing Portal.

Bahasa yang didukung: Indonesia (id), English (en).

Cara pakai di template:
    {{ t('login_title') }}

Cara pakai di app.py:
    from translations import t
    t('login_title', lang='en')

Untuk menambah teks baru: tambahkan key baru di dict `id` (bahasa acuan),
lalu isi padanannya di bahasa `en`. Kalau sebuah key belum diterjemahkan
di bahasa tertentu, sistem otomatis fallback ke teks Bahasa Indonesia.
"""

LANGUAGES = {
    "id": {"label": "Indonesia", "flag": "🇮🇩", "dir": "ltr"},
}

DEFAULT_LANG = "id"

TRANSLATIONS = {

    # ================== HALAMAN LOGIN ADMIN/RESELLER ==================
    "login_admin_title": {
        "id": "Login Admin/Reseller Dashboard",
        "en": "Admin/Reseller Dashboard Login",
    },
    "login_admin_subtitle": {
        "id": "Masukkan username & password untuk login.",
        "en": "Enter your username & password to sign in.",
    },
    "label_username": {
        "id": "Username",
        "en": "Username",
    },
    "label_password": {
        "id": "Password",
        "en": "Password",
    },
    "forgot_password": {
        "id": "Lupa password?",
        "en": "Forgot password?",
    },
    "btn_login_dashboard": {
        "id": "Login Dashboard",
        "en": "Login to Dashboard",
    },
    "btn_login_pelanggan_billing": {
        "id": "Login Pelanggan Billing/PPPoE",
        "en": "Customer Billing/PPPoE Login",
    },
    "info_label": {
        "id": "INFO",
        "en": "INFO",
    },
    "login_admin_info_text": {
        "id": "Pelanggan login pakai <strong>username &amp; password PPPoE</strong> yang sama dengan internet di rumah. Belum terdaftar / lupa password? Hubungi admin/teknisi jaringan kamu.",
        "en": "Customers log in using the same <strong>PPPoE username &amp; password</strong> as their home internet. Not registered yet / forgot password? Contact your network admin/technician.",
    },
    "cta_pasang_title": {
        "id": "Mau pasang internet baru?",
        "en": "Want to install new internet?",
    },
    "cta_pasang_sub": {
        "id": "Cek paket & daftar jadi pelanggan",
        "en": "Check packages & register as a customer",
    },
    "cta_daftar_pelanggan_btn": {
        "id": "Daftar Pelanggan",
        "en": "Register as Customer",
    },
    "cta_bisnis_title": {
        "id": "Punya bisnis ISP sendiri?",
        "en": "Have your own ISP business?",
    },
    "cta_bisnis_sub": {
        "id": "Gabung jadi reseller/mitra kami",
        "en": "Join as our reseller/partner",
    },
    "cta_daftar_reseller_btn": {
        "id": "Daftar Reseller",
        "en": "Register as Reseller",
    },
    "powered_by": {
        "id": "Powered by",
        "en": "Powered by",
    },
    "btn_paste": {
        "id": "Paste",
        "en": "Paste",
    },

    # ================== HALAMAN LOGIN PELANGGAN ==================
    "login_pelanggan_title": {
        "id": "Login Pelanggan Billing/PPP",
        "en": "Customer Billing/PPP Login",
    },
    "login_pelanggan_subtitle": {
        "id": "Masukan username dan password mu",
        "en": "Enter your username and password",
    },
    "btn_sign_in": {
        "id": "Sign in",
        "en": "Sign in",
    },
    "btn_kembali": {
        "id": "Kembali",
        "en": "Back",
    },

    # ================== UMUM / SWITCHER ==================
    "select_language": {
        "id": "Pilih Bahasa",
        "en": "Select Language",
    },

    # ================== SIDEBAR: GRUP MENU ==================
    "menu_group_modul_inti": {"id": "Modul Inti", "en": "Core Modules"},
    "menu_group_modul_erp": {"id": "Modul ERP", "en": "ERP Module"},
    "menu_group_crm_konten": {"id": "CRM & Konten", "en": "CRM & Content"},
    "menu_group_workspace": {"id": "Workspace", "en": "Workspace"},
    "menu_group_analitik": {"id": "Analitik", "en": "Analytics"},
    "menu_group_ekstensi": {"id": "Ekstensi", "en": "Extensions"},
    "menu_group_administrasi": {"id": "Administrasi", "en": "Administration"},
    "menu_group_general": {"id": "General", "en": "General"},
    "menu_group_pop_site": {"id": "POP Site", "en": "POP Site"},
    "menu_group_customer": {"id": "Customer", "en": "Customer"},
    "menu_group_monitoring": {"id": "Monitoring", "en": "Monitoring"},
    "menu_group_maps": {"id": "Maps", "en": "Maps"},
    "menu_group_payment": {"id": "Payment", "en": "Payment"},
    "menu_group_gateway": {"id": "Gateway", "en": "Gateway"},
    "menu_group_sistem": {"id": "Sistem", "en": "System"},
    "menu_group_pengaturan": {"id": "Pengaturan", "en": "Settings"},

    # ================== SIDEBAR: ITEM MENU - MODUL INTI ==================
    "menu_modul_inti_klien": {"id": "Klien", "en": "Client"},
    "menu_modul_inti_plans_policy": {"id": "Plans & Policy", "en": "Plans & Policy"},
    "menu_modul_inti_network": {"id": "Network", "en": "Network"},
    "menu_modul_inti_billing": {"id": "Billing", "en": "Billing"},
    "menu_billing_invoice": {"id": "Invoice", "en": "Invoice"},
    "menu_billing_virtual_accounts": {"id": "Virtual Accounts", "en": "Virtual Accounts"},
    "menu_billing_configuration": {"id": "Configuration", "en": "Configuration"},
    "menu_modul_inti_payments": {"id": "Payments", "en": "Payments"},
    "menu_payments_transactions": {"id": "Transactions", "en": "Transactions"},
    "menu_payments_records": {"id": "Records", "en": "Records"},
    "menu_payments_manual_transfers": {"id": "Manual Transfers", "en": "Manual Transfers"},
    "menu_modul_inti_support": {"id": "Support", "en": "Support"},
    "menu_support_internal_tickets": {"id": "Internal Tickets", "en": "Internal Tickets"},
    "menu_support_customer_tickets": {"id": "Customer Tickets", "en": "Customer Tickets"},
    "menu_support_linknet_tickets": {"id": "LinkNet Tickets", "en": "LinkNet Tickets"},
    "menu_support_cs_handover": {"id": "CS Handover", "en": "CS Handover"},
    "menu_modul_inti_radius": {"id": "RADIUS", "en": "RADIUS"},
    "menu_radius_sessions": {"id": "Sessions", "en": "Sessions"},
    "menu_radius_isolation": {"id": "Isolasi", "en": "Isolation"},
    "menu_radius_configuration": {"id": "Konfigurasi", "en": "Configuration"},
    "menu_radius_hotspot_sessions": {"id": "Sesi Hotspot", "en": "Hotspot Sessions"},
    "menu_modul_inti_vpn": {"id": "VPN", "en": "VPN"},
    "menu_modul_inti_hotspot": {"id": "Hotspot", "en": "Hotspot"},
    "menu_group_hotspot": {"id": "Hotspot", "en": "Hotspot"},
    "menu_hotspot_voucher": {"id": "Voucher", "en": "Voucher"},
    "menu_hotspot_profil_voucher": {"id": "Profile Voucher", "en": "Voucher Profile"},
    "menu_hotspot_stok_voucher": {"id": "Stok Voucher", "en": "Voucher Stock"},
    "menu_hotspot_voucher_terjual": {"id": "Voucher Terjual", "en": "Sold Vouchers"},
    "menu_hotspot_voucher_online": {"id": "Voucher Online", "en": "Online Vouchers"},
    "menu_hotspot_voucher_offline": {"id": "Voucher Offline", "en": "Offline Vouchers"},
    "menu_hotspot_template": {"id": "Template", "en": "Template"},
    "menu_group_map": {"id": "Map", "en": "Map"},
    "menu_map_pelanggan": {"id": "Map Pelanggan", "en": "Customer Map"},
    "menu_map_odp": {"id": "Map ODP", "en": "ODP Map"},
    "menu_modul_inti_snmp": {"id": "SNMP", "en": "SNMP"},
    "menu_modul_inti_acs": {"id": "ACS", "en": "ACS"},
    "menu_acs_dashboard": {"id": "Dashboard", "en": "Dashboard"},
    "menu_acs_devices": {"id": "Perangkat", "en": "Devices"},
    "menu_acs_configuration": {"id": "Configuration", "en": "Configuration"},
    "menu_acs_tasks": {"id": "Tugas", "en": "Tasks"},
    "menu_acs_profiles": {"id": "Profil", "en": "Profiles"},
    "menu_acs_firmware": {"id": "Firmware", "en": "Firmware"},
    "menu_modul_inti_live_chat": {"id": "Live Chat", "en": "Live Chat"},

    # ================== SIDEBAR: ITEM MENU - MODUL ERP ==================
    "menu_modul_erp_sdm": {"id": "SDM", "en": "HR"},
    "menu_modul_erp_keuangan": {"id": "Keuangan", "en": "Finance"},
    "menu_modul_erp_general_affair": {"id": "General Affair", "en": "General Affair"},
    "menu_modul_erp_inventaris": {"id": "Inventaris", "en": "Inventory"},
    "menu_modul_erp_vendors": {"id": "Vendors", "en": "Vendors"},

    # ================== SIDEBAR: ITEM MENU - CRM & KONTEN ==================
    "menu_crm_konten_crm": {"id": "CRM", "en": "CRM"},
    "menu_crm_konten_cms": {"id": "CMS", "en": "CMS"},
    "menu_crm_konten_dokumen": {"id": "Dokumen", "en": "Documents"},

    # ================== SIDEBAR: ITEM MENU - WORKSPACE ==================
    "menu_workspace_my_work": {"id": "My Work", "en": "My Work"},
    "menu_workspace_projects": {"id": "Projects", "en": "Projects"},
    "menu_workspace_calendar": {"id": "Calendar", "en": "Calendar"},
    "menu_workspace_workload": {"id": "Workload", "en": "Workload"},
    "menu_workspace_utilization": {"id": "Utilization", "en": "Utilization"},
    "menu_workspace_activity": {"id": "Activity", "en": "Activity"},
    "menu_workspace_mentions": {"id": "Mentions", "en": "Mentions"},

    # ================== SIDEBAR: ITEM MENU - ANALITIK ==================
    "menu_analitik_analytics_reporting": {"id": "Analytics & Reporting", "en": "Analytics & Reporting"},

    # ================== SIDEBAR: ITEM MENU - EKSTENSI ==================
    "menu_ekstensi_rka_planning": {"id": "RKA Planning", "en": "RKA Planning"},

    # ================== SIDEBAR: ITEM MENU - ADMINISTRASI ==================
    "menu_administrasi_system_administration": {"id": "System Administration", "en": "System Administration"},
    "menu_administrasi_partners": {"id": "Partners", "en": "Partners"},
    "menu_administrasi_migrasi": {"id": "Migrasi", "en": "Migration"},

    # ================== SIDEBAR: ITEM MENU ==================
    "menu_dashboard": {"id": "Dashboard", "en": "Dashboard"},
    "menu_pendaftaran_reseller": {"id": "Registrasi POP Site", "en": "POP Site Registration"},
    "menu_pelanggan": {"id": "Pelanggan", "en": "Customers"},
    "menu_data_customer": {"id": "Data Customer", "en": "Customer Data"},
    "menu_pop_site_nas": {"id": "NAS", "en": "NAS"},
    "menu_pop_site_pelanggan": {"id": "Pelanggan POP Site", "en": "POP Site Customers"},
    "menu_pendaftaran": {"id": "Pendaftaran", "en": "Registration"},
    "menu_paket_internet": {"id": "Profile Langganan", "en": "Internet Packages"},
    "menu_tagihan": {"id": "Tagihan", "en": "Invoices"},
    "menu_stop_langganan": {"id": "Stop Langganan", "en": "Stopped Subscriptions"},
    "menu_langganan_online": {"id": "Langganan Online", "en": "Online Subscribers"},
    "menu_langganan_offline": {"id": "Langganan Offline", "en": "Offline Subscribers"},
    "menu_tiket_gangguan": {"id": "Tiket Gangguan", "en": "Support Tickets"},
    "menu_hotspot_voucher": {"id": "Hotspot & Voucher", "en": "Hotspot & Voucher"},
    "menu_monitoring_jaringan": {"id": "Monitoring Jaringan", "en": "Network Monitoring"},
    "menu_olt_onu": {"id": "OLT & ONU", "en": "OLT & ONU"},
    "menu_peta_jaringan": {"id": "Peta Jaringan", "en": "Network Map"},
    "menu_odp": {"id": "ODP", "en": "ODP"},
    "menu_payment_gateway": {"id": "Payment Gateway", "en": "Payment Gateway"},
    "menu_transfer_bank": {"id": "Transfer Bank", "en": "Bank Transfer"},
    "menu_withdraw": {"id": "Withdraw", "en": "Withdraw"},
    "menu_wa_gateway": {"id": "WA Gateway", "en": "WA Gateway"},
    "menu_telegram_gateway": {"id": "Telegram Gateway", "en": "Telegram Gateway"},
    "menu_email_gateway": {"id": "Email Gateway", "en": "Email Gateway"},
    "menu_status_sistem": {"id": "Status Sistem", "en": "System Status"},
    "menu_vpn_mikrotik": {"id": "VPN Mikrotik", "en": "VPN Mikrotik"},
    "menu_vpn_klien_jarak_jauh": {"id": "Klien Jarak Jauh", "en": "Remote Clients"},
    "menu_vpn_akses_pengguna": {"id": "Akses Pengguna", "en": "User Access"},
    "menu_vpn_konfigurasi": {"id": "Konfigurasi", "en": "Configuration"},
    "menu_pengaturan_mikrotik": {"id": "Pengaturan Mikrotik", "en": "Mikrotik Settings"},
    "menu_pengaturan_genieacs": {"id": "Pengaturan GenieACS", "en": "GenieACS Settings"},
    "menu_pengguna_admin": {"id": "Pengguna Admin", "en": "Admin Users"},
    "menu_domain_akses": {"id": "Domain / Akses Online", "en": "Domain / Online Access"},

    # ================== TOPBAR ==================
    "topbar_tema_gelap": {"id": "Tema Gelap", "en": "Dark Theme"},
    "topbar_tema_terang": {"id": "Tema Terang", "en": "Light Theme"},
    "topbar_notif_title": {"id": "Komplain Pelanggan", "en": "Customer Complaints"},
    "topbar_notif_baru": {"id": "baru", "en": "new"},
    "topbar_notif_kosong": {"id": "Tidak ada komplain baru.", "en": "No new complaints."},
    "topbar_lihat_semua_tiket": {"id": "Lihat semua tiket gangguan", "en": "View all support tickets"},
    "topbar_online": {"id": "Online", "en": "Online"},
    "topbar_login_sebagai": {"id": "Login sebagai", "en": "Logged in as"},
    "topbar_pengaturan_akun": {"id": "Pengaturan Akun", "en": "Account Settings"},
    "topbar_keluar": {"id": "Keluar", "en": "Log out"},

    # ================== BANNER PASSWORD DEFAULT ==================
    "banner_password_default": {
        "id": "Kamu masih pakai username &amp; password admin bawaan (<code>admin</code> / <code>admin123</code>). <strong>Wajib diganti</strong> terutama kalau aplikasi ini bisa diakses dari internet (tunnel/online).",
        "en": "You're still using the default admin username &amp; password (<code>admin</code> / <code>admin123</code>). <strong>You must change it</strong>, especially if this app is accessible from the internet (tunnel/online).",
    },
    "banner_ganti_sekarang": {"id": "Ganti Sekarang", "en": "Change Now"},

    # ================== DASHBOARD ==================
    "dash_lihat_detail": {"id": "Lihat Detail", "en": "View Details"},
    "dash_total_pelanggan": {"id": "Total Pelanggan", "en": "Total Customers"},
    "dash_pelanggan_aktif": {"id": "Pelanggan Aktif", "en": "Active Customers"},
    "dash_pelanggan_isolir": {"id": "Pelanggan Isolir", "en": "Suspended Customers"},
    "dash_belum_lunas": {"id": "Belum Lunas", "en": "Unpaid"},
    "dash_total_user_hotspot": {"id": "Total User Hotspot", "en": "Total Hotspot Users"},
    "dash_hotspot_aktif": {"id": "Hotspot Aktif", "en": "Active Hotspot"},
    "dash_hotspot_nonaktif": {"id": "Hotspot Nonaktif", "en": "Inactive Hotspot"},
    "dash_pendapatan_voucher": {"id": "Pendapatan Voucher", "en": "Voucher Revenue"},
}


def t(key, lang=None):
    """Ambil teks terjemahan untuk `key` pada bahasa `lang`.
    Fallback otomatis ke Bahasa Indonesia (DEFAULT_LANG) kalau key/bahasa
    tidak ditemukan, supaya tidak pernah muncul teks kosong/error di UI.
    """
    lang = lang if lang in LANGUAGES else DEFAULT_LANG
    entry = TRANSLATIONS.get(key)
    if not entry:
        return key
    return entry.get(lang) or entry.get(DEFAULT_LANG) or key
