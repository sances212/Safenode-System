@echo off
REM ============================================================
REM  BENTANG RADIUS - Buka Service Controller (GUI)
REM  Wrapper: Service Controller sekarang mengontrol aplikasi ini
REM  sebagai Windows Service asli (Start/Stop/Restart/Install/
REM  Uninstall), file sebenarnya ada di folder windows_service\.
REM ============================================================
cd /d "%~dp0windows_service"
call ServiceController.bat
