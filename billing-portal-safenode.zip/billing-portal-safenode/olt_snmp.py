"""
olt_snmp.py
Klien SNMP v2c minimal (pure Python, tanpa dependency eksternal seperti pysnmp)
untuk memantau status ONU pada OLT (mis. HIOSO) lewat GET / GETNEXT (walk).

Kenapa pure Python? Supaya konsisten dengan mikrotik_api.py (tidak butuh
`pip install` library SNMP) dan tetap ringan dijalankan di server kecil.

Catatan penting soal OID:
Tiap merk/firmware OLT punya OID privat (enterprise MIB) yang berbeda-beda
untuk status ONU & RX power, dan HIOSO tidak mempublikasikan MIB-nya secara
resmi/umum. Karena itu OID untuk status & RX power **wajib diisi manual**
di menu Pengaturan OLT (didapat lewat MIB Browser / snmpwalk ke OLT, atau
minta file MIB ke support HIOSO). Default yang disediakan di sini adalah
OID standar MIB-2 (ifOperStatus / ifDescr) yang umum dipakai banyak
perangkat jaringan untuk status interface, dan sering ikut bisa dipakai
untuk status port PON/ONU jika OLT mengekspos interface ONU lewat ifTable.
"""

import socket

OID_IF_DESCR = "1.3.6.1.2.1.2.2.1.2"        # nama interface (standar MIB-2)
OID_IF_OPER_STATUS = "1.3.6.1.2.1.2.2.1.8"  # status: 1=up(online) 2=down(offline)

# OID sistem standar MIB-2 (System group) — dipakai untuk panel "Login OLT"
# ala dashboard MSRadius (System Information). Umumnya didukung hampir semua
# perangkat SNMP walau OID privat vendor (CPU/DRAM/ONU) tidak tersedia.
OID_SYS_DESCR = "1.3.6.1.2.1.1.1.0"     # deskripsi sistem/firmware
OID_SYS_UPTIME = "1.3.6.1.2.1.1.3.0"    # waktu nyala (timeticks, 1/100 detik)
OID_SYS_NAME = "1.3.6.1.2.1.1.5.0"      # nama host/sistem
OID_SYS_LOCATION = "1.3.6.1.2.1.1.6.0"  # lokasi (sysLocation)


class SNMPError(Exception):
    pass


def _oid_to_bytes(oid_str):
    parts = [int(p) for p in oid_str.strip(".").split(".")]
    if len(parts) < 2:
        raise SNMPError(f"OID tidak valid: {oid_str}")
    first = parts[0] * 40 + parts[1]
    out = bytearray([first])
    for p in parts[2:]:
        if p == 0:
            out.append(0)
            continue
        chunk = []
        while p > 0:
            chunk.insert(0, p & 0x7F)
            p >>= 7
        for i in range(len(chunk) - 1):
            chunk[i] |= 0x80
        out.extend(chunk)
    return bytes(out)


def _bytes_to_oid(data):
    if not data:
        return ""
    first = data[0]
    parts = [first // 40, first % 40]
    val = 0
    for b in data[1:]:
        val = (val << 7) | (b & 0x7F)
        if not (b & 0x80):
            parts.append(val)
            val = 0
    return ".".join(str(p) for p in parts)


def _encode_len(n):
    if n < 0x80:
        return bytes([n])
    body = []
    while n > 0:
        body.insert(0, n & 0xFF)
        n >>= 8
    return bytes([0x80 | len(body)]) + bytes(body)


def _tlv(tag, content):
    return bytes([tag]) + _encode_len(len(content)) + content


def _encode_int(value, tag=0x02):
    if value == 0:
        content = b"\x00"
    elif value > 0:
        body = []
        n = value
        while n > 0:
            body.insert(0, n & 0xFF)
            n >>= 8
        if body[0] & 0x80:
            body.insert(0, 0x00)
        content = bytes(body)
    else:
        # dua-komplemen minimal: cari jumlah byte terkecil yang cukup menampung nilai negatif
        nbytes = 1
        while -(1 << (8 * nbytes - 1)) > value:
            nbytes += 1
        content = (value & ((1 << (8 * nbytes)) - 1)).to_bytes(nbytes, "big")
    return _tlv(tag, content)


def _encode_oid(oid_str):
    return _tlv(0x06, _oid_to_bytes(oid_str))


def _encode_octet_string(s, tag=0x04):
    if isinstance(s, str):
        s = s.encode("utf-8")
    return _tlv(tag, s)


def _encode_null():
    return _tlv(0x05, b"")


def _encode_sequence(content, tag=0x30):
    return _tlv(tag, content)


def _read_tlv(data, offset):
    tag = data[offset]
    offset += 1
    length = data[offset]
    offset += 1
    if length & 0x80:
        nbytes = length & 0x7F
        length = 0
        for i in range(nbytes):
            length = (length << 8) | data[offset + i]
        offset += nbytes
    value = data[offset:offset + length]
    return tag, value, offset + length


def _decode_int(data):
    val = 0
    negative = data[0] & 0x80
    for b in data:
        val = (val << 8) | b
    if negative:
        val -= 1 << (8 * len(data))
    return val


def _decode_value(tag, value):
    if tag == 0x02:            # INTEGER
        return _decode_int(value) if value else 0
    if tag == 0x04:             # OCTET STRING
        try:
            return value.decode("utf-8", errors="replace")
        except Exception:
            return value.hex()
    if tag == 0x06:             # OBJECT IDENTIFIER
        return _bytes_to_oid(value)
    if tag == 0x05:             # NULL
        return None
    if tag in (0x40,):          # IpAddress
        return ".".join(str(b) for b in value)
    if tag in (0x41, 0x42, 0x43, 0x46, 0x47):  # Counter/Gauge/TimeTicks/Counter64/Opaque
        return _decode_int(value) if value else 0
    if tag == 0x80:
        return "noSuchObject"
    if tag == 0x81:
        return "noSuchInstance"
    if tag == 0x82:
        return "endOfMibView"
    return value


class SNMPClient:
    """Klien SNMP v2c sederhana lewat UDP (default port 161)."""

    def __init__(self, host, community="public", port=161, timeout=2):
        self.host = host
        self.port = int(port) if port else 161
        self.community = community or "public"
        self.timeout = timeout
        self._req_id = 1

    def _next_id(self):
        self._req_id += 1
        return self._req_id

    def _build_packet(self, pdu_type, oid):
        req_id = self._next_id()
        varbind = _encode_sequence(_encode_oid(oid) + _encode_null())
        varbind_list = _encode_sequence(varbind)
        pdu_body = (
            _encode_int(req_id)
            + _encode_int(0)   # error-status
            + _encode_int(0)   # error-index
            + varbind_list
        )
        pdu = _tlv(pdu_type, pdu_body)
        message = (
            _encode_int(1)     # version: SNMPv2c = 1
            + _encode_octet_string(self.community)
            + pdu
        )
        return _encode_sequence(message), req_id

    def _send_recv(self, packet):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(self.timeout)
        try:
            sock.sendto(packet, (self.host, self.port))
            data, _ = sock.recvfrom(65535)
            return data
        except socket.timeout:
            raise SNMPError(f"Timeout menghubungi {self.host}:{self.port} (SNMP tidak merespon)")
        except Exception as e:
            raise SNMPError(f"Gagal SNMP ke {self.host}:{self.port} -> {e}")
        finally:
            sock.close()

    def _parse_response(self, data):
        tag, msg, _ = _read_tlv(data, 0)
        offset = 0
        _, _version, offset = _read_tlv(msg, offset)
        _, _community, offset = _read_tlv(msg, offset)
        pdu_tag, pdu_body, offset = _read_tlv(msg, offset)
        o = 0
        _, _req_id, o = _read_tlv(pdu_body, o)
        _, err_status, o = _read_tlv(pdu_body, o)
        _, _err_index, o = _read_tlv(pdu_body, o)
        vbl_tag, vbl_body, o = _read_tlv(pdu_body, o)
        results = []
        vo = 0
        while vo < len(vbl_body):
            vb_tag, vb_body, vo = _read_tlv(vbl_body, vo)
            io = 0
            oid_tag, oid_val, io = _read_tlv(vb_body, io)
            val_tag, val_val, io = _read_tlv(vb_body, io)
            oid_str = _bytes_to_oid(oid_val)
            results.append((oid_str, _decode_value(val_tag, val_val)))
        return results, _decode_int(err_status) if err_status else 0

    def get(self, oid):
        """GET satu OID, kembalikan value-nya (atau None jika gagal)."""
        packet, _ = self._build_packet(0xA0, oid)
        data = self._send_recv(packet)
        results, err = self._parse_response(data)
        if err != 0 or not results:
            return None
        return results[0][1]

    def get_next(self, oid):
        """GETNEXT satu OID, kembalikan (oid_berikutnya, value)."""
        packet, _ = self._build_packet(0xA1, oid)
        data = self._send_recv(packet)
        results, err = self._parse_response(data)
        if err != 0 or not results:
            return None, None
        return results[0]

    def walk(self, oid_prefix, max_rows=2000):
        """SNMP WALK: GETNEXT berulang selama masih di dalam sub-tree oid_prefix."""
        out = []
        current = oid_prefix
        prefix = oid_prefix.strip(".")
        for _ in range(max_rows):
            next_oid, value = self.get_next(current)
            if next_oid is None:
                break
            if not (next_oid == prefix or next_oid.startswith(prefix + ".")):
                break
            if value in ("endOfMibView",):
                break
            out.append((next_oid, value))
            current = next_oid
        return out

    def test_koneksi(self):
        """Tes cepat: GET sysDescr (1.3.6.1.2.1.1.1.0)."""
        try:
            val = self.get("1.3.6.1.2.1.1.1.0")
            if val is None:
                raise SNMPError("OLT tidak merespon SNMP GET (cek IP, port, community, dan service SNMP di OLT).")
            return val
        except SNMPError:
            raise
        except Exception as e:
            raise SNMPError(str(e))


def status_dari_nilai(nilai):
    """Terjemahkan nilai ifOperStatus (atau OID status kustom) ke label online/offline."""
    if nilai is None or nilai in ("noSuchObject", "noSuchInstance", "endOfMibView"):
        return "unknown"
    try:
        n = int(nilai)
    except (TypeError, ValueError):
        return "unknown"
    if n == 1:
        return "online"
    if n == 2:
        return "offline"
    return "unknown"


def format_uptime(timeticks):
    """Ubah nilai sysUpTime (satuan 1/100 detik) jadi teks 'X hari Y jam Z menit'."""
    try:
        detik = int(timeticks) / 100
    except (TypeError, ValueError):
        return None
    hari = int(detik // 86400)
    jam = int((detik % 86400) // 3600)
    menit = int((detik % 3600) // 60)
    bagian = []
    if hari:
        bagian.append(f"{hari} hari")
    if jam or hari:
        bagian.append(f"{jam} jam")
    bagian.append(f"{menit} menit")
    return " ".join(bagian)
