# BENTANG RADIUS — Web Portal Billing Internet (Sinkron Mikrotik)

Web server billing internet berbasis **Python (Flask)** + **SQLite**, dengan
sinkronisasi pelanggan ke **Mikrotik** lewat **RouterOS API** (PPP Secret
PPPoE). Modul API Mikrotik ditulis pure-Python tanpa dependency eksternal
(`mikrotik_api.py`), jadi tidak butuh library RADIUS pihak ketiga.

## 1. Cara Menjalankan

```bash
cd billing-portal
pip install -r requirements.txt
python app.py
```

Buka browser: **http://localhost**

Login default:
- Username: `admin`
- Password: `admin123`

> Ganti password admin setelah login pertama (lihat bagian "Pengembangan Lanjutan").

### 1b. Cara Menjalankan Sebagai Windows Service (GUI Service Controller)

Server juga bisa dipasang sebagai **Windows Service asli** (jalan otomatis
saat komputer nyala, tidak perlu jendela terminal terbuka terus), dikontrol
lewat panel GUI ala aplikasi Windows pada umumnya.

Langkah pertama kali (Windows):
1. Masuk folder `windows_service\`, jalankan **`1_setup.bat`** (klik 2x) —
   ini membuat virtual environment dan install semua library yang dibutuhkan.
2. Dobel-klik **`ServiceController.bat`** (bisa dari folder `windows_service\`
   atau dari root project) — akan minta akses Administrator lewat UAC.

Muncul jendela **Service Controller** dengan:
- Status service real-time: **BERJALAN / BERHENTI / BELUM TERPASANG**
- Tombol **Start / Stop / Restart**
- Tombol **Install Service** / **Uninstall Service**
- Tombol **Buka Aplikasi** (langsung buka browser ke `http://127.0.0.1`)
- Panel **Log Terbaru** (isi `service.log` / `service_error.log`)

Karena berjalan sebagai Windows Service asli, server otomatis tetap jalan di
background walau jendela Service Controller ditutup, dan bisa disetel start
otomatis saat Windows menyala — tidak seperti menjalankan `app.py` manual di
terminal yang berhenti begitu jendelanya ditutup.

Kontrol manual (tanpa GUI) juga tersedia di folder `windows_service\`:
`2_install_service.bat`, `3_start.bat`, `4_stop.bat`, `5_uninstall.bat`,
atau lewat aplikasi bawaan Windows **Services** (`services.msc`), cari nama
service **BENTANG RADIUS Billing Portal**.

### 1c. Supaya Bisa Diakses Online (dari Luar Jaringan Lokal)

Server di atas defaultnya cuma bisa diakses dari jaringan lokal (WiFi/LAN
yang sama). Untuk bisa diakses dari mana saja lewat internet (mis. dari HP
saat di luar), pakai **Cloudflare Named Tunnel** (gratis, link online
TETAP/tidak berubah-ubah, tidak perlu buka port di router/firewall):

1. **Setup sekali saja**: klik **"Setup Pertama Kali"** di jendela Service
   Controller (atau jalankan `setup_tunnel_pertama_kali.bat` langsung).
   Ikuti instruksinya: login ke akun Cloudflare kamu di browser yang
   terbuka, lalu masukkan subdomain yang mau dipakai (mis.
   `billing.namadomainkamu.com`). Syaratnya kamu sudah punya domain sendiri
   yang terdaftar gratis di Cloudflare, dan `cloudflared` sudah terinstall
   (`winget install --id Cloudflare.cloudflared`).
2. Setelah setup selesai, klik **"Install Service"** di bagian **Akses
   Online**, lalu **"Start Tunnel"**.

Karena berjalan sebagai Windows Service terpisah (`BentangRadiusTunnel`),
tunnel ini otomatis tetap menyala 24 jam — termasuk nyala lagi sendiri
kalau koneksi internet sempat putus, dan otomatis start lagi saat komputer
dinyalakan ulang — tanpa perlu ada jendela apa pun yang dibiarkan terbuka.

Status & link online-nya bisa dipantau langsung di jendela Service
Controller (bagian "Akses Online"), lengkap dengan tombol Start/Stop/
Install/Uninstall terpisah dari server lokal.

## 2. Struktur Proyek

```
billing-portal/
├── app.py                     # Server Flask + semua route
├── mikrotik_api.py            # Klien RouterOS API (pure Python)
├── vpn_manager.py              # Manajer VPN Server bawaan billing (WireGuard)
├── tripay_gateway.py          # Klien payment gateway Tripay (pure Python)
├── genieacs_client.py         # Klien GenieACS/TR-069 untuk Client Area WiFi & ONT
├── ServiceController.bat      # Shortcut ke Service Controller (lihat windows_service/)
├── setup_tunnel_pertama_kali.bat/.sh  # Setup SEKALI SAJA untuk link online tetap
├── windows_service/            # Windows Service asli (pywin32) + GUI Service Controller
│   ├── bentang_service.py     # Service Control Handler (pywin32) yang menjalankan app.py
│   ├── bentang_tunnel_service.py  # Service terpisah: jaga Cloudflare Tunnel tetap nyala
│   ├── service_controller.pyw # GUI Service Controller (server lokal + akses online)
│   ├── ServiceController.bat  # Launcher GUI (otomatis minta akses Administrator)
│   ├── 1_setup.bat            # Setup awal: buat venv + install semua library
│   ├── 2_install_service.bat  # Pasang server sebagai Windows Service
│   ├── 3_start.bat / 4_stop.bat / 5_uninstall.bat
│   ├── 6_install_tunnel_service.bat / 7_uninstall_tunnel_service.bat  # Akses online
├── requirements.txt
├── billing.db                 # dibuat otomatis saat pertama run (SQLite)
├── templates/                 # Halaman HTML (Jinja2 + Bootstrap 5)
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── pelanggan.html
│   ├── paket.html
│   ├── tagihan.html
│   ├── pengaturan_mikrotik.html
│   └── vpn_mikrotik.html
└── static/css/style.css
```

## 3. Setup di Sisi Mikrotik

1. **Aktifkan API service**: `IP > Services`, pastikan `api` aktif di port `8728` (non-SSL).
2. **Buat user API khusus** (disarankan bukan admin utama):
   `System > Users`, group minimal butuh akses `read, write, api, ppp`.
3. **Buat PPP Profile** untuk tiap paket internet:
   `PPP > Profiles > Add` — atur `Rate Limit (rx/tx)`, `Local Address`,
   `Remote Address` (IP Pool). Nama profile ini nanti diisi di menu
   **Paket Internet** pada web portal.
4. **Aktifkan PPPoE Server**: `PPP > Interface > PPPoE Server`, pilih
   interface yang menghadap ke pelanggan.
5. Pastikan Mikrotik bisa diakses dari komputer yang menjalankan server
   Python ini (satu jaringan / port forwarding jika beda lokasi) — ATAU
   pakai **VPN Mikrotik bawaan billing** (lihat bagian 3b) kalau router
   tidak punya IP publik sendiri (CGNAT / WiFi rumah).

## 3b. VPN Mikrotik Bawaan Billing (Opsional, WireGuard)

Billing ini bisa jadi **VPN Server sendiri** (berbasis WireGuard) supaya
router Mikrotik bisa konek langsung ke billing tanpa layanan tunnel pihak
ketiga (MyTunnel.id, ZeroTier, dll). Cocok kalau router ada di belakang
CGNAT/tidak punya IP publik.

**Syarat di server tempat billing ini dijalankan** (Linux disarankan):
- Kernel Linux mendukung WireGuard (kernel ≥ 5.6, atau modul tambahan).
- Paket `wireguard-tools` terinstall, contoh Debian/Ubuntu:
  `sudo apt install wireguard wireguard-tools`
- Aplikasi billing dijalankan dengan hak akses yang cukup (root/sudo) untuk
  bikin network interface, dan port UDP yang dipakai (default `51820`)
  terbuka di firewall.
- Router Mikrotik: **RouterOS versi 7 ke atas** (WireGuard sudah bawaan).

**Cara pakai** (menu **VPN Mikrotik** di sidebar):
1. Isi *Pengaturan Server* (nama interface, port, subnet tunnel, dan
   *Alamat/Domain Publik Server* — IP publik/domain server billing ini).
2. Klik **Generate Key Server**, lalu **Hidupkan VPN**.
3. Klik **Tambah Router** untuk mendaftarkan tiap Mikrotik (otomatis
   dapat IP tunnel & keypair sendiri).
4. Klik **Script Mikrotik** pada router terkait, salin & tempel ke
   terminal Mikrotik (WinBox/SSH) satu per satu.
5. Setelah status di halaman VPN Mikrotik menunjukkan **Terhubung**, buka
   **Pengaturan Mikrotik** → pilih metode **VPN Bawaan Billing** → pilih
   router tadi (IP tunnel otomatis terisi) → **Simpan** → **Tes Koneksi**.

Kalau `wireguard-tools` belum terinstall atau hak akses kurang, halaman
VPN Mikrotik akan menampilkan pesan error apa adanya (bukan cuma "gagal")
supaya jelas apa yang perlu diinstall/diperbaiki di servernya.

## 4. Alur Penggunaan di Web Portal

1. **Pengaturan Mikrotik** → isi IP, port API, username, password → klik
   **Tes Koneksi** untuk memastikan berhasil connect.
2. **Paket Internet** → tambahkan paket (nama, kecepatan, harga, nama PPP
   Profile yang sudah dibuat di Mikrotik).
3. **Pelanggan** → tambahkan pelanggan baru (otomatis jadi kandidat PPPoE
   Secret) → klik **Sync** untuk push ke Mikrotik (membuat/update PPP Secret).
4. **Tagihan**:
   - Klik **Generate Tagihan Bulan Ini** untuk membuat tagihan otomatis ke
     semua pelanggan aktif sesuai harga paketnya.
   - Klik **Tandai Lunas** saat pelanggan bayar → jika sebelumnya diisolir,
     otomatis diaktifkan kembali di Mikrotik.
   - Klik **Jalankan Isolir Otomatis** untuk mengisolir (disable PPP
     Secret) semua pelanggan yang tagihannya lewat jatuh tempo. Bisa
     dijadwalkan manual tiap hari, atau lihat bagian cron di bawah.

## 4b. Modul OLT (Monitoring ONU) — Sinkron dengan Mikrotik & Billing

Modul baru `olt_snmp.py` memantau status ONU lewat **SNMP** (pure Python, tanpa
library tambahan, sama seperti `mikrotik_api.py`). Fitur:

- Menu **OLT & ONU**: tambah perangkat OLT (IP, port SNMP, community, OID),
  lalu tambah daftar ONU per OLT (label, index SNMP, serial number, Mac
  Address, dan opsional dihubungkan ke pelanggan billing).
- Tombol **Cek Status Sekarang** di halaman ONU: SNMP GET ke tiap ONU untuk
  ambil status online/offline, dan (jika OID-nya sudah diisi) RX Power, TX
  Power, Temperatur, serta Mac Address — kolomnya dibuat sinkron persis
  dengan tampilan panel OLT HIOSO di MSRadius: **No, Onu ID, Name, Mac
  Address, Status, Temperatur, TXPower, RXPower**, ditambah kolom **Pelanggan
  (Billing)** supaya langsung kelihatan ONU itu milik pelanggan mana di
  billing.
- Panel **Login OLT** menampilkan kartu ringkasan per port PON (mis. `0/1`,
  `0/2`, `0/3`, `0/4`) berisi `ONU Total`, `Online`, `Offline` — sama seperti
  tab port di dashboard MSRadius — klik kartunya untuk lihat daftar ONU yang
  sudah difilter ke port tersebut.
- Menu **Monitoring Jaringan**: gabungan status ONU (dari OLT) dengan status
  sesi PPPoE real-time (dari Mikrotik) per pelanggan dalam satu tabel — supaya
  kelihatan cepat kalau ONU online tapi PPPoE tidak connect (biasanya masalah
  router pelanggan), atau ONU offline (biasanya masalah jalur fiber/ONU).

**Penting soal OID SNMP HIOSO**: HiOSO tidak mempublikasikan MIB privatnya
secara umum/resmi, jadi OID status, RX Power, TX Power, Temperatur & Mac
Address ONU **berbeda-beda tergantung seri/firmware** OLT Anda. Default yang
disediakan (`1.3.6.1.2.1.2.2.1.8` untuk status, standar MIB-2 `ifOperStatus`)
sering ikut mencerminkan status port ONU, tapi tidak dijamin cocok di semua
unit HIOSO. OID RX Power/TX Power/Temperatur/Mac Address bersifat opsional —
kalau belum tahu OID-nya, cukup kosongkan (isi Mac Address ONU secara manual
di menu Kelola ONU kalau perlu), status online/offline tetap bisa jalan.
Langkah verifikasi:

1. Aktifkan SNMP di OLT (biasanya di menu Web OLT > System > SNMP, set
   community, misal `public`).
2. Dari komputer yang satu jaringan dengan OLT, jalankan:
   `snmpwalk -v2c -c public <ip_olt> 1.3.6.1.2.1.2.2.1.8` — cocokkan index di
   ujung tiap baris hasil dengan port/ONU fisiknya (via halaman Web OLT), lalu
   isi angka index tersebut sebagai "Index SNMP" saat menambah ONU.
3. Untuk RX Power/TX Power/Temperatur/Mac Address, minta file MIB privat ke
   support HiOSO atau cari lewat MIB Browser (biasanya ada di bawah OID
   enterprise HiOSO), lalu isi di menu edit OLT pada kolom OID masing-masing
   (bagian "Pengaturan SNMP"). Kalau belum ketemu, kosongkan saja — kolom
   terkait akan tampil "-" di tabel ONU sampai OID-nya diisi.

## 5. Menjadwalkan Isolir Otomatis Harian (opsional)

Endpoint `/tagihan/jalankan-isolir-otomatis` bisa dipanggil otomatis
setiap hari lewat cron (Linux) atau Task Scheduler (Windows), misalnya
dengan `curl` + cookie session, atau paling gampang: buat script Python
kecil yang login dan memanggil endpoint tersebut secara terjadwal.

## 6. Akses Online dari Mana Saja (Cloudflare Tunnel, Link Tetap)

Aplikasi ini bisa diakses lewat internet tanpa perlu setting router/port
forwarding, pakai **Cloudflare Tunnel** (gratis, otomatis HTTPS). Sejak
versi ini, link online-nya **TETAP/tidak berubah-ubah** setiap kali
server dinyalakan ulang -- cocok dipakai sebagai callback URL Tripay,
dibagikan ke pelanggan, dsb.

**Setup (hanya sekali):**

1. Pastikan kamu punya domain sendiri (mis. `msradius2.com`) yang
   nameserver-nya sudah diarahkan ke akun Cloudflare (gratis, daftar di
   https://dash.cloudflare.com kalau belum).
2. Jalankan sekali saja:
   - Windows: `setup_tunnel_pertama_kali.bat`
   - Linux/Mac: `./setup_tunnel_pertama_kali.sh`
3. Ikuti langkah di layar: login ke Cloudflare (browser akan terbuka),
   lalu masukkan subdomain yang mau dipakai (mis. `billing.msradius2.com`).
4. Setelah selesai, link online tetap kamu akan tampil, dan tersimpan
   di file `tunnel_info.txt`.

**Menjalankan sehari-hari:**

- Kalau pakai **Service Controller** (`ServiceController.bat`), tunnel
  online akan **otomatis menyala bareng server lokal** setiap kali
  Service Controller dibuka -- tinggal lihat kartu "ONLINE ACCESS
  (Cloudflare)" untuk link tetapnya dan tombol START/STOP ONLINE-nya
  sendiri (terpisah dari tombol START/STOP SERVICES yang mengatur
  server lokal).
- Atau manual lewat terminal: `start.bat`/`start.sh` dulu, lalu di
  jendela baru jalankan `start_tunnel.bat`/`./start_tunnel.sh`.

**Catatan penting:**

- Link ini sekarang **Named Tunnel**, jadi **tidak lagi acak/berubah**
  seperti Quick Tunnel (`trycloudflare.com`) versi sebelumnya. Cocok
  dipakai untuk callback URL Tripay yang butuh domain kredibel.
- Selama tunnel aktif, siapa pun yang tahu URL-nya bisa membuka halaman
  login aplikasi ini. **Wajib ganti password admin default** dulu (lihat
  bagian Catatan Keamanan di bawah) sebelum menyalakan tunnel.
- Aplikasi otomatis membatasi percobaan login gagal (maks. 5x per IP,
  lalu terkunci sementara) untuk mengurangi risiko brute-force selagi
  online.
- Server sekarang berjalan dengan **waitress** (server produksi yang
  lebih aman & stabil dibanding mode debug Flask) saat dijalankan lewat
  `start.bat`/`start.sh`/`python app.py` secara normal.

## 7. Catatan Keamanan (sebelum dipakai produksi/online)

- **Ganti password admin default** (`admin` / `admin123`) — aplikasi akan
  menampilkan banner peringatan di semua halaman selama password default
  masih dipakai. Menu: **Pengguna Admin**.
- Secret key sesi sekarang otomatis dibuat sekali dan disimpan di file
  `secret_key.txt` (bukan acak tiap restart lagi), supaya sesi login
  tidak ke-logout tiap kali server direstart/lewat tunnel. **Jangan bagikan
  isi file `secret_key.txt` ini ke siapa pun**, dan jangan ikut
  di-commit/upload kalau memakai Git/version control publik.
- Password PPPoE pelanggan saat ini disimpan plain di database — untuk
  produksi pertimbangkan enkripsi kolom tersebut.
- Password Mikrotik API juga disimpan plain di tabel `pengaturan_mikrotik`
  — pertimbangkan enkripsi atau environment variable untuk produksi.
- Kalau memakai Cloudflare Tunnel (lihat bagian 6), HTTPS sudah otomatis
  ditangani Cloudflare — kamu tidak perlu setup sertifikat sendiri.
- Untuk deployment yang lebih permanen (server selalu nyala 24 jam),
  pertimbangkan jalankan lewat Nginx reverse proxy atau VPS, bukan cuma
  laptop/PC pribadi yang bisa mati sewaktu-waktu.
