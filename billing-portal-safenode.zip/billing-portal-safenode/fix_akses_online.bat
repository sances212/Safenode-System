@echo off
setlocal enabledelayedexpansion
title BENTANG RADIUS - Perbaiki Akses Online (Cloudflare Tunnel)
cd /d "%~dp0"

echo ============================================================
echo  BENTANG RADIUS - Perbaiki Akses Online (Error 1033)
echo ============================================================
echo.
echo Script ini otomatis memperbaiki penyebab paling umum Error 1033:
echo  Windows Service "BentangRadiusTunnel" jalan sebagai akun
echo  Local System, yang TIDAK bisa mengakses folder kredensial
echo  cloudflared milik akun Windows kamu sendiri.
echo.
echo Yang akan dilakukan script ini:
echo   1. Cek apakah service BentangRadiusTunnel sudah terpasang
echo   2. Cek folder kredensial cloudflared kamu ^(%%USERPROFILE%%\.cloudflared^)
echo   3. Salin folder itu ke profil Local System
echo   4. Restart service tunnel
echo   5. Tampilkan status akhir
echo.
pause

REM ------------------------------------------------------------
REM  Minta akses Administrator kalau belum
REM ------------------------------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Meminta akses Administrator...
    set "VBS=%temp%\bentang_fixtunnel_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "", "", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)

set "SERVICE_NAME=BentangRadiusTunnel"
set "SRC=%USERPROFILE%\.cloudflared"
set "DST=C:\Windows\System32\config\systemprofile\.cloudflared"

echo.
echo ------------------------------------------------------------
echo  LANGKAH 1/5 - Cek apakah service sudah terpasang
echo ------------------------------------------------------------
sc query %SERVICE_NAME% >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Service "%SERVICE_NAME%" belum terpasang di komputer ini.
    echo Jalankan dulu:
    echo   1^) setup_tunnel_pertama_kali.bat  ^(kalau belum pernah^)
    echo   2^) windows_service\6_install_tunnel_service.bat
    echo Baru jalankan ulang script ini.
    echo.
    pause
    exit /b 1
)
echo OK - service ditemukan.
sc qc %SERVICE_NAME% | findstr /i "SERVICE_START_NAME"

echo.
echo ------------------------------------------------------------
echo  LANGKAH 2/5 - Cek folder kredensial cloudflared kamu
echo ------------------------------------------------------------
if not exist "%SRC%" (
    echo.
    echo [ERROR] Folder %SRC% tidak ditemukan.
    echo Ini berarti kamu belum pernah menjalankan "cloudflared tunnel login"
    echo dengan akun Windows yang sedang kamu pakai sekarang. Jalankan dulu
    echo setup_tunnel_pertama_kali.bat sampai selesai, baru jalankan ulang
    echo script ini.
    echo.
    pause
    exit /b 1
)
echo OK - ditemukan: %SRC%
dir /b "%SRC%"

echo.
echo ------------------------------------------------------------
echo  LANGKAH 3/5 - Menghentikan service dulu sebelum menyalin file
echo ------------------------------------------------------------
net stop %SERVICE_NAME% >nul 2>&1
echo (Kalau sebelumnya sudah berhenti, itu normal.)

echo.
echo ------------------------------------------------------------
echo  LANGKAH 4/5 - Menyalin kredensial ke profil Local System
echo ------------------------------------------------------------
if not exist "C:\Windows\System32\config\systemprofile" (
    echo [ERROR] Folder profil Local System tidak ditemukan/tidak bisa diakses.
    echo Pastikan script ini dijalankan sebagai Administrator.
    pause
    exit /b 1
)
if not exist "%DST%" mkdir "%DST%" >nul 2>&1
xcopy "%SRC%\*" "%DST%\" /E /I /Y /Q
if errorlevel 1 (
    echo.
    echo [ERROR] Gagal menyalin file. Pastikan jendela ini benar-benar
    echo berjalan sebagai Administrator ^(judul jendela biasanya diawali
    echo "Administrator:"^).
    pause
    exit /b 1
)
echo OK - kredensial berhasil disalin ke:
echo %DST%

echo.
echo ------------------------------------------------------------
echo  LANGKAH 5/5 - Menyalakan ulang service tunnel
echo ------------------------------------------------------------
net start %SERVICE_NAME%
if errorlevel 1 (
    echo.
    echo [PERINGATAN] Service belum mau menyala. Cek isi file berikut untuk
    echo pesan error detail:
    echo   windows_service\tunnel_service_error.log
    echo   windows_service\tunnel_service.log
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  SELESAI!
echo ============================================================
echo.
echo Status service sekarang:
sc query %SERVICE_NAME% | findstr /i "STATE"
echo.
echo Tunggu 10-20 detik, lalu buka https://sysai.my.id di browser
echo ^(sebaiknya dari HP pakai kuota data, bukan WiFi yang sama^) untuk
echo memastikan sudah bisa diakses. Kalau masih Error 1033, kirim isi
echo file tunnel_service_error.log dan tunnel_service.log di folder
echo windows_service untuk dicek lebih lanjut.
echo.
pause
