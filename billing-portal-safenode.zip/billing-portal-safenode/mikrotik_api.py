"""
mikrotik_api.py
Klien RouterOS API sederhana (pure Python, tanpa library eksternal)
untuk komunikasi ke Mikrotik: login, kirim perintah, kelola PPPoE Secret.

Kompatibel dengan RouterOS API port 8728 (non-SSL).
Referensi protokol: dokumentasi resmi Mikrotik "API".
"""

import socket
import binascii


class RouterOSError(Exception):
    pass


class RouterOSAPI:
    def __init__(self, host, username, password, port=8728, timeout=6):
        self.host = host
        self.port = int(port)
        self.username = username
        self.password = password
        self.timeout = timeout
        self.sock = None

    # ---------- low level ----------
    def connect(self):
        try:
            self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        except Exception as e:
            raise RouterOSError(f"Tidak bisa konek ke {self.host}:{self.port} -> {e}")
        self._login()

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None

    def _write_len(self, length):
        if length < 0x80:
            self.sock.send(bytes([length]))
        elif length < 0x4000:
            length |= 0x8000
            self.sock.send(bytes([(length >> 8) & 0xFF, length & 0xFF]))
        elif length < 0x200000:
            length |= 0xC00000
            self.sock.send(bytes([(length >> 16) & 0xFF, (length >> 8) & 0xFF, length & 0xFF]))
        elif length < 0x10000000:
            length |= 0xE0000000
            self.sock.send(bytes([(length >> 24) & 0xFF, (length >> 16) & 0xFF,
                                   (length >> 8) & 0xFF, length & 0xFF]))
        else:
            self.sock.send(bytes([0xF0, (length >> 24) & 0xFF, (length >> 16) & 0xFF,
                                   (length >> 8) & 0xFF, length & 0xFF]))

    def _write_word(self, word):
        data = word.encode("utf-8")
        self._write_len(len(data))
        self.sock.send(data)

    def _write_sentence(self, words):
        for w in words:
            self._write_word(w)
        self._write_word("")  # end of sentence

    def _read_len(self):
        c = self.sock.recv(1)
        if not c:
            raise RouterOSError("Koneksi ke Mikrotik terputus")
        c0 = c[0]
        if (c0 & 0x80) == 0x00:
            return c0
        elif (c0 & 0xC0) == 0x80:
            c1 = self.sock.recv(1)[0]
            return ((c0 & ~0xC0) << 8) + c1
        elif (c0 & 0xE0) == 0xC0:
            c1, c2 = self.sock.recv(2)
            return ((c0 & ~0xE0) << 16) + (c1 << 8) + c2
        elif (c0 & 0xF0) == 0xE0:
            c1, c2, c3 = self.sock.recv(3)
            return ((c0 & ~0xF0) << 24) + (c1 << 16) + (c2 << 8) + c3
        else:
            c1, c2, c3, c4 = self.sock.recv(4)
            return (c1 << 24) + (c2 << 16) + (c3 << 8) + c4

    def _read_word(self):
        length = self._read_len()
        data = b""
        while len(data) < length:
            chunk = self.sock.recv(length - len(data))
            if not chunk:
                break
            data += chunk
        return data.decode("utf-8", errors="replace")

    def _read_sentence(self):
        sentence = []
        while True:
            word = self._read_word()
            if word == "":
                break
            sentence.append(word)
        return sentence

    def talk(self, words):
        """Kirim perintah, kembalikan list of dict hasil !re, raise jika !trap"""
        self._write_sentence(words)
        results = []
        while True:
            sentence = self._read_sentence()
            if not sentence:
                continue
            reply_type = sentence[0]
            attrs = {}
            for w in sentence[1:]:
                if w.startswith("="):
                    parts = w[1:].split("=", 1)
                    if len(parts) == 2:
                        attrs[parts[0]] = parts[1]
                    else:
                        attrs[parts[0]] = ""
            if reply_type == "!done":
                break
            elif reply_type == "!trap":
                raise RouterOSError(attrs.get("message", "Perintah Mikrotik gagal (!trap)"))
            elif reply_type == "!re":
                results.append(attrs)
        return results

    # ---------- login ----------
    def _login(self):
        # RouterOS >= 6.43 mendukung login plain (user, password) langsung
        try:
            res = self.talk(["/login", f"=name={self.username}", f"=password={self.password}"])
        except RouterOSError:
            raise
        if res and "ret" in res[0]:
            # metode lama (challenge-response, RouterOS lama)
            challenge = binascii.unhexlify(res[0]["ret"])
            import hashlib
            md = hashlib.md5()
            md.update(b"\x00")
            md.update(self.password.encode("utf-8"))
            md.update(challenge)
            self.talk(["/login", f"=name={self.username}",
                       f"=response=00{md.hexdigest()}"])
        # jika tidak ada 'ret', berarti sudah berhasil login langsung

    # ---------- helper tingkat tinggi ----------
    def test_connection(self):
        self.connect()
        identity = self.talk(["/system/identity/print"])
        self.close()
        return identity[0].get("name", "Mikrotik") if identity else "Mikrotik"

    def get_ppp_secrets(self):
        self.connect()
        data = self.talk(["/ppp/secret/print"])
        self.close()
        return data

    def find_secret_id(self, name):
        self.connect()
        data = self.talk(["/ppp/secret/print", f"?name={name}"])
        self.close()
        if data:
            return data[0].get(".id")
        return None

    def get_secret(self, name):
        """Ambil detail satu PPP Secret (username, password, profile, service,
        disabled, comment) berdasarkan nama -- dipakai fitur "Secret" di menu
        Pelanggan untuk lihat kredensial PPPoE langsung dari Mikrotik."""
        self.connect()
        data = self.talk(["/ppp/secret/print", f"?name={name}"])
        self.close()
        return data[0] if data else None

    def add_or_update_secret(self, name, password, profile, service="pppoe", comment=""):
        """Buat PPPoE secret baru, atau update jika sudah ada (sinkron dari billing)."""
        self.connect()
        existing = self.talk(["/ppp/secret/print", f"?name={name}"])
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ppp/secret/set", f"=.id={sid}",
                       f"=password={password}", f"=profile={profile}",
                       f"=service={service}", f"=comment={comment}"])
        else:
            self.talk(["/ppp/secret/add", f"=name={name}", f"=password={password}",
                       f"=profile={profile}", f"=service={service}", f"=comment={comment}"])
        self.close()

    def set_secret_disabled(self, name, disabled=True):
        """Aktifkan/nonaktifkan (isolir) pelanggan di Mikrotik."""
        self.connect()
        existing = self.talk(["/ppp/secret/print", f"?name={name}"])
        if not existing:
            self.close()
            raise RouterOSError(f"Secret '{name}' tidak ditemukan di Mikrotik")
        sid = existing[0][".id"]
        self.talk(["/ppp/secret/set", f"=.id={sid}", f"=disabled={'yes' if disabled else 'no'}"])
        self.close()

    def remove_secret(self, name):
        self.connect()
        existing = self.talk(["/ppp/secret/print", f"?name={name}"])
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ppp/secret/remove", f"=.id={sid}"])
        self.close()

    def get_ppp_profiles(self):
        """Ambil daftar PPP Profile (PPPoE) beserta detailnya dari Mikrotik
        (PPP > Profiles). Dipakai untuk fitur kelola Profil PPPoE di billing."""
        self.connect()
        data = self.talk(["/ppp/profile/print"])
        self.close()
        return data

    def add_or_update_ppp_profile(self, name, local_address="", remote_address="",
                                   rate_limit="", only_one="", parent_queue=""):
        """Buat PPP Profile baru, atau update kalau nama sudah ada (dikenali dari
        nama profile, sama seperti sinkronisasi PPPoE Secret)."""
        self.connect()
        existing = self.talk(["/ppp/profile/print", f"?name={name}"])
        args = [f"=name={name}"]
        if local_address:
            args.append(f"=local-address={local_address}")
        if remote_address:
            args.append(f"=remote-address={remote_address}")
        if rate_limit:
            args.append(f"=rate-limit={rate_limit}")
        if only_one:
            args.append(f"=only-one={only_one}")
        if parent_queue:
            args.append(f"=parent-queue={parent_queue}")
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ppp/profile/set", f"=.id={sid}"] + args)
        else:
            self.talk(["/ppp/profile/add"] + args)
        self.close()

    def remove_ppp_profile(self, name):
        """Hapus PPP Profile dari Mikrotik berdasarkan nama."""
        self.connect()
        existing = self.talk(["/ppp/profile/print", f"?name={name}"])
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ppp/profile/remove", f"=.id={sid}"])
        self.close()

    def get_active_connections(self):
        self.connect()
        data = self.talk(["/ppp/active/print"])
        self.close()
        return data

    def get_active_connection_by_username(self, username):
        """Cari 1 sesi PPPoE aktif berdasarkan username, kembalikan None kalau sedang offline."""
        self.connect()
        data = self.talk(["/ppp/active/print", f"?name={username}"])
        self.close()
        return data[0] if data else None

    def kick_ppp_active(self, session_id):
        """Putuskan 1 sesi PPPoE yang sedang aktif berdasarkan .id dari get_active_connections()."""
        self.connect()
        self.talk(["/ppp/active/remove", f"=.id={session_id}"])
        self.close()

    def get_interface_traffic(self, interface_name):
        """Ambil traffic RX/TX sesaat (real-time, sekali ambil) dari sebuah interface,
        misalnya interface PPPoE dinamis milik pelanggan: '<pppoe-USERNAME>'.
        Setara perintah terminal: /interface monitor-traffic <interface> once
        Mengembalikan dict berisi rx-bits-per-second, tx-bits-per-second, dkk (masih string)."""
        self.connect()
        data = self.talk(["/interface/monitor-traffic", f"=interface={interface_name}", "=once="])
        self.close()
        if not data:
            raise RouterOSError(f"Interface '{interface_name}' tidak ditemukan / tidak aktif di Mikrotik")
        return data[0]

    def get_bulk_pppoe_traffic(self, usernames):
        """Ambil traffic RX/TX sesaat untuk BANYAK interface PPPoE sekaligus,
        dalam satu koneksi saja (supaya tidak login berkali-kali ke Mikrotik
        kalau jumlah client yang dicek banyak, misal untuk ringkasan trafik Dashboard).
        Kembalikan dict {username: {"rx_bps": int, "tx_bps": int}}.
        Username yang interface-nya tidak ditemukan/tidak aktif dilewati saja."""
        hasil = {}
        if not usernames:
            return hasil
        self.connect()
        try:
            for username in usernames:
                interface_name = f"<pppoe-{username}>"
                try:
                    data = self.talk(["/interface/monitor-traffic", f"=interface={interface_name}", "=once="])
                except Exception:
                    continue
                if not data:
                    continue
                rx = int(data[0].get("rx-bits-per-second", 0) or 0)
                tx = int(data[0].get("tx-bits-per-second", 0) or 0)
                hasil[username] = {"rx_bps": rx, "tx_bps": tx}
        finally:
            self.close()
        return hasil

    def get_system_resource(self):
        """Ambil info resource router: uptime, versi, CPU load, RAM, dan HDD/storage."""
        self.connect()
        data = self.talk(["/system/resource/print"])
        self.close()
        return data[0] if data else {}

    # ---------- Hotspot ----------
    def get_hotspot_profiles(self):
        self.connect()
        data = self.talk(["/ip/hotspot/user/profile/print"])
        self.close()
        return data

    def get_hotspot_users(self):
        self.connect()
        data = self.talk(["/ip/hotspot/user/print"])
        self.close()
        return data

    def add_hotspot_user(self, username, password, profile, limit_uptime="", comment=""):
        self.connect()
        existing = self.talk(["/ip/hotspot/user/print", f"?name={username}"])
        args = [f"=name={username}", f"=password={password}", f"=profile={profile}", f"=comment={comment}"]
        if limit_uptime:
            args.append(f"=limit-uptime={limit_uptime}")
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ip/hotspot/user/set", f"=.id={sid}"] + args)
        else:
            self.talk(["/ip/hotspot/user/add"] + args)
        self.close()

    def remove_hotspot_user(self, username):
        self.connect()
        existing = self.talk(["/ip/hotspot/user/print", f"?name={username}"])
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ip/hotspot/user/remove", f"=.id={sid}"])
        self.close()

    def set_hotspot_user_disabled(self, username, disabled=True):
        """Aktifkan/nonaktifkan akun user hotspot (voucher) di Mikrotik.
        Kalau dinonaktifkan, user itu tidak akan bisa login hotspot lagi
        (sesi yang sedang berjalan tetap aktif sampai diputus/expired)."""
        self.connect()
        existing = self.talk(["/ip/hotspot/user/print", f"?name={username}"])
        if not existing:
            self.close()
            raise RouterOSError(f"User hotspot '{username}' tidak ditemukan di Mikrotik")
        sid = existing[0][".id"]
        self.talk(["/ip/hotspot/user/set", f"=.id={sid}", f"=disabled={'yes' if disabled else 'no'}"])
        self.close()

    def reset_hotspot_user_counters(self, username):
        """Reset counter (uptime, bytes-in/out) user hotspot di Mikrotik -- dipakai
        tombol MENU > Reset Counter di toolbar Voucher Terjual, mis. kalau mau kasih
        kuota/waktu tambahan ke voucher yang sama tanpa bikin user baru."""
        self.connect()
        existing = self.talk(["/ip/hotspot/user/print", f"?name={username}"])
        if not existing:
            self.close()
            raise RouterOSError(f"User hotspot '{username}' tidak ditemukan di Mikrotik")
        sid = existing[0][".id"]
        self.talk(["/ip/hotspot/user/reset-counters", f"=.id={sid}"])
        self.close()

    def get_hotspot_active(self):
        self.connect()
        data = self.talk(["/ip/hotspot/active/print"])
        self.close()
        return data

    def get_hotspot_servers(self):
        self.connect()
        data = self.talk(["/ip/hotspot/print"])
        self.close()
        return data

    def add_or_update_hotspot_profile(self, name, rate_limit="", shared_users="1",
                                       session_timeout="", idle_timeout=""):
        self.connect()
        existing = self.talk(["/ip/hotspot/user/profile/print", f"?name={name}"])
        args = [f"=name={name}", f"=shared-users={shared_users or '1'}"]
        if rate_limit:
            args.append(f"=rate-limit={rate_limit}")
        if session_timeout:
            args.append(f"=session-timeout={session_timeout}")
        if idle_timeout:
            args.append(f"=idle-timeout={idle_timeout}")
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ip/hotspot/user/profile/set", f"=.id={sid}"] + args)
        else:
            self.talk(["/ip/hotspot/user/profile/add"] + args)
        self.close()

    def remove_hotspot_profile(self, name):
        self.connect()
        existing = self.talk(["/ip/hotspot/user/profile/print", f"?name={name}"])
        if existing:
            sid = existing[0][".id"]
            self.talk(["/ip/hotspot/user/profile/remove", f"=.id={sid}"])
        self.close()

    def kick_hotspot_active(self, session_id):
        """Putuskan sesi aktif hotspot berdasarkan .id dari get_hotspot_active()."""
        self.connect()
        self.talk(["/ip/hotspot/active/remove", f"=.id={session_id}"])
        self.close()

    # ---------- Simple Queue ----------
    def get_simple_queues(self):
        """Ambil semua Simple Queue (Queue > Simple Queues) dari Mikrotik."""
        self.connect()
        data = self.talk(["/queue/simple/print"])
        self.close()
        return data

    def add_or_update_simple_queue(self, name, target, max_limit="", burst_limit="",
                                    burst_threshold="", burst_time="", limit_at="",
                                    priority="", queue_type="", comment=""):
        """Buat Simple Queue baru, atau update kalau nama sudah ada (dikenali dari nama,
        sama seperti sinkronisasi PPPoE Secret / PPP Profile)."""
        self.connect()
        existing = self.talk(["/queue/simple/print", f"?name={name}"])
        args = [f"=name={name}"]
        if target:
            args.append(f"=target={target}")
        if max_limit:
            args.append(f"=max-limit={max_limit}")
        else:
            args.append("=max-limit=0/0")
        if burst_limit:
            args.append(f"=burst-limit={burst_limit}")
        if burst_threshold:
            args.append(f"=burst-threshold={burst_threshold}")
        if burst_time:
            args.append(f"=burst-time={burst_time}")
        if limit_at:
            args.append(f"=limit-at={limit_at}")
        if priority:
            args.append(f"=priority={priority}")
        if queue_type:
            args.append(f"=queue={queue_type}")
        args.append(f"=comment={comment}")
        if existing:
            sid = existing[0][".id"]
            self.talk(["/queue/simple/set", f"=.id={sid}"] + args)
        else:
            self.talk(["/queue/simple/add"] + args)
        self.close()

    def remove_simple_queue(self, name):
        """Hapus Simple Queue dari Mikrotik berdasarkan nama."""
        self.connect()
        existing = self.talk(["/queue/simple/print", f"?name={name}"])
        if existing:
            sid = existing[0][".id"]
            self.talk(["/queue/simple/remove", f"=.id={sid}"])
        self.close()

    def set_simple_queue_disabled(self, name, disabled=True):
        """Aktifkan/nonaktifkan Simple Queue di Mikrotik."""
        self.connect()
        existing = self.talk(["/queue/simple/print", f"?name={name}"])
        if not existing:
            self.close()
            raise RouterOSError(f"Simple Queue '{name}' tidak ditemukan di Mikrotik")
        sid = existing[0][".id"]
        self.talk(["/queue/simple/set", f"=.id={sid}", f"=disabled={'yes' if disabled else 'no'}"])
        self.close()
