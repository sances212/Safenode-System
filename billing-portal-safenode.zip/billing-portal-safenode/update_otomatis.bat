@echo off
setlocal EnableDelayedExpansion
title SafeNode - Update Otomatis
REM ============================================================
REM  UPDATE OTOMATIS SafeNode Billing
REM  Cara pakai:
REM    1. Download zip update terbaru dari chat Claude (di server,
REM       lewat browser yang dibuka via AnyDesk).
REM    2. Taruh file zip itu di folder yang sama dengan script ini,
REM       ATAU seret file zip-nya lalu drop ke atas update_otomatis.bat.
REM    3. Klik 2x update_otomatis.bat (kalau muncul minta izin
REM       Administrator, klik Yes).
REM  Script ini otomatis: stop service -> backup data lama (database,
REM  secret_key, uploads) -> timpa kode baru -> nyalakan lagi service.
REM  Data pelanggan (billing.db) TIDAK ikut ketimpa/hilang.
REM ============================================================

REM --- minta akses Administrator (dibutuhkan buat stop/start service) ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Meminta akses Administrator...
    set "VBS=%temp%\safenode_getadmin_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "%~1", "%~dp0", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)

set "FOLDER_APLIKASI=%~dp0"
cd /d "%FOLDER_APLIKASI%"

REM --- cari file zip: dari argumen (drag-drop) atau file zip terbaru di folder ini ---
set "ZIPFILE=%~1"
if "%ZIPFILE%"=="" (
    for /f "delims=" %%f in ('dir /b /o-d "%FOLDER_APLIKASI%*.zip" 2^>nul') do (
        set "ZIPFILE=%FOLDER_APLIKASI%%%f"
        goto :zip_ketemu
    )
)
:zip_ketemu
if "%ZIPFILE%"=="" (
    echo [ERROR] Tidak ada file .zip ditemukan di folder ini.
    echo Taruh dulu file zip update dari Claude di folder yang sama dengan script ini,
    echo lalu jalankan lagi.
    pause
    exit /b 1
)
echo File update yang dipakai: %ZIPFILE%
echo.

set "STAMP=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%"
set "STAMP=%STAMP: =0%"
set "FOLDER_BACKUP=%FOLDER_APLIKASI%backup_update_%STAMP%"
set "FOLDER_EXTRACT=%temp%\safenode_update_%STAMP%"

echo ============================================================
echo  1/5  Menghentikan service...
echo ============================================================
net stop BentangRadiusBilling >nul 2>&1
timeout /t 2 /nobreak >nul

echo ============================================================
echo  2/5  Backup data lama ke: %FOLDER_BACKUP%
echo ============================================================
mkdir "%FOLDER_BACKUP%" >nul 2>&1
if exist "%FOLDER_APLIKASI%billing.db" copy /y "%FOLDER_APLIKASI%billing.db" "%FOLDER_BACKUP%\" >nul
if exist "%FOLDER_APLIKASI%secret_key.txt" copy /y "%FOLDER_APLIKASI%secret_key.txt" "%FOLDER_BACKUP%\" >nul
if exist "%FOLDER_APLIKASI%static\uploads" xcopy /e /i /y "%FOLDER_APLIKASI%static\uploads" "%FOLDER_BACKUP%\uploads\" >nul

echo ============================================================
echo  3/5  Mengekstrak file update...
echo ============================================================
powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIPFILE%' -DestinationPath '%FOLDER_EXTRACT%' -Force"

REM cari folder hasil extract (nama foldernya bisa beda-beda tiap versi zip)
set "SUMBER="
for /d %%d in ("%FOLDER_EXTRACT%\*") do set "SUMBER=%%d"
if "%SUMBER%"=="" set "SUMBER=%FOLDER_EXTRACT%"

echo ============================================================
echo  4/5  Menimpa kode aplikasi (data pelanggan TIDAK disentuh)...
echo ============================================================
REM /XF & /XD: file/folder yang dikecualikan supaya data lama server tetap aman
robocopy "%SUMBER%" "%FOLDER_APLIKASI%" /E /IS /IT ^
    /XF billing.db secret_key.txt *.db ^
    /XD "static\uploads" "backup_update_*" ".git" >nul

REM kembalikan data lama kalau somehow ikut ketimpa (jaga-jaga)
if exist "%FOLDER_BACKUP%\billing.db" copy /y "%FOLDER_BACKUP%\billing.db" "%FOLDER_APLIKASI%billing.db" >nul
if exist "%FOLDER_BACKUP%\secret_key.txt" copy /y "%FOLDER_BACKUP%\secret_key.txt" "%FOLDER_APLIKASI%secret_key.txt" >nul

echo ============================================================
echo  5/5  Menyalakan service lagi...
echo ============================================================
net start BentangRadiusBilling

echo.
echo ============================================================
echo  SELESAI. Cek di browser: http://103.54.171.27:8080/data-customer
echo  Kalau ada masalah, data lama sudah diamankan di folder:
echo  %FOLDER_BACKUP%
echo ============================================================
pause
