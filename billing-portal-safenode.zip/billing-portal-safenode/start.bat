@echo off
title BENTANG RADIUS - Web Portal Billing Internet
echo ============================================================
echo  BENTANG RADIUS - Menyiapkan server...
echo ============================================================

where python >nul 2>nul
if not errorlevel 1 goto :python_ada

echo.
echo [ERROR] Python tidak ditemukan di komputer ini.
echo Silakan install Python dulu dari https://www.python.org/downloads/
echo PENTING: saat instalasi, centang "Add Python to PATH".
echo.
pause
exit /b 1

:python_ada
echo.
echo Menginstall library yang dibutuhkan (Flask, Pillow, waitress)...
python -m pip install -r requirements.txt

echo.
echo ============================================================
echo  Menjalankan server... Jangan tutup jendela ini.
echo  Buka browser lalu akses: http://localhost:80
echo  Mau diakses online dari mana saja? Lihat start_tunnel.bat
echo ============================================================
echo.

python app.py

echo.
echo ============================================================
echo  Server berhenti / terjadi error (lihat pesan di atas).
echo ============================================================
pause
exit /b 0
