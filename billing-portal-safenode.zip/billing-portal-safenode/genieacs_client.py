"""
genieacs_client.py - Klien sederhana untuk GenieACS NBI (Northbound Interface) REST API.

Dipakai untuk fitur "Client Area" pelanggan: baca & ubah SSID/password WiFi (SSID 1-4),
restart ONT, lihat redaman (RX power), uptime, dan daftar device yang terhubung --
semuanya lewat protokol TR-069/CWMP yang dijembatani GenieACS.

Catatan penting: struktur parameter TR-069 BERBEDA-BEDA antar merk ONT (Huawei, ZTE,
Fiberhome, dll). Modul ini memakai path default gaya TR-098 (InternetGatewayDevice.*)
yang paling umum dipakai vendor GPON di Indonesia, tapi path-nya dibuat bisa
dikonfigurasi ulang lewat menu Pengaturan > GenieACS kalau ONT yang dipakai berbeda.

Referensi umum: https://github.com/genieacs/genieacs/wiki/API-Reference
"""

import json
import base64
import time
import mimetypes
import urllib.request
import urllib.parse
import urllib.error

TIMEOUT_DETIK = 15


class GenieACSError(Exception):
    pass


def _headers(cfg, extra=None):
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if cfg.get("username"):
        token = base64.b64encode(f"{cfg['username']}:{cfg.get('password') or ''}".encode()).decode()
        headers["Authorization"] = f"Basic {token}"
    if extra:
        headers.update(extra)
    return headers


def _request_full(cfg, method, path, body=None, query_string="", raw_body=None, extra_headers=None):
    """Sama seperti _request tapi mengembalikan (status, body_teks, headers_response)
    supaya bisa membaca header seperti X-Total-Count untuk pagination."""
    url = f"{cfg['url'].rstrip('/')}{path}"
    if query_string:
        url = f"{url}?{query_string}"
    if raw_body is not None:
        data = raw_body
        headers = _headers(cfg, extra_headers)
        headers.pop("Content-Type", None)
        if extra_headers and "Content-Type" in extra_headers:
            headers["Content-Type"] = extra_headers["Content-Type"]
    else:
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = _headers(cfg, extra_headers)
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_DETIK) as resp:
            mentah = resp.read().decode("utf-8", errors="replace")
            return resp.status, mentah, resp.headers
    except urllib.error.HTTPError as e:
        try:
            mentah = e.read().decode("utf-8", errors="replace")
        except Exception:
            mentah = ""
        raise GenieACSError(f"GenieACS membalas error HTTP {e.code}: {mentah[:200] or e.reason}")
    except urllib.error.URLError as e:
        raise GenieACSError(f"Tidak bisa terhubung ke server GenieACS: {e.reason}")
    except Exception as e:
        raise GenieACSError(f"Gagal menghubungi GenieACS: {e}")


def _request(cfg, method, path, body=None, query_string=""):
    status, mentah, _headers_resp = _request_full(cfg, method, path, body=body, query_string=query_string)
    return status, mentah


def cari_device_by_serial(cfg, serial_number):
    """Cari satu device GenieACS berdasarkan Serial Number ONT. Return dict device
    (JSON mentah dari GenieACS) atau None kalau tidak ketemu."""
    query = json.dumps({"_deviceId._SerialNumber": serial_number})
    qs = urllib.parse.urlencode({"query": query})
    status, mentah = _request(cfg, "GET", "/devices/", query_string=qs)
    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise GenieACSError("Balasan GenieACS tidak valid (bukan JSON).")
    return hasil[0] if hasil else None


def tes_koneksi(cfg):
    """Cek server GenieACS bisa diakses (tidak peduli ada device atau tidak)."""
    _request(cfg, "GET", "/devices/", query_string="limit=1")
    return True


def _ambil_nilai(device, path):
    """Telusuri path bertitik (mis. 'InternetGatewayDevice.DeviceInfo.UpTime') di
    struktur JSON device GenieACS, ambil field '_value'-nya."""
    if not path:
        return None
    node = device
    for bagian in path.split("."):
        if not isinstance(node, dict) or bagian not in node:
            return None
        node = node[bagian]
    if isinstance(node, dict) and "_value" in node:
        return node["_value"]
    return None


def _anak_berindeks(device, path):
    """Untuk path collection (mis. 'InternetGatewayDevice.LANDevice.1.Hosts.Host'),
    ambil dict {index: node} dari anak-anak bernomor di bawahnya."""
    node = device
    for bagian in path.split("."):
        if not isinstance(node, dict) or bagian not in node:
            return {}
        node = node[bagian]
    if not isinstance(node, dict):
        return {}
    return {k: v for k, v in node.items() if isinstance(v, dict) and k.isdigit()}


def ambil_info_ont(cfg, device):
    """Ekstrak info yang dipakai halaman Client Area dari device GenieACS mentah:
    daftar SSID (1-4), redaman RX power, uptime detik, & daftar host yang terhubung."""
    ssid_list = []
    for idx in range(1, 5):
        path_ssid = cfg["path_ssid"].replace("{idx}", str(idx))
        path_enable = cfg["path_ssid_enable"].replace("{idx}", str(idx))
        nama = _ambil_nilai(device, path_ssid)
        aktif = _ambil_nilai(device, path_enable)
        ssid_list.append({
            "index": idx,
            "nama": nama,
            "aktif": bool(aktif) if aktif is not None else None,
        })

    rx_power_raw = _ambil_nilai(device, cfg["path_rx_power"]) if cfg.get("path_rx_power") else None
    rx_power = None
    if rx_power_raw not in (None, ""):
        try:
            rx_power = float(rx_power_raw)
            # sebagian ONT melaporkan dalam satuan 0.1 dBm (mis. -209 = -20.9 dBm)
            if abs(rx_power) > 60:
                rx_power = rx_power / 10
        except (TypeError, ValueError):
            rx_power = None

    uptime_detik = _ambil_nilai(device, cfg["path_uptime"]) if cfg.get("path_uptime") else None
    try:
        uptime_detik = int(uptime_detik) if uptime_detik is not None else None
    except (TypeError, ValueError):
        uptime_detik = None

    hosts = []
    if cfg.get("path_hosts"):
        for _, node in sorted(_anak_berindeks(device, cfg["path_hosts"]).items(), key=lambda x: int(x[0])):
            aktif_host = node.get("Active", {}).get("_value")
            hosts.append({
                "nama": node.get("HostName", {}).get("_value") or None,
                "ip": node.get("IPAddress", {}).get("_value") or None,
                "mac": node.get("MACAddress", {}).get("_value") or None,
                "tipe": node.get("InterfaceType", {}).get("_value") or None,
                "aktif": bool(aktif_host) if aktif_host is not None else True,
            })
        hosts = [h for h in hosts if h["aktif"]]

    return {
        "ssid_list": ssid_list,
        "rx_power": rx_power,
        "uptime_detik": uptime_detik,
        "hosts": hosts,
    }


def _device_id(device):
    return device.get("_id")


def kirim_set_parameter(cfg, device, pasangan_path_nilai):
    """Kirim task setParameterValues ke satu device. pasangan_path_nilai: list of
    (path, value). connection_request supaya GenieACS langsung minta device apply
    (tidak menunggu periodic inform berikutnya)."""
    body = {
        "name": "setParameterValues",
        "parameterValues": [[path, value, "xsd:string"] for path, value in pasangan_path_nilai],
    }
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(_device_id(device), safe='')}/tasks",
             body=body, query_string="connection_request")


def kirim_reboot(cfg, device):
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(_device_id(device), safe='')}/tasks",
             body={"name": "reboot"}, query_string="connection_request")


def kirim_refresh(cfg, device, object_path):
    """Minta GenieACS menarik ulang satu cabang parameter (GetParameterValues) dari
    device saat ini juga, dipakai tombol 'Cek Ulang' di Client Area."""
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(_device_id(device), safe='')}/tasks",
             body={"name": "refreshObject", "objectName": object_path}, query_string="connection_request")


AMBANG_ONLINE_DETIK = 15 * 60  # device dianggap online kalau _lastInform < 15 menit lalu


def _epoch_dari_iso(teks):
    if not teks:
        return None
    try:
        # GenieACS mengirim format ISO 8601 mis. 2026-08-24T09:50:11.123Z
        bersih = teks.replace("Z", "+00:00")
        return datetime_fromisoformat_kompat(bersih)
    except Exception:
        return None


def datetime_fromisoformat_kompat(teks):
    from datetime import datetime
    try:
        return datetime.fromisoformat(teks).timestamp()
    except Exception:
        return None


def ringkas_device(device):
    """Ubah satu device mentah GenieACS jadi dict ringkas siap tampil di tabel Perangkat."""
    from datetime import datetime, timezone

    device_id = device.get("_id")
    deviceid = device.get("_deviceId") or {}
    manufacturer = deviceid.get("_Manufacturer") or _ambil_nilai(device, "DeviceID.Manufacturer") or "-"
    product_class = deviceid.get("_ProductClass") or _ambil_nilai(device, "DeviceID.ProductClass") or "-"
    serial = deviceid.get("_SerialNumber") or _ambil_nilai(device, "DeviceID.SerialNumber") or device_id
    oui = deviceid.get("_OUI") or "-"

    last_inform_raw = device.get("_lastInform")
    online = False
    if last_inform_raw:
        epoch = _epoch_dari_iso(last_inform_raw)
        if epoch is not None:
            online = (time.time() - epoch) < AMBANG_ONLINE_DETIK

    ip_address = (
        _ambil_nilai(device, "InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANIPConnection.1.ExternalIPAddress")
        or _ambil_nilai(device, "InternetGatewayDevice.ManagementServer.ConnectionRequestURL")
        or "-"
    )
    software = (
        _ambil_nilai(device, "InternetGatewayDevice.DeviceInfo.SoftwareVersion")
        or _ambil_nilai(device, "DeviceInfo.SoftwareVersion")
        or "-"
    )

    return {
        "id": device_id,
        "serial_number": serial,
        "manufacturer": manufacturer,
        "product_class": product_class,
        "oui": oui,
        "status": "online" if online else "offline",
        "last_inform": last_inform_raw,
        "ip_address": ip_address,
        "software": software,
    }


def daftar_device(cfg, q=None, status=None, manufacturer=None, limit=20, skip=0):
    """Ambil daftar device dari GenieACS dengan filter opsional pencarian (serial/ID),
    status (online/offline dihitung dari _lastInform), dan manufacturer.
    Return (daftar_ringkas, total_count)."""
    query = {}
    if q:
        query["$or"] = [
            {"_deviceId._SerialNumber": {"$regex": q, "$options": "i"}},
            {"_id": {"$regex": q, "$options": "i"}},
        ]
    if manufacturer:
        query["_deviceId._Manufacturer"] = manufacturer

    qs_parts = {"limit": str(limit), "skip": str(skip)}
    if query:
        qs_parts["query"] = json.dumps(query)
    qs = urllib.parse.urlencode(qs_parts)

    status_code, mentah, headers = _request_full(cfg, "GET", "/devices/", query_string=qs)
    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise GenieACSError("Balasan GenieACS tidak valid (bukan JSON).")

    ringkas = [ringkas_device(d) for d in hasil]
    if status in ("online", "offline"):
        ringkas = [d for d in ringkas if d["status"] == status]

    total_header = headers.get("X-Total-Count") if headers else None
    try:
        total = int(total_header) if total_header is not None else len(ringkas)
    except (TypeError, ValueError):
        total = len(ringkas)

    return ringkas, total


def hitung_ringkasan_device(cfg):
    """Hitung total/online/offline device (dipakai kartu dashboard)."""
    ringkas, total = daftar_device(cfg, limit=1000, skip=0)
    online = sum(1 for d in ringkas if d["status"] == "online")
    return {"total": total, "online": online, "offline": max(total - online, 0)}


def ambil_device_by_id(cfg, device_id):
    qs = urllib.parse.urlencode({"query": json.dumps({"_id": device_id})})
    _status, mentah = _request(cfg, "GET", "/devices/", query_string=qs)
    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise GenieACSError("Balasan GenieACS tidak valid (bukan JSON).")
    return hasil[0] if hasil else None


def hapus_device(cfg, device_id):
    _request(cfg, "DELETE", f"/devices/{urllib.parse.quote(device_id, safe='')}")


def kirim_reboot_by_id(cfg, device_id):
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(device_id, safe='')}/tasks",
             body={"name": "reboot"}, query_string="connection_request")


def kirim_factory_reset(cfg, device_id):
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(device_id, safe='')}/tasks",
             body={"name": "factoryReset"}, query_string="connection_request")


def kirim_refresh_by_id(cfg, device_id, object_path="InternetGatewayDevice"):
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(device_id, safe='')}/tasks",
             body={"name": "refreshObject", "objectName": object_path}, query_string="connection_request")


def kirim_set_parameter_by_id(cfg, device_id, pasangan_path_nilai):
    body = {
        "name": "setParameterValues",
        "parameterValues": [[path, value, "xsd:string"] for path, value in pasangan_path_nilai],
    }
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(device_id, safe='')}/tasks",
             body=body, query_string="connection_request")


def kirim_download_firmware(cfg, device_id, file_type, file_name, target_filename=""):
    """Kirim task 'download' (dipakai untuk push firmware OTA) ke satu device."""
    body = {
        "name": "download",
        "fileType": file_type or "1 Firmware Upgrade Image",
        "fileName": file_name,
        "targetFileName": target_filename or file_name,
    }
    _request(cfg, "POST", f"/devices/{urllib.parse.quote(device_id, safe='')}/tasks",
             body=body, query_string="connection_request")


# --------------------------- Task Queue (/tasks) ---------------------------

def daftar_tugas(cfg, q=None, limit=20, skip=0):
    """Ambil antrean tugas TR-069 dari GenieACS (collection /tasks).
    Return (daftar_tugas, total_count)."""
    query = {}
    if q:
        query["$or"] = [
            {"device": {"$regex": q, "$options": "i"}},
            {"name": {"$regex": q, "$options": "i"}},
        ]
    qs_parts = {"limit": str(limit), "skip": str(skip), "sort": json.dumps({"_id": -1})}
    if query:
        qs_parts["query"] = json.dumps(query)
    qs = urllib.parse.urlencode(qs_parts)

    _status, mentah, headers = _request_full(cfg, "GET", "/tasks/", query_string=qs)
    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise GenieACSError("Balasan GenieACS tidak valid (bukan JSON) saat mengambil task queue.")

    daftar = []
    for tsk in hasil:
        fault = tsk.get("fault")
        if fault:
            status = "failed"
        elif tsk.get("timestamp"):
            status = "done"
        else:
            status = "pending"
        daftar.append({
            "id": tsk.get("_id"),
            "device": tsk.get("device"),
            "name": tsk.get("name"),
            "status": status,
            "retries": tsk.get("retries", 0),
            "timestamp": tsk.get("timestamp"),
            "fault": fault,
        })

    total_header = headers.get("X-Total-Count") if headers else None
    try:
        total = int(total_header) if total_header is not None else len(daftar)
    except (TypeError, ValueError):
        total = len(daftar)

    return daftar, total


def hitung_ringkasan_tugas(cfg):
    daftar, total = daftar_tugas(cfg, limit=2000, skip=0)
    pending = sum(1 for t in daftar if t["status"] == "pending")
    failed = sum(1 for t in daftar if t["status"] == "failed")
    done = sum(1 for t in daftar if t["status"] == "done")
    return {"total": total, "pending": pending, "running": 0, "done": done, "failed": failed}


def hapus_tugas(cfg, task_id):
    _request(cfg, "DELETE", f"/tasks/{urllib.parse.quote(task_id, safe='')}")


# --------------------------- Files (firmware) ---------------------------

def unggah_firmware_file(cfg, filename, isi_bytes, metadata=None):
    """Unggah satu file firmware ke GenieACS Files API (PUT /files/<filename>).
    metadata (opsional) diisi lewat header X-Metadata (dipakai GenieACS untuk
    mencocokkan otomatis file dengan preset/download task)."""
    extra_headers = {"Content-Type": mimetypes.guess_type(filename)[0] or "application/octet-stream"}
    if metadata:
        extra_headers["metadata"] = json.dumps(metadata)
    _request_full(cfg, "PUT", f"/files/{urllib.parse.quote(filename, safe='')}",
                  raw_body=isi_bytes, extra_headers=extra_headers)


def hapus_firmware_file(cfg, filename):
    _request(cfg, "DELETE", f"/files/{urllib.parse.quote(filename, safe='')}")


def format_uptime_detik(detik):
    """Format 'UpTime' TR-069 (satuan detik langsung, beda dari SNMP timeticks) jadi
    teks singkat ala 'Xd HH:MM:SS' seperti di panel Client Area."""
    if detik is None:
        return None
    try:
        detik = int(detik)
    except (TypeError, ValueError):
        return None
    hari, sisa = divmod(detik, 86400)
    jam, sisa = divmod(sisa, 3600)
    menit, detik_sisa = divmod(sisa, 60)
    if hari:
        return f"{hari}d {jam:02d}:{menit:02d}:{detik_sisa:02d}"
    return f"{jam:02d}:{menit:02d}:{detik_sisa:02d}"
