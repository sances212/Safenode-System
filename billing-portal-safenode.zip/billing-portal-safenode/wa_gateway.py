"""
wa_gateway.py - Klien sederhana untuk WA Gateway Wablas (wablas.com).

Dipakai untuk:
- Mengirim pesan WhatsApp (mis. notifikasi tagihan/reminder ke pelanggan)
- Tes koneksi/autentikasi ke akun Wablas yang dikonfigurasi

Referensi resmi: https://wablas.com/documentation
Ditulis pakai urllib bawaan Python supaya tidak perlu tambahan dependency (requests dll),
mengikuti pola yang sama dengan tripay_gateway.py.

Catatan: Wablas itu multi-server (tiap akun dapat domain server sendiri, mis.
https://sby.wablas.com, https://bcp.wablas.com, dst), jadi domain-nya HARUS
disimpan per-instalasi lewat halaman Pengaturan > WA Gateway, tidak ada default
domain global yang berlaku untuk semua orang.
"""

import json
import urllib.request
import urllib.parse
import urllib.error

TIMEOUT_DETIK = 20


class WablasError(Exception):
    """Dilempar kalau request ke Wablas gagal atau Wablas membalas error."""
    pass


def _bersihkan_domain(domain):
    domain = (domain or "").strip().rstrip("/")
    if domain and not domain.startswith("http://") and not domain.startswith("https://"):
        domain = f"https://{domain}"
    return domain


def _header_otorisasi(cfg):
    """Wablas pakai header Authorization: token (atau token.secret_key kalau
    fitur Secret Key diaktifkan di akun Wablas-nya)."""
    token = (cfg.get("token") or "").strip()
    secret = (cfg.get("secret_key") or "").strip()
    return f"{token}.{secret}" if secret else token


def _request(method, url, cfg, data=None):
    headers = {"Authorization": _header_otorisasi(cfg), "Accept": "application/json"}
    body = None
    if method == "POST":
        body = json.dumps(data or {}).encode("utf-8")
        headers["Content-Type"] = "application/json"
    elif data:
        url = f"{url}?{urllib.parse.urlencode(data)}"

    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_DETIK) as resp:
            mentah = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        try:
            mentah = e.read().decode("utf-8")
        except Exception:
            raise WablasError(f"Gagal menghubungi Wablas (HTTP {e.code}).")
    except urllib.error.URLError as e:
        raise WablasError(f"Tidak bisa terhubung ke server Wablas: {e.reason}")
    except Exception as e:
        raise WablasError(f"Gagal menghubungi Wablas: {e}")

    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise WablasError("Balasan Wablas tidak bisa dibaca (bukan JSON valid). "
                           "Cek lagi domain server Wablas-nya sudah benar.")

    # Wablas membalas "status": true/false di root untuk sebagian besar endpoint
    if isinstance(hasil, dict) and hasil.get("status") is False:
        pesan = hasil.get("message") or "Wablas menolak permintaan tanpa pesan error."
        if isinstance(pesan, list):
            pesan = ", ".join(str(p) for p in pesan)
        raise WablasError(pesan)

    return hasil


def rapikan_nomor_hp(nomor):
    """Wablas minta format 62xxx (tanpa +, tanpa 0 di depan)."""
    nomor = "".join(ch for ch in (nomor or "") if ch.isdigit())
    if nomor.startswith("0"):
        nomor = "62" + nomor[1:]
    elif nomor.startswith("8"):
        nomor = "62" + nomor
    return nomor


def kirim_pesan(cfg, nomor_tujuan, pesan):
    """Kirim satu pesan WhatsApp teks lewat Wablas.
    cfg: dict berisi domain, token, (opsional) secret_key."""
    domain = _bersihkan_domain(cfg.get("domain"))
    if not domain:
        raise WablasError("Domain server Wablas belum diisi.")
    url = f"{domain}/api/send-message"
    payload = {"phone": rapikan_nomor_hp(nomor_tujuan), "message": pesan}
    return _request("POST", url, cfg, payload)


def cek_perangkat(cfg):
    """Tes koneksi/autentikasi: ambil info status device dari Wablas
    (dipakai buat tombol 'Tes Koneksi' di halaman pengaturan)."""
    domain = _bersihkan_domain(cfg.get("domain"))
    if not domain:
        raise WablasError("Domain server Wablas belum diisi.")
    url = f"{domain}/api/device/info"
    return _request("GET", url, cfg)
