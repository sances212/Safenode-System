# Update: Multi-Router & Reseller (POP)

## Yang baru
1. **Multi-router**: Bisa punya banyak router Mikrotik sekaligus lewat menu **Router / POP**
   (admin master) atau **POP** (dashboard reseller). Setiap pelanggan dipasangkan ke satu
   router tertentu, tapi **tagihan tetap satu daftar gabungan** — tinggal difilter per
   router/reseller kalau perlu.
2. **Akun Reseller sungguhan**: reseller sekarang bisa login sendiri di `/reseller/login`
   dan punya dashboard sendiri (Router/POP miliknya, Pelanggan miliknya, Tagihan miliknya).
   Beda dari menu "Pendaftaran Reseller" lama yang cuma form lead — sekarang begitu status
   diubah jadi "Berlangganan", akun login-nya beneran dibuat otomatis.
3. **Admin master** bisa melihat & mengelola semua reseller (menu **Reseller**), dan bisa
   membuka daftar pelanggan siapa saja termasuk milik reseller manapun (tombol
   "Lihat Pelanggan" di halaman Reseller, atau filter di halaman Pelanggan).

## Migrasi data lama
Otomatis jalan begitu aplikasi pertama kali dijalankan setelah update:
- Pengaturan Mikrotik lama (single router) dipindah jadi "Router Utama" (id=1).
- Semua pelanggan lama otomatis ditempelkan ke Router Utama. Tidak ada data yang hilang
  atau perlu diisi ulang manual.

## Yang perlu diperhatikan / batasan saat ini
- **Perkakas umum** yang sifatnya per-router tapi bukan per-pelanggan (menu Hotspot/Voucher,
  daftar PPP Profile, ringkasan traffic di Dashboard) masih mengikuti satu "router aktif"
  yang dipilih lewat tombol **Jadikan Aktif** di halaman Router. Belum otomatis
  berpindah-pindah per pelanggan seperti fitur Sync/Isolir/Monitor Traffic pelanggan
  (yang sudah otomatis pakai router masing-masing pelanggan).
- **Paket Internet** masih satu daftar bersama untuk semua router/reseller (belum bisa
  reseller punya harga/paket sendiri-sendiri). Kalau ini dibutuhkan, perlu iterasi lanjutan.
- Fitur "lihat traffic dari peta" (`peta.html`) belum ikut disambungkan ke router
  per-pelanggan seperti di halaman Pelanggan.

## File yang berubah/ditambah
- `app.py` — skema DB baru (`router`, `reseller`), route baru untuk reseller & manajemen
  router/reseller, penyesuaian fungsi sync/isolir/traffic per-pelanggan.
- `templates/pelanggan.html`, `templates/base.html` — filter & kolom router/reseller.
- `templates/pengaturan_mikrotik.html` — kini khusus mengedit Router Utama (id=1).
- **Baru**: `templates/router_admin.html`, `templates/reseller_admin.html`,
  `templates/reseller_base.html`, `templates/reseller_login.html`,
  `templates/reseller_dashboard.html`, `templates/reseller_pop.html`,
  `templates/reseller_pelanggan.html`, `templates/reseller_tagihan.html`.

## Cara pakai singkat
1. Jalankan aplikasi seperti biasa (`start.bat` / `start.sh`) — migrasi jalan otomatis.
2. Untuk tambah router kedua dst milik Anda sendiri: menu **Router / POP** → Tambah Router.
3. Untuk kasih akses reseller: menu **Reseller** → Tambah Reseller (atau setujui lewat
   Pendaftaran Reseller) → reseller login sendiri di `/reseller/login` → reseller tambah
   POP-nya sendiri → baru bisa tambah pelanggan.
