#!/bin/bash
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "============================================================"
echo " BENTANG RADIUS - Setup Akses Online Permanen (Named Tunnel)"
echo "============================================================"
echo ""
echo "Script ini HANYA perlu dijalankan SATU KALI. Setelah ini, link"
echo "online kamu akan TETAP SAMA selamanya (tidak acak/berubah-ubah"
echo "seperti punya start_tunnel.sh yang lama)."
echo ""
echo "SYARAT sebelum lanjut:"
echo "  1. Kamu punya domain sendiri (mis. msradius2.com) yang sudah"
echo "     terdaftar di akun Cloudflare kamu (gratis, tinggal daftar"
echo "     di https://dash.cloudflare.com kalau belum, lalu arahkan"
echo "     nameserver domainnya ke Cloudflare)."
echo "  2. cloudflared sudah terinstall di komputer ini."
echo ""
read -p "Tekan ENTER untuk lanjut..."

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLOUDFLARED=""
if command -v cloudflared &> /dev/null; then
    CLOUDFLARED="cloudflared"
elif [ -x "$DIR/cloudflared" ]; then
    CLOUDFLARED="$DIR/cloudflared"
fi

if [ -z "$CLOUDFLARED" ]; then
    echo ""
    echo "[ERROR] cloudflared belum ditemukan di komputer ini."
    echo "  Mac (Homebrew): brew install cloudflared"
    echo "  Linux: lihat https://pkg.cloudflare.com/index.html"
    read -p "Tekan ENTER untuk keluar..."
    exit 1
fi

echo ""
echo "------------------------------------------------------------"
echo " LANGKAH 1/4 - Login ke akun Cloudflare kamu"
echo "------------------------------------------------------------"
echo "Browser akan terbuka. Login, lalu PILIH domain yang mau dipakai"
echo "(mis. msradius2.com). Kalau sudah selesai di browser, kembali"
echo "ke terminal ini."
read -p "Tekan ENTER untuk lanjut..."
"$CLOUDFLARED" tunnel login
if [ $? -ne 0 ]; then
    echo "[ERROR] Login gagal/dibatalkan. Jalankan ulang script ini."
    exit 1
fi

echo ""
read -p "Masukkan subdomain lengkap yang mau dipakai (contoh: billing.msradius2.com): " HOSTNAME
if [ -z "$HOSTNAME" ]; then
    echo "[ERROR] Subdomain tidak boleh kosong."
    exit 1
fi

NAMA_TUNNEL="bentangradius-billing"

echo ""
echo "------------------------------------------------------------"
echo " LANGKAH 2/4 - Membuat tunnel \"$NAMA_TUNNEL\""
echo "------------------------------------------------------------"
"$CLOUDFLARED" tunnel create "$NAMA_TUNNEL"
echo "(Kalau muncul pesan \"tunnel already exists\", tidak apa-apa --"
echo " berarti tunnel dari percobaan setup sebelumnya masih ada.)"

echo ""
echo "------------------------------------------------------------"
echo " LANGKAH 3/4 - Menghubungkan $HOSTNAME ke tunnel ini"
echo "------------------------------------------------------------"
"$CLOUDFLARED" tunnel route dns "$NAMA_TUNNEL" "$HOSTNAME"
if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] Gagal menghubungkan domain. Pastikan domain $HOSTNAME"
    echo "memang ada di akun Cloudflare yang tadi kamu login."
    exit 1
fi

echo ""
echo "------------------------------------------------------------"
echo " LANGKAH 4/4 - Menyimpan pengaturan"
echo "------------------------------------------------------------"
cat > "$DIR/tunnel_info.txt" <<EOF
HOSTNAME=$HOSTNAME
TUNNEL_NAME=$NAMA_TUNNEL
EOF
echo "Tersimpan di tunnel_info.txt"

echo ""
echo "============================================================"
echo " SELESAI! Link online tetap kamu:"
echo " https://$HOSTNAME"
echo ""
echo " Link ini TIDAK AKAN BERUBAH lagi mulai sekarang."
echo " Jalankan lewat start_tunnel.sh (atau Service Controller kalau"
echo " ada) untuk menyalakannya."
echo "============================================================"
