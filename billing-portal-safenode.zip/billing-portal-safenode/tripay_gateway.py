"""
tripay_gateway.py - Klien sederhana untuk payment gateway Tripay (tripay.co.id).

Dipakai untuk:
- Mengambil daftar channel/metode pembayaran yang aktif di akun merchant
- Membuat transaksi pembayaran (closed payment) untuk satu tagihan
- Mengecek status transaksi secara manual (polling)
- Memverifikasi signature callback/webhook yang dikirim Tripay

Referensi resmi: https://tripay.co.id/developer
Ditulis pakai urllib bawaan Python supaya tidak perlu tambahan dependency (requests dll).
"""

import hmac
import hashlib
import json
import urllib.request
import urllib.parse
import urllib.error

BASE_URL_PRODUCTION = "https://tripay.co.id/api"
BASE_URL_SANDBOX = "https://tripay.co.id/api-sandbox"

TIMEOUT_DETIK = 20


class TripayError(Exception):
    """Dilempar kalau request ke Tripay gagal atau Tripay membalas error."""
    pass


def _base_url(mode):
    return BASE_URL_SANDBOX if (mode or "").lower() == "sandbox" else BASE_URL_PRODUCTION


def _flatten_untuk_urlencode(data, prefix=""):
    """Ubah dict/list bersarang (mis. order_items) jadi pasangan key-value ala
    http_build_query PHP, supaya bisa dikirim sebagai application/x-www-form-urlencoded
    persis seperti contoh resmi Tripay (mis. order_items[0][sku]=..., dst)."""
    hasil = []
    if isinstance(data, dict):
        for k, v in data.items():
            key_baru = f"{prefix}[{k}]" if prefix else str(k)
            hasil.extend(_flatten_untuk_urlencode(v, key_baru))
    elif isinstance(data, (list, tuple)):
        for i, v in enumerate(data):
            key_baru = f"{prefix}[{i}]"
            hasil.extend(_flatten_untuk_urlencode(v, key_baru))
    else:
        if data is not None:
            hasil.append((prefix, data))
    return hasil


def _request(method, url, api_key, data=None):
    headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    body = None
    if method == "POST":
        pasangan = _flatten_untuk_urlencode(data or {})
        body = urllib.parse.urlencode(pasangan).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif data:
        url = f"{url}?{urllib.parse.urlencode(data)}"

    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_DETIK) as resp:
            mentah = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        # Tripay tetap membalas body JSON meski status HTTP-nya error (mis. 422/401)
        try:
            mentah = e.read().decode("utf-8")
        except Exception:
            raise TripayError(f"Gagal menghubungi Tripay (HTTP {e.code}).")
    except urllib.error.URLError as e:
        raise TripayError(f"Tidak bisa terhubung ke server Tripay: {e.reason}")
    except Exception as e:
        raise TripayError(f"Gagal menghubungi Tripay: {e}")

    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise TripayError("Balasan Tripay tidak bisa dibaca (bukan JSON valid).")

    if not hasil.get("success", False):
        pesan = hasil.get("message") or "Tripay menolak permintaan tanpa pesan error."
        raise TripayError(pesan)

    return hasil.get("data")


def buat_signature_transaksi(private_key, merchant_code, merchant_ref, amount):
    """Signature untuk endpoint transaction/create (closed payment)."""
    teks = f"{merchant_code}{merchant_ref}{amount}"
    return hmac.new(private_key.encode("utf-8"), teks.encode("utf-8"), hashlib.sha256).hexdigest()


def ambil_channel_pembayaran(cfg):
    """Ambil daftar metode pembayaran yang aktif di akun merchant.
    cfg: dict berisi api_key, mode."""
    url = f"{_base_url(cfg['mode'])}/merchant/payment-channel"
    return _request("GET", url, cfg["api_key"])


def buat_transaksi(cfg, merchant_ref, amount, metode, nama_item, customer_name,
                    customer_phone=None, customer_email=None,
                    callback_url=None, return_url=None, expired_time=None):
    """Membuat transaksi closed payment baru. Mengembalikan dict data dari Tripay
    (berisi reference, checkout_url, pay_code, status, dst)."""
    signature = buat_signature_transaksi(cfg["private_key"], cfg["merchant_code"], merchant_ref, amount)
    payload = {
        "method": metode,
        "merchant_ref": merchant_ref,
        "amount": amount,
        "customer_name": customer_name or "Pelanggan",
        "order_items": [
            {"sku": "TAGIHAN", "name": nama_item, "price": amount, "quantity": 1},
        ],
        "signature": signature,
    }
    if customer_phone:
        payload["customer_phone"] = customer_phone
    if customer_email:
        payload["customer_email"] = customer_email
    if callback_url:
        payload["callback_url"] = callback_url
    if return_url:
        payload["return_url"] = return_url
    if expired_time:
        payload["expired_time"] = expired_time

    url = f"{_base_url(cfg['mode'])}/transaction/create"
    return _request("POST", url, cfg["api_key"], payload)


def ambil_detail_transaksi(cfg, reference):
    """Cek status terkini satu transaksi lewat reference dari Tripay (untuk polling
    manual kalau webhook callback belum/tidak sempat diterima, mis. saat testing lokal)."""
    url = f"{_base_url(cfg['mode'])}/transaction/detail"
    return _request("GET", url, cfg["api_key"], {"reference": reference})


def verifikasi_signature_callback(private_key, raw_body_bytes, signature_header):
    """Verifikasi X-Callback-Signature yang dikirim Tripay di webhook.
    raw_body_bytes HARUS body mentah (belum di-parse) supaya hash-nya cocok."""
    if not signature_header:
        return False
    hitung = hmac.new(private_key.encode("utf-8"), raw_body_bytes, hashlib.sha256).hexdigest()
    return hmac.compare_digest(hitung, signature_header)
