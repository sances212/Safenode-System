"""
vpn_manager.py
Manajer VPN Server bawaan billing berbasis WireGuard, supaya billing bisa
"menyediakan layanan VPN" sendiri untuk router Mikrotik konek masuk --
tanpa tergantung layanan tunnel pihak ketiga (MyTunnel.id, ZeroTier, dkk).

Cara kerja singkat:
- Billing menjalankan 1 interface WireGuard (server) di server/VPS tempat
  billing ini berjalan, mendengarkan di sebuah UDP port (default 51820).
- Tiap router Mikrotik yang mau konek didaftarkan sebagai "Klien VPN" di
  billing -> dapat IP tunnel sendiri (mis. 10.77.77.2) + keypair WireGuard.
- Billing menghasilkan script siap-tempel untuk dijalankan di terminal
  Mikrotik (RouterOS >= 7, WireGuard native) supaya router itu konek balik
  ke server VPN billing ini.
- Begitu terhubung, admin tinggal isi IP tunnel klien (mis. 10.77.77.2)
  sebagai host di halaman "Pengaturan Mikrotik" -> billing akses RouterOS
  API lewat jalur VPN itu, aman walau router di belakang CGNAT/WiFi rumah.

Modul ini murni membungkus perintah `wg` / `wg-quick` (paket wireguard-tools)
lewat subprocess -- tidak reimplement protokol WireGuard sendiri. Server
tempat billing ini dijalankan wajib:
  1) OS Linux dengan dukungan kernel WireGuard (kernel >= 5.6, atau modul
     wireguard tambahan di kernel lama),
  2) paket `wireguard-tools` terinstall (perintah `wg` & `wg-quick` ada),
  3) proses billing dijalankan dengan hak akses yang cukup (root/sudo, atau
     binary `wg`/`wg-quick` diberi capability CAP_NET_ADMIN) supaya boleh
     bikin network interface.
Kalau salah satu syarat di atas belum terpenuhi, semua fungsi di sini akan
melempar VPNError dengan pesan yang jelas -- ditangkap & ditampilkan apa
adanya ke admin di halaman VPN Mikrotik, supaya admin tahu persis apa yang
kurang, bukan sekadar "gagal".
"""

import ipaddress
import os
import shutil
import subprocess
import tempfile
import time

KONFIG_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vpn_config")
os.makedirs(KONFIG_FOLDER, exist_ok=True)


class VPNError(Exception):
    pass


# ---------------------------------------------------------------------------
# Cek ketersediaan tool di sistem
# ---------------------------------------------------------------------------
def wg_tersedia():
    """True kalau perintah `wg` DAN `wg-quick` ada di PATH server ini."""
    return bool(shutil.which("wg")) and bool(shutil.which("wg-quick"))


def alasan_tidak_tersedia():
    """Pesan bantuan kalau wireguard-tools belum ada, sesuai OS yang terdeteksi."""
    if os.name == "nt":
        return ("WireGuard belum terdeteksi di server Windows ini. Fitur VPN bawaan "
                "billing paling stabil dijalankan di server/VPS Linux. Kalau billing "
                "memang dijalankan di Linux, install dulu dengan: sudo apt install "
                "wireguard wireguard-tools (Debian/Ubuntu) lalu restart aplikasi billing.")
    return ("Paket wireguard-tools belum terinstall di server ini (perintah `wg` / "
            "`wg-quick` tidak ditemukan). Install dulu, contoh Debian/Ubuntu: "
            "sudo apt update && sudo apt install -y wireguard wireguard-tools -- "
            "lalu restart aplikasi billing ini.")


def _jalankan(cmd, input_text=None, timeout=10):
    """Wrapper subprocess.run seragam -- lempar VPNError dengan stderr aslinya
    kalau gagal, supaya pesan error dari `wg`/`wg-quick`/`ip` sampai apa adanya
    ke admin (isinya biasanya sudah jelas, mis. 'Operation not permitted' kalau
    kurang hak akses root)."""
    try:
        hasil = subprocess.run(cmd, input=input_text, capture_output=True,
                                text=True, timeout=timeout)
    except FileNotFoundError:
        raise VPNError(f"Perintah '{cmd[0]}' tidak ditemukan di server ini.")
    except subprocess.TimeoutExpired:
        raise VPNError(f"Perintah '{' '.join(cmd)}' timeout (tidak merespon).")
    if hasil.returncode != 0:
        pesan = (hasil.stderr or hasil.stdout or "").strip() or f"exit code {hasil.returncode}"
        raise VPNError(pesan)
    return hasil.stdout


# ---------------------------------------------------------------------------
# Keypair
# ---------------------------------------------------------------------------
def buat_keypair():
    """Hasilkan sepasang private/public key WireGuard baru. Kembalikan (privkey, pubkey)."""
    privkey = _jalankan(["wg", "genkey"]).strip()
    pubkey = _jalankan(["wg", "pubkey"], input_text=privkey + "\n").strip()
    return privkey, pubkey


def pubkey_dari_privkey(privkey):
    return _jalankan(["wg", "pubkey"], input_text=privkey + "\n").strip()


# ---------------------------------------------------------------------------
# Alokasi IP tunnel otomatis untuk klien baru
# ---------------------------------------------------------------------------
def ip_berikutnya(subnet_cidr, ip_terpakai):
    """Cari IP host pertama yang masih kosong di dalam subnet_cidr, lewati
    alamat network/broadcast, IP server (host pertama, dipakai server), dan
    IP yang sudah dipakai klien lain (ip_terpakai: set/list string IP)."""
    jaringan = ipaddress.ip_network(subnet_cidr, strict=False)
    dipakai = set(ip_terpakai) | {str(next(jaringan.hosts()))}  # host pertama = IP server
    for host in jaringan.hosts():
        if str(host) not in dipakai:
            return str(host)
    raise VPNError("Subnet VPN sudah penuh, tidak ada IP tunnel tersisa. "
                    "Perbesar subnet di Pengaturan VPN (mis. ganti ke /23) atau hapus klien yang tidak dipakai.")


def ip_server_dari_subnet(subnet_cidr):
    jaringan = ipaddress.ip_network(subnet_cidr, strict=False)
    return str(next(jaringan.hosts()))


def prefix_dari_subnet(subnet_cidr):
    return ipaddress.ip_network(subnet_cidr, strict=False).prefixlen


# ---------------------------------------------------------------------------
# Konfigurasi file wg-quick
# ---------------------------------------------------------------------------
def path_config(interface_name):
    return os.path.join(KONFIG_FOLDER, f"{interface_name}.conf")


def tulis_config(pengaturan, daftar_klien):
    """Susun & simpan file konfigurasi ala wg-quick untuk interface server,
    berisi [Interface] server + [Peer] untuk tiap klien Mikrotik yang aktif.
    pengaturan: row sqlite pengaturan_vpn. daftar_klien: list row vpn_client."""
    baris = [
        "[Interface]",
        f"PrivateKey = {pengaturan['server_privkey']}",
        f"Address = {ip_server_dari_subnet(pengaturan['subnet_cidr'])}/{prefix_dari_subnet(pengaturan['subnet_cidr'])}",
        f"ListenPort = {pengaturan['listen_port']}",
        "",
    ]
    for k in daftar_klien:
        if not k["aktif"]:
            continue
        baris += [
            f"# Klien: {k['nama']}",
            "[Peer]",
            f"PublicKey = {k['client_pubkey']}",
            f"AllowedIPs = {k['ip_address']}/32",
            "",
        ]
    isi = "\n".join(baris)
    path = path_config(pengaturan["interface_name"])
    # file berisi private key server -> batasi permission-nya
    with open(path, "w") as f:
        f.write(isi)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


# ---------------------------------------------------------------------------
# Kontrol interface (start/stop/sync)
# ---------------------------------------------------------------------------
def interface_aktif(interface_name):
    """Cek apakah interface WireGuard sedang hidup di server ini."""
    try:
        subprocess.run(["wg", "show", interface_name], capture_output=True,
                        text=True, timeout=5, check=True)
        return True
    except Exception:
        return False


def start_interface(pengaturan, daftar_klien):
    if not wg_tersedia():
        raise VPNError(alasan_tidak_tersedia())
    path = tulis_config(pengaturan, daftar_klien)
    if interface_aktif(pengaturan["interface_name"]):
        # sudah hidup -> sinkronkan saja daripada down/up (supaya tidak putus2)
        sinkronkan_peer(pengaturan, daftar_klien)
        return
    _jalankan(["wg-quick", "up", path], timeout=20)


def stop_interface(interface_name):
    if not wg_tersedia():
        raise VPNError(alasan_tidak_tersedia())
    path = path_config(interface_name)
    if not interface_aktif(interface_name):
        return
    _jalankan(["wg-quick", "down", path], timeout=20)


def sinkronkan_peer(pengaturan, daftar_klien):
    """Terapkan perubahan daftar klien (tambah/hapus/ubah) ke interface yang
    SEDANG HIDUP tanpa perlu down/up (supaya klien lain yang masih terhubung
    tidak ikut putus). Pakai `wg syncconf`, cara resmi yang direkomendasikan
    dokumentasi WireGuard untuk reload konfigurasi tanpa downtime."""
    if not wg_tersedia():
        raise VPNError(alasan_tidak_tersedia())
    iface = pengaturan["interface_name"]
    path = tulis_config(pengaturan, daftar_klien)
    if not interface_aktif(iface):
        # belum hidup, tidak ada yang perlu disinkronkan sekarang -- akan
        # otomatis kepakai saat start_interface() dipanggil
        return
    stripped = _jalankan(["wg-quick", "strip", path], timeout=10)
    with tempfile.NamedTemporaryFile("w", delete=False, suffix=".conf") as tmp:
        tmp.write(stripped)
        tmp_path = tmp.name
    try:
        _jalankan(["wg", "syncconf", iface, tmp_path], timeout=10)
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Status live (dipakai buat lihat kapan Mikrotik terakhir "kontak" ke VPN)
# ---------------------------------------------------------------------------
def status_peer(interface_name):
    """Kembalikan dict {public_key: {"endpoint":..,"latest_handshake":epoch,
    "rx":bytes,"tx":bytes,"online":bool}} dari `wg show <iface> dump`.
    Kembalikan {} kalau interface belum/tidak hidup (bukan error, karena ini
    dipakai buat polling status tiap beberapa detik dari halaman VPN)."""
    if not wg_tersedia() or not interface_aktif(interface_name):
        return {}
    try:
        keluaran = _jalankan(["wg", "show", interface_name, "dump"], timeout=5)
    except VPNError:
        return {}
    hasil = {}
    baris = keluaran.strip().split("\n")
    now = time.time()
    for i, ln in enumerate(baris):
        kolom = ln.split("\t")
        if i == 0:
            continue  # baris pertama = info interface sendiri, bukan peer
        if len(kolom) < 8:
            continue
        pubkey, _psk, endpoint, _allowed, handshake, rx, tx, _keepalive = kolom[:8]
        handshake = int(handshake) if handshake.isdigit() else 0
        hasil[pubkey] = {
            "endpoint": endpoint if endpoint != "(none)" else None,
            "latest_handshake": handshake,
            "rx": int(rx) if rx.isdigit() else 0,
            "tx": int(tx) if tx.isdigit() else 0,
            # dianggap online kalau ada handshake dalam 3 menit terakhir
            # (WireGuard biasanya re-handshake tiap ~2 menit selama trafik/keepalive jalan)
            "online": bool(handshake) and (now - handshake) < 180,
        }
    return hasil


def format_terakhir_terhubung(epoch):
    if not epoch:
        return "Belum pernah"
    selisih = int(time.time() - epoch)
    if selisih < 60:
        return f"{selisih} detik lalu"
    if selisih < 3600:
        return f"{selisih // 60} menit lalu"
    if selisih < 86400:
        return f"{selisih // 3600} jam lalu"
    return f"{selisih // 86400} hari lalu"


# ---------------------------------------------------------------------------
# Script siap-tempel untuk terminal Mikrotik (RouterOS >= 7, WireGuard native)
# ---------------------------------------------------------------------------
def script_routeros(pengaturan, klien):
    prefix = prefix_dari_subnet(pengaturan["subnet_cidr"])
    endpoint_host = pengaturan["endpoint_host"] or "ISI-IP-PUBLIK-ATAU-DOMAIN-SERVER-BILLING"
    return f"""# ===== Script VPN Mikrotik untuk klien: {klien['nama']} =====
# Jalankan baris-baris ini satu per satu di New Terminal Mikrotik (WinBox/SSH).
# Syarat: RouterOS versi 7 ke atas (WireGuard sudah built-in).

/interface wireguard add name={pengaturan['interface_name']} private-key="{klien['client_privkey']}" listen-port=13231

/interface wireguard peers add interface={pengaturan['interface_name']} \\
    public-key="{pengaturan['server_pubkey']}" \\
    endpoint-address={endpoint_host} endpoint-port={pengaturan['listen_port']} \\
    allowed-address={pengaturan['subnet_cidr']} persistent-keepalive=25s

/ip address add address={klien['ip_address']}/{prefix} interface={pengaturan['interface_name']}

# Setelah 3 baris di atas dijalankan, tunggu 10-30 detik lalu cek status koneksi:
/interface wireguard peers print

# Kalau "current-endpoint-address" & "rx/tx" sudah terisi (bukan kosong), berarti
# VPN sudah tersambung ke billing. Selanjutnya, di billing buka menu:
# Pengaturan > Pengaturan Mikrotik, isi "Host" dengan {klien['ip_address']}
# (IP tunnel router ini), lalu Simpan & Tes Koneksi seperti biasa.
"""
