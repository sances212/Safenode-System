"""
app.py - Web Portal Billing Internet Sinkron Mikrotik
Jalankan: python app.py
Akses: http://localhost:80  (login default: admin / admin123)
"""

import sqlite3
import csv
import json
import hashlib
import ipaddress
import secrets
import os
import io
import calendar
import re
import shutil
import smtplib
import socket
import subprocess
import sys
import math
import tempfile
import threading
import time
import urllib.request
import urllib.error
import zipfile
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, date, timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, g, send_file, Response
from werkzeug.utils import secure_filename
from PIL import Image, UnidentifiedImageError

from mikrotik_api import RouterOSAPI, RouterOSError
from olt_snmp import (
    SNMPClient, SNMPError, OID_IF_DESCR, OID_IF_OPER_STATUS, status_dari_nilai,
    OID_SYS_DESCR, OID_SYS_UPTIME, OID_SYS_NAME, OID_SYS_LOCATION, format_uptime,
)
import tripay_gateway
import wa_gateway
import telegram_gateway
import genieacs_client
import olt_ssh
import vpn_manager
import uptimerobot_client
from translations import t as _t, LANGUAGES, DEFAULT_LANG

# Versi aplikasi & changelog bawaan (ditampilkan di menu About kalau belum pernah
# cek update online, atau kalau URL manifest update belum diisi/gagal diakses).
APP_VERSION = "1.7.0"
CHANGELOG_BAWAAN = [
    {"tanggal": "2026-08-29", "catatan": [
        "Tambah field lengkap di form Tambah Pelanggan (No. Identitas, Kategori Layanan, "
        "IP Address, Status/Merk/SN Perangkat, No. Port ODP, Jenis Tagihan, Tanggal Mulai "
        "Aktif/Isolir, Tgl Invoice Perdana, Jatuh Tempo Pembayaran, Catatan).",
        "Tambah pencarian alamat di peta (geocoding) saat Tambah Pelanggan.",
        "Tambah menu About / Cek Update.",
    ]},
]

DB_PATH = "billing.db"
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "uploads")
BACKUP_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backup_otomatis")
SECRET_KEY_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "secret_key.txt")
TUNNEL_INFO_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tunnel_info.txt")
EKSTENSI_LOGO_DIIZINKAN = {"png", "jpg", "jpeg", "webp", "gif", "bmp"}
EKSTENSI_BACKUP_DIIZINKAN = {"db", "sqlite", "sqlite3"}
TABEL_WAJIB_BACKUP = {"admin", "paket", "pelanggan", "tagihan", "pengaturan_umum", "pengaturan_mikrotik",
                      "pengaturan_tripay", "pembayaran_online", "rekening_bank", "konfirmasi_transfer_bank",
                      "kas_withdraw", "pengaturan_vpn", "vpn_client", "router", "reseller"}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(BACKUP_FOLDER, exist_ok=True)


def _muat_atau_buat_secret_key():
    """Pakai secret key tetap yang disimpan di file, bukan acak tiap restart.
    Kalau acak tiap restart, semua orang yang sedang login akan otomatis logout
    setiap kali server direstart/diakses ulang lewat tunnel — merepotkan
    terutama saat aplikasi diakses online lewat Cloudflare Tunnel/ngrok."""
    if os.path.isfile(SECRET_KEY_PATH):
        with open(SECRET_KEY_PATH, "r") as f:
            kunci = f.read().strip()
            if kunci:
                return kunci
    kunci_baru = secrets.token_hex(32)
    with open(SECRET_KEY_PATH, "w") as f:
        f.write(kunci_baru)
    return kunci_baru


app = Flask(__name__)
app.secret_key = _muat_atau_buat_secret_key()
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # batas upload 25MB (cukup untuk file backup database)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


@app.context_processor
def _inject_static_versi():
    """Tambahkan helper static_v() ke semua template supaya file CSS/JS statis
    otomatis punya query string versi berdasarkan waktu file terakhir diubah.
    Ini mencegah browser pengguna nyangkut pakai file CSS/JS lama dari cache
    setiap kali ada perubahan tampilan (tanpa harus hard-refresh manual)."""
    def static_v(filename):
        try:
            path_lengkap = os.path.join(app.static_folder, filename)
            versi = int(os.path.getmtime(path_lengkap))
        except OSError:
            versi = 1
        return url_for("static", filename=filename, v=versi)
    return dict(static_v=static_v)

# ---------------------------------------------------------------------------
# Proteksi login sederhana (rate limit) — penting begitu aplikasi bisa
# diakses dari internet lewat tunnel, supaya tidak gampang dibrute-force.
# Catatan tersimpan di memori saja, reset kalau server direstart.
# ---------------------------------------------------------------------------
PERCOBAAN_LOGIN_GAGAL = {}
BATAS_PERCOBAAN_LOGIN = 5
DURASI_KUNCI_DETIK = 15 * 60


# ---------------------------------------------------------------------------
# Database helper
# ---------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def hash_password(raw):
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def warna_voucher(harga):
    """Memetakan nominal voucher ke satu set warna (untuk desain cetak voucher).
    Supaya voucher dengan nominal berbeda otomatis tercetak dengan warna berbeda,
    tanpa admin perlu mengatur warna secara manual."""
    try:
        h = int(harga or 0)
    except (TypeError, ValueError):
        h = 0
    if h < 2000:
        return {"nama": "Abu-abu", "utama": "#6c757d", "muda": "#eef0f2", "gelap": "#495057"}
    if h < 5000:
        return {"nama": "Hijau", "utama": "#1f9d55", "muda": "#e6f7ec", "gelap": "#136b39"}
    if h < 10000:
        return {"nama": "Biru", "utama": "#2f7dd9", "muda": "#e8f1fc", "gelap": "#1c5aa8"}
    if h < 20000:
        return {"nama": "Oranye", "utama": "#e07b1f", "muda": "#fdf0e2", "gelap": "#a85c14"}
    if h < 50000:
        return {"nama": "Ungu", "utama": "#7c3aed", "muda": "#f1eafd", "gelap": "#5b21b6"}
    return {"nama": "Merah", "utama": "#d63444", "muda": "#fce8ea", "gelap": "#a01f2c"}


def buat_link_wa(nomor):
    """Ubah nomor telepon (format apapun, mis. '0858-7218-3973') jadi link wa.me
    yang bisa langsung diklik untuk membuka chat WhatsApp."""
    if not nomor:
        return "https://wa.me/6285872183973"
    digit = re.sub(r"\D", "", nomor)
    if digit.startswith("0"):
        digit = "62" + digit[1:]
    elif not digit.startswith("62"):
        digit = "62" + digit
    return f"https://wa.me/{digit}"


def catat_log_pesan_gateway(db, provider, arah, kontak, isi, status, keterangan=None):
    """Simpan satu baris riwayat pesan WA/Telegram Gateway ke tabel log_pesan_gateway,
    supaya bisa ditampilkan langsung di halaman Gateway aplikasi ini (menu WA Gateway /
    Telegram Gateway) tanpa perlu buka dashboard provider pihak ketiga."""
    db.execute(
        "INSERT INTO log_pesan_gateway (provider, arah, kontak, isi, status, keterangan, waktu) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (provider, arah, kontak, isi, status, keterangan,
         datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    db.commit()


app.jinja_env.globals["buat_link_wa"] = buat_link_wa
app.jinja_env.globals["FACEBOOK_URL"] = "https://www.facebook.com/AsepBadarsys/"
app.jinja_env.globals["INSTAGRAM_URL"] = "https://www.instagram.com/asepcolection212"


app.jinja_env.globals["warna_voucher"] = warna_voucher


@app.context_processor
def inject_pengaturan_umum():
    try:
        db = get_db()
        row = db.execute("SELECT nama_aplikasi, logo_path, telepon FROM pengaturan_umum WHERE id=1").fetchone()
        admin_default = db.execute(
            "SELECT 1 FROM admin WHERE username='admin' AND password_hash=?",
            (hash_password("admin123"),)).fetchone()
    except sqlite3.OperationalError:
        row = None
        admin_default = None
    hasil = dict(nama_aplikasi="SafeNode", logo_url="img/logo_safenode.png", telepon_wa=None,
                 pakai_password_default=bool(admin_default), tahun_sekarang=datetime.now().year)
    if row:
        hasil["nama_aplikasi"] = row["nama_aplikasi"]
        hasil["logo_url"] = row["logo_path"]
        try:
            hasil["telepon_wa"] = row["telepon"]
        except (IndexError, KeyError):
            hasil["telepon_wa"] = None
    # jumlah tiket gangguan berstatus "baru" -- dipakai untuk badge notifikasi di sidebar admin
    try:
        db = get_db()
        hasil["jumlah_tiket_baru"] = db.execute(
            "SELECT COUNT(*) c FROM tiket_gangguan WHERE status='baru'").fetchone()["c"]
    except sqlite3.OperationalError:
        hasil["jumlah_tiket_baru"] = 0
    # jumlah konfirmasi transfer bank yang masih menunggu diproses -- badge notifikasi menu Transfer Bank
    try:
        db = get_db()
        hasil["jumlah_konfirmasi_transfer_pending"] = db.execute(
            "SELECT COUNT(*) c FROM konfirmasi_transfer_bank WHERE status='menunggu'").fetchone()["c"]
    except sqlite3.OperationalError:
        hasil["jumlah_konfirmasi_transfer_pending"] = 0
    # jumlah pendaftaran calon pelanggan baru yang belum diproses admin -- badge notifikasi menu Pendaftaran
    try:
        db = get_db()
        hasil["jumlah_pendaftaran_baru"] = db.execute(
            "SELECT COUNT(*) c FROM calon_pelanggan WHERE status='baru'").fetchone()["c"]
    except sqlite3.OperationalError:
        hasil["jumlah_pendaftaran_baru"] = 0
    # jumlah pendaftaran reseller/software (calon pengguna baru SafeNode) yang belum
    # ditindaklanjuti -- badge notifikasi menu Pendaftaran Reseller
    try:
        db = get_db()
        hasil["jumlah_pendaftaran_reseller_baru"] = db.execute(
            "SELECT COUNT(*) c FROM pendaftaran_reseller WHERE status='baru'").fetchone()["c"]
    except sqlite3.OperationalError:
        hasil["jumlah_pendaftaran_reseller_baru"] = 0
    # jumlah tiket maintenance dari reseller yang masih berstatus "baru" -- badge
    # notifikasi menu POP Site > Tiket
    try:
        db = get_db()
        hasil["jumlah_tiket_reseller_baru"] = db.execute(
            "SELECT COUNT(*) c FROM tiket_reseller WHERE status='baru'").fetchone()["c"]
    except sqlite3.OperationalError:
        hasil["jumlah_tiket_reseller_baru"] = 0
    # daftar notifikasi lonceng di topbar: tiket komplain pelanggan yang masih berstatus "baru"
    # (belum ditindaklanjuti admin manapun) -- muncul otomatis begitu pelanggan lapor gangguan
    # lewat Portal Pelanggan atau dibuatkan admin.
    hasil["daftar_notifikasi_tiket"] = []
    try:
        db = get_db()
        hasil["daftar_notifikasi_tiket"] = db.execute(
            """SELECT tk.id, tk.judul, tk.kategori, tk.tanggal_lapor, p.nama AS nama_pelanggan
               FROM tiket_gangguan tk JOIN pelanggan p ON p.id = tk.pelanggan_id
               WHERE tk.status='baru' ORDER BY tk.id DESC LIMIT 8"""
        ).fetchall()
    except sqlite3.OperationalError:
        pass
    # foto profil (avatar) admin yang sedang login -- ditampilkan di topbar kanan atas
    hasil["admin_avatar_url"] = None
    if session.get("admin_id"):
        try:
            db = get_db()
            baris_admin = db.execute(
                "SELECT avatar_path FROM admin WHERE id=?", (session["admin_id"],)).fetchone()
            if baris_admin and baris_admin["avatar_path"]:
                hasil["admin_avatar_url"] = baris_admin["avatar_path"]
        except sqlite3.OperationalError:
            pass
    # ---------------- bahasa / language ----------------
    # bahasa aktif disimpan di session, default Indonesia; dipakai lewat {{ t('key') }}
    # di semua template dan lewat dropdown pemilih bahasa di navbar/halaman login.
    bahasa_aktif = session.get("bahasa", DEFAULT_LANG)
    if bahasa_aktif not in LANGUAGES:
        bahasa_aktif = DEFAULT_LANG
    hasil["current_lang"] = bahasa_aktif
    hasil["lang_dir"] = LANGUAGES[bahasa_aktif]["dir"]
    hasil["daftar_bahasa"] = LANGUAGES
    hasil["t"] = lambda key: _t(key, lang=bahasa_aktif)
    # ---------------- level akses admin ----------------
    # dipakai di sidebar (base.html) buat sembunyiin grup menu yang levelnya nggak boleh
    # akses modul itu -- lihat LEVEL_MODUL & ENDPOINT_MODUL di bagian Auth.
    hasil["admin_level_aktif"] = _level_admin_aktif()
    hasil["nama_level_aktif"] = LEVEL_ADMIN.get(_level_admin_aktif(), "Administrator")
    hasil["boleh_modul"] = lambda modul: _level_boleh_akses_modul(_level_admin_aktif(), modul)
    return hasil


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS admin (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS paket (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_paket TEXT NOT NULL,
            kecepatan TEXT NOT NULL,           -- contoh: 10M/10M
            harga INTEGER NOT NULL,
            profile_mikrotik TEXT NOT NULL     -- nama PPP profile di Mikrotik
        );

        CREATE TABLE IF NOT EXISTS pelanggan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            alamat TEXT,
            no_hp TEXT,
            username_pppoe TEXT UNIQUE NOT NULL,
            password_pppoe TEXT NOT NULL,
            paket_id INTEGER,
            status TEXT NOT NULL DEFAULT 'aktif',   -- aktif / isolir
            tanggal_daftar TEXT NOT NULL,
            FOREIGN KEY (paket_id) REFERENCES paket(id)
        );

        CREATE TABLE IF NOT EXISTS tagihan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pelanggan_id INTEGER NOT NULL,
            periode TEXT NOT NULL,           -- format: YYYY-MM
            jumlah INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'belum_lunas',  -- belum_lunas / lunas
            tanggal_jatuh_tempo TEXT,
            tanggal_bayar TEXT,
            FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS calon_pelanggan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            alamat TEXT,
            no_hp TEXT NOT NULL,
            email TEXT,
            paket_id INTEGER,
            catatan TEXT,
            status TEXT NOT NULL DEFAULT 'baru',   -- baru / diproses / ditolak
            tanggal_daftar TEXT NOT NULL,
            pelanggan_id INTEGER,                  -- terisi setelah diproses jadi pelanggan
            FOREIGN KEY (paket_id) REFERENCES paket(id),
            FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id)
        );

        CREATE TABLE IF NOT EXISTS pendaftaran_reseller (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_bisnis TEXT NOT NULL,             -- nama usaha/ISP calon reseller
            nama_pic TEXT NOT NULL,                -- nama penanggung jawab/pemilik
            no_hp TEXT NOT NULL,
            email TEXT,
            kota TEXT,
            jumlah_pelanggan_saat_ini TEXT,        -- perkiraan skala usaha, mis. "50-100"
            paket TEXT NOT NULL,                   -- Starter / Professional / Enterprise
            catatan TEXT,
            status TEXT NOT NULL DEFAULT 'baru',   -- baru / dihubungi / berlangganan / ditolak
            tanggal_daftar TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS pengaturan_mikrotik (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            host TEXT,
            port INTEGER DEFAULT 8728,
            username TEXT,
            password TEXT
        );

        -- Akun reseller sungguhan (bisa login sendiri), beda dari pendaftaran_reseller
        -- yang cuma form lead. Satu reseller bisa punya banyak router/POP sendiri dan
        -- banyak pelanggan sendiri, terpisah dari pelanggan milik admin master/reseller lain.
        CREATE TABLE IF NOT EXISTS reseller (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            nama_bisnis TEXT NOT NULL,
            nama_pic TEXT,
            no_hp TEXT,
            email TEXT,
            status TEXT NOT NULL DEFAULT 'aktif',   -- aktif / nonaktif
            saldo_deposit INTEGER NOT NULL DEFAULT 0,
            pendaftaran_id INTEGER,                 -- asalnya dari lead pendaftaran_reseller mana (kalau ada)
            tanggal_dibuat TEXT NOT NULL,
            FOREIGN KEY (pendaftaran_id) REFERENCES pendaftaran_reseller(id)
        );

        -- Router/POP: setiap baris = satu koneksi Mikrotik terpisah. reseller_id NULL
        -- artinya router milik admin master (bukan punya reseller manapun). Dengan ini,
        -- satu instalasi billing bisa punya banyak router sekaligus (multi-router/multi-POP),
        -- masing-masing pelanggan tinggal dipasangkan ke salah satu router lewat pelanggan.router_id.
        CREATE TABLE IF NOT EXISTS router (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reseller_id INTEGER,                    -- NULL = milik admin master
            nama_router TEXT NOT NULL,               -- label bebas, mis. "Router Pusat", "POP Cileungsi"
            host TEXT,
            port INTEGER DEFAULT 8728,
            username TEXT,
            password TEXT,
            metode_koneksi TEXT NOT NULL DEFAULT 'langsung',
            nama_tunnel TEXT,
            status TEXT NOT NULL DEFAULT 'aktif',
            tanggal_dibuat TEXT NOT NULL,
            FOREIGN KEY (reseller_id) REFERENCES reseller(id) ON DELETE CASCADE
        );

        -- Master "Server Name" -- nama server Hotspot/PPPoE yang wajib sama persis
        -- dengan yang didaftarkan di Mikrotik (IP > Hotspot > Servers > Name, atau
        -- PPP > PPPoE Servers > Service Name). Dipakai sebagai daftar rujukan/kunci
        -- supaya klien hanya boleh login dari server tertentu.
        CREATE TABLE IF NOT EXISTS server_name_master (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL UNIQUE,
            tanggal_dibuat TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS voucher (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            profile_hotspot TEXT NOT NULL,
            harga INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'belum_terpakai',   -- belum_terpakai / terpakai
            batch TEXT NOT NULL,
            dibuat_tanggal TEXT NOT NULL
        );

        -- Profile Voucher: profil HARGA/komisi lokal untuk voucher hotspot (terpisah dari
        -- profile Mikrotik mentah di menu Router > Profile). Satu baris di sini bisa
        -- dipetakan ke satu nama profile Hotspot di Mikrotik (kolom profile_mikrotik),
        -- ditambah info harga jual/HPP/komisi/kuota/durasi ala menu "Profile Voucher"
        -- di aplikasi billing sejenis (RL Radius, dsb).
        CREATE TABLE IF NOT EXISTS hotspot_voucher_profile (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_profile TEXT NOT NULL UNIQUE,
            profile_mikrotik TEXT,
            group_reseller TEXT,
            addresslist TEXT,
            rate_limit TEXT,
            shared_users INTEGER NOT NULL DEFAULT 1,
            kuota TEXT,
            durasi TEXT,
            aktif INTEGER NOT NULL DEFAULT 1,
            hpp INTEGER NOT NULL DEFAULT 0,
            komisi INTEGER NOT NULL DEFAULT 0,
            harga INTEGER NOT NULL DEFAULT 0,
            dibuat_tanggal TEXT NOT NULL
        );

        -- Template Voucher Kustom (menu Hotspot > Template): desain kupon voucher
        -- versi "kode HTML" yang bisa diedit bebas oleh admin (ala editor Template
        -- Voucher RL Radius) -- terpisah dari 4 desain bawaan di DAFTAR_TEMPLATE_VOUCHER.
        -- header_html/row_html/footer_html digabung berurutan (header + row diulang per
        -- voucher + footer) sewaktu dicetak, dengan tag #placeholder# diganti data asli.
        CREATE TABLE IF NOT EXISTS template_voucher_custom (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kode TEXT NOT NULL UNIQUE,
            nama TEXT NOT NULL,
            header_html TEXT NOT NULL,
            row_html TEXT NOT NULL,
            footer_html TEXT NOT NULL,
            dibuat_tanggal TEXT NOT NULL
        );

        -- Outlet: toko/warung/individu yang menjual voucher hotspot langsung ke
        -- konsumen, posisinya di bawah kontrol satu Mitra/reseller (reseller_id
        -- NULL = outlet milik admin master langsung, tanpa mitra perantara).
        CREATE TABLE IF NOT EXISTS outlet (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reseller_id INTEGER,
            nama_outlet TEXT NOT NULL,
            pemilik TEXT,
            phone TEXT,
            alamat TEXT,
            tanggal_dibuat TEXT NOT NULL,
            FOREIGN KEY (reseller_id) REFERENCES reseller(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS pengaturan_umum (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            nama_aplikasi TEXT NOT NULL DEFAULT 'SafeNode',
            logo_path TEXT,
            alamat TEXT,
            telepon TEXT
        );

        -- Pengaturan fitur "Cek Update" di menu About: URL manifest JSON yang berisi
        -- info versi terbaru + link download zip-nya + changelog. URL ini punya admin
        -- sendiri (misalnya di-hosting di GitHub milik admin), BUKAN server Anthropic.
        CREATE TABLE IF NOT EXISTS pengaturan_update (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            manifest_url TEXT,
            versi_terbaru TEXT,
            catatan_terbaru TEXT,
            download_url TEXT,
            changelog_json TEXT,
            terakhir_dicek TEXT,
            terakhir_pasang TEXT
        );

        CREATE TABLE IF NOT EXISTS pengaturan_tripay (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            merchant_code TEXT,
            api_key TEXT,
            private_key TEXT,
            mode TEXT NOT NULL DEFAULT 'production',   -- production / sandbox
            aktif INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS pengaturan_wa_gateway (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            provider TEXT NOT NULL DEFAULT 'wablas',
            domain TEXT,
            token TEXT,
            secret_key TEXT,
            nomor_pengirim TEXT,
            aktif INTEGER NOT NULL DEFAULT 0
        );

        -- Menu Gateway > Telegram Gateway: kirim notifikasi lewat bot Telegram
        -- (mis. reminder tagihan, notifikasi internal ke admin/grup).
        CREATE TABLE IF NOT EXISTS pengaturan_telegram_gateway (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            bot_token TEXT,
            chat_id_default TEXT,
            aktif INTEGER NOT NULL DEFAULT 0
        );

        -- Menu Customer > Tiket Gangguan > tombol Setting: ID Group Telegram tujuan
        -- notifikasi khusus tiket (pakai Bot Token yang sama dengan Telegram Gateway di atas).
        CREATE TABLE IF NOT EXISTS pengaturan_notifikasi_tiket (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            telegram_group_id TEXT
        );

        -- Log pesan WA & Telegram Gateway (terkirim & masuk), supaya bisa dilihat
        -- langsung di halaman Gateway aplikasi ini tanpa buka dashboard provider
        -- (Wablas/Telegram) secara terpisah.
        CREATE TABLE IF NOT EXISTS log_pesan_gateway (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            provider TEXT NOT NULL,      -- 'wa' / 'telegram'
            arah TEXT NOT NULL,          -- 'keluar' (terkirim) / 'masuk' (diterima)
            kontak TEXT,                 -- nomor HP (WA) atau chat id/username (Telegram)
            isi TEXT,
            status TEXT,                 -- 'terkirim' / 'gagal'
            keterangan TEXT,             -- pesan error (kalau gagal) atau info tambahan
            waktu TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS pembayaran_online (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tagihan_id INTEGER NOT NULL,
            merchant_ref TEXT NOT NULL UNIQUE,
            reference TEXT,
            metode TEXT,
            nama_metode TEXT,
            checkout_url TEXT,
            jumlah INTEGER NOT NULL,
            fee_pelanggan INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'UNPAID',    -- UNPAID / PAID / EXPIRED / FAILED / REFUND
            dibuat_tanggal TEXT NOT NULL,
            kadaluarsa_tanggal TEXT,
            dibayar_tanggal TEXT,
            FOREIGN KEY (tagihan_id) REFERENCES tagihan(id) ON DELETE CASCADE
        );

        -- Billing > Configuration: aturan pajak (PPN) per cabang/paket. Rule yang lebih
        -- spesifik menang: cabang+paket, lalu cabang, lalu paket, baru default global.
        CREATE TABLE IF NOT EXISTS billing_pajak_rule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cabang TEXT NOT NULL DEFAULT 'Any',
            paket_id INTEGER,
            mode TEXT NOT NULL DEFAULT 'inclusive',   -- inclusive / exclusive
            rate REAL NOT NULL DEFAULT 11,
            catatan TEXT,
            dibuat_tanggal TEXT NOT NULL,
            FOREIGN KEY (paket_id) REFERENCES paket(id)
        );

        -- Billing > Configuration > Promo Rules: aturan diskon/promo per paket (opsional).
        CREATE TABLE IF NOT EXISTS billing_promo_rule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            tipe TEXT NOT NULL DEFAULT 'percent',     -- percent / nominal
            nilai INTEGER NOT NULL DEFAULT 0,
            paket_id INTEGER,                          -- NULL = berlaku semua paket
            aktif INTEGER NOT NULL DEFAULT 1,
            catatan TEXT,
            dibuat_tanggal TEXT NOT NULL,
            FOREIGN KEY (paket_id) REFERENCES paket(id)
        );

        CREATE TABLE IF NOT EXISTS olt_device (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            host TEXT NOT NULL,
            snmp_port INTEGER NOT NULL DEFAULT 161,
            snmp_community TEXT NOT NULL DEFAULT 'public',
            oid_status TEXT NOT NULL DEFAULT '1.3.6.1.2.1.2.2.1.8',
            oid_rx_power TEXT,
            oid_nama_interface TEXT NOT NULL DEFAULT '1.3.6.1.2.1.2.2.1.2',
            keterangan TEXT
        );

        CREATE TABLE IF NOT EXISTS onu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            olt_id INTEGER NOT NULL,
            pelanggan_id INTEGER,
            label TEXT NOT NULL,
            oid_index TEXT NOT NULL,
            serial_number TEXT,
            status_terakhir TEXT NOT NULL DEFAULT 'unknown',
            rx_power_terakhir TEXT,
            dicek_terakhir TEXT,
            FOREIGN KEY (olt_id) REFERENCES olt_device(id) ON DELETE CASCADE,
            FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS odp (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            alamat TEXT,
            latitude REAL,
            longitude REAL,
            kapasitas INTEGER NOT NULL DEFAULT 8,
            olt_id INTEGER,
            keterangan TEXT,
            tanggal_pasang TEXT,
            FOREIGN KEY (olt_id) REFERENCES olt_device(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS login_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipe TEXT NOT NULL,             -- admin / pelanggan
            username TEXT NOT NULL,
            status TEXT NOT NULL,           -- berhasil / gagal
            alamat_ip TEXT,
            waktu TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS aktivitas_sistem (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kategori TEXT NOT NULL,         -- pppoe / hotspot / admin_user
            aksi TEXT NOT NULL,             -- deskripsi singkat, misal "Tambah Pelanggan"
            keterangan TEXT,                -- detail terkait, misal nama/username
            status TEXT NOT NULL DEFAULT 'berhasil',
            dibuat_oleh TEXT,
            waktu TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS pengaturan_smtp (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            smtp_host TEXT,
            smtp_port INTEGER DEFAULT 587,
            smtp_username TEXT,
            smtp_password TEXT,
            smtp_gunakan_tls INTEGER NOT NULL DEFAULT 1,
            email_pengirim TEXT,
            nama_pengirim TEXT
        );

        CREATE TABLE IF NOT EXISTS tiket_gangguan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pelanggan_id INTEGER NOT NULL,
            kategori TEXT NOT NULL DEFAULT 'lainnya',   -- putus/lambat/perangkat/tagihan/lainnya
            judul TEXT NOT NULL,
            deskripsi TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'baru',        -- baru/menuju_lokasi/on_progress/selesai/ditutup
            catatan_admin TEXT,
            tanggal_lapor TEXT NOT NULL,
            tanggal_update TEXT,
            FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS tiket_riwayat (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tiket_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            catatan TEXT,
            waktu TEXT NOT NULL,
            FOREIGN KEY (tiket_id) REFERENCES tiket_gangguan(id) ON DELETE CASCADE
        );

        -- ==================== POP Site > Tiket (request maintenance dari Reseller) ====================
        -- Tiket yang diajukan reseller lewat Dashboard Reseller (menu Tiket) untuk
        -- minta maintenance/perbaikan POP-nya. Muncul & ditindaklanjuti admin lewat
        -- menu POP Site > Tiket. Beda dengan tiket_gangguan (itu punya pelanggan).
        CREATE TABLE IF NOT EXISTS tiket_reseller (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reseller_id INTEGER NOT NULL,
            router_id INTEGER,                             -- POP/router terkait (opsional)
            kategori TEXT NOT NULL DEFAULT 'maintenance',  -- maintenance/gangguan/upgrade/lainnya
            judul TEXT NOT NULL,
            deskripsi TEXT NOT NULL,
            prioritas TEXT NOT NULL DEFAULT 'medium',      -- low/medium/high/urgent
            status TEXT NOT NULL DEFAULT 'baru',           -- baru/diproses/selesai/ditutup
            catatan_admin TEXT,
            dibuat_pada TEXT NOT NULL,
            diperbarui_pada TEXT,
            FOREIGN KEY (reseller_id) REFERENCES reseller(id) ON DELETE CASCADE,
            FOREIGN KEY (router_id) REFERENCES router(id) ON DELETE SET NULL
        );

        -- ==================== Support > Internal Tickets ====================
        -- Tiket internal antar tim (bukan dari pelanggan) -- IT/NOC/Ops saling lapor kendala.
        CREATE TABLE IF NOT EXISTS tiket_internal (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subjek TEXT NOT NULL,
            deskripsi TEXT NOT NULL,
            kategori TEXT NOT NULL DEFAULT 'lainnya',      -- it/noc/hr/finance/operasional/lainnya
            prioritas TEXT NOT NULL DEFAULT 'medium',      -- low/medium/high/urgent
            status TEXT NOT NULL DEFAULT 'open',           -- open/in_progress/resolved/closed
            ditugaskan_ke TEXT,
            dibuat_oleh TEXT,
            dibuat_pada TEXT NOT NULL,
            diperbarui_pada TEXT
        );

        -- ==================== Support > LinkNet Tickets ====================
        -- Trouble ticket yang diajukan ke helpdesk LinkNet (open-access, standar TMF621).
        CREATE TABLE IF NOT EXISTS linknet_tiket (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id TEXT,                                -- nomor TT dari LinkNet (mis. TT130-7-xxxx)
            homepass TEXT,                                 -- ID Homepass terkait
            subjek TEXT NOT NULL,
            deskripsi TEXT,
            severity TEXT NOT NULL DEFAULT 'medium',        -- low/medium/high/critical
            status TEXT NOT NULL DEFAULT 'baru',            -- baru/open/in_progress/resolved/closed
            dibuat_oleh TEXT,
            dibuat_pada TEXT,
            diperbarui_pada TEXT
        );

        -- ==================== Support > CS Handover ====================
        -- Log interaksi pelanggan per-shift CS, supaya shift berikutnya tahu item yang belum "Done".
        CREATE TABLE IF NOT EXISTS cs_handover (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kontak TEXT NOT NULL,                           -- No. HP / CID pelanggan
            kategori TEXT NOT NULL DEFAULT 'lainnya',
            deskripsi TEXT,
            tindakan TEXT,
            status TEXT NOT NULL DEFAULT 'menunggu_update',  -- done/menunggu_update/on_progress/eskalasi
            shift TEXT NOT NULL DEFAULT 'pagi',              -- pagi/siang/malam
            cs_nama TEXT,
            dibuat_pada TEXT NOT NULL
        );

        -- ==================== RADIUS > Isolasi ====================
        -- Daftar username/MAC address yang diisolasi manual di level NAS (di luar
        -- status isolir otomatis milik pelanggan karena telat bayar).
        CREATE TABLE IF NOT EXISTS radius_isolasi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            mac_address TEXT,
            alasan TEXT,
            kadaluarsa TEXT,
            dibuat_oleh TEXT,
            dibuat_pada TEXT NOT NULL
        );

        -- ==================== RADIUS > Konfigurasi ====================
        -- Definisi server RADIUS (auth/acct/CoA) yang dipakai NAS untuk autentikasi.
        CREATE TABLE IF NOT EXISTS radius_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            server_alamat TEXT NOT NULL,
            port_auth INTEGER NOT NULL DEFAULT 1812,
            port_acct INTEGER NOT NULL DEFAULT 1813,
            port_coa INTEGER NOT NULL DEFAULT 3799,
            shared_secret TEXT,
            deskripsi TEXT,
            dibuat_pada TEXT NOT NULL
        );

        -- ==================== ACS > Configuration ====================
        -- Profil koneksi TR-069 (ACS URL, kredensial, periodic inform, STUN) yang
        -- bisa didorong (push) ke perangkat. Berbeda dari pengaturan_genieacs (satu
        -- baris, dipakai internal utk Client Area) -- tabel ini boleh banyak baris.
        CREATE TABLE IF NOT EXISTS acs_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            deskripsi TEXT,
            acs_url TEXT NOT NULL,
            username TEXT,
            password TEXT,
            inform_interval INTEGER NOT NULL DEFAULT 300,
            stun_aktif INTEGER NOT NULL DEFAULT 0,
            stun_host TEXT,
            stun_port INTEGER DEFAULT 3478,
            is_default INTEGER NOT NULL DEFAULT 0,
            dibuat_pada TEXT NOT NULL
        );

        -- ==================== ACS > Profil (Configuration Profiles) ====================
        -- Profil provisioning zero-touch: bootstrap/provision/firmware/custom, dicocokkan
        -- ke device lewat OUI/Product Class, lalu bisa didorong (push) ke device yang cocok.
        CREATE TABLE IF NOT EXISTS acs_profile (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            tipe TEXT NOT NULL DEFAULT 'bootstrap',
            vendor TEXT,
            match_oui TEXT,
            match_class TEXT,
            match_desc TEXT,
            prioritas INTEGER NOT NULL DEFAULT 100,
            status TEXT NOT NULL DEFAULT 'aktif',
            deskripsi TEXT,
            parameter_json TEXT,
            dibuat_pada TEXT NOT NULL
        );

        -- ==================== ACS > Firmware Catalog ====================
        CREATE TABLE IF NOT EXISTS acs_firmware (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            versi TEXT NOT NULL,
            vendor TEXT,
            model TEXT,
            file_path TEXT,
            file_size INTEGER DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'aktif',
            tanggal_rilis TEXT,
            dibuat_pada TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS pengaturan_genieacs (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            url TEXT,
            username TEXT,
            password TEXT,
            aktif INTEGER NOT NULL DEFAULT 0,
            path_ssid TEXT NOT NULL DEFAULT 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.{idx}.SSID',
            path_ssid_enable TEXT NOT NULL DEFAULT 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.{idx}.Enable',
            path_password TEXT NOT NULL DEFAULT 'InternetGatewayDevice.LANDevice.1.WLANConfiguration.{idx}.KeyPassphrase',
            path_rx_power TEXT NOT NULL DEFAULT 'InternetGatewayDevice.WANDevice.1.WANPONInterfaceConfig.RXPower',
            path_uptime TEXT NOT NULL DEFAULT 'InternetGatewayDevice.DeviceInfo.UpTime',
            path_hosts TEXT NOT NULL DEFAULT 'InternetGatewayDevice.LANDevice.1.Hosts.Host'
        );

        -- Pengaturan integrasi UptimeRobot untuk menu "Sistem" -> pantau status
        -- server/layanan (mis. status server billing ini sendiri, atau server lain
        -- yang mau dipantau) langsung dari dashboard admin.
        CREATE TABLE IF NOT EXISTS pengaturan_uptimerobot (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            api_key TEXT,
            aktif INTEGER NOT NULL DEFAULT 0
        );

        -- Rekening bank perusahaan, ditampilkan ke pelanggan (Portal Pelanggan & halaman
        -- bayar admin) sebagai tujuan transfer manual, pelengkap payment gateway Tripay.
        CREATE TABLE IF NOT EXISTS rekening_bank (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_bank TEXT NOT NULL,
            no_rekening TEXT NOT NULL,
            atas_nama TEXT NOT NULL,
            keterangan TEXT,
            aktif INTEGER NOT NULL DEFAULT 1,
            urutan INTEGER NOT NULL DEFAULT 0
        );

        -- Konfirmasi transfer bank manual dari pelanggan (atau dicatat admin) untuk satu
        -- tagihan: menunggu -> diterima (tagihan otomatis ditandai lunas) / ditolak.
        CREATE TABLE IF NOT EXISTS konfirmasi_transfer_bank (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tagihan_id INTEGER NOT NULL,
            pelanggan_id INTEGER NOT NULL,
            rekening_tujuan_id INTEGER,
            bank_pengirim TEXT NOT NULL,
            nama_pengirim TEXT NOT NULL,
            jumlah INTEGER NOT NULL,
            tanggal_transfer TEXT NOT NULL,
            catatan TEXT,
            bukti_path TEXT,
            status TEXT NOT NULL DEFAULT 'menunggu',   -- menunggu / diterima / ditolak
            dibuat_tanggal TEXT NOT NULL,
            diproses_tanggal TEXT,
            catatan_admin TEXT,
            FOREIGN KEY (tagihan_id) REFERENCES tagihan(id) ON DELETE CASCADE,
            FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE CASCADE,
            FOREIGN KEY (rekening_tujuan_id) REFERENCES rekening_bank(id) ON DELETE SET NULL
        );

        -- Pencatatan kas keluar / withdraw manual (BUKAN lewat Tripay) -- misalnya setoran
        -- hasil tagihan ke rekening pribadi, biaya operasional, gaji, dsb. Murni pembukuan.
        CREATE TABLE IF NOT EXISTS kas_withdraw (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tanggal TEXT NOT NULL,
            jumlah INTEGER NOT NULL,
            kategori TEXT NOT NULL DEFAULT 'lainnya',   -- setoran/operasional/gaji/lainnya
            tujuan TEXT,
            keterangan TEXT,
            dicatat_oleh TEXT,
            dibuat_tanggal TEXT NOT NULL
        );

        -- Pengaturan VPN Server bawaan billing (WireGuard) -- supaya billing bisa
        -- "menyediakan layanan VPN" sendiri untuk router Mikrotik konek masuk,
        -- tanpa perlu layanan tunnel pihak ketiga (MyTunnel.id, ZeroTier, dkk).
        CREATE TABLE IF NOT EXISTS pengaturan_vpn (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            interface_name TEXT NOT NULL DEFAULT 'wg-billing',
            listen_port INTEGER NOT NULL DEFAULT 51820,
            subnet_cidr TEXT NOT NULL DEFAULT '10.77.77.0/24',
            server_privkey TEXT,
            server_pubkey TEXT,
            endpoint_host TEXT,
            aktif INTEGER NOT NULL DEFAULT 0
        );

        -- Daftar klien VPN (1 baris = 1 router Mikrotik yang boleh konek lewat
        -- VPN bawaan billing). ip_address = IP tunnel router itu di dalam subnet VPN.
        CREATE TABLE IF NOT EXISTS vpn_client (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            keterangan TEXT,
            client_privkey TEXT NOT NULL,
            client_pubkey TEXT NOT NULL,
            ip_address TEXT NOT NULL UNIQUE,
            aktif INTEGER NOT NULL DEFAULT 1,
            dibuat_tanggal TEXT NOT NULL
        );

        -- ==================== Network > Fleet ====================
        -- Inventaris perangkat jaringan (router, ONT/ONU, switch, dsb) baik yang
        -- sedang terpasang di lapangan maupun masih di gudang.
        CREATE TABLE IF NOT EXISTS fleet_perangkat (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            tipe TEXT NOT NULL DEFAULT 'Router',      -- Router/ONT/ONU/Switch/Modem/Lainnya
            vendor TEXT,
            model TEXT,
            serial_number TEXT,
            mac_address TEXT,
            status TEXT NOT NULL DEFAULT 'gudang',     -- gudang/terpasang/rusak/hilang
            router_id INTEGER,                         -- NAS/lokasi tempat perangkat terpasang (opsional)
            pelanggan_id INTEGER,                      -- kalau dipasang di rumah pelanggan (opsional)
            tanggal_masuk TEXT,
            catatan TEXT,
            FOREIGN KEY (router_id) REFERENCES router(id) ON DELETE SET NULL,
            FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id) ON DELETE SET NULL
        );

        -- ==================== Network > IP Pools ====================
        -- Kumpulan blok/pool alamat IP yang dialokasikan untuk pelanggan PPPoE/statis.
        CREATE TABLE IF NOT EXISTS ip_pool (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            network_cidr TEXT NOT NULL,       -- contoh: 192.168.10.0/24
            gateway TEXT,
            dns_server TEXT,
            router_id INTEGER,                -- NAS pemilik pool ini (opsional)
            status TEXT NOT NULL DEFAULT 'aktif',   -- aktif/nonaktif
            keterangan TEXT,
            dibuat_tanggal TEXT NOT NULL,
            FOREIGN KEY (router_id) REFERENCES router(id) ON DELETE SET NULL
        );

        -- ==================== Network > LinkNet (Backbone Links) ====================
        -- Jalur/link backbone antar NAS (POP) -- dipakai untuk memetakan topologi
        -- koneksi antar titik jaringan (mis. link fiber POP A <-> POP B).
        CREATE TABLE IF NOT EXISTS link_jaringan (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_link TEXT NOT NULL,
            nas_asal_id INTEGER,
            nas_tujuan_id INTEGER,
            tipe TEXT NOT NULL DEFAULT 'Fiber',   -- Fiber/Wireless/VPN/Lainnya
            kapasitas TEXT,                        -- contoh: 1 Gbps
            status TEXT NOT NULL DEFAULT 'up',    -- up/down
            keterangan TEXT,
            dibuat_tanggal TEXT NOT NULL,
            FOREIGN KEY (nas_asal_id) REFERENCES router(id) ON DELETE SET NULL,
            FOREIGN KEY (nas_tujuan_id) REFERENCES router(id) ON DELETE SET NULL
        );

        -- ==================== Live Chat: fitur tambahan ====================
        -- Pengaturan auto-assign (pembagian chat masuk otomatis ke CS). 1 baris (id=1).
        CREATE TABLE IF NOT EXISTS live_chat_auto_assign (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            aktif INTEGER NOT NULL DEFAULT 1,
            metode TEXT NOT NULL DEFAULT 'round_robin',   -- round_robin/beban_kerja/tag
            maks_chat_per_cs INTEGER NOT NULL DEFAULT 8
        );

        -- Template balasan cepat (quick reply) untuk CS.
        CREATE TABLE IF NOT EXISTS live_chat_quick_reply (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shortcut TEXT NOT NULL,
            pesan TEXT NOT NULL,
            dibuat_tanggal TEXT NOT NULL
        );

        -- Tag/label untuk mengkategorikan percakapan.
        CREATE TABLE IF NOT EXISTS live_chat_tag (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            warna TEXT NOT NULL DEFAULT 'purple'   -- purple/teal/amber/red
        );

        -- Riwayat broadcast/blast pesan massal.
        CREATE TABLE IF NOT EXISTS live_chat_broadcast (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target TEXT NOT NULL,
            pesan TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'terkirim',   -- terkirim/dijadwalkan
            dibuat_tanggal TEXT NOT NULL
        );

        -- Langkah alur chatbot (trigger kata kunci -> balasan otomatis).
        CREATE TABLE IF NOT EXISTS live_chat_chatbot_flow (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trigger_kata_kunci TEXT NOT NULL,
            balasan TEXT NOT NULL,
            urutan INTEGER NOT NULL DEFAULT 0
        );

        -- Jam operasional per hari untuk auto-reply di luar jam kerja. 7 baris (Senin-Minggu).
        CREATE TABLE IF NOT EXISTS live_chat_working_hours (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hari TEXT NOT NULL UNIQUE,
            aktif INTEGER NOT NULL DEFAULT 1,
            jam_mulai TEXT NOT NULL DEFAULT '08:00',
            jam_selesai TEXT NOT NULL DEFAULT '20:00'
        );

        -- Pesan auto-reply yang dikirim di luar jam operasional. 1 baris (id=1).
        CREATE TABLE IF NOT EXISTS live_chat_working_hours_pesan (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            pesan TEXT NOT NULL DEFAULT 'Terima kasih telah menghubungi kami. Saat ini di luar jam operasional, tim kami akan membalas pesan Anda pada jam kerja berikutnya.'
        );

        -- Nomor yang diblokir supaya tidak masuk ke antrian chat CS.
        CREATE TABLE IF NOT EXISTS live_chat_blacklist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nomor TEXT NOT NULL,
            alasan TEXT,
            dibuat_tanggal TEXT NOT NULL
        );
        """
    )
    db.execute(
        "INSERT OR IGNORE INTO live_chat_auto_assign (id, aktif, metode, maks_chat_per_cs) VALUES (1, 1, 'round_robin', 8)"
    )
    db.execute(
        "INSERT OR IGNORE INTO live_chat_working_hours_pesan (id, pesan) VALUES (1, 'Terima kasih telah menghubungi kami. Saat ini di luar jam operasional, tim kami akan membalas pesan Anda pada jam kerja berikutnya.')"
    )
    for _hari in ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]:
        db.execute(
            "INSERT OR IGNORE INTO live_chat_working_hours (hari, aktif, jam_mulai, jam_selesai) VALUES (?, ?, '08:00', '20:00')",
            (_hari, 0 if _hari == "Minggu" else 1),
        )
    db.commit()
    # migrasi kolom "nama" (nama tampilan) untuk user admin -- dipakai di topbar supaya
    # yang muncul di pojok kanan atas adalah nama orangnya, bukan username login.
    # migrasi kolom alamat & telepon perusahaan untuk pengaturan_umum -- dipakai supaya
    # kop surat/alamat perusahaan otomatis muncul saat cetak invoice.
    kolom_pengaturan_umum = {row["name"] for row in db.execute("PRAGMA table_info(pengaturan_umum)").fetchall()}
    if "alamat" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN alamat TEXT")
    if "telepon" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN telepon TEXT")
    # Penanda "3 paket contoh sudah pernah disuntikkan" -- dulu paket
    # contoh (7/12/15 Mbps) di-cek ulang & disisipkan lagi tiap kali
    # aplikasi start kalau namanya belum ada di tabel paket. Efek
    # sampingnya: kalau admin sengaja MENGHAPUS ketiga paket contoh itu
    # (karena bukan paket asli / belum ada setingan Mikrotik-nya), paket
    # itu akan MUNCUL LAGI setiap restart aplikasi. Penanda 1x ini bikin
    # penyisipan paket contoh cuma jalan SEKALI SEUMUR HIDUP database,
    # persis di baris "seed 3 paket internet default" di bawah.
    if "paket_default_diseed" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN paket_default_diseed INTEGER NOT NULL DEFAULT 0")

    # migrasi kolom Support > Customer Tickets -- prioritas & metadata tiket yang datang
    # lewat integrasi MixRadius, supaya bisa ditampilkan di daftar Customer Tickets.
    kolom_tiket_gangguan = {row["name"] for row in db.execute("PRAGMA table_info(tiket_gangguan)").fetchall()}
    if "prioritas" not in kolom_tiket_gangguan:
        db.execute("ALTER TABLE tiket_gangguan ADD COLUMN prioritas TEXT NOT NULL DEFAULT 'medium'")
    if "mixradius_ticket" not in kolom_tiket_gangguan:
        db.execute("ALTER TABLE tiket_gangguan ADD COLUMN mixradius_ticket TEXT")
    if "dept" not in kolom_tiket_gangguan:
        db.execute("ALTER TABLE tiket_gangguan ADD COLUMN dept TEXT NOT NULL DEFAULT 'support'")
    if "assigned_teknisi_id" not in kolom_tiket_gangguan:
        db.execute("ALTER TABLE tiket_gangguan ADD COLUMN assigned_teknisi_id INTEGER")
    if "alamat_koordinat" not in kolom_tiket_gangguan:
        db.execute("ALTER TABLE tiket_gangguan ADD COLUMN alamat_koordinat TEXT")
    if "no_whatsapp" not in kolom_tiket_gangguan:
        db.execute("ALTER TABLE tiket_gangguan ADD COLUMN no_whatsapp TEXT")

    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_notifikasi_tiket")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_notifikasi_tiket (id, telegram_group_id) VALUES (1, '')")

    kolom_admin = {row["name"] for row in db.execute("PRAGMA table_info(admin)").fetchall()}
    if "nama" not in kolom_admin:
        db.execute("ALTER TABLE admin ADD COLUMN nama TEXT")
    # migrasi kolom untuk fitur "Lupa Password" -- email tujuan reset, plus token &
    # waktu kadaluarsanya (token dibuat ulang tiap kali diminta, sekali pakai, 1 jam).
    if "email" not in kolom_admin:
        db.execute("ALTER TABLE admin ADD COLUMN email TEXT")
    if "reset_token" not in kolom_admin:
        db.execute("ALTER TABLE admin ADD COLUMN reset_token TEXT")
    if "reset_token_expiry" not in kolom_admin:
        db.execute("ALTER TABLE admin ADD COLUMN reset_token_expiry TEXT")
    # foto profil admin (avatar), ditampilkan di topbar kanan atas
    if "avatar_path" not in kolom_admin:
        db.execute("ALTER TABLE admin ADD COLUMN avatar_path TEXT")
    # level/role akses admin -- membatasi menu & fitur yang boleh diakses tiap user admin.
    # default 'administrator' supaya akun-akun admin yang sudah ada sebelum fitur ini tidak
    # kehilangan akses (backward compatible).
    if "level" not in kolom_admin:
        db.execute("ALTER TABLE admin ADD COLUMN level TEXT NOT NULL DEFAULT 'administrator'")

    # kolom metode koneksi Mikrotik: langsung (IP lokal/publik) vs vpn_tunnel (mis. MyTunnel.id,
    # ZeroTier, Tailscale, dll). Koneksinya sendiri tetap sama persis (host + port ke RouterOS
    # API) -- cuma dipakai buat nampilin catatan/placeholder yang sesuai di form Pengaturan
    # Mikrotik, karena host & port yang diisi bukan IP router langsung tapi alamat tunnel.
    kolom_mikrotik = {row["name"] for row in db.execute("PRAGMA table_info(pengaturan_mikrotik)").fetchall()}
    if "metode_koneksi" not in kolom_mikrotik:
        db.execute("ALTER TABLE pengaturan_mikrotik ADD COLUMN metode_koneksi TEXT NOT NULL DEFAULT 'langsung'")
    if "nama_tunnel" not in kolom_mikrotik:
        db.execute("ALTER TABLE pengaturan_mikrotik ADD COLUMN nama_tunnel TEXT")

    # migrasi kolom baru untuk fitur peta (lokasi pemasangan pelanggan + ODP terkait)
    kolom_pelanggan = {row["name"] for row in db.execute("PRAGMA table_info(pelanggan)").fetchall()}
    if "latitude" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN latitude REAL")
    if "longitude" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN longitude REAL")
    if "odp_id" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN odp_id INTEGER REFERENCES odp(id)")
    # kolom IP pelanggan (statis/dinamis) -- dipakai fitur "Tambah Pelanggan Cepat" di Peta
    # yang menarik otomatis data IP dari secret PPPoE Mikrotik (statis) atau sesi aktif (dinamis).
    if "alamat_ip" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN alamat_ip TEXT")
    # multi-router/reseller: setiap pelanggan dipasangkan ke satu router (POP) tertentu,
    # dan opsional ke satu reseller pemilik (NULL = pelanggan milik admin master).
    # Tagihan tetap satu tabel gabungan (tagihan.pelanggan_id) -- tidak ikut dipecah per
    # router, jadi billing tetap terpusat, cuma pelanggannya yang jelas milik router/reseller mana.
    if "router_id" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN router_id INTEGER REFERENCES router(id)")
    if "reseller_id" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN reseller_id INTEGER REFERENCES reseller(id)")
    # kategori klien -- dipakai untuk tab "Personal" / "Corporate" di menu Klien
    # (mengikuti tampilan referensi: All Clients / Personal / Corporate / Prospects / Orphaned)
    if "tipe_klien" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN tipe_klien TEXT NOT NULL DEFAULT 'personal'")
    # kode unik pembayaran -- angka kecil (1-999) yang ditambahkan ke nominal tagihan
    # supaya tiap pelanggan punya nominal transfer yang beda-beda, memudahkan admin
    # mencocokkan mutasi rekening/e-wallet dengan tagihan yang mana. Diisi lewat
    # tombol "Kode Unik" (massal) di menu Pelanggan.
    if "kode_unik" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN kode_unik INTEGER")
    # hari tagihan custom per-pelanggan (1-28) -- kalau diisi, generate_tagihan()
    # pakai tanggal ini sebagai jatuh tempo pelanggan tsb, bukan tanggal default (20).
    # Diisi lewat tombol "Set Billing" (massal) di menu Pelanggan.
    if "hari_tagihan" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN hari_tagihan INTEGER")
    # kolom tambahan menyusul permintaan fitur "Tambah Pelanggan" yang lebih lengkap
    # (mengikuti referensi tampilan aplikasi billing lain): identitas pelanggan,
    # kategori layanan (PPP/DHCP/Hotspot), detail perangkat, & jenis tagihan.
    if "no_identitas" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN no_identitas TEXT")
    if "kategori_layanan" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN kategori_layanan TEXT NOT NULL DEFAULT 'ppp'")
    if "jenis_tagihan" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN jenis_tagihan TEXT NOT NULL DEFAULT 'pascabayar'")
    if "status_perangkat" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN status_perangkat TEXT")
    if "merk_perangkat" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN merk_perangkat TEXT")
    if "sn_perangkat" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN sn_perangkat TEXT")
    if "no_port_odp" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN no_port_odp TEXT")
    if "catatan" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN catatan TEXT")
    # tanggal-tanggal siklus billing (mengikuti referensi tampilan aplikasi billing lain):
    # tanggal mulai aktif layanan, target tanggal isolir otomatis, tanggal invoice
    # perdana diterbitkan, dan tanggal jatuh tempo pembayaran invoice perdana itu.
    if "tanggal_mulai_aktif" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN tanggal_mulai_aktif TEXT")
    if "tanggal_isolir" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN tanggal_isolir TEXT")
    if "tgl_invoice_perdana" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN tgl_invoice_perdana TEXT")
    if "jatuh_tempo_pembayaran" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN jatuh_tempo_pembayaran TEXT")
    # kolom tambahan untuk modal "Data Pelanggan" ala menu POP Site > Pelanggan
    # (NPWP, saldo deposit, & catatan waktu terakhir pelanggan login ke Portal Pelanggan).
    if "no_npwp" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN no_npwp TEXT")
    if "saldo" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN saldo INTEGER NOT NULL DEFAULT 0")
    if "last_login_portal" not in kolom_pelanggan:
        db.execute("ALTER TABLE pelanggan ADD COLUMN last_login_portal TEXT")

    # multi-router/reseller untuk voucher hotspot: sama seperti pelanggan, tiap voucher
    # dipasangkan ke router (POP) & reseller pemiliknya (NULL = milik admin master),
    # supaya reseller bisa punya menu Hotspot sendiri yang cuma nampilin voucher miliknya.
    kolom_voucher = {row["name"] for row in db.execute("PRAGMA table_info(voucher)").fetchall()}
    if "router_id" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN router_id INTEGER REFERENCES router(id)")
    if "reseller_id" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN reseller_id INTEGER REFERENCES reseller(id)")
    # migrasi menu Voucher (Profile Voucher/Stok/Terjual/Online/Offline/Template) --
    # "channel" nandain voucher itu dibuat lewat jalur Online (mis. voucher online/self
    # service) atau Offline (dicetak manual di loket), "profile_voucher_id" opsional
    # menautkan voucher ke satu baris di hotspot_voucher_profile (harga/HPP/komisi).
    if "channel" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN channel TEXT NOT NULL DEFAULT 'offline'")
    if "profile_voucher_id" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN profile_voucher_id INTEGER REFERENCES hotspot_voucher_profile(id)")
    if "terpakai_tanggal" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terpakai_tanggal TEXT")
    # migrasi menu Stok Voucher -- kolom tambahan menyusul toolbar "Buat VC/Buat User/
    # Outlet/Import" ala RL Radius: voucher bisa dikaitkan ke satu Outlet (outlet.id),
    # dikunci ke MAC Address perangkat pertama yang connect, override HPP/Komisi per
    # voucher (kalau NULL, tetap dihitung dari hotspot_voucher_profile seperti sebelumnya),
    # serta catatan nama Server hotspot & apakah pembuatannya memotong saldo deposit mitra.
    if "outlet_id" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN outlet_id INTEGER REFERENCES outlet(id)")
    if "kunci_mac" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN kunci_mac INTEGER NOT NULL DEFAULT 0")
    if "server_name" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN server_name TEXT")
    if "hpp" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN hpp INTEGER")
    if "komisi" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN komisi INTEGER")
    if "potong_saldo_mitra" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN potong_saldo_mitra INTEGER NOT NULL DEFAULT 0")
    # menu MENU > Set Aktif/Non Aktif di toolbar Stok Voucher -- nonaktifkan voucher
    # (akun hotspot-nya ikut dinonaktifkan di Mikrotik kalau router-nya online)
    # tanpa harus menghapus datanya.
    if "nonaktif" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN nonaktif INTEGER NOT NULL DEFAULT 0")
    # migrasi menu Voucher Offline (ala RL Radius) -- catatan sesi terakhir per voucher
    # (Interface/Server/IP/MAC saat terakhir online, total pemakaian data, serta jam
    # terakhir online & terakhir offline). Semua kolom ini di-refresh live tiap menu
    # Voucher Online/Offline dibuka, diambil dari Mikrotik (lihat _perbarui_riwayat_sesi_hotspot()).
    if "terakhir_interface" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terakhir_interface TEXT")
    if "terakhir_server" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terakhir_server TEXT")
    if "terakhir_ip" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terakhir_ip TEXT")
    if "terakhir_mac" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terakhir_mac TEXT")
    if "total_download" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN total_download INTEGER NOT NULL DEFAULT 0")
    if "total_upload" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN total_upload INTEGER NOT NULL DEFAULT 0")
    if "terakhir_online_tanggal" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terakhir_online_tanggal TEXT")
    if "terakhir_offline_tanggal" not in kolom_voucher:
        db.execute("ALTER TABLE voucher ADD COLUMN terakhir_offline_tanggal TEXT")

    # migrasi Pengaturan Hotspot (modal "Setting" di toolbar Stok Voucher) -- nama
    # tampilan hotspot, DNS Name (harus sama dengan DNS Name di Mikrotik), logo
    # halaman login voucher, dan nomor CS yang tampil di voucher/invoice.
    if "nama_hotspot" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN nama_hotspot TEXT NOT NULL DEFAULT 'RL HOTSPOT'")
    if "dns_name_hotspot" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN dns_name_hotspot TEXT")
    if "logo_hotspot_path" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN logo_hotspot_path TEXT")
    if "cs_phone_hotspot" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN cs_phone_hotspot TEXT")

    # migrasi hotspot_voucher_profile -- tambahan kolom "warna" (dipakai sebagai label
    # warna di tabel Profile Voucher) & "masa_aktif" (masa berlaku voucher sejak pertama
    # dipakai, terpisah dari "durasi"), mengikuti struktur menu Profile Voucher RL Radius.
    kolom_profil_voucher = {row["name"] for row in db.execute("PRAGMA table_info(hotspot_voucher_profile)").fetchall()}
    if "warna" not in kolom_profil_voucher:
        db.execute("ALTER TABLE hotspot_voucher_profile ADD COLUMN warna TEXT NOT NULL DEFAULT '#007BFF'")
    if "masa_aktif" not in kolom_profil_voucher:
        db.execute("ALTER TABLE hotspot_voucher_profile ADD COLUMN masa_aktif TEXT")

    # migrasi menu Hotspot > Template -- desain kupon voucher default dipakai otomatis
    # di halaman Cetak Voucher/Cetak Cepat kalau admin tidak pilih desain lain manual.
    if "voucher_desain_default" not in kolom_pengaturan_umum:
        db.execute("ALTER TABLE pengaturan_umum ADD COLUMN voucher_desain_default TEXT NOT NULL DEFAULT 'bizfiber'")

    # seed 1 contoh Template Voucher Kustom ("EXAMPLE") supaya menu Hotspot > Template
    # langsung ada isinya di editor kode HTML (ala Template Voucher RL Radius), tanpa
    # bikin admin mulai dari kotak kosong.
    if db.execute("SELECT COUNT(*) AS n FROM template_voucher_custom").fetchone()["n"] == 0:
        db.execute(
            """INSERT INTO template_voucher_custom (kode, nama, header_html, row_html, footer_html, dibuat_tanggal)
               VALUES (?,?,?,?,?,?)""",
            ("example", "EXAMPLE", _TEMPLATE_VOUCHER_CUSTOM_CONTOH_HEADER,
             _TEMPLATE_VOUCHER_CUSTOM_CONTOH_ROW, _TEMPLATE_VOUCHER_CUSTOM_CONTOH_FOOTER,
             date.today().isoformat()))

    # migrasi kolom baru untuk OLT: info umum ala panel radius (type/brand/alamat/koordinat)
    # + kredensial login web/API OLT supaya bisa langsung "Login OLT" dari billing.
    kolom_olt = {row["name"] for row in db.execute("PRAGMA table_info(olt_device)").fetchall()}
    if "tipe" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN tipe TEXT NOT NULL DEFAULT 'GPON'")
    if "brand" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN brand TEXT")
    if "alamat" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN alamat TEXT")
    if "latitude" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN latitude REAL")
    if "longitude" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN longitude REAL")
    if "username_login" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN username_login TEXT")
    if "password_login" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN password_login TEXT")
    if "url_akses" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN url_akses TEXT")
    if "jumlah_port" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN jumlah_port INTEGER")
    # kolom info tambahan untuk panel "Login OLT" (System Information ala MSRadius)
    # — diisi manual karena OID CPU/DRAM/Software Version bersifat privat per vendor.
    if "software_version" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN software_version TEXT")
    if "revisi" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN revisi TEXT")
    if "mac_address" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN mac_address TEXT")
    # OID opsional untuk ambil Mac Address / Temperatur / TX Power tiap ONU otomatis lewat
    # SNMP (sama seperti oid_rx_power) — dipakai tombol "Cek Status Sekarang" di menu ONU
    # supaya tabelnya sinkron persis dengan kolom panel MSRadius (Onu ID, Name, Mac Address,
    # Status, Temperatur, TXPower, RXPower).
    if "oid_mac_address" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN oid_mac_address TEXT")
    if "oid_temperature" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN oid_temperature TEXT")
    if "oid_tx_power" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN oid_tx_power TEXT")
    # kredensial SSH -- alternatif untuk OLT yang OID SNMP privatnya tidak diketahui/tidak
    # bisa diakses. Tombol "Sync via SSH" di menu ONU pakai ini untuk konek & jalankan
    # ssh_command (mis. 'show mac address-table'), lalu hasilnya di-parse otomatis.
    if "ssh_port" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN ssh_port INTEGER NOT NULL DEFAULT 22")
    if "ssh_username" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN ssh_username TEXT")
    if "ssh_password" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN ssh_password TEXT")
    if "ssh_command" not in kolom_olt:
        db.execute("ALTER TABLE olt_device ADD COLUMN ssh_command TEXT NOT NULL DEFAULT 'show mac address-table'")
    # ODP bisa "cascade" dari ODP lain (bukan cuma langsung dari OLT), misalnya
    # ODP-2 kabelnya ditarik dari ODP-1, bukan dari server langsung. Kolom ini
    # dipakai untuk menggambar garis backbone ODP <-> ODP berikutnya di Peta Jaringan.
    kolom_odp = {row["name"] for row in db.execute("PRAGMA table_info(odp)").fetchall()}
    if "odp_induk_id" not in kolom_odp:
        db.execute("ALTER TABLE odp ADD COLUMN odp_induk_id INTEGER REFERENCES odp(id)")
    # migrasi kolom port_pon untuk ONU: dipakai untuk mengelompokkan kartu status
    # per port PON di panel "Login OLT" (mis. 0/1, 0/2, 0/3, 0/4 seperti panel MSRadius).
    kolom_onu = {row["name"] for row in db.execute("PRAGMA table_info(onu)").fetchall()}
    if "port_pon" not in kolom_onu:
        db.execute("ALTER TABLE onu ADD COLUMN port_pon INTEGER NOT NULL DEFAULT 1")
    # kolom tambahan supaya tabel ONU persis seperti panel MSRadius: Mac Address, Temperatur,
    # TX Power (RX Power sudah ada lewat rx_power_terakhir). Bisa diisi manual atau otomatis
    # lewat SNMP kalau OID-nya sudah diisi di menu OLT.
    if "mac_address" not in kolom_onu:
        db.execute("ALTER TABLE onu ADD COLUMN mac_address TEXT")
    if "temperatur_terakhir" not in kolom_onu:
        db.execute("ALTER TABLE onu ADD COLUMN temperatur_terakhir TEXT")
    if "tx_power_terakhir" not in kolom_onu:
        db.execute("ALTER TABLE onu ADD COLUMN tx_power_terakhir TEXT")

    # migrasi kolom baru untuk Paket Internet: warna label (badge di tabel & tampilan
    # cetak), serta masa aktif (durasi + satuan) yang dipakai untuk hitung jatuh tempo
    # tagihan pelanggan pada paket ini -- terinspirasi tampilan "Update Profile Billing"
    # ala MSRadius.
    kolom_paket = {row["name"] for row in db.execute("PRAGMA table_info(paket)").fetchall()}
    if "warna" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN warna TEXT NOT NULL DEFAULT '#2f7dd9'")
    if "masa_aktif" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN masa_aktif INTEGER NOT NULL DEFAULT 1")
    if "unit_masa_aktif" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN unit_masa_aktif TEXT NOT NULL DEFAULT 'BULAN'")
    # migrasi kolom lanjutan: tipe paket (Rumahan/Dedicated/dll), media akses
    # (Fiber Optic/Wireless/dll), dan rate limit mentah gaya Mikrotik
    # (format: rate-up/down burst-up/down burst-threshold-up/down burst-time-up/down
    # priority min-rate-up/down, contoh: "100M/100M 0/0 0/0 0/0 8 0/0").
    if "tipe_paket" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN tipe_paket TEXT NOT NULL DEFAULT 'Rumahan'")
    if "media" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN media TEXT NOT NULL DEFAULT 'Fiber Optic'")
    if "rate_limit" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN rate_limit TEXT NOT NULL DEFAULT ''")

    # migrasi kolom lanjutan lagi: shared (jumlah user per satu alokasi bandwidth,
    # gaya "1:1" / "1:4"), status_paket (aktif/nonaktif -- profile nonaktif tetap
    # tersimpan tapi disembunyikan dari pilihan paket saat tambah pelanggan baru),
    # dan komisi (nominal komisi reseller per pembayaran, terinspirasi tampilan
    # "Profile Berlangganan" ala RLRadius).
    if "shared" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN shared INTEGER NOT NULL DEFAULT 1")
    if "status_paket" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN status_paket TEXT NOT NULL DEFAULT 'aktif'")
    if "komisi" not in kolom_paket:
        db.execute("ALTER TABLE paket ADD COLUMN komisi INTEGER NOT NULL DEFAULT 0")

    # migrasi kolom tambahan untuk form pendaftaran client publik (/daftar-pelanggan):
    # NIK/NPWP, koordinat lokasi pemasangan (dipilih lewat peta di form), nomor HP kedua
    # terpisah dari WhatsApp utama, serta preferensi SSID/password WiFi yang diminta
    # calon pelanggan -- semuanya opsional kecuali sudah divalidasi di route.
    kolom_calon = {row["name"] for row in db.execute("PRAGMA table_info(calon_pelanggan)").fetchall()}
    if "nik" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN nik TEXT")
    if "npwp" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN npwp TEXT")
    if "latitude" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN latitude REAL")
    if "longitude" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN longitude REAL")
    if "no_hp2" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN no_hp2 TEXT")
    if "ssid_wifi" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN ssid_wifi TEXT")
    if "password_wifi" not in kolom_calon:
        db.execute("ALTER TABLE calon_pelanggan ADD COLUMN password_wifi TEXT")

    # migrasi status tiket lama "diproses" (versi awal fitur tiket gangguan) ke status
    # baru yang lebih spesifik "on_progress", supaya data lama tetap konsisten.
    try:
        db.execute("UPDATE tiket_gangguan SET status='on_progress' WHERE status='diproses'")
    except sqlite3.OperationalError:
        pass

    # migrasi kolom akun untuk pendaftaran_reseller -- dipakai saat admin mengaktifkan
    # (ubah status jadi "berlangganan"), sistem generate username & password lalu
    # dikirim otomatis ke email calon reseller.
    kolom_pendaftaran_reseller = {row["name"] for row in db.execute(
        "PRAGMA table_info(pendaftaran_reseller)").fetchall()}
    if "akun_username" not in kolom_pendaftaran_reseller:
        db.execute("ALTER TABLE pendaftaran_reseller ADD COLUMN akun_username TEXT")
    if "akun_password" not in kolom_pendaftaran_reseller:
        db.execute("ALTER TABLE pendaftaran_reseller ADD COLUMN akun_password TEXT")
    if "akun_dikirim_tanggal" not in kolom_pendaftaran_reseller:
        db.execute("ALTER TABLE pendaftaran_reseller ADD COLUMN akun_dikirim_tanggal TEXT")

    # migrasi kolom pay_code (nomor VA/kode bayar dari Tripay) untuk halaman
    # Billing > Virtual Accounts -- sebelumnya cuma "reference" (ref internal Tripay)
    # yang disimpan, padahal nomor VA yang perlu ditampilkan ke pelanggan itu pay_code.
    kolom_pembayaran_online = {row["name"] for row in db.execute(
        "PRAGMA table_info(pembayaran_online)").fetchall()}
    if "pay_code" not in kolom_pembayaran_online:
        db.execute("ALTER TABLE pembayaran_online ADD COLUMN pay_code TEXT")

    # admin default
    cur = db.execute("SELECT COUNT(*) c FROM admin")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO admin (username, password_hash) VALUES (?, ?)",
                   ("admin", hash_password("admin123")))
    # baris pengaturan mikrotik default (kosong)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_mikrotik")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_mikrotik (id, host, port, username, password) "
                   "VALUES (1, '', 8728, '', '')")

    # migrasi multi-router: pindahkan pengaturan_mikrotik (router tunggal lama) jadi baris
    # pertama di tabel router baru, supaya instalasi lama otomatis lanjut jalan tanpa perlu
    # diisi ulang. Router ini jadi "router utama" milik admin master (reseller_id NULL).
    cur = db.execute("SELECT COUNT(*) c FROM router")
    if cur.fetchone()["c"] == 0:
        lama = db.execute("SELECT * FROM pengaturan_mikrotik WHERE id=1").fetchone()
        db.execute(
            """INSERT INTO router (id, reseller_id, nama_router, host, port, username, password,
                                    metode_koneksi, nama_tunnel, status, tanggal_dibuat)
               VALUES (1, NULL, 'Router Utama', ?, ?, ?, ?, ?, ?, 'aktif', ?)""",
            (lama["host"] if lama else "", lama["port"] if lama else 8728,
             lama["username"] if lama else "", lama["password"] if lama else "",
             lama["metode_koneksi"] if lama else "langsung", lama["nama_tunnel"] if lama else None,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    # semua pelanggan lama yang belum dipasangkan ke router manapun otomatis diarahkan
    # ke "Router Utama" (id=1) supaya tidak ada pelanggan yang jadi yatim/tidak tersambung.
    db.execute("UPDATE pelanggan SET router_id=1 WHERE router_id IS NULL")
    # baris pengaturan umum (nama aplikasi & logo) default
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_umum")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_umum (id, nama_aplikasi, logo_path) "
                   "VALUES (1, 'SafeNode', 'img/logo_safenode.png')")
    # baris pengaturan Cek Update default (kosong, diisi admin dari menu About)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_update")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_update (id, manifest_url) VALUES (1, '')")
    # baris pengaturan SMTP/email default (kosong, wajib diisi admin dulu supaya
    # fitur "Lupa Password" bisa mengirim email reset)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_smtp")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_smtp (id, smtp_host, smtp_port, smtp_username, "
                   "smtp_password, smtp_gunakan_tls, email_pengirim, nama_pengirim) "
                   "VALUES (1, '', 587, '', '', 1, '', '')")
    # baris pengaturan payment gateway Tripay default (kosong, nonaktif sampai diisi admin)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_tripay")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_tripay (id, merchant_code, api_key, private_key, mode, aktif) "
                   "VALUES (1, '', '', '', 'production', 0)")
    # baris pengaturan WA Gateway (Wablas) default (kosong, nonaktif sampai diisi admin)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_wa_gateway")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_wa_gateway (id, provider, domain, token, secret_key, "
                   "nomor_pengirim, aktif) VALUES (1, 'wablas', '', '', '', '', 0)")
    # baris pengaturan Telegram Gateway default (kosong, nonaktif sampai diisi admin)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_telegram_gateway")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_telegram_gateway (id, bot_token, chat_id_default, aktif) "
                   "VALUES (1, '', '', 0)")
    # baris pengaturan GenieACS default (kosong, nonaktif -- path parameter TR-069 pakai default TR-098)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_genieacs")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_genieacs (id, url, username, password, aktif) VALUES (1, '', '', '', 0)")
    # baris pengaturan UptimeRobot default (kosong, nonaktif sampai admin isi API Key)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_uptimerobot")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_uptimerobot (id, api_key, aktif) VALUES (1, '', 0)")
    # baris pengaturan VPN Server bawaan billing default (kosong, nonaktif sampai admin
    # generate keypair server & simpan di halaman VPN Mikrotik)
    cur = db.execute("SELECT COUNT(*) c FROM pengaturan_vpn")
    if cur.fetchone()["c"] == 0:
        db.execute("INSERT INTO pengaturan_vpn (id, interface_name, listen_port, subnet_cidr, "
                   "server_privkey, server_pubkey, endpoint_host, aktif) "
                   "VALUES (1, 'wg-billing', 51820, '10.77.77.0/24', '', '', '', 0)")
    # seed 3 paket internet default (7/12/15 Mbps) supaya halaman publik pendaftaran
    # client baru (/daftar-pelanggan) langsung punya paket buat ditampilkan & dipilih.
    # PENTING: paket contoh ini CUMA data lokal di tabel "paket" milik aplikasi
    # billing sendiri -- BUKAN ditarik/disinkron dari Mikrotik. Jadi kartu
    # "Paket Internet" di Dashboard bisa saja sudah menunjukkan angka 3 walau
    # Mikrotik belum diseting/dihubungkan sama sekali ke billing; itu wajar,
    # bukan tanda ada koneksi Mikrotik yang nyasar. profile_mikrotik yang
    # ditulis di sini (mis. "paket-7mbps") cuma NAMA REFERENSI teks biasa --
    # baru benar-benar dipakai/dicocokkan ke Mikrotik saat admin memasang
    # profile PPPoE/Hotspot itu di router & menghubungkan paket ini ke NAS
    # terkait di menu Pengaturan Mikrotik.
    # Disisipkan hanya SEKALI SEUMUR HIDUP database (ditandai
    # pengaturan_umum.paket_default_diseed) -- sebelumnya dicek ulang tiap
    # start berdasar nama paket, jadi kalau admin sengaja menghapus ketiga
    # paket contoh ini (karena belum relevan/belum ada setingan Mikrotik),
    # paket itu akan muncul lagi tiap restart aplikasi. Sekarang begitu
    # ditandai "sudah diseed", penyisipan ini tidak akan pernah jalan lagi
    # walau baris paketnya dihapus admin.
    sudah_diseed_paket = db.execute(
        "SELECT paket_default_diseed FROM pengaturan_umum WHERE id=1").fetchone()
    if sudah_diseed_paket and not sudah_diseed_paket["paket_default_diseed"]:
        paket_default = [
            ("Paket 7 Mbps", "7 Mbps", 170000, "paket-7mbps", "#2f7dd9"),
            ("Paket 12 Mbps", "12 Mbps", 210000, "paket-12mbps", "#38bdf8"),
            ("Paket 15 Mbps", "15 Mbps", 325000, "paket-15mbps", "#f5a623"),
        ]
        for nama_p, kecepatan_p, harga_p, profile_p, warna_p in paket_default:
            ada = db.execute("SELECT COUNT(*) c FROM paket WHERE nama_paket=?", (nama_p,)).fetchone()["c"]
            if ada == 0:
                db.execute(
                    "INSERT INTO paket (nama_paket, kecepatan, harga, profile_mikrotik, warna, "
                    "masa_aktif, unit_masa_aktif) VALUES (?,?,?,?,?,1,'BULAN')",
                    (nama_p, kecepatan_p, harga_p, profile_p, warna_p))
        db.execute("UPDATE pengaturan_umum SET paket_default_diseed=1 WHERE id=1")
    # baris default rule pajak (PPN) untuk Billing > Configuration -- harga paket yang
    # ditampilkan dianggap sudah termasuk pajak (inclusive), supaya konsisten dengan
    # harga paket publik yang selama ini "sudah termasuk PPN".
    cur = db.execute("SELECT COUNT(*) c FROM billing_pajak_rule")
    if cur.fetchone()["c"] == 0:
        db.execute(
            """INSERT INTO billing_pajak_rule (cabang, paket_id, mode, rate, catatan, dibuat_tanggal)
               VALUES ('Any', NULL, 'inclusive', 11, 'Default perusahaan (dibuat otomatis)', ?)""",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin_id"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


LEVEL_ADMIN = {
    "administrator": "Administrator",
    "noc": "NOC",
    "cs": "CS",
    "teknisi": "Teknisi",
    "sales": "Sales",
}

# Modul apa saja yang boleh diakses tiap level admin. "administrator" selalu dianggap
# akses penuh (lihat _level_boleh_akses_modul) -- tidak perlu didaftar di sini.
# "dashboard" & endpoint yang ditangani khusus (mis. pengaturan_admin, avatar) selalu
# boleh diakses semua level yang sudah login, jadi tidak perlu dicek modul.
LEVEL_MODUL = {
    "noc":     {"dashboard", "jaringan", "radius", "vpn", "snmp", "acs", "monitoring", "router", "hotspot", "support"},
    "cs":      {"dashboard", "klien", "paket", "billing", "pembayaran", "gateway", "support"},
    "teknisi": {"dashboard", "jaringan", "support", "monitoring", "router", "acs"},
    "sales":   {"dashboard", "klien", "paket", "reseller", "analitik"},
}

# Peta endpoint (nama fungsi Flask) -> modul. Dipakai untuk membatasi akses fitur per level
# admin (lihat before_request `_cek_akses_modul_admin`). Endpoint yang tidak ada di sini
# (mis. pengaturan_admin, upload_avatar, static file, login, logout) tidak dibatasi modul --
# beberapa di antaranya punya pengecekan levelnya sendiri di dalam fungsinya (lihat
# `_wajib_administrator` di route pengaturan_admin).
ENDPOINT_MODUL = {}
_MODUL_ENDPOINTS = {
    "dashboard": ["dashboard"],
    "klien": ["pendaftaran", "pendaftaran_proses", "pendaftaran_tolak", "pendaftaran_hapus",
        "pelanggan", "hapus_pelanggan", "edit_pelanggan", "import_pelanggan_rsc", "sync_pelanggan",
        "import_pelanggan_mikrotik", "toggle_isolir", "tambah_pelanggan_cepat", "modul_inti_klien",
        "pelanggan_hapus_massal", "pelanggan_set_billing_massal", "pelanggan_kode_unik_massal",
        "pelanggan_laporan", "pelanggan_secret_massal",
        "data_customer", "data_customer_status_massal", "data_customer_ganti_router_massal"],
    "paket": ["paket", "hapus_paket", "edit_paket", "modul_inti_plans_policy"],
    "jaringan": ["odp", "edit_odp", "hapus_odp", "fleet", "edit_fleet", "hapus_fleet", "ip_pools",
        "edit_ip_pool", "hapus_ip_pool", "linknet", "edit_linknet", "hapus_linknet", "topology",
        "peta", "api_peta_data", "olt", "hapus_olt", "edit_olt", "test_olt", "import_mac_onu",
        "api_olt_sync_ssh", "onu_list", "hapus_onu", "edit_onu", "api_olt_scan", "api_olt_discover",
        "import_onu", "olt_login", "api_olt_systeminfo", "api_ppp_secrets_tersedia", "modul_inti_network"],
    "billing": ["tagihan", "generate_tagihan", "tandai_lunas", "cetak_invoice", "admin_bayar_tagihan",
        "admin_cek_status_bayar", "jalankan_isolir_otomatis", "billing_invoice", "billing_virtual_accounts",
        "billing_configuration", "billing_pajak_simpan", "billing_pajak_hapus", "billing_promo_simpan",
        "billing_promo_hapus"],
    "pembayaran": ["transfer_bank", "simpan_rekening_bank", "hapus_rekening_bank", "terima_konfirmasi_transfer",
        "tolak_konfirmasi_transfer", "catat_transfer_manual", "kas_withdraw", "simpan_kas_withdraw",
        "hapus_kas_withdraw", "payment_gateway", "payments_transactions", "payments_records",
        "payments_manual_transfers"],
    # Menu Gateway: kanal pengiriman notifikasi (WA, Telegram, Email). Pesan terkirim &
    # masuk untuk WA/Telegram sekarang tampil langsung di masing-masing halaman gateway.
    # Dipisah dari "pembayaran" supaya WA Gateway pindah ke grup menu Gateway sendiri.
    "gateway": ["wa_gateway_settings", "telegram_gateway_settings", "email_gateway_settings"],
    "support": ["tiket_gangguan", "tiket_export", "tiket_tambah", "detail_tiket", "hapus_tiket",
        "tiket_hapus_massal", "tiket_setting_notifikasi", "tiket_laporan", "tiket_laporan_pdf",
        "support_internal_tickets", "support_internal_tickets_tambah", "support_internal_tickets_status",
        "support_internal_tickets_hapus", "support_customer_tickets", "support_linknet_tickets",
        "support_linknet_tickets_tambah", "support_linknet_tickets_import", "support_linknet_tickets_status",
        "support_cs_handover", "support_cs_handover_tambah", "support_cs_handover_status",
        "support_cs_handover_hapus", "modul_inti_live_chat",
        "live_chat_auto_assign_simpan", "live_chat_quick_reply_tambah", "live_chat_quick_reply_hapus",
        "live_chat_tag_tambah", "live_chat_tag_hapus", "live_chat_broadcast_kirim",
        "live_chat_chatbot_flow_tambah", "live_chat_chatbot_flow_hapus",
        "live_chat_working_hours_simpan", "live_chat_blacklist_tambah", "live_chat_blacklist_hapus"],
    "radius": ["radius_sessions", "radius_isolation", "radius_isolation_tambah", "radius_isolation_hapus",
        "radius_configuration", "radius_configuration_simpan", "radius_configuration_hapus",
        "radius_hotspot_sessions"],
    "vpn": ["vpn_mikrotik", "vpn_server_simpan", "vpn_server_generate_key", "vpn_server_hidupkan",
        "vpn_server_matikan", "vpn_klien_tambah", "vpn_klien_toggle", "vpn_klien_hapus", "vpn_klien_script",
        "api_vpn_status", "modul_inti_vpn_akses_pengguna"],
    "hotspot": ["hotspot", "generate_voucher", "cetak_voucher", "cetak_voucher_cepat", "hapus_batch_voucher",
        "api_hotspot_servers", "api_hotspot_users", "api_hotspot_user_simpan", "api_hotspot_user_hapus",
        "api_hotspot_profile_simpan", "api_hotspot_profile_hapus", "api_hotspot_active",
        "api_hotspot_user_toggle", "api_hotspot_active_putus", "api_hotspot_profiles_detail",
        "api_mikrotik_hotspot_profiles",
        "hotspot_profil_voucher", "hotspot_profil_voucher_simpan", "hotspot_profil_voucher_hapus",
        "hotspot_profil_voucher_bulk",
        "hotspot_stok_voucher", "hotspot_stok_voucher_hapus_terpilih", "hotspot_stok_voucher_bulk",
        "hotspot_stok_voucher_sync",
        "hotspot_voucher_terjual", "hotspot_voucher_terjual_sinkron",
        "hotspot_voucher_online", "hotspot_voucher_offline",
        "hotspot_template_voucher", "hotspot_template_voucher_simpan"],
    "snmp": ["modul_inti_snmp"],
    "acs": ["modul_inti_acs", "acs_devices", "acs_devices_reboot", "acs_devices_refresh",
        "acs_devices_factory_reset", "acs_devices_hapus", "acs_configuration", "acs_configuration_simpan",
        "acs_configuration_hapus", "acs_configuration_push", "acs_tasks", "acs_tasks_hapus", "acs_profiles",
        "acs_profiles_simpan", "acs_profiles_hapus", "acs_profiles_push", "acs_firmware", "acs_firmware_simpan",
        "acs_firmware_hapus", "acs_firmware_push", "pengaturan_genieacs"],
    "monitoring": ["monitoring", "sistem_status", "sistem_monitors_ajax", "api_client_aktif",
        "api_system_resource", "api_ppp_active", "api_traffic_pelanggan", "api_traffic_summary", "api_traffic_top"],
    "router": ["router_admin", "router_admin_edit", "router_admin_hapus", "router_admin_aktifkan",
        "router_admin_test", "pengaturan_mikrotik", "pengaturan_mikrotik_hapus",
        "pengaturan_mikrotik_hapus_terpilih", "test_mikrotik", "api_mikrotik_profiles",
        "api_ppp_profiles_detail", "api_ppp_profile_simpan", "api_ppp_profile_hapus", "api_pppoe_secrets",
        "api_pppoe_secret_simpan", "api_pppoe_secret_hapus", "api_pppoe_secret_toggle", "api_pppoe_active",
        "api_pppoe_active_putus", "api_simple_queues", "api_simple_queue_simpan", "api_simple_queue_hapus",
        "api_simple_queue_toggle"],
    "reseller": ["pendaftaran_reseller", "pendaftaran_reseller_status", "pendaftaran_reseller_kirim_ulang_akun",
        "pendaftaran_reseller_hapus", "reseller_admin", "reseller_admin_edit", "reseller_admin_status",
        "reseller_admin_hapus", "pop_site_pelanggan", "pop_site_tiket", "pop_site_tiket_tambah",
        "pop_site_tiket_detail", "pop_site_tiket_hapus", "pop_site_tiket_hapus_massal",
        "pop_site_tiket_export"],
    "pengaturan": ["hapus_admin", "pengaturan_domain", "cek_cloudflared", "login_cloudflare",
        "status_login_cloudflare", "hubungkan_domain", "hapus_domain", "upload_logo", "hapus_logo",
        "backup_database", "restore_database"],
    "erp": ["modul_erp_sdm", "modul_erp_keuangan", "modul_erp_general_affair", "modul_erp_inventaris", "modul_erp_vendors"],
    "crm": ["crm_konten_crm", "crm_konten_cms", "crm_konten_dokumen"],
    "workspace": ["workspace_my_work", "workspace_projects", "workspace_calendar", "workspace_workload",
        "workspace_utilization", "workspace_activity", "workspace_mentions"],
    "analitik": ["analitik_analytics_reporting"],
    "ekstensi": ["ekstensi_rka_planning"],
    "administrasi": ["administrasi_system_administration", "administrasi_partners", "administrasi_migrasi"],
}
for _modul, _endpoints in _MODUL_ENDPOINTS.items():
    for _ep in _endpoints:
        ENDPOINT_MODUL[_ep] = _modul


def _level_admin_aktif():
    """Level admin yang sedang login sekarang ('administrator' kalau belum diset -- akun
    lama sebelum fitur level ini ada, atau kalau bukan sesi admin sama sekali)."""
    return session.get("admin_level") or "administrator"


def _level_boleh_akses_modul(level, modul):
    if level == "administrator":
        return True
    return modul in LEVEL_MODUL.get(level, set())


def _wajib_administrator():
    """True kalau yang sedang login admin dengan level Administrator. Dipakai di dalam
    route yang beberapa aksinya lintas-level (mis. pengaturan_admin: ubah profil sendiri
    boleh semua level, tapi tambah/hapus user admin & pengaturan sistem cuma Administrator)."""
    return _level_admin_aktif() == "administrator"


@app.after_request
def _cegah_cache_halaman(response):
    """Matikan cache browser khusus untuk respons HTML (halaman biasa, bukan
    file statis seperti css/js/gambar). Tujuannya: kalau user tekan tombol
    back di browser, buka tab lama, atau reopen browser, halaman yang
    terakhir dilihat (mis. halaman Customer) TIDAK ditampilkan dari cache --
    browser dipaksa minta ulang ke server, jadi setiap kali "masuk" lagi
    aturan redirect di atas (login/root -> Dashboard) selalu berlaku."""
    if response.mimetype == "text/html":
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


@app.before_request
def _cek_akses_modul_admin():
    if not session.get("admin_id"):
        return None
    modul = ENDPOINT_MODUL.get(request.endpoint)
    if modul is None:
        return None
    level = _level_admin_aktif()
    if not _level_boleh_akses_modul(level, modul):
        flash("Kamu tidak punya akses ke fitur itu. Hubungi Administrator kalau butuh akses lebih.", "danger")
        return redirect(url_for("dashboard"))
    return None


def admin_atau_reseller_required(f):
    """Dipakai endpoint yang dipakai bersama admin master DAN dashboard reseller
    (mis. sync/isolir 1 pelanggan) -- login salah satu boleh, tapi kalau yang
    login reseller, kepemilikan pelanggan/router yang diakses tetap dicek di
    dalam fungsinya masing-masing (lihat helper `_boleh_akses_pelanggan`)."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin_id") and not session.get("reseller_id"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def _boleh_akses_pelanggan(pelanggan_row):
    """True kalau user yang sedang login (admin master ATAU reseller pemilik)
    boleh mengakses/mengubah baris pelanggan ini."""
    if session.get("admin_id"):
        return True
    if session.get("reseller_id"):
        return pelanggan_row and pelanggan_row["reseller_id"] == session["reseller_id"]
    return False


def pelanggan_login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("pelanggan_id"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def reseller_login_required(f):
    """Proteksi khusus dashboard reseller. Sekaligus mengecek status akun reseller
    masih 'aktif' -- kalau admin master menonaktifkan reseller ini, sesi lamanya
    otomatis ditolak walau cookie sesi masih ada."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("reseller_id"):
            return redirect(url_for("reseller_login"))
        db = get_db()
        row = db.execute("SELECT status FROM reseller WHERE id=?", (session["reseller_id"],)).fetchone()
        if not row or row["status"] != "aktif":
            session.pop("reseller_id", None)
            session.pop("reseller_nama", None)
            flash("Akun reseller Anda tidak aktif. Hubungi admin.", "danger")
            return redirect(url_for("reseller_login"))
        return f(*args, **kwargs)
    return wrapper


def _alamat_ip_klien():
    # kalau nanti dijalankan di belakang reverse proxy/tunnel yang meneruskan header ini
    depan = request.headers.get("X-Forwarded-For", "")
    if depan:
        return depan.split(",")[0].strip()
    return request.remote_addr or "unknown"


def _cek_kunci_login(ip):
    catatan = PERCOBAAN_LOGIN_GAGAL.get(ip)
    if not catatan:
        return False, 0
    gagal, waktu_terakhir = catatan
    if gagal >= BATAS_PERCOBAAN_LOGIN:
        sisa = DURASI_KUNCI_DETIK - (datetime.now().timestamp() - waktu_terakhir)
        if sisa > 0:
            return True, int(sisa)
        PERCOBAAN_LOGIN_GAGAL.pop(ip, None)  # sudah lewat masa kunci, reset
    return False, 0


def _catat_login_gagal(ip):
    gagal, _ = PERCOBAAN_LOGIN_GAGAL.get(ip, (0, 0))
    PERCOBAAN_LOGIN_GAGAL[ip] = (gagal + 1, datetime.now().timestamp())


def _catat_aktivitas_login(tipe, username, status, ip):
    """Simpan riwayat percobaan login (berhasil/gagal) untuk ditampilkan
    di widget Aktifitas pada dashboard."""
    try:
        db = get_db()
        db.execute(
            "INSERT INTO login_log (tipe, username, status, alamat_ip, waktu) VALUES (?,?,?,?,?)",
            (tipe, username or "-", status, ip, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        db.commit()
    except sqlite3.OperationalError:
        pass


def _catat_aktivitas(kategori, aksi, keterangan="", status="berhasil"):
    """Simpan riwayat perubahan data PPPoE / Hotspot / User Admin, supaya selalu
    muncul bersama riwayat login di widget Aktifitas pada dashboard."""
    try:
        db = get_db()
        pelaku = (session.get("admin_username") or session.get("admin_nama")
                  or session.get("reseller_username") or session.get("pelanggan_nama") or "-")
        db.execute(
            "INSERT INTO aktivitas_sistem (kategori, aksi, keterangan, status, dibuat_oleh, waktu) "
            "VALUES (?,?,?,?,?,?)",
            (kategori, aksi, keterangan or "", status, pelaku,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        db.commit()
    except sqlite3.OperationalError:
        pass


PER_PAGE_OPTIONS = [10, 25, 50, 100]


def _kapasitas_display_pelanggan(total_aktif, total_pelanggan):
    """Skala 'kapasitas' pembanding untuk bar visual widget 'Pelanggan Online (Aktif)'
    di Dashboard. Kalau dihitung langsung dari total_aktif/total_pelanggan, begitu SEMUA
    pelanggan yang ada berstatus aktif (walau baru 1-2 orang), barnya langsung penuh 100%
    -- padahal itu bukan berarti sistemnya sudah 'penuh'. Jadi kapasitasnya dibikin selalu
    sedikit di atas jumlah pelanggan saat ini (headroom 25%, minimal +5), supaya bar-nya
    naik/turun BERTAHAP mengikuti setiap perubahan angka pelanggan (bukan meloncat antar
    ambang tetap seperti 10/25/50), dan tetap tidak pernah kelihatan penuh kaku."""
    basis = max(total_aktif, total_pelanggan)
    headroom = max(5, math.ceil(basis * 0.25))
    return basis + headroom


def _paginate(items, default_per_page=25):
    """Helper pagination generik dipakai di semua menu yang punya tabel/antrian
    (tiket, pelanggan, dll) supaya tidak semua baris tampil sekaligus.
    Baca parameter ?page= & ?per_page= dari URL (dropdown 10/25/50/100),
    lalu potong `items` (list/hasil fetchall) sesuai halaman yang diminta."""
    try:
        per_page = int(request.args.get("per_page", default_per_page))
    except (TypeError, ValueError):
        per_page = default_per_page
    if per_page not in PER_PAGE_OPTIONS:
        per_page = default_per_page

    total = len(items)
    total_halaman = max(1, math.ceil(total / per_page))

    try:
        page = int(request.args.get("page", 1))
    except (TypeError, ValueError):
        page = 1
    if page < 1:
        page = 1
    if page > total_halaman:
        page = total_halaman

    mulai = (page - 1) * per_page
    selesai = mulai + per_page

    return {
        "items": items[mulai:selesai],
        "page": page,
        "per_page": per_page,
        "per_page_options": PER_PAGE_OPTIONS,
        "total": total,
        "total_halaman": total_halaman,
        "mulai": (mulai + 1) if total else 0,
        "selesai": selesai if selesai < total else total,
    }


# ---------------------------------------------------------------------------
# Fitur "Lupa Password" — kirim link reset password lewat email (SMTP)
# ---------------------------------------------------------------------------
def _ambil_pengaturan_smtp():
    db = get_db()
    return db.execute("SELECT * FROM pengaturan_smtp WHERE id=1").fetchone()


def _ambil_nama_aplikasi():
    db = get_db()
    row = db.execute("SELECT nama_aplikasi FROM pengaturan_umum WHERE id=1").fetchone()
    return row["nama_aplikasi"] if row and row["nama_aplikasi"] else "Billing Portal"


def kirim_email_tes_gateway(email_tujuan):
    """Kirim email tes sederhana lewat SMTP sesuai Pengaturan Email Gateway.
    Dipakai tombol 'Kirim Email Tes' di halaman Gateway > Email, supaya jelas
    beda dari email reset password (isinya bukan link reset, cuma pesan tes biasa).
    Return (berhasil: bool, pesan_error: str|None)."""
    smtp = _ambil_pengaturan_smtp()
    if not smtp or not smtp["smtp_host"] or not smtp["email_pengirim"]:
        return False, "Pengaturan SMTP/email belum diisi."

    nama_aplikasi = _ambil_nama_aplikasi()
    nama_pengirim = smtp["nama_pengirim"] or nama_aplikasi

    pesan = MIMEMultipart("alternative")
    pesan["Subject"] = f"Email Tes Gateway - {nama_aplikasi}"
    pesan["From"] = f'{nama_pengirim} <{smtp["email_pengirim"]}>'
    pesan["To"] = email_tujuan

    teks_polos = (
        f"Ini email tes dari {nama_aplikasi} (Email Gateway) — kalau kamu menerima ini, "
        f"berarti pengaturan Email Gateway kamu sudah benar."
    )
    teks_html = f"""
    <div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:0 auto;">
      <h2 style="color:#1c5aa8;">Email Tes Gateway</h2>
      <p>Ini email tes dari <strong>{nama_aplikasi}</strong> (Email Gateway) — kalau kamu menerima ini,
         berarti pengaturan Email Gateway kamu sudah benar.</p>
    </div>
    """
    pesan.attach(MIMEText(teks_polos, "plain"))
    pesan.attach(MIMEText(teks_html, "html"))

    try:
        port = smtp["smtp_port"] or 587
        if smtp["smtp_gunakan_tls"]:
            server = smtplib.SMTP(smtp["smtp_host"], port, timeout=15)
            server.starttls()
        else:
            server = smtplib.SMTP_SSL(smtp["smtp_host"], port, timeout=15)
        try:
            if smtp["smtp_username"]:
                server.login(smtp["smtp_username"], smtp["smtp_password"] or "")
            server.sendmail(smtp["email_pengirim"], [email_tujuan], pesan.as_string())
        finally:
            server.quit()
        return True, None
    except Exception as e:
        return False, str(e)


def kirim_email_reset_password(email_tujuan, nama_tujuan, link_reset):
    """Kirim email berisi link reset password lewat SMTP sesuai Pengaturan Admin.
    Return (berhasil: bool, pesan_error: str|None)."""
    smtp = _ambil_pengaturan_smtp()
    if not smtp or not smtp["smtp_host"] or not smtp["email_pengirim"]:
        return False, "Pengaturan SMTP/email belum diisi. Isi dulu di menu Pengaturan Admin."

    nama_aplikasi = _ambil_nama_aplikasi()
    nama_pengirim = smtp["nama_pengirim"] or nama_aplikasi

    pesan = MIMEMultipart("alternative")
    pesan["Subject"] = f"Reset Password - {nama_aplikasi}"
    pesan["From"] = f'{nama_pengirim} <{smtp["email_pengirim"]}>'
    pesan["To"] = email_tujuan

    teks_polos = (
        f"Halo {nama_tujuan},\n\n"
        f"Kami menerima permintaan reset password untuk akun kamu di {nama_aplikasi}.\n"
        f"Buka link berikut untuk membuat password baru (berlaku 1 jam):\n{link_reset}\n\n"
        f"Kalau kamu tidak merasa meminta ini, abaikan saja email ini, password kamu tidak akan berubah."
    )
    teks_html = f"""
    <div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:0 auto;">
      <h2 style="color:#1c5aa8;">Reset Password</h2>
      <p>Halo <strong>{nama_tujuan}</strong>,</p>
      <p>Kami menerima permintaan reset password untuk akun kamu di <strong>{nama_aplikasi}</strong>.</p>
      <p>Klik tombol di bawah untuk membuat password baru. Link ini hanya berlaku selama <strong>1 jam</strong>
         dan hanya bisa dipakai sekali.</p>
      <p style="text-align:center;margin:28px 0;">
        <a href="{link_reset}" style="background:#1c5aa8;color:#fff;padding:12px 24px;border-radius:6px;
           text-decoration:none;font-weight:bold;display:inline-block;">Reset Password</a>
      </p>
      <p style="font-size:0.85rem;color:#666;">Atau salin link ini ke browser kamu:<br>{link_reset}</p>
      <p style="font-size:0.85rem;color:#666;">Kalau kamu tidak merasa meminta ini, abaikan saja email ini,
         password kamu tidak akan berubah.</p>
    </div>
    """
    pesan.attach(MIMEText(teks_polos, "plain"))
    pesan.attach(MIMEText(teks_html, "html"))

    try:
        port = smtp["smtp_port"] or 587
        if smtp["smtp_gunakan_tls"]:
            server = smtplib.SMTP(smtp["smtp_host"], port, timeout=15)
            server.starttls()
        else:
            server = smtplib.SMTP_SSL(smtp["smtp_host"], port, timeout=15)
        try:
            if smtp["smtp_username"]:
                server.login(smtp["smtp_username"], smtp["smtp_password"] or "")
            server.sendmail(smtp["email_pengirim"], [email_tujuan], pesan.as_string())
        finally:
            server.quit()
        return True, None
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Pendaftaran Reseller -- generate & kirim akun (username/password) otomatis
# lewat email begitu admin mengaktifkan status jadi "berlangganan".
# ---------------------------------------------------------------------------
def _buat_username_reseller(nama_bisnis, cid):
    """Buat username dari nama usaha (huruf kecil, tanpa spasi/simbol) + id
    pendaftaran supaya unik, mis. "JUAN.NET" -> "juannet7"."""
    basis = re.sub(r"[^a-z0-9]", "", (nama_bisnis or "").lower())
    if not basis:
        basis = "reseller"
    return f"{basis[:16]}{cid}"


def _buat_password_reseller(panjang=10):
    """Buat password acak yang aman pakai modul secrets (huruf besar/kecil + angka)."""
    abjad = string.ascii_letters + string.digits
    return "".join(secrets.choice(abjad) for _ in range(panjang))


def _buat_atau_perbarui_akun_reseller(db, calon, cid, username, password):
    """Bikin (atau perbarui password) akun reseller SUNGGUHAN di tabel `reseller`
    supaya username/password yang dikirim lewat email benar-benar bisa dipakai
    login di /reseller/login -- bukan cuma catatan teks seperti sebelumnya."""
    ada = db.execute("SELECT id FROM reseller WHERE pendaftaran_id=?", (cid,)).fetchone()
    if ada:
        db.execute(
            "UPDATE reseller SET username=?, password_hash=?, nama_bisnis=?, nama_pic=?, "
            "no_hp=?, email=?, status='aktif' WHERE id=?",
            (username, hash_password(password), calon["nama_bisnis"], calon["nama_pic"],
             calon["no_hp"], calon["email"], ada["id"]))
    else:
        db.execute(
            """INSERT INTO reseller (username, password_hash, nama_bisnis, nama_pic, no_hp, email,
                                      status, pendaftaran_id, tanggal_dibuat)
               VALUES (?,?,?,?,?,?, 'aktif', ?, ?)""",
            (username, hash_password(password), calon["nama_bisnis"], calon["nama_pic"],
             calon["no_hp"], calon["email"], cid, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))


def kirim_email_akun_reseller_aktif(email_tujuan, nama_pic, nama_bisnis, username, password):
    """Kirim email selamat datang berisi username & password akun reseller yang
    baru diaktifkan. Return (berhasil: bool, pesan_error: str|None)."""
    smtp = _ambil_pengaturan_smtp()
    if not smtp or not smtp["smtp_host"] or not smtp["email_pengirim"]:
        return False, "Pengaturan SMTP/email belum diisi. Isi dulu di menu Pengaturan Admin."

    nama_aplikasi = _ambil_nama_aplikasi()
    nama_pengirim = smtp["nama_pengirim"] or nama_aplikasi

    pesan = MIMEMultipart("alternative")
    pesan["Subject"] = f"Selamat! Akun Reseller Anda Sudah Aktif - {nama_aplikasi}"
    pesan["From"] = f'{nama_pengirim} <{smtp["email_pengirim"]}>'
    pesan["To"] = email_tujuan

    teks_polos = (
        f"Halo {nama_pic},\n\n"
        f"Selamat, akun reseller Anda sudah aktif di {nama_aplikasi}.\n"
        f"Berikut detail akun untuk usaha \"{nama_bisnis}\":\n\n"
        f"Username : {username}\n"
        f"Password : {password}\n\n"
        f"Mohon segera login dan ganti password bawaan di atas demi keamanan akun Anda.\n"
        f"Terima kasih sudah bergabung bersama {nama_aplikasi}."
    )
    teks_html = f"""
    <div style="font-family:Arial,Helvetica,sans-serif;max-width:480px;margin:0 auto;">
      <h2 style="color:#1c9c4a;">Selamat, Akun Reseller Anda Sudah Aktif!</h2>
      <p>Halo <strong>{nama_pic}</strong>,</p>
      <p>Selamat, akun reseller Anda sudah aktif di <strong>{nama_aplikasi}</strong> untuk usaha
         <strong>{nama_bisnis}</strong>. Berikut detail akun Anda:</p>
      <table style="width:100%;border-collapse:collapse;margin:20px 0;">
        <tr>
          <td style="padding:10px 14px;background:#f1f5f9;border:1px solid #e2e8f0;font-weight:bold;">Username</td>
          <td style="padding:10px 14px;background:#f1f5f9;border:1px solid #e2e8f0;">{username}</td>
        </tr>
        <tr>
          <td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:bold;">Password</td>
          <td style="padding:10px 14px;border:1px solid #e2e8f0;">{password}</td>
        </tr>
      </table>
      <p style="font-size:0.9rem;color:#666;">Mohon segera login dan ganti password bawaan di atas demi
         keamanan akun Anda.</p>
      <p>Terima kasih sudah bergabung bersama <strong>{nama_aplikasi}</strong>.</p>
    </div>
    """
    pesan.attach(MIMEText(teks_polos, "plain"))
    pesan.attach(MIMEText(teks_html, "html"))

    try:
        port = smtp["smtp_port"] or 587
        if smtp["smtp_gunakan_tls"]:
            server = smtplib.SMTP(smtp["smtp_host"], port, timeout=15)
            server.starttls()
        else:
            server = smtplib.SMTP_SSL(smtp["smtp_host"], port, timeout=15)
        try:
            if smtp["smtp_username"]:
                server.login(smtp["smtp_username"], smtp["smtp_password"] or "")
            server.sendmail(smtp["email_pengirim"], [email_tujuan], pesan.as_string())
        finally:
            server.quit()
        return True, None
    except Exception as e:
        return False, str(e)


@app.route("/set-language/<lang_code>")
def set_language(lang_code):
    """Ganti bahasa aktif (disimpan di session) lalu kembali ke halaman asal.
    Dipanggil dari dropdown pemilih bahasa di halaman login & navbar."""
    if lang_code in LANGUAGES:
        session["bahasa"] = lang_code
    tujuan = request.referrer or url_for("login")
    return redirect(tujuan)


@app.route("/")
def beranda_awal():
    """Pintu masuk utama aplikasi. Selalu diarahkan ke Dashboard kalau sesi
    admin masih aktif (jangan pernah "nyangkut" ke halaman terakhir yang
    sempat dibuka sebelumnya, mis. halaman Customer) -- kalau belum login,
    lempar ke halaman login seperti biasa."""
    if session.get("admin_id"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/adminrad", methods=["GET", "POST"])
def login():
    ip = _alamat_ip_klien()

    # Kalau sesi admin masih aktif (mis. buka lagi tab/browser yang lama,
    # atau pencet tombol back ke halaman login) -- langsung lempar ke
    # Dashboard, jangan tampilkan form login lagi.
    if request.method == "GET" and session.get("admin_id"):
        return redirect(url_for("dashboard"))

    terkunci, sisa_detik = _cek_kunci_login(ip)
    if terkunci:
        flash(f"Terlalu banyak percobaan login gagal. Coba lagi dalam {sisa_detik // 60 + 1} menit.", "danger")
        return render_template("login.html", paksa_layout_publik=True)

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        row = db.execute("SELECT * FROM admin WHERE username=?", (username,)).fetchone()
        if row and row["password_hash"] == hash_password(password):
            PERCOBAAN_LOGIN_GAGAL.pop(ip, None)
            session["admin_id"] = row["id"]
            session["admin_username"] = row["username"]
            session["admin_nama"] = row["nama"] or row["username"]
            session["admin_level"] = row["level"] or "administrator"
            _catat_aktivitas_login("admin", row["username"], "berhasil", ip)
            return redirect(url_for("dashboard"))
        _catat_login_gagal(ip)
        _catat_aktivitas_login("admin", username, "gagal", ip)
        flash("Username atau password salah.", "danger")
    return render_template("login.html", paksa_layout_publik=True)


# ---------------------------------------------------------------------------
# Login & dashboard Reseller -- akun terpisah dari admin master. Reseller
# punya sesi sendiri (session["reseller_id"]) dan cuma bisa lihat/kelola
# router (POP) & pelanggan miliknya sendiri (reseller_id miliknya).
# ---------------------------------------------------------------------------
@app.route("/reseller/login", methods=["GET", "POST"])
def reseller_login():
    ip = _alamat_ip_klien()
    terkunci, sisa_detik = _cek_kunci_login(ip)
    if terkunci:
        flash(f"Terlalu banyak percobaan login gagal. Coba lagi dalam {sisa_detik // 60 + 1} menit.", "danger")
        return render_template("reseller_login.html", paksa_layout_publik=True)

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        row = db.execute("SELECT * FROM reseller WHERE username=?", (username,)).fetchone()
        if row and row["password_hash"] == hash_password(password):
            if row["status"] != "aktif":
                flash("Akun reseller ini sedang tidak aktif. Hubungi admin.", "danger")
                return render_template("reseller_login.html", paksa_layout_publik=True)
            PERCOBAAN_LOGIN_GAGAL.pop(ip, None)
            # Sesi reseller & admin sengaja dibuat independen -- login sebagai
            # reseller TIDAK menghapus sesi admin yang mungkin masih aktif di
            # browser yang sama, begitu pun sebaliknya (lihat route /logout).
            # Jadi admin bisa buka dashboard admin & dashboard reseller di tab
            # berbeda tanpa saling terlempar keluar.
            session["reseller_id"] = row["id"]
            session["reseller_nama"] = row["nama_bisnis"]
            session["reseller_username"] = row["username"]
            _catat_aktivitas_login("reseller", row["username"], "berhasil", ip)
            return redirect(url_for("reseller_dashboard"))
        _catat_login_gagal(ip)
        _catat_aktivitas_login("reseller", username, "gagal", ip)
        flash("Username atau password salah.", "danger")
    return render_template("reseller_login.html", paksa_layout_publik=True)


@app.route("/reseller/logout")
def reseller_logout():
    session.pop("reseller_id", None)
    session.pop("reseller_nama", None)
    session.pop("reseller_username", None)
    return redirect(url_for("reseller_login"))


@app.route("/reseller/dashboard")
@reseller_login_required
def reseller_dashboard():
    db = get_db()
    rid = session["reseller_id"]
    total_pelanggan = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE reseller_id=?", (rid,)).fetchone()["c"]
    total_aktif = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE reseller_id=? AND status='aktif'", (rid,)).fetchone()["c"]
    total_isolir = total_pelanggan - total_aktif
    total_router = db.execute(
        "SELECT COUNT(*) c FROM router WHERE reseller_id=?", (rid,)).fetchone()["c"]

    periode_ini = date.today().strftime("%Y-%m")
    tagihan_bulan_ini = db.execute(
        """SELECT COUNT(*) c, COALESCE(SUM(t.jumlah),0) total FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE p.reseller_id=? AND t.periode=?""", (rid, periode_ini)).fetchone()
    belum_lunas_bulan_ini = db.execute(
        """SELECT COUNT(*) c, COALESCE(SUM(t.jumlah),0) total FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE p.reseller_id=? AND t.periode=? AND t.status='belum_lunas'""",
        (rid, periode_ini)).fetchone()

    daftar_router = db.execute(
        "SELECT * FROM router WHERE reseller_id=? ORDER BY id DESC", (rid,)).fetchall()

    return render_template(
        "reseller_dashboard.html",
        total_pelanggan=total_pelanggan,
        total_aktif=total_aktif,
        total_isolir=total_isolir,
        total_router=total_router,
        periode_ini=periode_ini,
        tagihan_bulan_ini=tagihan_bulan_ini,
        belum_lunas_bulan_ini=belum_lunas_bulan_ini,
        daftar_router=daftar_router,
    )


# --------- Reseller: POP (router miliknya sendiri) ---------
@app.route("/reseller/pop", methods=["GET", "POST"])
@reseller_login_required
def reseller_pop():
    db = get_db()
    rid = session["reseller_id"]
    if request.method == "POST":
        nama_router = request.form.get("nama_router", "").strip()
        host = request.form.get("host", "").strip()
        port = int(request.form.get("port") or 8728)
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        metode_koneksi = request.form.get("metode_koneksi", "langsung").strip() or "langsung"
        nama_tunnel = request.form.get("nama_tunnel", "").strip() or None
        if not nama_router or not host:
            flash("Nama POP dan Host wajib diisi.", "danger")
        else:
            db.execute(
                """INSERT INTO router (reseller_id, nama_router, host, port, username, password,
                                        metode_koneksi, nama_tunnel, status, tanggal_dibuat)
                   VALUES (?,?,?,?,?,?,?,?, 'aktif', ?)""",
                (rid, nama_router, host, port, username, password, metode_koneksi, nama_tunnel,
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            db.commit()
            flash(f"POP/Router '{nama_router}' berhasil ditambahkan.", "success")
        return redirect(url_for("reseller_pop"))

    daftar_router = db.execute(
        "SELECT * FROM router WHERE reseller_id=? ORDER BY id DESC", (rid,)).fetchall()
    return render_template("reseller_pop.html", daftar_router=daftar_router)


@app.route("/reseller/pop/edit/<int:router_id>", methods=["POST"])
@reseller_login_required
def reseller_pop_edit(router_id):
    db = get_db()
    rid = session["reseller_id"]
    row = db.execute("SELECT * FROM router WHERE id=? AND reseller_id=?", (router_id, rid)).fetchone()
    if not row:
        flash("Router tidak ditemukan.", "danger")
        return redirect(url_for("reseller_pop"))
    nama_router = request.form.get("nama_router", "").strip()
    host = request.form.get("host", "").strip()
    port = int(request.form.get("port") or 8728)
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip() or row["password"]
    metode_koneksi = request.form.get("metode_koneksi", "langsung").strip() or "langsung"
    nama_tunnel = request.form.get("nama_tunnel", "").strip() or None
    db.execute(
        """UPDATE router SET nama_router=?, host=?, port=?, username=?, password=?,
           metode_koneksi=?, nama_tunnel=? WHERE id=?""",
        (nama_router, host, port, username, password, metode_koneksi, nama_tunnel, router_id))
    db.commit()
    flash("Router berhasil diperbarui.", "success")
    return redirect(url_for("reseller_pop"))


@app.route("/reseller/pop/hapus/<int:router_id>", methods=["POST"])
@reseller_login_required
def reseller_pop_hapus(router_id):
    db = get_db()
    rid = session["reseller_id"]
    row = db.execute("SELECT * FROM router WHERE id=? AND reseller_id=?", (router_id, rid)).fetchone()
    if not row:
        flash("Router tidak ditemukan.", "danger")
        return redirect(url_for("reseller_pop"))
    jumlah = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE router_id=?", (router_id,)).fetchone()["c"]
    if jumlah > 0:
        flash(f"Router tidak bisa dihapus, masih dipakai {jumlah} pelanggan. "
              f"Pindahkan dulu pelanggannya ke router lain.", "danger")
        return redirect(url_for("reseller_pop"))
    db.execute("DELETE FROM router WHERE id=?", (router_id,))
    db.commit()
    flash("Router dihapus.", "success")
    return redirect(url_for("reseller_pop"))


@app.route("/reseller/pop/test/<int:router_id>", methods=["POST"])
@reseller_login_required
def reseller_pop_test(router_id):
    db = get_db()
    rid = session["reseller_id"]
    row = db.execute("SELECT * FROM router WHERE id=? AND reseller_id=?", (router_id, rid)).fetchone()
    if not row:
        return jsonify(ok=False, message="Router tidak ditemukan.")
    client = _get_mikrotik_client(router_id)
    if not client:
        return jsonify(ok=False, message="Isi host/username dahulu.")
    try:
        identity = client.test_connection()
        return jsonify(ok=True, message=f"Berhasil konek! Identity router: {identity}")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal konek (error tak terduga): {e}")


# --------- Reseller: Tiket (request maintenance ke admin/POP Site) ---------
@app.route("/reseller/tiket", methods=["GET", "POST"])
@reseller_login_required
def reseller_tiket():
    """Halaman reseller untuk mengajukan tiket maintenance/gangguan POP baru &
    memantau status tiket-tiket yang pernah dia ajukan. Ini yang jadi 'topologi'
    permintaan maintenance reseller: reseller lapor di sini -> muncul & ditindaklanjuti
    admin di menu POP Site > Tiket -> status/catatannya kebaca lagi di sini."""
    db = get_db()
    rid = session["reseller_id"]

    if request.method == "POST":
        router_id = request.form.get("router_id", "").strip() or None
        kategori = request.form.get("kategori", "maintenance").strip() or "maintenance"
        if kategori not in KATEGORI_TIKET_RESELLER_LABEL:
            kategori = "maintenance"
        judul = request.form.get("judul", "").strip()
        deskripsi = request.form.get("deskripsi", "").strip()
        prioritas = request.form.get("prioritas", "medium")
        if prioritas not in PRIORITAS_LABEL:
            prioritas = "medium"

        if router_id:
            router_valid = db.execute(
                "SELECT id FROM router WHERE id=? AND reseller_id=?", (router_id, rid)).fetchone()
            if not router_valid:
                router_id = None

        if not judul or not deskripsi:
            flash("Judul dan deskripsi permintaan wajib diisi.", "danger")
        else:
            db.execute(
                """INSERT INTO tiket_reseller (reseller_id, router_id, kategori, judul, deskripsi,
                                                prioritas, status, dibuat_pada)
                   VALUES (?,?,?,?,?,?, 'baru', ?)""",
                (rid, router_id, kategori, judul, deskripsi, prioritas, _sekarang()))
            db.commit()
            flash("Permintaan tiket berhasil dikirim. Tim POP Site akan segera menindaklanjuti.", "success")
        return redirect(url_for("reseller_tiket"))

    daftar_router = db.execute(
        "SELECT id, nama_router FROM router WHERE reseller_id=? ORDER BY nama_router", (rid,)).fetchall()
    daftar_tiket = db.execute(
        """SELECT tr.*, rt.nama_router FROM tiket_reseller tr
           LEFT JOIN router rt ON rt.id = tr.router_id
           WHERE tr.reseller_id=? ORDER BY tr.id DESC""", (rid,)).fetchall()
    jumlah_per_status = {
        s: sum(1 for t in daftar_tiket if t["status"] == s) for s in STATUS_TIKET_RESELLER_LABEL
    }

    return render_template(
        "reseller_tiket.html", daftar_tiket=daftar_tiket, daftar_router=daftar_router,
        jumlah_per_status=jumlah_per_status, total_tiket=len(daftar_tiket),
        status_label=STATUS_TIKET_RESELLER_LABEL, kategori_label=KATEGORI_TIKET_RESELLER_LABEL,
        prioritas_label=PRIORITAS_LABEL)


@app.route("/reseller/tiket/<int:tiket_id>")
@reseller_login_required
def reseller_tiket_detail(tiket_id):
    """Detail satu tiket maintenance milik reseller yang sedang login -- lihat
    progres & catatan dari admin POP Site."""
    db = get_db()
    rid = session["reseller_id"]
    tk = db.execute(
        """SELECT tr.*, rt.nama_router FROM tiket_reseller tr
           LEFT JOIN router rt ON rt.id = tr.router_id
           WHERE tr.id=? AND tr.reseller_id=?""", (tiket_id, rid)).fetchone()
    if not tk:
        flash("Tiket tidak ditemukan.", "danger")
        return redirect(url_for("reseller_tiket"))
    return render_template(
        "reseller_tiket_detail.html", tk=tk, status_label=STATUS_TIKET_RESELLER_LABEL,
        kategori_label=KATEGORI_TIKET_RESELLER_LABEL)


# --------- Reseller: Pelanggan miliknya sendiri ---------
@app.route("/reseller/pelanggan", methods=["GET", "POST"])
@reseller_login_required
def reseller_pelanggan():
    db = get_db()
    rid = session["reseller_id"]
    daftar_router = db.execute(
        "SELECT * FROM router WHERE reseller_id=? ORDER BY nama_router", (rid,)).fetchall()

    if request.method == "POST":
        if not daftar_router:
            flash("Tambahkan minimal 1 POP/Router dulu sebelum menambah pelanggan.", "danger")
            return redirect(url_for("reseller_pelanggan"))
        nama = request.form["nama"].strip()
        alamat = request.form.get("alamat", "").strip()
        no_hp = request.form.get("no_hp", "").strip()
        username_pppoe = request.form["username_pppoe"].strip()
        password_pppoe = request.form["password_pppoe"].strip()
        paket_id = request.form["paket_id"]
        router_id = request.form.get("router_id", "").strip()
        router_valid = any(str(r["id"]) == router_id for r in daftar_router)
        if not router_valid:
            flash("Pilih POP/Router yang valid (milik Anda sendiri).", "danger")
            return redirect(url_for("reseller_pelanggan"))
        try:
            db.execute(
                """INSERT INTO pelanggan
                   (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id, status,
                    tanggal_daftar, router_id, reseller_id)
                   VALUES (?,?,?,?,?,?, 'aktif', ?,?,?)""",
                (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id,
                 date.today().isoformat(), router_id, rid))
            db.commit()
            flash("Pelanggan ditambahkan. Jangan lupa sinkronkan ke Mikrotik lewat menu Pelanggan.", "success")
        except sqlite3.IntegrityError:
            flash("Username PPPoE sudah dipakai pelanggan lain.", "danger")
        return redirect(url_for("reseller_pelanggan"))

    daftar_pelanggan = db.execute(
        """SELECT pl.*, pk.nama_paket, pk.harga, r.nama_router
           FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
           LEFT JOIN router r ON r.id = pl.router_id
           WHERE pl.reseller_id=? ORDER BY pl.id DESC""", (rid,)).fetchall()
    daftar_paket = db.execute("SELECT * FROM paket ORDER BY nama_paket").fetchall()

    # Router aktif dipakai oleh tab Profiles/Secrets/Active Connections (menu PPPoE)
    # yang berbicara langsung ke Mikrotik per-router, mirip pola di menu Hotspot.
    router_id_dipilih = request.args.get("router_id", "").strip()
    router_aktif = None
    if router_id_dipilih:
        router_aktif = next((r for r in daftar_router if str(r["id"]) == router_id_dipilih), None)
    if not router_aktif and daftar_router:
        router_aktif = daftar_router[0]

    return render_template(
        "reseller_pelanggan.html",
        daftar_pelanggan=daftar_pelanggan,
        daftar_paket=daftar_paket,
        daftar_router=daftar_router,
        router_aktif=router_aktif,
    )


@app.route("/reseller/pelanggan/edit/<int:pid>", methods=["POST"])
@reseller_login_required
def reseller_pelanggan_edit(pid):
    db = get_db()
    rid = session["reseller_id"]
    row = db.execute("SELECT * FROM pelanggan WHERE id=? AND reseller_id=?", (pid, rid)).fetchone()
    if not row:
        flash("Pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("reseller_pelanggan"))
    daftar_router = db.execute("SELECT id FROM router WHERE reseller_id=?", (rid,)).fetchall()
    router_id = request.form.get("router_id", "").strip()
    if not any(str(r["id"]) == router_id for r in daftar_router):
        flash("Pilih POP/Router yang valid (milik Anda sendiri).", "danger")
        return redirect(url_for("reseller_pelanggan"))

    nama = request.form["nama"].strip()
    alamat = request.form.get("alamat", "").strip()
    no_hp = request.form.get("no_hp", "").strip()
    username_pppoe = request.form["username_pppoe"].strip()
    password_pppoe = request.form.get("password_pppoe", "").strip() or row["password_pppoe"]
    paket_id = request.form["paket_id"]
    try:
        db.execute(
            """UPDATE pelanggan SET nama=?, alamat=?, no_hp=?, username_pppoe=?, password_pppoe=?,
               paket_id=?, router_id=? WHERE id=?""",
            (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id, router_id, pid))
        db.commit()
        flash("Data pelanggan berhasil diperbarui.", "success")
    except sqlite3.IntegrityError:
        flash("Username PPPoE sudah dipakai pelanggan lain.", "danger")
    return redirect(url_for("reseller_pelanggan"))


@app.route("/reseller/pelanggan/hapus/<int:pid>", methods=["POST"])
@reseller_login_required
def reseller_pelanggan_hapus(pid):
    db = get_db()
    rid = session["reseller_id"]
    row = db.execute("SELECT id FROM pelanggan WHERE id=? AND reseller_id=?", (pid, rid)).fetchone()
    if not row:
        flash("Pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("reseller_pelanggan"))
    db.execute("DELETE FROM pelanggan WHERE id=?", (pid,))
    db.commit()
    flash("Pelanggan dihapus.", "success")
    return redirect(url_for("reseller_pelanggan"))


@app.route("/reseller/pelanggan/import-mikrotik", methods=["POST"])
@reseller_login_required
def reseller_import_pelanggan_mikrotik():
    """Sama seperti /pelanggan/import-mikrotik punya admin, tapi khusus buat reseller:
    tarik PPPoE Secret dari salah satu router (POP) miliknya sendiri, masukkan ke
    billing sebagai pelanggan miliknya. Dipakai kalau pelanggan sudah lebih dulu
    dibuat langsung di Mikrotik/Winbox sebelum billing ini dipasang."""
    db = get_db()
    rid = session["reseller_id"]
    router_id = request.form.get("router_id", "").strip()
    router = db.execute(
        "SELECT * FROM router WHERE id=? AND reseller_id=?", (router_id, rid)).fetchone()
    if not router:
        return jsonify(ok=False, message="Pilih Router/POP milik Anda sendiri terlebih dahulu."), 400

    client = _get_mikrotik_client(router["id"])
    if not client:
        return jsonify(ok=False, message="Router ini belum diisi host/username Mikrotik-nya. Cek menu POP."), 400

    try:
        secrets = client.get_ppp_secrets()
    except RouterOSError as e:
        return jsonify(ok=False, message=f"Gagal ambil data dari Mikrotik: {e}"), 200
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal ambil data dari Mikrotik (error tak terduga): {e}"), 200

    hanya_aktif = request.form.get("hanya_aktif", "1") == "1"

    daftar_paket = db.execute("SELECT * FROM paket").fetchall()
    peta_profile_ke_paket = {p["profile_mikrotik"]: p["id"] for p in daftar_paket}

    ditambahkan = 0
    dilewati = 0
    diperbarui_pop = 0
    dilewati_nonaktif = 0
    paket_baru_dibuat = 0

    for s in secrets:
        username = s.get("name")
        if not username:
            continue

        disabled = s.get("disabled", "false") == "true"
        if hanya_aktif and disabled:
            dilewati_nonaktif += 1
            continue

        sudah_ada = db.execute(
            "SELECT id, router_id FROM pelanggan WHERE username_pppoe=?", (username,)).fetchone()
        if sudah_ada:
            # Pelanggan ini sudah ada di billing tapi belum tentu terkait ke
            # POP/router ini (misalnya data lama sebelum kaitan router_id ada).
            # Kaitkan/perbarui router_id-nya supaya langsung muncul saat
            # difilter per-POP, bukan cuma dilewati diam-diam.
            if sudah_ada["router_id"] != router["id"]:
                db.execute(
                    "UPDATE pelanggan SET router_id=?, reseller_id=? WHERE id=?",
                    (router["id"], rid, sudah_ada["id"]))
                diperbarui_pop += 1
            else:
                dilewati += 1
            continue

        profile = s.get("profile", "default")
        paket_id = peta_profile_ke_paket.get(profile)
        if not paket_id:
            cur = db.execute(
                "INSERT INTO paket (nama_paket, kecepatan, harga, profile_mikrotik) VALUES (?,?,?,?)",
                (f"Paket {profile}", "-", 0, profile))
            paket_id = cur.lastrowid
            peta_profile_ke_paket[profile] = paket_id
            paket_baru_dibuat += 1

        password = s.get("password", "")
        comment = s.get("comment", "")
        nama, alamat, no_hp = _uraikan_komentar_billing(comment, username)

        db.execute(
            """INSERT INTO pelanggan
               (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id, status,
                tanggal_daftar, router_id, reseller_id)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (nama, alamat, no_hp, username, password, paket_id,
             "isolir" if disabled else "aktif", date.today().isoformat(), router["id"], rid))
        ditambahkan += 1

    db.commit()
    if ditambahkan or diperbarui_pop:
        _catat_aktivitas("pppoe", "Import dari Mikrotik", f"{ditambahkan} pelanggan diimpor ({router['nama_router']})")

    pesan = (f"{ditambahkan} pelanggan berhasil diimpor dari router '{router['nama_router']}', "
             f"{diperbarui_pop} pelanggan lama dikaitkan ke POP ini, "
             f"{dilewati} dilewati (sudah ada di billing & sudah terkait POP ini).")
    if hanya_aktif:
        pesan += f" {dilewati_nonaktif} dilewati karena berstatus nonaktif/isolir di Mikrotik."
    if paket_baru_dibuat:
        pesan += (f" {paket_baru_dibuat} paket baru otomatis dibuat (harga masih Rp 0, "
                  f"silakan minta admin edit harga & nama paketnya di menu Paket Internet).")
    return jsonify(ok=True, message=pesan)


# --------- Reseller: Hotspot & Voucher (di router miliknya sendiri) ---------
@app.route("/reseller/hotspot")
@reseller_login_required
def reseller_hotspot():
    db = get_db()
    rid = session["reseller_id"]
    daftar_router = db.execute(
        "SELECT * FROM router WHERE reseller_id=? ORDER BY nama_router", (rid,)).fetchall()

    router_id = request.args.get("router_id", "").strip()
    router_aktif = None
    if router_id:
        router_aktif = next((r for r in daftar_router if str(r["id"]) == router_id), None)
    if not router_aktif and daftar_router:
        router_aktif = daftar_router[0]

    batch_terbaru = []
    total_voucher = 0
    belum_terpakai = 0
    if router_aktif:
        batch_terbaru = db.execute(
            """SELECT batch, COUNT(*) jumlah, MIN(dibuat_tanggal) tanggal FROM voucher
               WHERE reseller_id=? AND router_id=? GROUP BY batch ORDER BY tanggal DESC LIMIT 15""",
            (rid, router_aktif["id"])).fetchall()
        total_voucher = db.execute(
            "SELECT COUNT(*) c FROM voucher WHERE reseller_id=? AND router_id=?",
            (rid, router_aktif["id"])).fetchone()["c"]
        belum_terpakai = db.execute(
            "SELECT COUNT(*) c FROM voucher WHERE reseller_id=? AND router_id=? AND status='belum_terpakai'",
            (rid, router_aktif["id"])).fetchone()["c"]

    return render_template(
        "reseller_hotspot.html",
        daftar_router=daftar_router,
        router_aktif=router_aktif,
        batch_terbaru=batch_terbaru,
        total_voucher=total_voucher,
        belum_terpakai=belum_terpakai,
    )


@app.route("/reseller/hotspot/generate", methods=["POST"])
@reseller_login_required
def reseller_generate_voucher():
    db = get_db()
    rid = session["reseller_id"]
    router_id = request.form.get("router_id", "").strip()
    router = db.execute(
        "SELECT * FROM router WHERE id=? AND reseller_id=?", (router_id, rid)).fetchone()
    if not router:
        return jsonify(ok=False, message="Pilih Router/POP milik Anda sendiri terlebih dahulu."), 400

    jumlah = int(request.form.get("jumlah", 1))
    jumlah = max(1, min(jumlah, 200))
    profile = request.form.get("profile_hotspot", "").strip()
    if not profile:
        return jsonify(ok=False, message="Isi User Profile Hotspot dulu."), 400
    harga = int(request.form.get("harga") or 0)
    panjang_kode = int(request.form.get("panjang_kode") or 6)
    panjang_kode = max(4, min(panjang_kode, 12))
    format_kode = request.form.get("format_kode", "kapital_angka").strip()
    if format_kode not in ("kapital", "angka", "acak", "kapital_angka"):
        format_kode = "kapital_angka"

    client = _get_mikrotik_client(router["id"])
    if not client:
        return jsonify(ok=False, message="Router ini belum diisi host/username Mikrotik-nya."), 400

    batch = f"V{datetime.now().strftime('%y%m%d-%H%M%S')}"
    dibuat = 0
    gagal = []

    for _ in range(jumlah):
        kode = _generate_kode(panjang_kode, format_kode)
        for _percobaan in range(5):
            bentrok = db.execute("SELECT id FROM voucher WHERE username=?", (kode,)).fetchone()
            if not bentrok:
                break
            kode = _generate_kode(panjang_kode, format_kode)
        try:
            client.add_hotspot_user(username=kode, password=kode, profile=profile,
                                     comment=f"voucher:{batch}")
            db.execute(
                """INSERT INTO voucher (username, password, profile_hotspot, harga, status, batch,
                                         dibuat_tanggal, router_id, reseller_id)
                   VALUES (?,?,?,?, 'belum_terpakai', ?,?,?,?)""",
                (kode, kode, profile, harga, batch, date.today().isoformat(), router["id"], rid))
            dibuat += 1
        except RouterOSError as e:
            gagal.append(str(e))
        except Exception as e:
            gagal.append(str(e))

    db.commit()
    if dibuat:
        _catat_aktivitas("hotspot", "Generate Voucher", f"{dibuat} voucher (batch {batch}, {router['nama_router']})")

    pesan = f"{dibuat} voucher berhasil dibuat & disinkron ke Mikrotik (batch {batch})."
    if gagal:
        pesan += f" {len(gagal)} gagal: {gagal[0]}"
    return jsonify(ok=dibuat > 0, message=pesan, batch=batch)


@app.route("/reseller/hotspot/cetak/<batch>")
@reseller_login_required
def reseller_cetak_voucher(batch):
    db = get_db()
    rid = session["reseller_id"]
    daftar = db.execute(
        "SELECT * FROM voucher WHERE batch=? AND reseller_id=? ORDER BY id", (batch, rid)).fetchall()
    if not daftar:
        flash("Voucher tidak ditemukan.", "danger")
        return redirect(url_for("reseller_hotspot"))
    desain = request.args.get("desain", "bizfiber")
    return render_template("cetak_voucher.html", daftar=daftar, batch=batch, desain=desain)


@app.route("/reseller/hotspot/cetak-cepat/<batch>")
@reseller_login_required
def reseller_cetak_voucher_cepat(batch):
    db = get_db()
    rid = session["reseller_id"]
    daftar = db.execute(
        "SELECT * FROM voucher WHERE batch=? AND reseller_id=? ORDER BY id", (batch, rid)).fetchall()
    if not daftar:
        flash("Voucher tidak ditemukan.", "danger")
        return redirect(url_for("reseller_hotspot"))
    desain = request.args.get("desain", "bizfiber")
    return render_template("cetak_voucher_cepat.html", daftar=daftar, batch=batch, desain=desain)


@app.route("/reseller/hotspot/hapus-batch/<batch>", methods=["POST"])
@reseller_login_required
def reseller_hapus_batch_voucher(batch):
    db = get_db()
    rid = session["reseller_id"]
    daftar = db.execute(
        "SELECT * FROM voucher WHERE batch=? AND reseller_id=?", (batch, rid)).fetchall()
    if not daftar:
        flash("Batch voucher tidak ditemukan.", "danger")
        return redirect(url_for("reseller_hotspot"))
    router_id = daftar[0]["router_id"]
    client = _get_mikrotik_client(router_id)
    dihapus = 0
    for v in daftar:
        if client:
            try:
                client.remove_hotspot_user(v["username"])
            except Exception:
                pass
        db.execute("DELETE FROM voucher WHERE id=?", (v["id"],))
        dihapus += 1
    db.commit()
    _catat_aktivitas("hotspot", "Hapus Batch Voucher", f"{dihapus} voucher (batch {batch})")
    flash(f"{dihapus} voucher pada batch '{batch}' dihapus.", "success")
    return redirect(url_for("reseller_hotspot", router_id=router_id))


# --------- Reseller: Tagihan (billing gabungan, tapi cuma punya sendiri) ---------
@app.route("/reseller/tagihan")
@reseller_login_required
def reseller_tagihan():
    db = get_db()
    rid = session["reseller_id"]
    daftar_tagihan = db.execute(
        """SELECT t.*, p.nama, p.username_pppoe, r.nama_router
           FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           LEFT JOIN router r ON r.id = p.router_id
           WHERE p.reseller_id=? ORDER BY t.id DESC""", (rid,)).fetchall()
    return render_template("reseller_tagihan.html", daftar_tagihan=daftar_tagihan)


@app.route("/lupa-password", methods=["GET", "POST"])
def lupa_password():
    """Halaman 'Lupa Password' -- admin masukkan username/email, sistem kirim
    link reset password ke email yang terhubung ke akun tersebut (kalau ada)."""
    if request.method == "POST":
        identitas = request.form.get("identitas", "").strip()
        db = get_db()
        row = db.execute(
            "SELECT * FROM admin WHERE username=? OR email=?", (identitas, identitas)
        ).fetchone()

        pesan_umum = ("Kalau username/email itu terdaftar dan sudah punya email terhubung, "
                      "link reset password sudah dikirim. Cek juga folder Spam.")

        if row and row["email"]:
            token = secrets.token_urlsafe(32)
            kadaluarsa = (datetime.now() + timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            db.execute("UPDATE admin SET reset_token=?, reset_token_expiry=? WHERE id=?",
                       (token, kadaluarsa, row["id"]))
            db.commit()
            link_reset = url_for("reset_password", token=token, _external=True)
            berhasil, error = kirim_email_reset_password(row["email"], row["nama"] or row["username"], link_reset)
            if not berhasil:
                flash(f"Gagal mengirim email reset: {error}", "danger")
                return render_template("lupa_password.html")

        flash(pesan_umum, "success")
        return redirect(url_for("login"))
    return render_template("lupa_password.html")


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    """Halaman untuk membuat password baru lewat link yang dikirim ke email.
    Token berlaku 1 jam sejak diminta dan langsung hangus setelah dipakai."""
    db = get_db()
    row = db.execute("SELECT * FROM admin WHERE reset_token=?", (token,)).fetchone()

    token_valid = False
    if row and row["reset_token_expiry"]:
        try:
            kadaluarsa = datetime.strptime(row["reset_token_expiry"], "%Y-%m-%d %H:%M:%S")
            token_valid = datetime.now() <= kadaluarsa
        except ValueError:
            token_valid = False

    if not row or not token_valid:
        flash("Link reset password tidak valid atau sudah kadaluarsa. Silakan minta link baru.", "danger")
        return redirect(url_for("lupa_password"))

    if request.method == "POST":
        password_baru = request.form.get("password_baru", "")
        konfirmasi = request.form.get("konfirmasi_password", "")
        if len(password_baru) < 6:
            flash("Password minimal 6 karakter.", "danger")
        elif password_baru != konfirmasi:
            flash("Konfirmasi password tidak sama dengan password baru.", "danger")
        else:
            db.execute(
                "UPDATE admin SET password_hash=?, reset_token=NULL, reset_token_expiry=NULL WHERE id=?",
                (hash_password(password_baru), row["id"]))
            db.commit()
            flash("Password berhasil direset. Silakan login dengan password baru kamu.", "success")
            return redirect(url_for("login"))
        return render_template("reset_password.html", token=token, paksa_layout_publik=True)

    return render_template("reset_password.html", token=token, paksa_layout_publik=True)


@app.route("/login-pelanggan", methods=["GET", "POST"])
def login_pelanggan():
    """Login khusus pelanggan pakai username & password PPPoE yang sama dengan
    yang dipakai untuk internetnya, supaya pelanggan bisa cek tagihan sendiri
    tanpa perlu akun terpisah. Punya halaman sendiri (bukan gabung dengan login
    admin) supaya bisa didesain lebih ramah buat pelanggan awam."""
    ip = _alamat_ip_klien()
    terkunci, sisa_detik = _cek_kunci_login(ip)
    if terkunci:
        flash(f"Terlalu banyak percobaan login gagal. Coba lagi dalam {sisa_detik // 60 + 1} menit.", "danger")
        return render_template("login_pelanggan.html", paksa_layout_publik=True)

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        row = db.execute("SELECT * FROM pelanggan WHERE username_pppoe=?", (username,)).fetchone()
        if row and row["password_pppoe"] == password:
            PERCOBAAN_LOGIN_GAGAL.pop(ip, None)
            session["pelanggan_id"] = row["id"]
            session["pelanggan_nama"] = row["nama"]
            db.execute("UPDATE pelanggan SET last_login_portal=? WHERE id=?",
                       (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), row["id"]))
            db.commit()
            _catat_aktivitas_login("pelanggan", row["username_pppoe"], "berhasil", ip)
            return redirect(url_for("portal_pelanggan"))
        _catat_login_gagal(ip)
        _catat_aktivitas_login("pelanggan", username, "gagal", ip)
        flash("Username atau password PPPoE salah, atau kamu belum terdaftar sebagai pelanggan.", "danger")
    return render_template("login_pelanggan.html", paksa_layout_publik=True)


DAFTAR_FITUR_RESELLER = [
    {"judul": "Manajemen Pelanggan", "icon": "bi-people-fill", "warna": "#2f7dd9",
     "deskripsi": "Kelola data pelanggan, paket, dan status langganan dengan mudah."},
    {"judul": "Billing Otomatis", "icon": "bi-credit-card-fill", "warna": "#d99a2f",
     "deskripsi": "Penagihan otomatis, notifikasi pembayaran, dan pemutusan akses terjadwal."},
    {"judul": "Hotspot Voucher", "icon": "bi-wifi", "warna": "#2f7dd9",
     "deskripsi": "Buat dan kelola voucher wifi dengan harga dan durasi fleksibel."},
    {"judul": "Monitoring MikroTik", "icon": "bi-bar-chart-fill", "warna": "#2fa876",
     "deskripsi": "Pantau trafik, router, dan status koneksi MikroTik secara langsung."},
    {"judul": "Maps Pelanggan", "icon": "bi-geo-alt-fill", "warna": "#d94f4f",
     "deskripsi": "Lihat lokasi pelanggan terpasang pada peta Google Maps."},
    {"judul": "Laporan Lengkap", "icon": "bi-file-earmark-bar-graph-fill", "warna": "#2f7dd9",
     "deskripsi": "Laporan keuangan, trafik, dan statistik pelanggan lengkap."},
    {"judul": "Multi User", "icon": "bi-person-lock", "warna": "#d9a72f",
     "deskripsi": "Bagi akses dengan peran dan hak akses yang berbeda."},
    {"judul": "Backup Database", "icon": "bi-cloud-arrow-up-fill", "warna": "#2f7dd9",
     "deskripsi": "Data terjamin aman dengan sistem backup otomatis."},
    {"judul": "Responsive", "icon": "bi-phone-fill", "warna": "#2f5fd9",
     "deskripsi": "Bisa diakses dengan nyaman dari HP, tablet, maupun komputer."},
]


PAKET_RESELLER = [
    {
        "kode": "starter",
        "nama": "Starter",
        "tagline": "Untuk pemula",
        "harga": "Rp 100.000",
        "harga_satuan": "/Bulan",
        "populer": False,
        "jumlah_nas": 2,
        "jumlah_pelanggan": 250,
        "fitur": [
            "Hingga 250 Pelanggan",
            "2 Mikrotik/NAS",
            "Fitur Dasar",
        ],
        "fitur_tidak_ada": ["Laporan Lanjutan"],
    },
    {
        "kode": "professional",
        "nama": "Professional",
        "tagline": "Untuk bisnis berkembang",
        "harga": "Rp 200.000",
        "harga_satuan": "/Bulan",
        "populer": True,
        "jumlah_nas": 4,
        "jumlah_pelanggan": 750,
        "fitur": [
            "Hingga 750 Pelanggan",
            "4 Mikrotik/NAS",
            "Semua Fitur Utama",
            "Laporan Lengkap",
        ],
        "fitur_tidak_ada": [],
    },
    {
        "kode": "business",
        "nama": "Business",
        "tagline": "Untuk ISP menengah",
        "harga": "Rp 400.000",
        "harga_satuan": "/Bulan",
        "populer": False,
        "jumlah_nas": 6,
        "jumlah_pelanggan": 1000,
        "fitur": [
            "Hingga 1.000 Pelanggan",
            "6 Mikrotik/NAS",
            "Semua Fitur Utama",
            "Laporan Lengkap",
            "Dukungan Prioritas",
        ],
        "fitur_tidak_ada": [],
    },
    {
        "kode": "enterprise",
        "nama": "Enterprise",
        "tagline": "Untuk skala besar",
        "harga": "Rp 600.000",
        "harga_satuan": "/Bulan",
        "populer": False,
        "jumlah_nas": None,
        "jumlah_pelanggan": None,
        "fitur": [
            "Pelanggan Tak Terbatas",
            "Mikrotik/NAS Tak Terbatas",
            "Fitur Kustom",
            "Dukungan Prioritas",
            "Bisa Hubungi Langsung",
        ],
        "fitur_tidak_ada": [],
    },
]


@app.route("/", methods=["GET", "POST"])
@app.route("/daftar", methods=["GET", "POST"])
def daftar_pelanggan_publik():
    """Halaman pendaftaran publik untuk calon reseller/pengguna baru software
    SafeNode (pemilik bisnis ISP yang mau pakai aplikasi ini untuk
    mengelola pelanggan & billing mereka sendiri). Tidak butuh login.
    Data yang dikirim masuk ke menu Pendaftaran Reseller di dashboard admin
    untuk ditindaklanjuti tim sales/support."""
    kode_paket_valid = {p["kode"] for p in PAKET_RESELLER}
    if request.method == "POST":
        db = get_db()
        nama_bisnis = request.form.get("nama_bisnis", "").strip()
        nama_pic = request.form.get("nama_pic", "").strip()
        no_hp = request.form.get("no_hp", "").strip()
        email = request.form.get("email", "").strip()
        kota = request.form.get("kota", "").strip()
        jumlah_pelanggan_saat_ini = request.form.get("jumlah_pelanggan_saat_ini", "").strip()
        paket = request.form.get("paket", "").strip().lower()
        catatan = request.form.get("catatan", "").strip()

        if not nama_bisnis or not nama_pic or not no_hp:
            flash("Nama usaha, nama penanggung jawab, dan No. HP wajib diisi.", "danger")
            return render_template("daftar.html", daftar_paket=PAKET_RESELLER, daftar_fitur=DAFTAR_FITUR_RESELLER,
                                    sukses_kirim=False, tampilkan_form_langsung=True, paksa_layout_publik=True)
        if paket not in kode_paket_valid:
            paket = "starter"

        db.execute(
            """INSERT INTO pendaftaran_reseller (nama_bisnis, nama_pic, no_hp, email, kota,
                                                   jumlah_pelanggan_saat_ini, paket, catatan,
                                                   status, tanggal_daftar)
               VALUES (?,?,?,?,?,?,?,?, 'baru', ?)""",
            (nama_bisnis, nama_pic, no_hp, email or None, kota or None,
             jumlah_pelanggan_saat_ini or None, paket, catatan or None,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        db.commit()
        return render_template("daftar.html", daftar_paket=PAKET_RESELLER, daftar_fitur=DAFTAR_FITUR_RESELLER,
                                sukses_kirim=True, paksa_layout_publik=True)

    return render_template("daftar.html", daftar_paket=PAKET_RESELLER, daftar_fitur=DAFTAR_FITUR_RESELLER,
                            sukses_kirim=False, paksa_layout_publik=True)


# Info promo tambahan per paket internet, ditampilkan di halaman pendaftaran client
# publik (/daftar-pelanggan). Dicocokkan ke baris tabel `paket` lewat "kecepatan" -
# kalau admin ganti/tambah paket dengan kecepatan lain, paket itu tetap tampil di
# halaman publik tapi tanpa badge promo (pakai harga normal apa adanya).
PROMO_PAKET_PUBLIK = {
    "7 Mbps": {"tagline": "Pas buat browsing, sosmed, & streaming ringan",
               "harga_coret": 200000, "badge": "Hemat 15%"},
    "12 Mbps": {"tagline": "Andalan keluarga, cukup buat WFH & meeting online",
                "harga_coret": 250000, "badge": "Hemat 16%", "populer": True},
    "15 Mbps": {"tagline": "Ngebut buat gaming, multi-device, & kerja tim",
                "harga_coret": 375000, "badge": "Hemat 13%"},
}


@app.route("/daftar-pelanggan", methods=["GET", "POST"])
def daftar_pelanggan_client():
    """Halaman publik pendaftaran client/pelanggan baru internet (bukan reseller):
    menampilkan semua paket yang tersedia (dari menu admin Paket Internet) lengkap
    dengan promo untuk paket 7/12/15 Mbps, dan form pendaftaran lengkap (data diri,
    koordinat lokasi pemasangan, kontak, preferensi WiFi) yang langsung sinkron ke
    billing -- data masuk ke tabel calon_pelanggan sehingga langsung muncul di menu
    admin Customer > Pendaftaran untuk ditindaklanjuti/diproses jadi pelanggan aktif."""
    db = get_db()
    baris_paket = db.execute("SELECT * FROM paket ORDER BY harga ASC").fetchall()
    daftar_paket = []
    for pk in baris_paket:
        promo = PROMO_PAKET_PUBLIK.get(pk["kecepatan"], {})
        daftar_paket.append({
            "id": pk["id"],
            "nama_paket": pk["nama_paket"],
            "kecepatan": pk["kecepatan"],
            "harga": pk["harga"],
            "badge": promo.get("badge"),
            "populer": promo.get("populer", False),
        })

    if request.method == "POST":
        nama = request.form.get("nama", "").strip()
        alamat = request.form.get("alamat", "").strip()
        nik = request.form.get("nik", "").strip()
        npwp = request.form.get("npwp", "").strip()
        latitude = request.form.get("latitude", "").strip()
        longitude = request.form.get("longitude", "").strip()
        no_hp = request.form.get("no_hp", "").strip()       # WhatsApp (wajib)
        no_hp2 = request.form.get("no_hp2", "").strip()     # Handphone (opsional)
        email = request.form.get("email", "").strip()
        ssid_wifi = request.form.get("ssid_wifi", "").strip()
        password_wifi = request.form.get("password_wifi", "").strip()
        paket_id = request.form.get("paket_id", "").strip()
        catatan = request.form.get("catatan", "").strip()

        if not nama or not alamat or not no_hp or not paket_id:
            flash("Nama, Alamat, Nomor Whatsapp, dan Paket wajib diisi.", "danger")
            paket_dipilih = next((p for p in daftar_paket if str(p["id"]) == str(paket_id)), None)
            return render_template("daftar_pelanggan.html", daftar_paket=daftar_paket,
                                    sukses_kirim=False, tampilkan_form_langsung=True,
                                    paket_id_dipilih=paket_id, paket_dipilih=paket_dipilih)

        db.execute(
            """INSERT INTO calon_pelanggan (nama, alamat, no_hp, email, paket_id, catatan,
                                              status, tanggal_daftar, nik, npwp, latitude, longitude,
                                              no_hp2, ssid_wifi, password_wifi)
               VALUES (?,?,?,?,?,?, 'baru', ?, ?,?,?,?,?,?,?)""",
            (nama, alamat, no_hp, email or None, int(paket_id), catatan or None,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             nik or None, npwp or None,
             float(latitude) if latitude else None, float(longitude) if longitude else None,
             no_hp2 or None, ssid_wifi or None, password_wifi or None))
        db.commit()
        return render_template("daftar_pelanggan.html", daftar_paket=daftar_paket, sukses_kirim=True)

    return render_template("daftar_pelanggan.html", daftar_paket=daftar_paket, sukses_kirim=False)


@app.route("/pendaftaran")
@login_required
def pendaftaran():
    """Dashboard admin untuk meninjau pendaftaran calon pelanggan yang masuk
    lewat halaman publik /daftar, lalu memprosesnya jadi akun pelanggan aktif."""
    db = get_db()
    daftar_calon = db.execute(
        """SELECT cp.*, pk.nama_paket, pk.harga
           FROM calon_pelanggan cp LEFT JOIN paket pk ON pk.id = cp.paket_id
           ORDER BY cp.id DESC"""
    ).fetchall()
    daftar_paket = db.execute("SELECT * FROM paket ORDER BY nama_paket").fetchall()
    daftar_odp = db.execute("SELECT * FROM odp ORDER BY nama").fetchall()
    total_baru = sum(1 for c in daftar_calon if c["status"] == "baru")
    return render_template(
        "pendaftaran.html",
        daftar_calon=daftar_calon,
        daftar_paket=daftar_paket,
        daftar_odp=daftar_odp,
        total_baru=total_baru,
    )


@app.route("/pendaftaran/proses/<int:cid>", methods=["POST"])
@login_required
def pendaftaran_proses(cid):
    """Menyetujui pendaftaran: bikin akun pelanggan (PPPoE) beneran dari data calon
    pelanggan, lalu tandai pendaftarannya sebagai sudah diproses."""
    db = get_db()
    calon = db.execute("SELECT * FROM calon_pelanggan WHERE id=?", (cid,)).fetchone()
    if not calon:
        flash("Data pendaftaran tidak ditemukan.", "danger")
        return redirect(url_for("pendaftaran"))

    username_pppoe = request.form.get("username_pppoe", "").strip()
    password_pppoe = request.form.get("password_pppoe", "").strip()
    paket_id = request.form.get("paket_id") or calon["paket_id"]
    odp_id = request.form.get("odp_id", "").strip() or None

    if not username_pppoe or not password_pppoe or not paket_id:
        flash("Username PPPoE, password PPPoE, dan paket wajib diisi untuk memproses pendaftaran.", "danger")
        return redirect(url_for("pendaftaran"))

    try:
        cur = db.execute(
            """INSERT INTO pelanggan (nama, alamat, no_hp, username_pppoe, password_pppoe,
                                       paket_id, status, tanggal_daftar, odp_id, latitude, longitude)
               VALUES (?,?,?,?,?,?, 'aktif', ?,?,?,?)""",
            (calon["nama"], calon["alamat"], calon["no_hp"], username_pppoe, password_pppoe,
             paket_id, date.today().isoformat(), odp_id, calon["latitude"], calon["longitude"]))
        pelanggan_id = cur.lastrowid
        db.execute(
            "UPDATE calon_pelanggan SET status='diproses', pelanggan_id=? WHERE id=?",
            (pelanggan_id, cid))
        db.commit()
        flash(f"Pendaftaran {calon['nama']} berhasil diproses jadi pelanggan aktif. "
              f"Jangan lupa klik 'Sync ke Mikrotik' di menu Pelanggan.", "success")
    except sqlite3.IntegrityError:
        flash("Username PPPoE sudah dipakai pelanggan lain. Coba username lain.", "danger")
    return redirect(url_for("pendaftaran"))


@app.route("/pendaftaran/tolak/<int:cid>", methods=["POST"])
@login_required
def pendaftaran_tolak(cid):
    db = get_db()
    db.execute("UPDATE calon_pelanggan SET status='ditolak' WHERE id=?", (cid,))
    db.commit()
    flash("Pendaftaran ditolak.", "info")
    return redirect(url_for("pendaftaran"))


@app.route("/pendaftaran/hapus/<int:cid>", methods=["POST"])
@login_required
def pendaftaran_hapus(cid):
    db = get_db()
    db.execute("DELETE FROM calon_pelanggan WHERE id=?", (cid,))
    db.commit()
    flash("Data pendaftaran dihapus.", "info")
    return redirect(url_for("pendaftaran"))


@app.route("/pendaftaran-reseller")
@login_required
def pendaftaran_reseller():
    """Dashboard admin untuk meninjau calon pengguna baru/reseller software
    SafeNode yang mendaftar lewat halaman publik /daftar (memilih paket
    Starter/Professional/Enterprise), lalu ditindaklanjuti tim sales."""
    db = get_db()
    daftar_calon = db.execute(
        "SELECT * FROM pendaftaran_reseller ORDER BY id DESC"
    ).fetchall()
    total_baru = sum(1 for c in daftar_calon if c["status"] == "baru")
    return render_template(
        "pendaftaran_reseller.html",
        daftar_calon=daftar_calon,
        total_baru=total_baru,
    )


@app.route("/pendaftaran-reseller/status/<int:cid>", methods=["POST"])
@login_required
def pendaftaran_reseller_status(cid):
    """Ubah status tindak lanjut satu lead reseller (baru/dihubungi/berlangganan/ditolak).

    Khusus saat status diubah jadi "berlangganan": kalau calon reseller ini belum
    pernah punya akun, sistem otomatis generate username & password lalu
    mengirimkannya ke email calon reseller (subjek "Selamat! Akun Reseller Anda
    Sudah Aktif"). Kalau sebelumnya sudah pernah diaktifkan, statusnya diubah saja
    tanpa membuat/mengirim ulang akun -- pakai tombol "Kirim Ulang Akun" untuk itu.
    """
    status_baru = request.form.get("status", "").strip()
    if status_baru not in ("baru", "dihubungi", "berlangganan", "ditolak"):
        flash("Status tidak valid.", "danger")
        return redirect(url_for("pendaftaran_reseller"))

    db = get_db()
    calon = db.execute("SELECT * FROM pendaftaran_reseller WHERE id=?", (cid,)).fetchone()
    if not calon:
        flash("Data pendaftaran tidak ditemukan.", "danger")
        return redirect(url_for("pendaftaran_reseller"))

    db.execute("UPDATE pendaftaran_reseller SET status=? WHERE id=?", (status_baru, cid))
    db.commit()

    if status_baru == "berlangganan" and not calon["akun_username"]:
        if not calon["email"]:
            flash("Status diperbarui jadi Berlangganan, tapi calon reseller ini tidak mengisi "
                  "email jadi akun tidak bisa dikirim otomatis.", "warning")
        else:
            username = _buat_username_reseller(calon["nama_bisnis"], cid)
            password = _buat_password_reseller()
            berhasil, error = kirim_email_akun_reseller_aktif(
                calon["email"], calon["nama_pic"], calon["nama_bisnis"], username, password)
            db.execute(
                "UPDATE pendaftaran_reseller SET akun_username=?, akun_password=?, "
                "akun_dikirim_tanggal=? WHERE id=?",
                (username, password, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), cid))
            _buat_atau_perbarui_akun_reseller(db, calon, cid, username, password)
            db.commit()
            if berhasil:
                flash(f"Status diperbarui jadi Berlangganan. Akun (username: {username}) sudah "
                      f"dikirim ke {calon['email']}, dan sudah bisa dipakai login di halaman "
                      f"Login Reseller.", "success")
            else:
                flash(f"Status diperbarui, akun sudah dibuat (username: {username}) tapi email "
                      f"gagal terkirim: {error}. Coba \"Kirim Ulang Akun\" nanti.", "danger")
    else:
        flash("Status pendaftaran diperbarui.", "success")

    return redirect(url_for("pendaftaran_reseller"))


@app.route("/pendaftaran-reseller/kirim-ulang-akun/<int:cid>", methods=["POST"])
@login_required
def pendaftaran_reseller_kirim_ulang_akun(cid):
    """Buat ulang password & kirim ulang email akun reseller (dipakai kalau
    pengiriman pertama gagal, atau admin mau reset password reseller)."""
    db = get_db()
    calon = db.execute("SELECT * FROM pendaftaran_reseller WHERE id=?", (cid,)).fetchone()
    if not calon:
        flash("Data pendaftaran tidak ditemukan.", "danger")
        return redirect(url_for("pendaftaran_reseller"))
    if not calon["email"]:
        flash("Calon reseller ini tidak mengisi email, akun tidak bisa dikirim.", "warning")
        return redirect(url_for("pendaftaran_reseller"))

    username = calon["akun_username"] or _buat_username_reseller(calon["nama_bisnis"], cid)
    password = _buat_password_reseller()
    berhasil, error = kirim_email_akun_reseller_aktif(
        calon["email"], calon["nama_pic"], calon["nama_bisnis"], username, password)
    db.execute(
        "UPDATE pendaftaran_reseller SET status='berlangganan', akun_username=?, akun_password=?, "
        "akun_dikirim_tanggal=? WHERE id=?",
        (username, password, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), cid))
    _buat_atau_perbarui_akun_reseller(db, calon, cid, username, password)
    db.commit()
    if berhasil:
        flash(f"Akun (username: {username}) berhasil dikirim ulang ke {calon['email']} "
              f"(password direset, akun bisa langsung dipakai login).", "success")
    else:
        flash(f"Gagal mengirim ulang akun: {error}", "danger")
    return redirect(url_for("pendaftaran_reseller"))


@app.route("/pendaftaran-reseller/hapus/<int:cid>", methods=["POST"])
@login_required
def pendaftaran_reseller_hapus(cid):
    db = get_db()
    db.execute("DELETE FROM pendaftaran_reseller WHERE id=?", (cid,))
    db.commit()
    flash("Data pendaftaran dihapus.", "info")
    return redirect(url_for("pendaftaran_reseller"))


# ---------------------------------------------------------------------------
# Reseller -- manajemen akun reseller AKTIF oleh admin master. Beda dari
# "Pendaftaran Reseller" (leads/calon) di atas -- ini daftar reseller yang
# sudah bisa login sendiri, plus di sini admin master bisa buka semua
# pelanggan milik reseller manapun (klik "Lihat Pelanggan").
# ---------------------------------------------------------------------------
@app.route("/reseller-admin", methods=["GET", "POST"])
@login_required
def reseller_admin():
    db = get_db()
    if request.method == "POST":
        nama_bisnis = request.form.get("nama_bisnis", "").strip()
        nama_pic = request.form.get("nama_pic", "").strip()
        no_hp = request.form.get("no_hp", "").strip()
        email = request.form.get("email", "").strip()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not nama_bisnis or not username or not password:
            flash("Nama usaha, username, dan password wajib diisi.", "danger")
        else:
            try:
                db.execute(
                    """INSERT INTO reseller (username, password_hash, nama_bisnis, nama_pic, no_hp,
                                              email, status, tanggal_dibuat)
                       VALUES (?,?,?,?,?,?, 'aktif', ?)""",
                    (username, hash_password(password), nama_bisnis, nama_pic, no_hp, email,
                     datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                db.commit()
                flash(f"Reseller '{nama_bisnis}' berhasil dibuat. Username: {username}.", "success")
            except sqlite3.IntegrityError:
                flash("Username sudah dipakai reseller lain.", "danger")
        return redirect(url_for("reseller_admin"))

    daftar_reseller = db.execute(
        """SELECT rs.*,
                  (SELECT COUNT(*) FROM pelanggan WHERE reseller_id = rs.id) AS jumlah_pelanggan,
                  (SELECT COUNT(*) FROM router WHERE reseller_id = rs.id) AS jumlah_router
           FROM reseller rs ORDER BY rs.id DESC"""
    ).fetchall()
    return render_template("reseller_admin.html", daftar_reseller=daftar_reseller)


@app.route("/reseller-admin/edit/<int:rid>", methods=["POST"])
@login_required
def reseller_admin_edit(rid):
    db = get_db()
    row = db.execute("SELECT * FROM reseller WHERE id=?", (rid,)).fetchone()
    if not row:
        flash("Reseller tidak ditemukan.", "danger")
        return redirect(url_for("reseller_admin"))
    nama_bisnis = request.form.get("nama_bisnis", "").strip()
    nama_pic = request.form.get("nama_pic", "").strip()
    no_hp = request.form.get("no_hp", "").strip()
    email = request.form.get("email", "").strip()
    password_baru = request.form.get("password", "").strip()
    db.execute(
        "UPDATE reseller SET nama_bisnis=?, nama_pic=?, no_hp=?, email=? WHERE id=?",
        (nama_bisnis, nama_pic, no_hp, email, rid))
    if password_baru:
        db.execute("UPDATE reseller SET password_hash=? WHERE id=?", (hash_password(password_baru), rid))
    db.commit()
    flash("Data reseller berhasil diperbarui." + (" Password direset." if password_baru else ""), "success")
    return redirect(url_for("reseller_admin"))


@app.route("/reseller-admin/status/<int:rid>", methods=["POST"])
@login_required
def reseller_admin_status(rid):
    db = get_db()
    row = db.execute("SELECT status FROM reseller WHERE id=?", (rid,)).fetchone()
    if not row:
        flash("Reseller tidak ditemukan.", "danger")
        return redirect(url_for("reseller_admin"))
    status_baru = "nonaktif" if row["status"] == "aktif" else "aktif"
    db.execute("UPDATE reseller SET status=? WHERE id=?", (status_baru, rid))
    db.commit()
    flash(f"Reseller {'diaktifkan' if status_baru == 'aktif' else 'dinonaktifkan'}.", "success")
    return redirect(url_for("reseller_admin"))


@app.route("/reseller-admin/hapus/<int:rid>", methods=["POST"])
@login_required
def reseller_admin_hapus(rid):
    db = get_db()
    jumlah_pelanggan = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE reseller_id=?", (rid,)).fetchone()["c"]
    if jumlah_pelanggan > 0:
        flash(f"Reseller tidak bisa dihapus, masih punya {jumlah_pelanggan} pelanggan. "
              f"Nonaktifkan saja, atau pindahkan pelanggannya dulu.", "danger")
        return redirect(url_for("reseller_admin"))
    db.execute("DELETE FROM router WHERE reseller_id=?", (rid,))
    db.execute("DELETE FROM reseller WHERE id=?", (rid,))
    db.commit()
    flash("Reseller dihapus.", "success")
    return redirect(url_for("reseller_admin"))


# ---------------------------------------------------------------------------
# Router / POP -- manajemen multi-router milik admin master sendiri. Router
# yang dibuat reseller lewat dashboard mereka masing-masing ikut tampil di
# sini (read-only, ditandai pemiliknya) supaya admin master tetap punya
# gambaran lengkap semua router yang terhubung ke sistem.
# ---------------------------------------------------------------------------
@app.route("/router", methods=["GET", "POST"])
@login_required
def router_admin():
    db = get_db()
    if request.method == "POST":
        nama_router = request.form.get("nama_router", "").strip()
        host = request.form.get("host", "").strip()
        port = int(request.form.get("port") or 8728)
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        metode_koneksi = request.form.get("metode_koneksi", "langsung").strip() or "langsung"
        nama_tunnel = request.form.get("nama_tunnel", "").strip() or None
        # Router ini mau dibuat punya siapa: kosong/"" = milik admin master sendiri,
        # atau id salah satu reseller supaya langsung tampil & bisa dikelola di
        # dashboard reseller tsb (menu POP) -- admin master cukup pilih dari sini,
        # tidak perlu reseller-nya login dulu buat menambahkan routernya sendiri.
        reseller_id_raw = request.form.get("reseller_id", "").strip()
        reseller_id = None
        if reseller_id_raw:
            reseller_valid = db.execute(
                "SELECT id FROM reseller WHERE id=?", (reseller_id_raw,)).fetchone()
            if reseller_valid:
                reseller_id = reseller_valid["id"]
            else:
                flash("Reseller yang dipilih tidak ditemukan, router dibuat sebagai milik sendiri.", "warning")
        if not nama_router or not host:
            flash("Nama router dan Host wajib diisi.", "danger")
        else:
            db.execute(
                """INSERT INTO router (reseller_id, nama_router, host, port, username, password,
                                        metode_koneksi, nama_tunnel, status, tanggal_dibuat)
                   VALUES (?,?,?,?,?,?,?,?, 'aktif', ?)""",
                (reseller_id, nama_router, host, port, username, password, metode_koneksi, nama_tunnel,
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            db.commit()
            if reseller_id:
                flash(f"Router '{nama_router}' berhasil ditambahkan sebagai milik reseller.", "success")
            else:
                flash(f"Router '{nama_router}' berhasil ditambahkan.", "success")
        return redirect(url_for("router_admin"))

    daftar_router = db.execute(
        """SELECT r.*, rs.nama_bisnis AS pemilik_reseller,
                  (SELECT COUNT(*) FROM pelanggan WHERE router_id = r.id) AS jumlah_pelanggan
           FROM router r LEFT JOIN reseller rs ON rs.id = r.reseller_id
           WHERE NOT (r.id = 1 AND (r.host IS NULL OR r.host = '') AND r.reseller_id IS NULL)
           ORDER BY (r.reseller_id IS NOT NULL), r.id"""
    ).fetchall()
    klien_vpn = db.execute("SELECT * FROM vpn_client WHERE aktif=1 ORDER BY nama").fetchall()
    daftar_reseller = db.execute(
        "SELECT id, nama_bisnis, username FROM reseller ORDER BY nama_bisnis").fetchall()
    return render_template("router_admin.html", daftar_router=daftar_router, klien_vpn=klien_vpn,
                            daftar_reseller=daftar_reseller)


@app.route("/router/edit/<int:router_id>", methods=["POST"])
@login_required
def router_admin_edit(router_id):
    db = get_db()
    row = db.execute("SELECT * FROM router WHERE id=? AND reseller_id IS NULL", (router_id,)).fetchone()
    if not row:
        flash("Router tidak ditemukan, atau router ini milik reseller (edit lewat dashboard reseller).", "danger")
        return redirect(url_for("router_admin"))
    nama_router = request.form.get("nama_router", "").strip()
    host = request.form.get("host", "").strip()
    port = int(request.form.get("port") or 8728)
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip() or row["password"]
    metode_koneksi = request.form.get("metode_koneksi", "langsung").strip() or "langsung"
    nama_tunnel = request.form.get("nama_tunnel", "").strip() or None
    # Boleh dipindah jadi milik reseller lewat edit ini juga (sebelumnya cuma
    # bisa diatur pas Tambah). Setelah dipindah, router-nya otomatis tidak lagi
    # bisa diedit dari sini -- ikut aturan reseller_id IS NULL di atas.
    reseller_id_raw = request.form.get("reseller_id", "").strip()
    reseller_id = row["reseller_id"]
    if reseller_id_raw:
        reseller_valid = db.execute(
            "SELECT id FROM reseller WHERE id=?", (reseller_id_raw,)).fetchone()
        reseller_id = reseller_valid["id"] if reseller_valid else None
    else:
        reseller_id = None
    db.execute(
        """UPDATE router SET nama_router=?, host=?, port=?, username=?, password=?,
           metode_koneksi=?, nama_tunnel=?, reseller_id=? WHERE id=?""",
        (nama_router, host, port, username, password, metode_koneksi, nama_tunnel, reseller_id, router_id))
    db.commit()
    if reseller_id and reseller_id != row["reseller_id"]:
        flash("Router berhasil diperbarui & dipindah jadi milik reseller.", "success")
    else:
        flash("Router berhasil diperbarui.", "success")
    return redirect(url_for("router_admin"))


@app.route("/router/hapus/<int:router_id>", methods=["POST"])
@login_required
def router_admin_hapus(router_id):
    db = get_db()
    if router_id == 1:
        flash("Router Utama (id=1) tidak bisa dihapus.", "danger")
        return redirect(url_for("router_admin"))
    row = db.execute("SELECT * FROM router WHERE id=? AND reseller_id IS NULL", (router_id,)).fetchone()
    if not row:
        flash("Router tidak ditemukan, atau router ini milik reseller.", "danger")
        return redirect(url_for("router_admin"))
    jumlah = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE router_id=?", (router_id,)).fetchone()["c"]
    if jumlah > 0:
        flash(f"Router tidak bisa dihapus, masih dipakai {jumlah} pelanggan.", "danger")
        return redirect(url_for("router_admin"))
    db.execute("DELETE FROM router WHERE id=?", (router_id,))
    db.commit()
    flash("Router dihapus.", "success")
    return redirect(url_for("router_admin"))


@app.route("/router/aktifkan/<int:router_id>", methods=["POST"])
@login_required
def router_admin_aktifkan(router_id):
    """Set router mana yang jadi 'router aktif' admin master saat ini -- dipakai
    perkakas umum yang beroperasi per-router (hotspot, voucher, PPP profile,
    simple queue, dashboard ringkasan Mikrotik), BUKAN untuk aksi per-pelanggan
    (itu selalu otomatis pakai router milik pelanggan yang bersangkutan)."""
    db = get_db()
    row = db.execute("SELECT id, nama_router FROM router WHERE id=?", (router_id,)).fetchone()
    if not row:
        flash("Router tidak ditemukan.", "danger")
    else:
        session["router_aktif"] = row["id"]
        flash(f"Router aktif sekarang: {row['nama_router']}. Menu hotspot/voucher/PPP profile "
              f"dsb sekarang mengarah ke router ini.", "success")
    return redirect(url_for("router_admin"))


@app.route("/router/test/<int:router_id>", methods=["POST"])
@login_required
def router_admin_test(router_id):
    client = _get_mikrotik_client(router_id)
    if not client:
        return jsonify(ok=False, message="Isi host/username terlebih dahulu, lalu Simpan dulu.")
    try:
        identity = client.test_connection()
        return jsonify(ok=True, message=f"Berhasil konek! Identity router: {identity}")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal konek (error tak terduga): {e}")


@app.route("/router/aksi-massal", methods=["POST"])
@login_required
def router_admin_aksi_massal():
    """Aksi massal (MENU) di halaman Router / POP: SET AKTIF, NON AKTIF, atau
    HAPUS untuk beberapa router yang dicentang sekaligus. Hanya berlaku untuk
    router milik admin master sendiri (bukan milik reseller)."""
    db = get_db()
    aksi = request.form.get("aksi", "").strip()
    router_ids = [int(x) for x in request.form.getlist("router_ids") if x.isdigit()]
    if not router_ids:
        flash("Pilih dulu minimal satu router.", "danger")
        return redirect(url_for("router_admin"))

    placeholder = ",".join("?" * len(router_ids))
    milik_sendiri = {
        row["id"] for row in db.execute(
            f"SELECT id FROM router WHERE id IN ({placeholder}) AND reseller_id IS NULL", router_ids
        ).fetchall()
    }

    if aksi == "set_aktif":
        if milik_sendiri:
            ph = ",".join("?" * len(milik_sendiri))
            db.execute(f"UPDATE router SET status='aktif' WHERE id IN ({ph})", tuple(milik_sendiri))
            db.commit()
        flash(f"{len(milik_sendiri)} router diaktifkan.", "success")

    elif aksi == "non_aktif":
        boleh = milik_sendiri - {1}
        if boleh:
            ph = ",".join("?" * len(boleh))
            db.execute(f"UPDATE router SET status='nonaktif' WHERE id IN ({ph})", tuple(boleh))
            db.commit()
        flash(f"{len(boleh)} router dinonaktifkan.", "success")
        if 1 in milik_sendiri:
            flash("Router Utama tidak bisa dinonaktifkan.", "warning")

    elif aksi == "hapus":
        total = 0
        gagal = []
        for rid in milik_sendiri:
            if rid == 1:
                gagal.append("Router Utama")
                continue
            row = db.execute("SELECT * FROM router WHERE id=?", (rid,)).fetchone()
            if not row:
                continue
            jumlah = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE router_id=?", (rid,)).fetchone()["c"]
            if jumlah > 0:
                gagal.append(f"{row['nama_router']} (masih dipakai {jumlah} pelanggan)")
                continue
            db.execute("DELETE FROM router WHERE id=?", (rid,))
            total += 1
        db.commit()
        if total:
            flash(f"{total} router berhasil dihapus.", "success")
        if gagal:
            flash("Tidak bisa dihapus: " + ", ".join(gagal), "warning")
    else:
        flash("Aksi tidak dikenali.", "danger")

    return redirect(url_for("router_admin"))


@app.route("/api/server-name", methods=["GET"])
@login_required
def api_server_name_list():
    db = get_db()
    rows = db.execute("SELECT id, nama FROM server_name_master ORDER BY id DESC").fetchall()
    return jsonify(ok=True, data=[{"id": r["id"], "nama": r["nama"]} for r in rows])


@app.route("/api/server-name", methods=["POST"])
@login_required
def api_server_name_tambah():
    db = get_db()
    nama = (request.form.get("nama") or (request.get_json(silent=True) or {}).get("nama") or "").strip()
    if not nama:
        return jsonify(ok=False, message="Nama server wajib diisi.")
    ada = db.execute("SELECT id FROM server_name_master WHERE nama=?", (nama,)).fetchone()
    if ada:
        return jsonify(ok=False, message="Nama server ini sudah ada di daftar.")
    db.execute("INSERT INTO server_name_master (nama, tanggal_dibuat) VALUES (?, ?)",
               (nama, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    db.commit()
    return jsonify(ok=True, message="Server name ditambahkan.")


@app.route("/api/server-name/edit/<int:server_id>", methods=["POST"])
@login_required
def api_server_name_edit(server_id):
    db = get_db()
    nama = (request.form.get("nama") or (request.get_json(silent=True) or {}).get("nama") or "").strip()
    if not nama:
        return jsonify(ok=False, message="Nama server wajib diisi.")
    row = db.execute("SELECT id FROM server_name_master WHERE id=?", (server_id,)).fetchone()
    if not row:
        return jsonify(ok=False, message="Data tidak ditemukan.")
    bentrok = db.execute("SELECT id FROM server_name_master WHERE nama=? AND id!=?", (nama, server_id)).fetchone()
    if bentrok:
        return jsonify(ok=False, message="Nama server ini sudah dipakai baris lain.")
    db.execute("UPDATE server_name_master SET nama=? WHERE id=?", (nama, server_id))
    db.commit()
    return jsonify(ok=True, message="Server name diperbarui.")


@app.route("/api/server-name/hapus/<int:server_id>", methods=["POST"])
@login_required
def api_server_name_hapus(server_id):
    db = get_db()
    db.execute("DELETE FROM server_name_master WHERE id=?", (server_id,))
    db.commit()
    return jsonify(ok=True, message="Server name dihapus.")


@app.route("/pop-site/pelanggan")
@login_required
def pop_site_pelanggan():
    """Menu POP Site > Pelanggan POP Site -- daftar pelanggan yang dikelompokkan
    per POP/router, lengkap dengan fitur isolir langsung dari halaman ini
    (memakai endpoint toggle_isolir yang sama dengan menu Customer > Pelanggan)."""
    db = get_db()
    f_router_id = request.args.get("router_id", "").strip()

    # Menu ini khusus untuk pelanggan yang ada di router POP Site milik RESELLER
    # -- pelanggan yang nempel di Router Utama (id=1) ATAUPUN di router yang
    # dibuat sendiri oleh Admin Master (bukan milik reseller manapun) sengaja
    # TIDAK ditampilkan di sini, supaya "Pelanggan POP Site" murni cuma berisi
    # pelanggan yang POP/router-nya benar-benar milik reseller. Pelanggan yang
    # dikecualikan tadi tetap kebaca lengkap di menu Customer > Pelanggan.
    kondisi = ["pl.router_id IS NOT NULL", "pl.router_id != 1", "r.reseller_id IS NOT NULL"]
    parameter = []
    if f_router_id:
        kondisi.append("pl.router_id = ?")
        parameter.append(f_router_id)
    where_sql = f"WHERE {' AND '.join(kondisi)}"

    daftar_pelanggan = db.execute(
        f"""SELECT pl.*, pk.nama_paket, r.nama_router, rs.nama_bisnis AS nama_reseller
            FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
            LEFT JOIN router r ON r.id = pl.router_id
            LEFT JOIN reseller rs ON rs.id = pl.reseller_id
            {where_sql}
            ORDER BY (r.reseller_id IS NOT NULL), r.id, pl.nama""", parameter
    ).fetchall()

    # Ringkasan per POP/router (dipakai kartu filter cepat di atas tabel).
    # Router Utama (id=1) dan router yang bukan milik reseller (dikelola
    # langsung Admin Master) dikecualikan karena bukan POP Site reseller.
    daftar_router = db.execute(
        """SELECT r.*, rs.nama_bisnis AS pemilik_reseller,
                  (SELECT COUNT(*) FROM pelanggan WHERE router_id = r.id) AS jumlah_pelanggan,
                  (SELECT COUNT(*) FROM pelanggan WHERE router_id = r.id AND status = 'isolir') AS jumlah_isolir
           FROM router r LEFT JOIN reseller rs ON rs.id = r.reseller_id
           WHERE r.id != 1 AND r.reseller_id IS NOT NULL
           ORDER BY (r.reseller_id IS NOT NULL), r.id"""
    ).fetchall()

    total_pelanggan = len(daftar_pelanggan)
    total_aktif = sum(1 for p in daftar_pelanggan if p["status"] == "aktif")
    total_isolir = total_pelanggan - total_aktif

    # Data pendukung untuk toolbar aksi cepat (Set Billing, Simulator, Tambah
    # Pelanggan, Ganti Router, dst) -- sama seperti yang dipakai menu Data Customer.
    daftar_paket = db.execute("SELECT * FROM paket ORDER BY nama_paket").fetchall()
    daftar_odp = db.execute("SELECT * FROM odp ORDER BY nama").fetchall()

    hal = _paginate(daftar_pelanggan)
    daftar_pelanggan = hal["items"]

    return render_template(
        "pop_site_pelanggan.html",
        daftar_pelanggan=daftar_pelanggan,
        daftar_router=daftar_router,
        daftar_paket=daftar_paket,
        daftar_odp=daftar_odp,
        filter_router_id=f_router_id,
        total_pelanggan=total_pelanggan,
        total_aktif=total_aktif,
        total_isolir=total_isolir,
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"],
        total=hal["total"],
        hari_ini=date.today().isoformat(),
    )


# ==================== Modal "DATA PELANGGAN" di tombol toolbar Pelanggan (POP Site) ====================
# Tombol "Pelanggan" di toolbar Aksi Cepat POP Site tadinya cuma link pindah ke
# menu Customer > Pelanggan. Sekarang tombol itu membuka layer/modal "DATA
# PELANGGAN" langsung di halaman ini (lihat modalDataPelangganPS di
# pop_site_pelanggan.html), lengkap dengan tombol Menu/Export/Password
# Massal/Kosongkan PW/Tambah. 3 endpoint di bawah ini melayani tombol-tombol
# tersebut, dibatasi hanya ke pelanggan POP Site sesuai filter router yang
# sedang aktif supaya tidak menyentuh pelanggan di POP/router lain.

@app.route("/pop-site/pelanggan/password-massal", methods=["POST"])
@login_required
def pop_site_pelanggan_password_massal():
    db = get_db()
    password_baru = request.form.get("password_baru", "").strip()
    ids = request.form.getlist("pelanggan_ids")
    router_id = request.form.get("router_id", "").strip()
    if len(password_baru) < 7:
        flash("Password minimal 7 karakter.", "danger")
    elif not ids:
        flash("Tidak ada pelanggan pada POP Site ini untuk diganti passwordnya.", "warning")
    else:
        db.executemany("UPDATE pelanggan SET password_pppoe=? WHERE id=?",
                        [(password_baru, i) for i in ids])
        db.commit()
        _catat_aktivitas("pppoe", "Password Massal", f"Ganti password {len(ids)} pelanggan (POP Site).")
        flash(f"Password {len(ids)} pelanggan pada POP Site ini berhasil diganti.", "success")
    return redirect(url_for("pop_site_pelanggan", router_id=router_id))


@app.route("/pop-site/pelanggan/kosongkan-password", methods=["POST"])
@login_required
def pop_site_pelanggan_kosongkan_password():
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    router_id = request.form.get("router_id", "").strip()
    if not ids:
        flash("Tidak ada pelanggan pada POP Site ini untuk dikosongkan passwordnya.", "warning")
    else:
        db.executemany("UPDATE pelanggan SET password_pppoe='' WHERE id=?", [(i,) for i in ids])
        db.commit()
        _catat_aktivitas("pppoe", "Kosongkan Password", f"Kosongkan password {len(ids)} pelanggan (POP Site).")
        flash(f"Password {len(ids)} pelanggan pada POP Site ini berhasil dikosongkan.", "success")
    return redirect(url_for("pop_site_pelanggan", router_id=router_id))


@app.route("/pop-site/pelanggan/reset-password/<int:pid>", methods=["POST"])
@login_required
def pop_site_pelanggan_reset_password_satu(pid):
    db = get_db()
    row = db.execute("SELECT nama FROM pelanggan WHERE id=?", (pid,)).fetchone()
    router_id = request.form.get("router_id", "").strip()
    if not row:
        flash("Pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("pop_site_pelanggan", router_id=router_id))
    password_baru = secrets.token_hex(3)
    db.execute("UPDATE pelanggan SET password_pppoe=? WHERE id=?", (password_baru, pid))
    db.commit()
    _catat_aktivitas("pppoe", "Reset Password", f"Reset password {row['nama']}.")
    flash(f"Password baru untuk {row['nama']}: {password_baru}", "success")
    return redirect(url_for("pop_site_pelanggan", router_id=router_id))


@app.route("/pop-site/pelanggan/kredensial/<int:pid>")
@login_required
def pop_site_pelanggan_kredensial(pid):
    """Dipakai tombol AUTO LOGIN di modal Data Pelanggan -- kembalikan username &
    password PPPoE pelanggan supaya bisa disalin admin untuk login-kan pelanggan
    ke Portal Pelanggan tanpa harus buka menu lain."""
    db = get_db()
    row = db.execute("SELECT username_pppoe, password_pppoe FROM pelanggan WHERE id=?", (pid,)).fetchone()
    if not row:
        return jsonify({"ok": False, "pesan": "Pelanggan tidak ditemukan."}), 404
    return jsonify({"ok": True, "username": row["username_pppoe"], "password": row["password_pppoe"] or ""})


# ==================== POP Site > Tiket (request maintenance dari Reseller) ====================
STATUS_TIKET_RESELLER_LABEL = {
    "baru": "Baru",
    "diproses": "Diproses",
    "selesai": "Selesai",
    "ditutup": "Ditutup",
}
KATEGORI_TIKET_RESELLER_LABEL = {
    "maintenance": "Maintenance",
    "gangguan": "Gangguan",
    "upgrade": "Upgrade",
    "lainnya": "Lainnya",
}


def _query_tiket_reseller(db):
    """Ambil daftar tiket maintenance reseller sesuai filter (?status, ?kategori, ?q)
    yang sedang aktif di URL. Dipakai halaman POP Site > Tiket."""
    status_filter = request.args.get("status", "semua")
    kategori_filter = request.args.get("kategori", "semua")
    q = request.args.get("q", "").strip()

    query = """SELECT tr.*, rs.nama_bisnis AS nama_reseller, rs.username AS username_reseller,
                      rt.nama_router
               FROM tiket_reseller tr
               JOIN reseller rs ON rs.id = tr.reseller_id
               LEFT JOIN router rt ON rt.id = tr.router_id
               WHERE 1=1"""
    params = []
    if status_filter != "semua":
        query += " AND tr.status=?"
        params.append(status_filter)
    if kategori_filter != "semua":
        query += " AND tr.kategori=?"
        params.append(kategori_filter)
    if q:
        query += " AND (tr.judul LIKE ? OR rs.nama_bisnis LIKE ? OR rs.username LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    query += " ORDER BY tr.id DESC"
    daftar = db.execute(query, params).fetchall()
    return daftar, status_filter, kategori_filter, q


@app.route("/pop-site/tiket")
@login_required
def pop_site_tiket():
    """Menu POP Site > Tiket -- daftar permintaan maintenance/gangguan yang
    diajukan reseller lewat Dashboard Reseller, ditindaklanjuti admin di sini."""
    db = get_db()
    daftar_tiket, status_filter, kategori_filter, q = _query_tiket_reseller(db)

    jumlah_per_status = {
        s: db.execute("SELECT COUNT(*) c FROM tiket_reseller WHERE status=?", (s,)).fetchone()["c"]
        for s in STATUS_TIKET_RESELLER_LABEL
    }
    total_tiket = db.execute("SELECT COUNT(*) c FROM tiket_reseller").fetchone()["c"]

    # Daftar reseller & router buat dropdown di modal "Add Ticket" (bikin tiket
    # tanpa pindah halaman, form-nya sama persis dengan pop_site_tiket_tambah).
    daftar_reseller = db.execute(
        "SELECT id, nama_bisnis, username FROM reseller ORDER BY nama_bisnis").fetchall()
    daftar_router = db.execute(
        "SELECT id, nama_router, reseller_id FROM router ORDER BY nama_router").fetchall()

    hal = _paginate(daftar_tiket)

    return render_template(
        "pop_site_tiket.html",
        daftar_tiket=hal["items"], status_filter=status_filter, kategori_filter=kategori_filter, q=q,
        jumlah_per_status=jumlah_per_status, total_tiket=total_tiket,
        status_label=STATUS_TIKET_RESELLER_LABEL, kategori_label=KATEGORI_TIKET_RESELLER_LABEL,
        prioritas_label=PRIORITAS_LABEL, daftar_reseller=daftar_reseller, daftar_router=daftar_router,
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total=hal["total"], total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"],
    )


@app.route("/pop-site/tiket/tambah", methods=["GET", "POST"])
@login_required
def pop_site_tiket_tambah():
    """Menu POP Site > Tambah Tiket -- admin bikin tiket maintenance/gangguan
    manual atas nama salah satu reseller (mis. reseller lapor lewat telepon/WA,
    bukan lewat Dashboard Reseller). Hasilnya masuk ke tabel yang sama dengan
    tiket yang diajukan reseller sendiri, jadi langsung muncul di daftar
    POP Site > Tiket dan bisa dipantau reseller yang bersangkutan."""
    db = get_db()
    daftar_reseller = db.execute(
        "SELECT id, nama_bisnis, username FROM reseller ORDER BY nama_bisnis").fetchall()
    daftar_router = db.execute(
        "SELECT id, nama_router, reseller_id FROM router ORDER BY nama_router").fetchall()

    if request.method == "POST":
        reseller_id = request.form.get("reseller_id", "").strip()
        router_id = request.form.get("router_id", "").strip() or None
        kategori = request.form.get("kategori", "maintenance").strip() or "maintenance"
        if kategori not in KATEGORI_TIKET_RESELLER_LABEL:
            kategori = "maintenance"
        judul = request.form.get("judul", "").strip()
        deskripsi = request.form.get("deskripsi", "").strip()
        prioritas = request.form.get("prioritas", "medium")
        if prioritas not in PRIORITAS_LABEL:
            prioritas = "medium"

        reseller_valid = db.execute(
            "SELECT id FROM reseller WHERE id=?", (reseller_id,)).fetchone() if reseller_id else None

        if router_id:
            router_valid = db.execute(
                "SELECT id FROM router WHERE id=? AND (reseller_id=? OR reseller_id IS NULL)",
                (router_id, reseller_id)).fetchone()
            if not router_valid:
                router_id = None

        if not reseller_valid:
            flash("Reseller/POP wajib dipilih.", "danger")
        elif not judul or not deskripsi:
            flash("Judul dan deskripsi permintaan wajib diisi.", "danger")
        else:
            db.execute(
                """INSERT INTO tiket_reseller (reseller_id, router_id, kategori, judul, deskripsi,
                                                prioritas, status, dibuat_pada)
                   VALUES (?,?,?,?,?,?, 'baru', ?)""",
                (reseller_valid["id"], router_id, kategori, judul, deskripsi, prioritas, _sekarang()))
            db.commit()
            flash("Tiket berhasil dibuat.", "success")
            return redirect(url_for("pop_site_tiket"))

    return render_template(
        "pop_site_tiket_tambah.html", daftar_reseller=daftar_reseller, daftar_router=daftar_router,
        kategori_label=KATEGORI_TIKET_RESELLER_LABEL, prioritas_label=PRIORITAS_LABEL)


@app.route("/pop-site/tiket/<int:tiket_id>", methods=["GET", "POST"])
@login_required
def pop_site_tiket_detail(tiket_id):
    """Detail satu tiket maintenance reseller: admin ubah status & kasih catatan,
    hasilnya langsung kebaca reseller yang bersangkutan di Dashboard Reseller."""
    db = get_db()
    tk = db.execute(
        """SELECT tr.*, rs.nama_bisnis AS nama_reseller, rs.username AS username_reseller,
                  rs.no_hp AS no_hp_reseller, rt.nama_router, rt.host AS host_router
           FROM tiket_reseller tr
           JOIN reseller rs ON rs.id = tr.reseller_id
           LEFT JOIN router rt ON rt.id = tr.router_id
           WHERE tr.id=?""", (tiket_id,)).fetchone()
    if not tk:
        flash("Tiket tidak ditemukan.", "danger")
        return redirect(url_for("pop_site_tiket"))

    if request.method == "POST":
        status_baru = request.form.get("status", tk["status"])
        if status_baru not in STATUS_TIKET_RESELLER_LABEL:
            status_baru = tk["status"]
        catatan_admin = request.form.get("catatan_admin", "").strip() or None
        db.execute(
            "UPDATE tiket_reseller SET status=?, catatan_admin=?, diperbarui_pada=? WHERE id=?",
            (status_baru, catatan_admin, _sekarang(), tiket_id))
        db.commit()
        flash("Tiket berhasil diperbarui.", "success")
        return redirect(url_for("pop_site_tiket_detail", tiket_id=tiket_id))

    return render_template(
        "pop_site_tiket_detail.html", tk=tk, status_label=STATUS_TIKET_RESELLER_LABEL,
        kategori_label=KATEGORI_TIKET_RESELLER_LABEL)


@app.route("/pop-site/tiket/<int:tiket_id>/hapus", methods=["POST"])
@login_required
def pop_site_tiket_hapus(tiket_id):
    db = get_db()
    db.execute("DELETE FROM tiket_reseller WHERE id=?", (tiket_id,))
    db.commit()
    flash("Tiket dihapus.", "success")
    return redirect(url_for("pop_site_tiket"))


@app.route("/pop-site/tiket/hapus-massal", methods=["POST"])
@login_required
def pop_site_tiket_hapus_massal():
    """Tombol HAPUS di toolbar menu POP Site > Tiket -- hapus banyak tiket sekaligus."""
    db = get_db()
    ids = request.form.getlist("tiket_ids")
    if not ids:
        flash("Pilih dulu minimal satu tiket yang mau dihapus.", "danger")
        return redirect(url_for("pop_site_tiket"))

    total = 0
    for tid in ids:
        try:
            tid = int(tid)
        except ValueError:
            continue
        row = db.execute("SELECT id FROM tiket_reseller WHERE id=?", (tid,)).fetchone()
        if not row:
            continue
        db.execute("DELETE FROM tiket_reseller WHERE id=?", (tid,))
        total += 1
    db.commit()
    flash(f"{total} tiket dihapus.", "success")
    return redirect(url_for("pop_site_tiket"))


@app.route("/pop-site/tiket/export")
@login_required
def pop_site_tiket_export():
    """Tombol EXPORT FILE di toolbar menu POP Site > Tiket -- export daftar tiket
    yang sedang tampil (sesuai filter aktif) ke file Excel (.xlsx)."""
    db = get_db()
    daftar_tiket, status_filter, kategori_filter, q = _query_tiket_reseller(db)

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Tiket POP Site"

    kolom = [
        ("ID", 6), ("Judul", 30), ("Deskripsi", 36), ("Reseller", 20), ("Username Reseller", 18),
        ("POP / Router", 18), ("Kategori", 16), ("Prioritas", 12), ("Status", 12),
        ("Catatan Admin", 30), ("Dibuat Pada", 16), ("Diperbarui Pada", 16),
    ]
    header_font = Font(name="Calibri", bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    for idx, (judul_kolom, lebar) in enumerate(kolom, start=1):
        sel = ws.cell(row=1, column=idx, value=judul_kolom)
        sel.font = header_font
        sel.fill = header_fill
        sel.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = lebar
    ws.freeze_panes = "A2"

    for baris, tk in enumerate(daftar_tiket, start=2):
        nilai = [
            tk["id"], tk["judul"], tk["deskripsi"], tk["nama_reseller"], tk["username_reseller"],
            tk["nama_router"] or "-", KATEGORI_TIKET_RESELLER_LABEL.get(tk["kategori"], tk["kategori"]),
            PRIORITAS_LABEL.get(tk["prioritas"], tk["prioritas"]),
            STATUS_TIKET_RESELLER_LABEL.get(tk["status"], tk["status"]),
            tk["catatan_admin"] or "", tk["dibuat_pada"], tk["diperbarui_pada"] or "",
        ]
        for kolom_idx, v in enumerate(nilai, start=1):
            ws.cell(row=baris, column=kolom_idx, value=v).alignment = Alignment(vertical="top")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    nama_file = f"tiket_pop_site_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=nama_file,
    )


@app.route("/portal")
@pelanggan_login_required
def portal_pelanggan():
    """Halaman billing pribadi pelanggan: status layanan & riwayat tagihan."""
    db = get_db()
    pelanggan = db.execute(
        """SELECT pl.*, pk.nama_paket, pk.kecepatan, pk.harga
           FROM pelanggan pl LEFT JOIN paket pk ON pl.paket_id = pk.id
           WHERE pl.id=?""",
        (session["pelanggan_id"],)
    ).fetchone()
    if not pelanggan:
        session.pop("pelanggan_id", None)
        session.pop("pelanggan_nama", None)
        flash("Data pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("login"))

    daftar_tagihan = db.execute(
        "SELECT * FROM tagihan WHERE pelanggan_id=? ORDER BY periode DESC",
        (session["pelanggan_id"],)
    ).fetchall()

    total_belum_lunas = sum(t["jumlah"] for t in daftar_tagihan if t["status"] == "belum_lunas")

    # --- tagihan terdekat yang belum lunas, untuk CTA "waktunya bayar" di dashboard ---
    tagihan_belum_lunas_list = [t for t in daftar_tagihan if t["status"] == "belum_lunas"]
    tagihan_terdekat = None
    hari_menuju_jatuh_tempo = None
    status_jatuh_tempo = None  # 'lewat', 'dekat', 'normal'
    if tagihan_belum_lunas_list:
        def _kunci_urut(t):
            return t["tanggal_jatuh_tempo"] or "9999-99-99"
        tagihan_terdekat = sorted(tagihan_belum_lunas_list, key=_kunci_urut)[0]
        if tagihan_terdekat["tanggal_jatuh_tempo"]:
            try:
                tgl_jatuh_tempo = datetime.strptime(tagihan_terdekat["tanggal_jatuh_tempo"], "%Y-%m-%d").date()
                selisih = (tgl_jatuh_tempo - date.today()).days
                hari_menuju_jatuh_tempo = selisih
                if selisih < 0:
                    status_jatuh_tempo = "lewat"
                elif selisih <= 3:
                    status_jatuh_tempo = "dekat"
                else:
                    status_jatuh_tempo = "normal"
            except ValueError:
                status_jatuh_tempo = "normal"
        else:
            status_jatuh_tempo = "normal"

    # --- data Client Area (WiFi/ONT via GenieACS), kalau fiturnya aktif ---
    genieacs_cfg, genieacs_device = _ambil_device_genieacs_pelanggan(db, session["pelanggan_id"])
    info_ont = None
    if genieacs_cfg and genieacs_device:
        info_ont = genieacs_client.ambil_info_ont(genieacs_cfg, genieacs_device)
        info_ont["warna_redaman"] = _warna_redaman(info_ont["rx_power"])
        info_ont["uptime_teks"] = genieacs_client.format_uptime_detik(info_ont["uptime_detik"])

    return render_template(
        "portal_pelanggan.html",
        pelanggan=pelanggan,
        daftar_tagihan=daftar_tagihan,
        total_belum_lunas=total_belum_lunas,
        tagihan_terdekat=tagihan_terdekat,
        hari_menuju_jatuh_tempo=hari_menuju_jatuh_tempo,
        status_jatuh_tempo=status_jatuh_tempo,
        genieacs_aktif=bool(genieacs_cfg),
        genieacs_device_ada=bool(genieacs_device),
        info_ont=info_ont,
    )


@app.route("/portal/ont/ssid/<int:idx>", methods=["POST"])
@pelanggan_login_required
def portal_ubah_ssid(idx):
    """Ganti nama SSID dan/atau password WiFi untuk salah satu SSID (1-4) milik
    ONT pelanggan yang sedang login."""
    if idx not in (1, 2, 3, 4):
        flash("SSID tidak valid.", "danger")
        return redirect(url_for("portal_pelanggan"))

    db = get_db()
    cfg, device = _ambil_device_genieacs_pelanggan(db, session["pelanggan_id"])
    if not cfg:
        flash("Fitur Client Area WiFi belum aktif. Hubungi admin/CS.", "danger")
        return redirect(url_for("portal_pelanggan"))
    if not device:
        flash("Perangkat ONT kamu belum terdeteksi di sistem. Hubungi admin/CS.", "danger")
        return redirect(url_for("portal_pelanggan"))

    nama_baru = request.form.get("nama_ssid", "").strip()
    password_baru = request.form.get("password_ssid", "").strip()

    if not nama_baru and not password_baru:
        flash("Isi nama WiFi baru dan/atau password baru dulu.", "danger")
        return redirect(url_for("portal_pelanggan"))

    pasangan = []
    if nama_baru:
        pasangan.append((cfg["path_ssid"].replace("{idx}", str(idx)), nama_baru))
    if password_baru:
        if len(password_baru) < 8:
            flash("Password WiFi minimal 8 karakter.", "danger")
            return redirect(url_for("portal_pelanggan"))
        pasangan.append((cfg["path_password"].replace("{idx}", str(idx)), password_baru))

    try:
        genieacs_client.kirim_set_parameter(cfg, device, pasangan)
        flash(f"SSID {idx} berhasil diperbarui. Perangkat yang terhubung ke SSID ini "
              f"perlu menyambung ulang pakai nama/password baru.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal memperbarui SSID {idx}: {e}", "danger")

    return redirect(url_for("portal_pelanggan"))


@app.route("/portal/ont/restart", methods=["POST"])
@pelanggan_login_required
def portal_restart_ont():
    db = get_db()
    cfg, device = _ambil_device_genieacs_pelanggan(db, session["pelanggan_id"])
    if not cfg:
        flash("Fitur Client Area WiFi belum aktif. Hubungi admin/CS.", "danger")
        return redirect(url_for("portal_pelanggan"))
    if not device:
        flash("Perangkat ONT kamu belum terdeteksi di sistem. Hubungi admin/CS.", "danger")
        return redirect(url_for("portal_pelanggan"))
    try:
        genieacs_client.kirim_reboot(cfg, device)
        flash("Perintah restart ONT terkirim. Internet/WiFi akan terputus sementara selama proses booting (sekitar 1-2 menit).", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal mengirim perintah restart: {e}", "danger")
    return redirect(url_for("portal_pelanggan"))



@app.route("/portal/bayar/<int:tid>", methods=["GET", "POST"])
@pelanggan_login_required
def portal_bayar_tagihan(tid):
    """Halaman pelanggan untuk membayar satu tagihan lewat payment gateway Tripay,
    atau transfer bank manual ke rekening perusahaan (dikonfirmasi admin nanti)."""
    db = get_db()
    t = db.execute(
        "SELECT * FROM tagihan WHERE id=? AND pelanggan_id=?",
        (tid, session["pelanggan_id"])).fetchone()
    if not t:
        flash("Tagihan tidak ditemukan.", "danger")
        return redirect(url_for("portal_pelanggan"))
    if t["status"] == "lunas":
        flash("Tagihan ini sudah lunas.", "success")
        return redirect(url_for("portal_pelanggan"))

    pl = db.execute("SELECT * FROM pelanggan WHERE id=?", (session["pelanggan_id"],)).fetchone()
    cfg = _get_tripay_cfg(db)

    if request.method == "POST":
        metode = request.form.get("metode", "").strip()
        if not metode:
            flash("Pilih metode pembayaran dulu.", "danger")
            return redirect(url_for("portal_bayar_tagihan", tid=tid))
        berhasil, hasil = _proses_buat_transaksi_pembayaran(db, t, metode, pl["no_hp"] if pl else None)
        if not berhasil:
            flash(hasil, "danger")
            return redirect(url_for("portal_bayar_tagihan", tid=tid))
        return redirect(hasil["checkout_url"])

    pembayaran_pending = db.execute(
        """SELECT * FROM pembayaran_online WHERE tagihan_id=? AND status='UNPAID'
           ORDER BY id DESC LIMIT 1""", (tid,)).fetchone()

    channel = []
    error_channel = None
    if cfg and not pembayaran_pending:
        try:
            channel = [c for c in (tripay_gateway.ambil_channel_pembayaran(cfg) or []) if c.get("active")]
        except tripay_gateway.TripayError as e:
            error_channel = str(e)

    daftar_rekening_bank = db.execute(
        "SELECT * FROM rekening_bank WHERE aktif=1 ORDER BY urutan ASC, id ASC").fetchall()
    konfirmasi_transfer_pending = db.execute(
        """SELECT * FROM konfirmasi_transfer_bank WHERE tagihan_id=? AND status='menunggu'
           ORDER BY id DESC LIMIT 1""", (tid,)).fetchone()

    return render_template(
        "portal_bayar.html", t=t, tripay_aktif=bool(cfg),
        pembayaran_pending=pembayaran_pending, channel=channel, error_channel=error_channel,
        daftar_rekening_bank=daftar_rekening_bank,
        konfirmasi_transfer_pending=konfirmasi_transfer_pending,
    )


@app.route("/portal/bayar/<int:tid>/transfer-bank", methods=["POST"])
@pelanggan_login_required
def portal_kirim_konfirmasi_transfer(tid):
    """Pelanggan mengirim konfirmasi sudah transfer manual ke rekening perusahaan.
    Tagihan BELUM otomatis lunas -- menunggu admin memeriksa mutasi & menerimanya
    di menu Transfer Bank."""
    db = get_db()
    t = db.execute(
        "SELECT * FROM tagihan WHERE id=? AND pelanggan_id=?",
        (tid, session["pelanggan_id"])).fetchone()
    if not t:
        flash("Tagihan tidak ditemukan.", "danger")
        return redirect(url_for("portal_pelanggan"))
    if t["status"] == "lunas":
        flash("Tagihan ini sudah lunas.", "success")
        return redirect(url_for("portal_pelanggan"))

    rekening_id = request.form.get("rekening_tujuan_id") or None
    bank_pengirim = request.form.get("bank_pengirim", "").strip()
    nama_pengirim = request.form.get("nama_pengirim", "").strip()
    jumlah = request.form.get("jumlah", "").strip()
    tanggal_transfer = request.form.get("tanggal_transfer", "").strip()
    catatan = request.form.get("catatan", "").strip()

    if not bank_pengirim or not nama_pengirim or not jumlah or not tanggal_transfer:
        flash("Bank pengirim, nama pengirim, jumlah, dan tanggal transfer wajib diisi.", "danger")
        return redirect(url_for("portal_bayar_tagihan", tid=tid))

    try:
        jumlah_int = int(jumlah)
    except ValueError:
        flash("Jumlah transfer harus berupa angka.", "danger")
        return redirect(url_for("portal_bayar_tagihan", tid=tid))

    # Bukti transfer (screenshot/foto struk) opsional -- kalau diupload, dinormalisasi
    # jadi JPEG (menghapus metadata & format aneh) supaya aman & konsisten disimpan.
    bukti_path = None
    file_bukti = request.files.get("bukti")
    if file_bukti and file_bukti.filename:
        ekstensi = file_bukti.filename.rsplit(".", 1)[-1].lower() if "." in file_bukti.filename else ""
        if ekstensi not in EKSTENSI_LOGO_DIIZINKAN:
            flash("Format bukti transfer tidak didukung. Gunakan PNG, JPG, JPEG, atau WEBP.", "danger")
            return redirect(url_for("portal_bayar_tagihan", tid=tid))
        try:
            gambar = Image.open(file_bukti.stream)
            gambar = gambar.convert("RGB")
            nama_file = secure_filename(f"bukti_transfer_{tid}_{secrets.token_hex(6)}.jpg")
            gambar.save(os.path.join(UPLOAD_FOLDER, nama_file), format="JPEG", quality=85)
            bukti_path = f"uploads/{nama_file}"
        except (UnidentifiedImageError, OSError):
            flash("Gagal membaca file bukti transfer. Pastikan file berupa gambar yang valid.", "danger")
            return redirect(url_for("portal_bayar_tagihan", tid=tid))

    db.execute(
        """INSERT INTO konfirmasi_transfer_bank
           (tagihan_id, pelanggan_id, rekening_tujuan_id, bank_pengirim, nama_pengirim,
            jumlah, tanggal_transfer, catatan, bukti_path, status, dibuat_tanggal)
           VALUES (?,?,?,?,?,?,?,?,?, 'menunggu', ?)""",
        (tid, session["pelanggan_id"], rekening_id, bank_pengirim, nama_pengirim,
         jumlah_int, tanggal_transfer, catatan, bukti_path, datetime.now().isoformat(timespec="seconds")))
    db.commit()
    flash("Konfirmasi transfer terkirim. Admin akan memeriksa & mengonfirmasi setelah "
          "dana masuk ke rekening.", "success")
    return redirect(url_for("portal_bayar_tagihan", tid=tid))


@app.route("/portal/bayar/<int:tid>/cek-status", methods=["POST"])
@pelanggan_login_required
def portal_cek_status_bayar(tid):
    """Cek manual status transaksi ke Tripay -- dipakai kalau webhook callback belum
    sempat diterima (mis. akses aplikasi masih lokal, belum lewat tunnel publik)."""
    db = get_db()
    t = db.execute(
        "SELECT * FROM tagihan WHERE id=? AND pelanggan_id=?",
        (tid, session["pelanggan_id"])).fetchone()
    if not t:
        flash("Tagihan tidak ditemukan.", "danger")
        return redirect(url_for("portal_pelanggan"))

    pembayaran = db.execute(
        "SELECT * FROM pembayaran_online WHERE tagihan_id=? ORDER BY id DESC LIMIT 1", (tid,)).fetchone()
    cfg = _get_tripay_cfg(db)
    if not pembayaran or not cfg:
        flash("Belum ada transaksi pembayaran online untuk tagihan ini.", "danger")
        return redirect(url_for("portal_bayar_tagihan", tid=tid))

    try:
        data = tripay_gateway.ambil_detail_transaksi(cfg, pembayaran["reference"])
        status_baru = data.get("status") or pembayaran["status"]
        _perbarui_status_pembayaran(
            db, pembayaran, status_baru,
            date.today().isoformat() if status_baru == "PAID" else None)
        if status_baru == "PAID":
            flash("Pembayaran berhasil dikonfirmasi. Tagihan sudah lunas. Terima kasih!", "success")
            return redirect(url_for("portal_pelanggan"))
        flash(f"Status transaksi saat ini: {status_baru}.", "warning")
    except tripay_gateway.TripayError as e:
        flash(f"Gagal cek status ke Tripay: {e}", "danger")

    return redirect(url_for("portal_bayar_tagihan", tid=tid))


def _catat_riwayat_tiket(db, tiket_id, status, catatan):
    """Update status tiket & catat ke tiket_riwayat sekaligus -- ini yang bikin
    setiap perubahan status (baru/menuju_lokasi/on_progress/selesai/ditutup) otomatis
    sinkron & tampil sebagai timeline di halaman pelanggan."""
    waktu = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        "UPDATE tiket_gangguan SET status=?, catatan_admin=?, tanggal_update=? WHERE id=?",
        (status, catatan, waktu, tiket_id))
    db.execute(
        "INSERT INTO tiket_riwayat (tiket_id, status, catatan, waktu) VALUES (?,?,?,?)",
        (tiket_id, status, catatan, waktu))
    db.commit()


@app.route("/portal/tiket", methods=["GET", "POST"])
@pelanggan_login_required
def portal_tiket():
    """Halaman pelanggan untuk lapor gangguan baru & lihat riwayat tiket miliknya."""
    db = get_db()

    if request.method == "POST":
        kategori = request.form.get("kategori", "lainnya").strip() or "lainnya"
        judul = request.form.get("judul", "").strip()
        deskripsi = request.form.get("deskripsi", "").strip()
        if not judul or not deskripsi:
            flash("Judul dan deskripsi gangguan wajib diisi.", "danger")
        else:
            cur = db.execute(
                """INSERT INTO tiket_gangguan (pelanggan_id, kategori, judul, deskripsi, status, tanggal_lapor)
                   VALUES (?,?,?,?, 'baru', ?)""",
                (session["pelanggan_id"], kategori, judul, deskripsi,
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            db.commit()
            _catat_riwayat_tiket(db, cur.lastrowid, "baru", "Laporan diterima, menunggu ditugaskan ke teknisi.")
            flash("Laporan gangguan berhasil dikirim. Tim teknisi akan segera menindaklanjuti.", "success")
        return redirect(url_for("portal_tiket"))

    daftar_tiket = db.execute(
        "SELECT * FROM tiket_gangguan WHERE pelanggan_id=? ORDER BY id DESC",
        (session["pelanggan_id"],)).fetchall()
    return render_template("portal_tiket.html", daftar_tiket=daftar_tiket)


@app.route("/portal/tiket/<int:tiket_id>")
@pelanggan_login_required
def portal_tiket_detail(tiket_id):
    """Detail satu tiket untuk pelanggan: progres teknisi & timeline lengkap."""
    db = get_db()
    tk = db.execute(
        "SELECT * FROM tiket_gangguan WHERE id=? AND pelanggan_id=?",
        (tiket_id, session["pelanggan_id"])).fetchone()
    if not tk:
        flash("Tiket tidak ditemukan.", "danger")
        return redirect(url_for("portal_tiket"))
    riwayat = db.execute(
        "SELECT * FROM tiket_riwayat WHERE tiket_id=? ORDER BY id ASC", (tiket_id,)).fetchall()
    return render_template("portal_tiket_detail.html", tk=tk, riwayat=riwayat)


@app.route("/logout")
def logout():
    # Route ini dipakai bersama oleh tombol "Keluar" admin (base.html) DAN
    # tombol "Keluar" portal pelanggan (portal_pelanggan.html dkk), jadi kedua
    # sesi itu yang dihapus di sini. Sesi reseller sengaja TIDAK ikut dihapus
    # supaya kalau reseller juga sedang login di browser/tab yang sama, dia
    # tidak ikut ter-logout saat admin atau pelanggan logout (lihat juga
    # route /reseller/login & /reseller/logout).
    session.pop("admin_id", None)
    session.pop("admin_username", None)
    session.pop("admin_nama", None)
    session.pop("pelanggan_id", None)
    session.pop("pelanggan_nama", None)
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    # Catatan: pelanggan milik reseller (reseller_id terisi) sengaja TIDAK
    # dihitung/ditampilkan di halaman Dashboard admin ini. Data pelanggan
    # reseller tetap bisa dipantau lewat menu Router/POP (kartu router
    # bertanda "milik reseller") dan menu Reseller (kolom jumlah pelanggan).
    total_pelanggan = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE reseller_id IS NULL").fetchone()["c"]
    total_aktif = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE status='aktif' AND reseller_id IS NULL").fetchone()["c"]
    total_isolir = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE status='isolir' AND reseller_id IS NULL").fetchone()["c"]
    # Persentase pelanggan aktif dipakai buat lebar bar ungu "Pelanggan Online (Aktif)"
    # di panel Realtime dashboard -- dibandingkan ke kapasitas_pelanggan (bukan langsung
    # ke total_pelanggan) supaya barnya tidak langsung penuh 100% cuma karena semua
    # pelanggan yang ada (walau baru 1-2 orang) kebetulan berstatus aktif.
    kapasitas_pelanggan = _kapasitas_display_pelanggan(total_aktif, total_pelanggan)
    pct_aktif = round((total_aktif / kapasitas_pelanggan * 100)) if kapasitas_pelanggan else 0

    periode_ini = date.today().strftime("%Y-%m")
    tagihan_bulan_ini = db.execute(
        """SELECT COUNT(*) c, COALESCE(SUM(t.jumlah),0) total
           FROM tagihan t JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.periode=? AND p.reseller_id IS NULL""",
        (periode_ini,)).fetchone()
    lunas_bulan_ini = db.execute(
        """SELECT COUNT(*) c, COALESCE(SUM(t.jumlah),0) total
           FROM tagihan t JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.periode=? AND t.status='lunas' AND p.reseller_id IS NULL""",
        (periode_ini,)).fetchone()
    belum_lunas_bulan_ini = db.execute(
        """SELECT COUNT(*) c, COALESCE(SUM(t.jumlah),0) total
           FROM tagihan t JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.periode=? AND t.status='belum_lunas' AND p.reseller_id IS NULL""",
        (periode_ini,)).fetchone()

    tagihan_terbaru = db.execute(
        """SELECT t.*, p.nama FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE p.reseller_id IS NULL
           ORDER BY t.id DESC LIMIT 8"""
    ).fetchall()

    total_voucher = db.execute(
        "SELECT COUNT(*) c FROM voucher WHERE reseller_id IS NULL").fetchone()["c"]
    voucher_terpakai = db.execute(
        "SELECT COUNT(*) c FROM voucher WHERE status='terpakai' AND reseller_id IS NULL").fetchone()["c"]
    total_paket = db.execute("SELECT COUNT(*) c FROM paket").fetchone()["c"]
    total_admin = db.execute("SELECT COUNT(*) c FROM admin").fetchone()["c"]

    # Pendapatan voucher: total nilai semua voucher yang sudah dibuat/dicetak.
    # Voucher hotspot bersifat prabayar (dicetak lalu langsung dijual/dipakai),
    # jadi nilainya dihitung dari total harga voucher yang sudah digenerate.
    # Voucher milik reseller dikecualikan dengan alasan yang sama seperti pelanggan.
    pendapatan_voucher_total = db.execute(
        "SELECT COALESCE(SUM(harga),0) total FROM voucher WHERE reseller_id IS NULL").fetchone()["total"]
    pendapatan_voucher_bulan_ini = db.execute(
        "SELECT COALESCE(SUM(harga),0) total FROM voucher WHERE dibuat_tanggal LIKE ? AND reseller_id IS NULL",
        (f"{periode_ini}%",)).fetchone()["total"]

    pengaturan_mk = db.execute("SELECT host FROM router WHERE id=1").fetchone()
    mikrotik_terhubung = bool(pengaturan_mk and pengaturan_mk["host"])

    total_router = db.execute(
        "SELECT COUNT(*) c FROM router WHERE reseller_id IS NULL").fetchone()["c"]
    router_aktif = db.execute(
        "SELECT COUNT(*) c FROM router WHERE status='aktif' AND reseller_id IS NULL").fetchone()["c"]

    total_olt = db.execute("SELECT COUNT(*) c FROM olt_device").fetchone()["c"]
    onu_total = db.execute("SELECT COUNT(*) c FROM onu").fetchone()["c"]
    onu_online_total = db.execute("SELECT COUNT(*) c FROM onu WHERE status_terakhir='online'").fetchone()["c"]

    try:
        aktivitas_login = db.execute(
            """SELECT waktu, 'login' AS kategori, tipe AS sub_tipe, username AS aksi,
                      NULL AS keterangan, status
               FROM login_log
               UNION ALL
               SELECT waktu, kategori, kategori AS sub_tipe, aksi, keterangan, status
               FROM aktivitas_sistem
               ORDER BY waktu DESC LIMIT 10"""
        ).fetchall()
    except sqlite3.OperationalError:
        aktivitas_login = []

    # Widget "Tagihan Jatuh Tempo / Akan Expired": tagihan belum lunas yang sudah
    # lewat jatuh tempo (tunggakan) ATAU akan jatuh tempo dalam 7 hari ke depan,
    # diurutkan dari yang paling mendesak (paling lama lewat tempo) di atas.
    hari_ini = date.today()
    batas_h7 = (hari_ini + timedelta(days=7)).isoformat()
    baris_jatuh_tempo = db.execute(
        """SELECT t.id, t.periode, t.jumlah, t.tanggal_jatuh_tempo, p.nama, p.no_hp
           FROM tagihan t JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.status='belum_lunas' AND t.tanggal_jatuh_tempo IS NOT NULL
                 AND t.tanggal_jatuh_tempo <= ? AND p.reseller_id IS NULL
           ORDER BY t.tanggal_jatuh_tempo ASC LIMIT 10""",
        (batas_h7,)
    ).fetchall()

    tagihan_jatuh_tempo = []
    for r in baris_jatuh_tempo:
        try:
            tgl = datetime.strptime(r["tanggal_jatuh_tempo"], "%Y-%m-%d").date()
            selisih = (tgl - hari_ini).days
        except (ValueError, TypeError):
            selisih = None
        tagihan_jatuh_tempo.append({
            "id": r["id"], "nama": r["nama"], "no_hp": r["no_hp"], "periode": r["periode"],
            "jumlah": r["jumlah"], "tanggal_jatuh_tempo": r["tanggal_jatuh_tempo"],
            "selisih_hari": selisih,
        })
    total_tunggakan_jatuh_tempo = sum(t["jumlah"] for t in tagihan_jatuh_tempo)

    return render_template(
        "dashboard.html",
        total_olt=total_olt,
        onu_total=onu_total,
        onu_online_total=onu_online_total,
        total_pelanggan=total_pelanggan,
        total_aktif=total_aktif,
        total_isolir=total_isolir,
        pct_aktif=pct_aktif,
        kapasitas_pelanggan=kapasitas_pelanggan,
        periode_ini=periode_ini,
        tagihan_bulan_ini=tagihan_bulan_ini,
        lunas_bulan_ini=lunas_bulan_ini,
        belum_lunas_bulan_ini=belum_lunas_bulan_ini,
        tagihan_terbaru=tagihan_terbaru,
        tagihan_jatuh_tempo=tagihan_jatuh_tempo,
        total_tunggakan_jatuh_tempo=total_tunggakan_jatuh_tempo,
        total_voucher=total_voucher,
        voucher_terpakai=voucher_terpakai,
        total_paket=total_paket,
        total_admin=total_admin,
        pendapatan_voucher_total=pendapatan_voucher_total,
        pendapatan_voucher_bulan_ini=pendapatan_voucher_bulan_ini,
        mikrotik_terhubung=mikrotik_terhubung,
        mikrotik_host=pengaturan_mk["host"] if pengaturan_mk else "",
        total_router=total_router,
        router_aktif=router_aktif,
        aktivitas_login=aktivitas_login,
    )


# ---------------------------------------------------------------------------
# Paket
# ---------------------------------------------------------------------------
@app.route("/paket", methods=["GET", "POST"])
@login_required
def paket():
    db = get_db()
    if request.method == "POST":
        nama = request.form["nama_paket"].strip()
        profile = request.form["profile_mikrotik"].strip()
        rate_limit = request.form.get("rate_limit", "").strip()
        # "Kecepatan" (label ringkas mis. "10M/10M") dulunya diisi manual lewat form
        # terpisah; sekarang kalau dikosongkan, ambil otomatis dari token pertama
        # rate limit mentah (contoh "15M/15M 0/0 0/0 0/0 8 0/0" -> "15M/15M") supaya
        # tampilan di invoice/portal pelanggan tetap terisi tanpa perlu isi dobel.
        kecepatan = request.form.get("kecepatan", "").strip() or (rate_limit.split(" ")[0] if rate_limit else "")
        harga = int(request.form["harga"] or 0)
        warna = request.form.get("warna", "#2f7dd9").strip() or "#2f7dd9"
        masa_aktif = int(request.form.get("masa_aktif") or 30)
        unit_masa_aktif = "HARI"
        tipe_paket = request.form.get("tipe_paket", "Rumahan").strip() or "Rumahan"
        media = request.form.get("media", "Fiber Optic").strip() or "Fiber Optic"
        shared = int(request.form.get("shared") or 1)
        komisi = int(request.form.get("komisi") or 0)
        db.execute(
            "INSERT INTO paket (nama_paket, kecepatan, harga, profile_mikrotik, warna, masa_aktif, "
            "unit_masa_aktif, tipe_paket, media, rate_limit, shared, komisi, status_paket) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'aktif')",
            (nama, kecepatan, harga, profile, warna, masa_aktif, unit_masa_aktif, tipe_paket, media,
             rate_limit, shared, komisi))
        db.commit()
        flash("Profile langganan berhasil ditambahkan.", "success")
        return redirect(url_for("paket"))

    daftar_paket = db.execute("SELECT * FROM paket ORDER BY id DESC").fetchall()

    return render_template(
        "paket.html",
        daftar_paket=daftar_paket,
    )


@app.route("/paket/hapus/<int:paket_id>", methods=["POST"])
@login_required
def hapus_paket(paket_id):
    db = get_db()
    jumlah_pemakai = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE paket_id=?", (paket_id,)).fetchone()["c"]
    if jumlah_pemakai > 0:
        flash(
            f"Paket tidak bisa dihapus karena masih dipakai oleh {jumlah_pemakai} pelanggan. "
            f"Pindahkan dulu pelanggan tersebut ke paket lain, atau edit paket ini saja alih-alih menghapusnya.",
            "danger")
        return redirect(url_for("paket"))
    db.execute("DELETE FROM paket WHERE id=?", (paket_id,))
    db.commit()
    flash("Paket dihapus.", "success")
    return redirect(url_for("paket"))


@app.route("/paket/edit/<int:paket_id>", methods=["POST"])
@login_required
def edit_paket(paket_id):
    db = get_db()
    nama = request.form["nama_paket"].strip()
    profile = request.form["profile_mikrotik"].strip()
    rate_limit = request.form.get("rate_limit", "").strip()
    kecepatan = request.form.get("kecepatan", "").strip() or (rate_limit.split(" ")[0] if rate_limit else "")
    harga = int(request.form["harga"] or 0)
    warna = request.form.get("warna", "#2f7dd9").strip() or "#2f7dd9"
    masa_aktif = int(request.form.get("masa_aktif") or 30)
    unit_masa_aktif = "HARI"
    tipe_paket = request.form.get("tipe_paket", "Rumahan").strip() or "Rumahan"
    media = request.form.get("media", "Fiber Optic").strip() or "Fiber Optic"
    shared = int(request.form.get("shared") or 1)
    komisi = int(request.form.get("komisi") or 0)
    db.execute(
        "UPDATE paket SET nama_paket=?, kecepatan=?, harga=?, profile_mikrotik=?, "
        "warna=?, masa_aktif=?, unit_masa_aktif=?, tipe_paket=?, media=?, rate_limit=?, "
        "shared=?, komisi=? WHERE id=?",
        (nama, kecepatan, harga, profile, warna, masa_aktif, unit_masa_aktif,
         tipe_paket, media, rate_limit, shared, komisi, paket_id))
    db.commit()
    flash("Profile langganan berhasil diperbarui. Klik 'Sync' ulang di halaman Pelanggan agar profile baru diterapkan ke Mikrotik.", "success")
    return redirect(url_for("paket"))


@app.route("/paket/status/<int:paket_id>/<status>", methods=["POST"])
@login_required
def set_status_paket(paket_id, status):
    """Tombol SET AKTIF / NON AKTIF di menu Aksi tiap baris profile langganan.
    Profile yang dinonaktifkan tidak dihapus (pelanggan lama tetap jalan),
    cuma disembunyikan dari pilihan paket saat tambah pelanggan baru."""
    if status not in ("aktif", "nonaktif"):
        flash("Status tidak valid.", "danger")
        return redirect(url_for("paket"))
    db = get_db()
    row = db.execute("SELECT nama_paket FROM paket WHERE id=?", (paket_id,)).fetchone()
    if not row:
        flash("Profile tidak ditemukan.", "danger")
        return redirect(url_for("paket"))
    db.execute("UPDATE paket SET status_paket=? WHERE id=?", (status, paket_id))
    db.commit()
    flash(f"Profile '{row['nama_paket']}' sekarang berstatus {status}.", "success")
    return redirect(url_for("paket"))


@app.route("/paket/bulk-status", methods=["POST"])
@login_required
def bulk_status_paket():
    """Aksi massal (dari dropdown Menu) buat set aktif/nonaktif banyak profile sekaligus."""
    db = get_db()
    status = request.form.get("status")
    ids = request.form.getlist("paket_ids")
    if status not in ("aktif", "nonaktif") or not ids:
        flash("Pilih dulu minimal satu profile dan status yang valid.", "danger")
        return redirect(url_for("paket"))
    total = 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        db.execute("UPDATE paket SET status_paket=? WHERE id=?", (status, pid))
        total += 1
    db.commit()
    flash(f"{total} profile langganan diubah menjadi {status}.", "success")
    return redirect(url_for("paket"))


@app.route("/paket/bulk-hapus", methods=["POST"])
@login_required
def bulk_hapus_paket():
    db = get_db()
    ids = request.form.getlist("paket_ids")
    if not ids:
        flash("Pilih dulu minimal satu profile yang mau dihapus.", "danger")
        return redirect(url_for("paket"))
    dihapus, dilewati = 0, 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        jumlah_pemakai = db.execute(
            "SELECT COUNT(*) c FROM pelanggan WHERE paket_id=?", (pid,)).fetchone()["c"]
        if jumlah_pemakai > 0:
            dilewati += 1
            continue
        db.execute("DELETE FROM paket WHERE id=?", (pid,))
        dihapus += 1
    db.commit()
    pesan = f"{dihapus} profile dihapus."
    if dilewati:
        pesan += f" {dilewati} profile dilewati karena masih dipakai pelanggan."
    flash(pesan, "success" if dihapus else "danger")
    return redirect(url_for("paket"))


# ---------------------------------------------------------------------------
# Pelanggan
# ---------------------------------------------------------------------------
@app.route("/pelanggan", methods=["GET", "POST"])
@login_required
def pelanggan():
    db = get_db()
    if request.method == "POST":
        # 'asal_halaman' dikirim oleh modal Tambah Pelanggan di Data Customer / POP Site
        # supaya user diarahkan balik ke halaman asal setelah simpan, bukan ke menu Pelanggan.
        _asal = request.form.get("asal_halaman")
        tujuan_setelah_simpan = "data_customer" if _asal == "data_customer" else ("pop_site_pelanggan" if _asal == "pop_site" else "pelanggan")
        nama = request.form["nama"].strip()
        alamat = request.form.get("alamat", "").strip()
        no_hp = request.form.get("no_hp", "").strip()
        username_pppoe = request.form["username_pppoe"].strip()
        password_pppoe = request.form["password_pppoe"].strip()
        paket_id = request.form["paket_id"]
        latitude = request.form.get("latitude", "").strip() or None
        longitude = request.form.get("longitude", "").strip() or None
        odp_id = request.form.get("odp_id", "").strip() or None
        tipe_klien = request.form.get("tipe_klien", "personal").strip() or "personal"
        if tipe_klien not in ("personal", "corporate"):
            tipe_klien = "personal"
        no_identitas = request.form.get("no_identitas", "").strip() or None
        kategori_layanan = request.form.get("kategori_layanan", "ppp").strip().lower() or "ppp"
        if kategori_layanan not in ("ppp", "dhcp", "hotspot"):
            kategori_layanan = "ppp"
        jenis_tagihan = request.form.get("jenis_tagihan", "pascabayar").strip().lower() or "pascabayar"
        if jenis_tagihan not in ("prabayar", "pascabayar"):
            jenis_tagihan = "pascabayar"
        status_perangkat = request.form.get("status_perangkat", "").strip() or None
        merk_perangkat = request.form.get("merk_perangkat", "").strip() or None
        sn_perangkat = request.form.get("sn_perangkat", "").strip() or None
        no_port_odp = request.form.get("no_port_odp", "").strip() or None
        catatan = request.form.get("catatan", "").strip() or None
        alamat_ip = request.form.get("alamat_ip", "").strip() or None
        tanggal_mulai_aktif = request.form.get("tanggal_mulai_aktif", "").strip() or date.today().isoformat()
        tanggal_isolir = request.form.get("tanggal_isolir", "").strip() or None
        tgl_invoice_perdana = request.form.get("tgl_invoice_perdana", "").strip() or None
        jatuh_tempo_pembayaran = request.form.get("jatuh_tempo_pembayaran", "").strip() or None
        # Jatuh tempo & kode unik pembayaran -- opsional, bisa langsung diisi saat
        # tambah pelanggan (dipakai modal Tambah Pelanggan di Data Customer) atau
        # diatur belakangan lewat tombol Set Billing / Kode Unik massal.
        hari_tagihan = request.form.get("hari_tagihan", "").strip() or None
        if hari_tagihan is not None:
            try:
                hari_tagihan = int(hari_tagihan)
                if not (1 <= hari_tagihan <= 28):
                    hari_tagihan = None
            except ValueError:
                hari_tagihan = None
        kode_unik = request.form.get("kode_unik", "").strip() or None
        if kode_unik is not None:
            try:
                kode_unik = int(kode_unik)
                if not (0 <= kode_unik <= 998):
                    kode_unik = None
            except ValueError:
                kode_unik = None
        # Router (POP) tujuan pelanggan ini. Admin master boleh pilih router
        # manapun (miliknya sendiri ATAU salah satu punya reseller); kalau
        # dikosongkan/tidak valid, fallback ke Router Utama (id=1) supaya tetap
        # tersambung dan tidak jadi pelanggan "yatim".
        router_id = request.form.get("router_id", "").strip() or "1"
        router_valid = db.execute("SELECT id, reseller_id FROM router WHERE id=?", (router_id,)).fetchone()
        if not router_valid:
            router_id = "1"
            router_valid = db.execute("SELECT id, reseller_id FROM router WHERE id=1").fetchone()
        # kalau router yang dipilih itu punya reseller, pelanggan otomatis ikut
        # tercatat sebagai milik reseller tsb (supaya konsisten dengan dashboard reseller).
        reseller_id = router_valid["reseller_id"] if router_valid else None

        try:
            db.execute(
                """INSERT INTO pelanggan
                   (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id, status,
                    tanggal_daftar, latitude, longitude, odp_id, router_id, reseller_id, tipe_klien,
                    hari_tagihan, kode_unik, no_identitas, kategori_layanan, jenis_tagihan,
                    status_perangkat, merk_perangkat, sn_perangkat, no_port_odp, catatan, alamat_ip,
                    tanggal_mulai_aktif, tanggal_isolir, tgl_invoice_perdana, jatuh_tempo_pembayaran)
                   VALUES (?,?,?,?,?,?, 'aktif', ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id,
                 date.today().isoformat(), latitude, longitude, odp_id, router_id, reseller_id, tipe_klien,
                 hari_tagihan, kode_unik, no_identitas, kategori_layanan, jenis_tagihan,
                 status_perangkat, merk_perangkat, sn_perangkat, no_port_odp, catatan, alamat_ip,
                 tanggal_mulai_aktif, tanggal_isolir, tgl_invoice_perdana, jatuh_tempo_pembayaran))
            db.commit()
            _catat_aktivitas("pppoe", "Tambah Pelanggan", f"{nama} ({username_pppoe})")
            flash("Pelanggan ditambahkan. Jangan lupa klik 'Sync ke Mikrotik'.", "success")
        except sqlite3.IntegrityError:
            flash("Username PPPoE sudah dipakai pelanggan lain.", "danger")
        return redirect(url_for(tujuan_setelah_simpan))

    # Filter opsional: admin master bisa mempersempit tampilan ke pelanggan
    # milik satu reseller/router tertentu saja lewat ?reseller_id=..&router_id=..
    # (dipakai tombol "Lihat Pelanggan" di halaman Reseller). Tanpa filter,
    # SEMUA pelanggan tetap tampil jadi satu daftar gabungan -- baik milik
    # admin master maupun milik reseller manapun.
    f_reseller_id = request.args.get("reseller_id", "").strip()
    f_router_id = request.args.get("router_id", "").strip()
    # Tab kategori Klien: all / personal / corporate / prospects / orphaned
    # (mengikuti tampilan referensi menu Customers -> All Clients/Personal/Corporate/Prospects/Orphaned)
    tab_klien = request.args.get("tab", "all").strip().lower()
    if tab_klien not in ("all", "personal", "corporate", "prospects", "orphaned"):
        tab_klien = "all"

    kondisi = []
    parameter = []
    if f_reseller_id:
        kondisi.append("pl.reseller_id = ?")
        parameter.append(f_reseller_id)
    if f_router_id:
        kondisi.append("pl.router_id = ?")
        parameter.append(f_router_id)
    if tab_klien == "personal":
        kondisi.append("pl.tipe_klien = 'personal'")
    elif tab_klien == "corporate":
        kondisi.append("pl.tipe_klien = 'corporate'")
    elif tab_klien == "orphaned":
        # "Orphaned" = klien yang belum ditautkan ke ODP/infrastruktur jaringan manapun.
        kondisi.append("pl.odp_id IS NULL")
    where_sql = f"WHERE {' AND '.join(kondisi)}" if kondisi else ""

    # Tab "Prospects" menampilkan calon pelanggan (leads) yang belum diproses jadi
    # klien aktif -- datanya dari tabel calon_pelanggan (menu Pendaftaran), bukan
    # tabel pelanggan, jadi daftar_pelanggan dikosongkan dan diganti daftar_prospek.
    daftar_prospek = []
    if tab_klien == "prospects":
        daftar_pelanggan = []
        daftar_prospek = db.execute(
            """SELECT cp.*, pk.nama_paket, pk.harga
               FROM calon_pelanggan cp LEFT JOIN paket pk ON pk.id = cp.paket_id
               WHERE cp.status = 'baru'
               ORDER BY cp.id DESC"""
        ).fetchall()
    else:
        daftar_pelanggan = db.execute(
            f"""SELECT pl.*, pk.nama_paket, pk.harga, pk.profile_mikrotik, od.nama AS nama_odp,
                       r.nama_router, rs.nama_bisnis AS nama_reseller
                FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
                LEFT JOIN odp od ON od.id = pl.odp_id
                LEFT JOIN router r ON r.id = pl.router_id
                LEFT JOIN reseller rs ON rs.id = pl.reseller_id
                {where_sql}
                ORDER BY pl.id DESC""", parameter
        ).fetchall()
    daftar_paket = db.execute("SELECT * FROM paket ORDER BY nama_paket").fetchall()
    daftar_odp = db.execute("SELECT * FROM odp ORDER BY nama").fetchall()
    daftar_router = db.execute(
        """SELECT r.*, rs.nama_bisnis AS pemilik_reseller
           FROM router r LEFT JOIN reseller rs ON rs.id = r.reseller_id
           ORDER BY (r.reseller_id IS NOT NULL), r.nama_router"""
    ).fetchall()
    daftar_reseller_filter = db.execute("SELECT id, nama_bisnis FROM reseller ORDER BY nama_bisnis").fetchall()

    # Badge jumlah per tab, dihitung dari data mentah (tanpa filter reseller/router)
    # supaya konsisten dengan yang ditampilkan di menu referensi.
    jumlah_semua = db.execute("SELECT COUNT(*) c FROM pelanggan").fetchone()["c"]
    jumlah_personal = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE tipe_klien='personal'").fetchone()["c"]
    jumlah_corporate = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE tipe_klien='corporate'").fetchone()["c"]
    jumlah_prospek = db.execute("SELECT COUNT(*) c FROM calon_pelanggan WHERE status='baru'").fetchone()["c"]
    jumlah_orphaned = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE odp_id IS NULL").fetchone()["c"]

    total_pelanggan = len(daftar_pelanggan)
    total_aktif = sum(1 for p in daftar_pelanggan if p["status"] == "aktif")
    total_isolir = total_pelanggan - total_aktif
    # PSB Baru = pelanggan yang tanggal daftarnya jatuh di bulan berjalan (bukan
    # akumulasi keseluruhan), supaya kartu statistik ini menunjukkan penambahan
    # pelanggan baru bulan ini saja dan otomatis reset tiap ganti bulan.
    bulan_berjalan = date.today().strftime("%Y-%m")
    psb_bulan_ini = sum(1 for p in daftar_pelanggan if (p["tanggal_daftar"] or "").startswith(bulan_berjalan))

    # Pagination (dropdown 10/25/50/100) supaya daftar pelanggan/prospek tidak
    # tampil semua sekaligus -- dipotong TERAKHIR, setelah semua badge/statistik
    # di atas dihitung dari data lengkap.
    if tab_klien == "prospects":
        hal = _paginate(daftar_prospek)
        daftar_prospek = hal["items"]
    else:
        hal = _paginate(daftar_pelanggan)
        daftar_pelanggan = hal["items"]

    return render_template(
        "pelanggan.html",
        daftar_pelanggan=daftar_pelanggan,
        daftar_prospek=daftar_prospek,
        daftar_paket=daftar_paket,
        daftar_odp=daftar_odp,
        daftar_router=daftar_router,
        router_aktif_id=session.get("router_aktif", 1),
        daftar_reseller_filter=daftar_reseller_filter,
        filter_reseller_id=f_reseller_id,
        filter_router_id=f_router_id,
        tab_klien=tab_klien,
        jumlah_semua=jumlah_semua,
        jumlah_personal=jumlah_personal,
        jumlah_corporate=jumlah_corporate,
        jumlah_prospek=jumlah_prospek,
        jumlah_orphaned=jumlah_orphaned,
        total_pelanggan=total_pelanggan,
        total_aktif=total_aktif,
        total_isolir=total_isolir,
        psb_bulan_ini=psb_bulan_ini,
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"],
        total=hal["total"],
    )


@app.route("/pelanggan/hapus/<int:pid>", methods=["POST"])
@login_required
def hapus_pelanggan(pid):
    db = get_db()
    row = db.execute("SELECT nama, username_pppoe FROM pelanggan WHERE id=?", (pid,)).fetchone()
    db.execute("DELETE FROM pelanggan WHERE id=?", (pid,))
    db.commit()
    if row:
        _catat_aktivitas("pppoe", "Hapus Pelanggan", f"{row['nama']} ({row['username_pppoe']})")
    flash("Pelanggan dihapus dari billing (tidak otomatis dihapus dari Mikrotik).", "success")
    return redirect(url_for("pelanggan"))


@app.route("/pelanggan/hapus-massal", methods=["POST"])
@login_required
def pelanggan_hapus_massal():
    """Tombol HAPUS di toolbar menu Pelanggan / Data Customer -- hapus banyak
    pelanggan sekaligus (tidak otomatis dihapus dari Mikrotik, sama seperti hapus
    satuan). Dipakai bersama oleh kedua halaman lewat hidden field 'asal_halaman'
    supaya user diarahkan kembali ke halaman asal, bukan selalu ke menu Pelanggan."""
    _asal = request.form.get("asal_halaman")
    tujuan = "data_customer" if _asal == "data_customer" else ("pop_site_pelanggan" if _asal == "pop_site" else "pelanggan")
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    if not ids:
        flash("Pilih dulu minimal satu pelanggan yang mau dihapus.", "danger")
        return redirect(url_for(tujuan))

    total = 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        row = db.execute("SELECT nama, username_pppoe FROM pelanggan WHERE id=?", (pid,)).fetchone()
        if not row:
            continue
        db.execute("DELETE FROM pelanggan WHERE id=?", (pid,))
        _catat_aktivitas("pppoe", "Hapus Pelanggan", f"{row['nama']} ({row['username_pppoe']})")
        total += 1
    db.commit()
    flash(f"{total} pelanggan dihapus dari billing (tidak otomatis dihapus dari Mikrotik).", "success")
    return redirect(url_for(tujuan))


@app.route("/pelanggan/set-billing-massal", methods=["POST"])
@login_required
def pelanggan_set_billing_massal():
    """Tombol SET BILLING di toolbar menu Pelanggan / Data Customer -- atur tanggal
    jatuh tempo (hari dalam bulan) untuk banyak pelanggan sekaligus. Dipakai
    generate_tagihan() setiap bulan sebagai jatuh tempo pelanggan tsb, menggantikan
    default tanggal 20. Diarahkan kembali ke halaman asal lewat 'asal_halaman'."""
    _asal = request.form.get("asal_halaman")
    tujuan = "data_customer" if _asal == "data_customer" else ("pop_site_pelanggan" if _asal == "pop_site" else "pelanggan")
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    hari = request.form.get("hari_tagihan", "").strip()
    if not ids:
        flash("Pilih dulu minimal satu pelanggan.", "danger")
        return redirect(url_for(tujuan))
    try:
        hari = int(hari)
        if not (1 <= hari <= 28):
            raise ValueError
    except ValueError:
        flash("Tanggal jatuh tempo harus angka 1-28.", "danger")
        return redirect(url_for(tujuan))

    total = 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        res = db.execute("UPDATE pelanggan SET hari_tagihan=? WHERE id=?", (hari, pid))
        if res.rowcount:
            total += 1
    db.commit()
    _catat_aktivitas("pppoe", "Set Billing", f"{total} pelanggan diatur jatuh tempo ke tanggal {hari}.")
    flash(f"Tanggal jatuh tempo (tanggal {hari} tiap bulan) diterapkan ke {total} pelanggan.", "success")
    return redirect(url_for(tujuan))


@app.route("/pelanggan/kode-unik-massal", methods=["POST"])
@login_required
def pelanggan_kode_unik_massal():
    """Tombol KODE UNIK di toolbar menu Pelanggan / Data Customer -- generate kode
    unik pembayaran (angka 1-999) untuk banyak pelanggan sekaligus. Kode ini
    otomatis ditambahkan ke nominal tagihan saat generate_tagihan(), supaya nominal
    transfer tiap pelanggan beda-beda dan gampang dicocokkan dengan mutasi
    rekening/e-wallet. Diarahkan kembali ke halaman asal lewat 'asal_halaman'."""
    _asal = request.form.get("asal_halaman")
    tujuan = "data_customer" if _asal == "data_customer" else ("pop_site_pelanggan" if _asal == "pop_site" else "pelanggan")
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    if not ids:
        flash("Pilih dulu minimal satu pelanggan.", "danger")
        return redirect(url_for(tujuan))

    kode_terpakai = {
        row["kode_unik"] for row in db.execute(
            "SELECT kode_unik FROM pelanggan WHERE kode_unik IS NOT NULL").fetchall()
    }
    total = 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        kode = secrets.randbelow(899) + 100  # 100-998, cukup unik & tidak terlalu panjang
        percobaan = 0
        while kode in kode_terpakai and percobaan < 50:
            kode = secrets.randbelow(899) + 100
            percobaan += 1
        kode_terpakai.add(kode)
        res = db.execute("UPDATE pelanggan SET kode_unik=? WHERE id=?", (kode, pid))
        if res.rowcount:
            total += 1
    db.commit()
    _catat_aktivitas("pppoe", "Kode Unik", f"Kode unik pembayaran dibuat untuk {total} pelanggan.")
    flash(f"Kode unik pembayaran berhasil dibuat untuk {total} pelanggan. "
          f"Kode ini otomatis ditambahkan ke nominal tagihan berikutnya.", "success")
    return redirect(url_for(tujuan))


@app.route("/data-customer")
@login_required
def data_customer():
    """Menu Customer > Data Customer -- tampilan tabel padat & mudah difilter untuk
    seluruh data langganan (nomor layanan, kategori, profile, router, status), terinspirasi
    dari tampilan 'Data Langganan' di RL Radius. Untuk tambah/edit/hapus pelanggan secara
    lengkap tetap dilakukan di menu Pelanggan; menu ini fokus untuk mencari & menyaring
    cepat, plus aksi cepat aktif/isolir dan ubah router secara massal."""
    db = get_db()

    q = request.args.get("q", "").strip()
    f_paket_id = request.args.get("paket_id", "").strip()
    f_tipe = request.args.get("tipe", "").strip()
    f_router_id = request.args.get("router_id", "").strip()
    f_status = request.args.get("status", "").strip()
    f_reseller_id = request.args.get("reseller_id", "").strip()

    kondisi = []
    parameter = []
    if q:
        like = f"%{q}%"
        kondisi.append("(pl.nama LIKE ? OR pl.username_pppoe LIKE ? OR pl.no_hp LIKE ? OR pl.alamat LIKE ?)")
        parameter += [like, like, like, like]
    if f_paket_id:
        kondisi.append("pl.paket_id = ?")
        parameter.append(f_paket_id)
    if f_tipe in ("personal", "corporate"):
        kondisi.append("pl.tipe_klien = ?")
        parameter.append(f_tipe)
    if f_router_id:
        kondisi.append("pl.router_id = ?")
        parameter.append(f_router_id)
    if f_status in ("aktif", "isolir"):
        kondisi.append("pl.status = ?")
        parameter.append(f_status)
    if f_reseller_id:
        kondisi.append("pl.reseller_id = ?")
        parameter.append(f_reseller_id)
    where_sql = f"WHERE {' AND '.join(kondisi)}" if kondisi else ""

    daftar_pelanggan = db.execute(
        f"""SELECT pl.*, pk.nama_paket, pk.harga, pk.kecepatan,
                   r.nama_router, rs.nama_bisnis AS nama_reseller
            FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
            LEFT JOIN router r ON r.id = pl.router_id
            LEFT JOIN reseller rs ON rs.id = pl.reseller_id
            {where_sql}
            ORDER BY pl.id DESC""", parameter
    ).fetchall()

    daftar_paket = db.execute("SELECT * FROM paket ORDER BY nama_paket").fetchall()
    daftar_router = db.execute(
        """SELECT r.*, rs.nama_bisnis AS pemilik_reseller
           FROM router r LEFT JOIN reseller rs ON rs.id = r.reseller_id
           ORDER BY (r.reseller_id IS NOT NULL), r.nama_router"""
    ).fetchall()
    daftar_odp = db.execute("SELECT * FROM odp ORDER BY nama").fetchall()
    daftar_reseller_filter = db.execute("SELECT id, nama_bisnis FROM reseller ORDER BY nama_bisnis").fetchall()

    # Statistik kartu di atas dihitung dari data mentah (SEBELUM filter apapun),
    # supaya kartu Total/PSB/Aktif/Terisolir konsisten sebagai gambaran keseluruhan,
    # sama seperti pola di menu Pelanggan.
    jumlah_semua = db.execute("SELECT COUNT(*) c FROM pelanggan").fetchone()["c"]
    jumlah_aktif = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE status='aktif'").fetchone()["c"]
    jumlah_isolir = jumlah_semua - jumlah_aktif
    bulan_berjalan = date.today().strftime("%Y-%m")
    jumlah_psb = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE tanggal_daftar LIKE ?", (f"{bulan_berjalan}%",)
    ).fetchone()["c"]

    hal = _paginate(daftar_pelanggan)
    daftar_pelanggan = hal["items"]

    return render_template(
        "data_customer.html",
        daftar_pelanggan=daftar_pelanggan,
        daftar_paket=daftar_paket,
        daftar_router=daftar_router,
        daftar_odp=daftar_odp,
        daftar_reseller_filter=daftar_reseller_filter,
        q=q, f_paket_id=f_paket_id, f_tipe=f_tipe, f_router_id=f_router_id,
        f_status=f_status, f_reseller_id=f_reseller_id,
        jumlah_semua=jumlah_semua, jumlah_aktif=jumlah_aktif,
        jumlah_isolir=jumlah_isolir, jumlah_psb=jumlah_psb,
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"], total=hal["total"],
        hari_ini=date.today().isoformat(),
    )


# ==================== Modal "DATA PELANGGAN" di tombol toolbar Pelanggan (Data Customer) ====================
# Sama seperti versi POP Site: tombol "Pelanggan" di toolbar Data Customer sekarang
# membuka modal "DATA PELANGGAN" (lihat modalDataPelangganDC di data_customer.html)
# alih-alih pindah ke menu Customer > Pelanggan. 4 endpoint di bawah melayani
# tombol-tombol modal itu, dibatasi ke pelanggan yang cocok dengan filter (q, paket,
# tipe, router, status, reseller) yang sedang aktif di halaman Data Customer.

def _dc_filter_kembali():
    """Susun ulang query string filter Data Customer yang sedang aktif supaya redirect
    balik ke halaman ini tetap mempertahankan filter yang dipakai admin."""
    kunci = ("q", "paket_id", "tipe", "router_id", "status", "reseller_id")
    return {k: request.form.get(k, "") for k in kunci if request.form.get(k, "")}


@app.route("/data-customer/pelanggan/password-massal", methods=["POST"])
@login_required
def data_customer_pelanggan_password_massal():
    db = get_db()
    password_baru = request.form.get("password_baru", "").strip()
    ids = request.form.getlist("pelanggan_ids")
    if len(password_baru) < 7:
        flash("Password minimal 7 karakter.", "danger")
    elif not ids:
        flash("Tidak ada pelanggan pada filter ini untuk diganti passwordnya.", "warning")
    else:
        db.executemany("UPDATE pelanggan SET password_pppoe=? WHERE id=?",
                        [(password_baru, i) for i in ids])
        db.commit()
        _catat_aktivitas("pppoe", "Password Massal", f"Ganti password {len(ids)} pelanggan (Data Customer).")
        flash(f"Password {len(ids)} pelanggan berhasil diganti.", "success")
    return redirect(url_for("data_customer", **_dc_filter_kembali()))


@app.route("/data-customer/pelanggan/kosongkan-password", methods=["POST"])
@login_required
def data_customer_pelanggan_kosongkan_password():
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    if not ids:
        flash("Tidak ada pelanggan pada filter ini untuk dikosongkan passwordnya.", "warning")
    else:
        db.executemany("UPDATE pelanggan SET password_pppoe='' WHERE id=?", [(i,) for i in ids])
        db.commit()
        _catat_aktivitas("pppoe", "Kosongkan Password", f"Kosongkan password {len(ids)} pelanggan (Data Customer).")
        flash(f"Password {len(ids)} pelanggan berhasil dikosongkan.", "success")
    return redirect(url_for("data_customer", **_dc_filter_kembali()))


@app.route("/data-customer/pelanggan/reset-password/<int:pid>", methods=["POST"])
@login_required
def data_customer_pelanggan_reset_password_satu(pid):
    db = get_db()
    row = db.execute("SELECT nama FROM pelanggan WHERE id=?", (pid,)).fetchone()
    if not row:
        flash("Pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("data_customer", **_dc_filter_kembali()))
    password_baru = secrets.token_hex(3)
    db.execute("UPDATE pelanggan SET password_pppoe=? WHERE id=?", (password_baru, pid))
    db.commit()
    _catat_aktivitas("pppoe", "Reset Password", f"Reset password {row['nama']}.")
    flash(f"Password baru untuk {row['nama']}: {password_baru}", "success")
    return redirect(url_for("data_customer", **_dc_filter_kembali()))


@app.route("/data-customer/pelanggan/kredensial/<int:pid>")
@login_required
def data_customer_pelanggan_kredensial(pid):
    """Dipakai tombol AUTO LOGIN di modal Data Pelanggan (Data Customer) -- sama
    seperti versi POP Site, kembalikan username & password PPPoE pelanggan."""
    db = get_db()
    row = db.execute("SELECT username_pppoe, password_pppoe FROM pelanggan WHERE id=?", (pid,)).fetchone()
    if not row:
        return jsonify({"ok": False, "pesan": "Pelanggan tidak ditemukan."}), 404
    return jsonify({"ok": True, "username": row["username_pppoe"], "password": row["password_pppoe"] or ""})


@app.route("/data-customer/status-massal", methods=["POST"])
@login_required
def data_customer_status_massal():
    """Tombol SET AKTIF / SET ISOLIR MANUAL di toolbar Menu -- ubah status banyak
    pelanggan sekaligus, best-effort disinkron ke Mikrotik masing-masing router
    (kalau salah satu router gagal dihubungi, yang lain tetap lanjut diproses).
    Dipakai bersama oleh Data Customer & Pelanggan POP Site lewat hidden field
    'asal_halaman' supaya user diarahkan kembali ke halaman asal."""
    tujuan = "pop_site_pelanggan" if request.form.get("asal_halaman") == "pop_site" else "data_customer"
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    status_baru = request.form.get("status_baru", "").strip()
    if status_baru not in ("aktif", "isolir"):
        flash("Status tujuan tidak valid.", "danger")
        return redirect(url_for(tujuan))
    if not ids:
        flash("Pilih dulu minimal satu pelanggan (centang di tabel).", "danger")
        return redirect(url_for(tujuan))

    berhasil, gagal_sync = 0, 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        row = db.execute("SELECT * FROM pelanggan WHERE id=?", (pid,)).fetchone()
        if not row:
            continue
        client = _get_mikrotik_client(row["router_id"])
        try:
            if client:
                client.set_secret_disabled(row["username_pppoe"], disabled=(status_baru == "isolir"))
        except Exception:
            gagal_sync += 1
        db.execute("UPDATE pelanggan SET status=? WHERE id=?", (status_baru, pid))
        berhasil += 1
    db.commit()
    _catat_aktivitas("pppoe", f"Ubah Status Massal Jadi {status_baru.capitalize()}",
                      f"{berhasil} pelanggan (via {'Pelanggan POP Site' if tujuan == 'pop_site_pelanggan' else 'Data Customer'})")
    pesan = f"{berhasil} pelanggan diubah ke status {status_baru}."
    if gagal_sync:
        pesan += f" {gagal_sync} di antaranya gagal disinkron ke Mikrotik (cek koneksi routernya), tapi status di billing tetap tersimpan."
    flash(pesan, "success" if berhasil else "danger")
    return redirect(url_for(tujuan))


@app.route("/data-customer/ganti-router-massal", methods=["POST"])
@login_required
def data_customer_ganti_router_massal():
    """Tombol GANTI ROUTER di toolbar Menu -- pindahkan banyak pelanggan sekaligus
    ke router/POP lain. Ini hanya memindahkan data billing (router_id & kepemilikan
    reseller-nya ikut router tujuan); secret PPPoE di Mikrotik TIDAK otomatis
    dipindah/dibuat ulang, jadi tetap perlu klik 'Sync ke Mikrotik' per pelanggan
    kalau memang perlu dibuatkan secret baru di router tujuan. Dipakai bersama oleh
    Data Customer & Pelanggan POP Site lewat hidden field 'asal_halaman'."""
    tujuan = "pop_site_pelanggan" if request.form.get("asal_halaman") == "pop_site" else "data_customer"
    db = get_db()
    ids = request.form.getlist("pelanggan_ids")
    router_id = request.form.get("router_id", "").strip()
    if not ids:
        flash("Pilih dulu minimal satu pelanggan (centang di tabel).", "danger")
        return redirect(url_for(tujuan))
    router_row = db.execute("SELECT * FROM router WHERE id=?", (router_id,)).fetchone()
    if not router_row:
        flash("Router tujuan tidak valid.", "danger")
        return redirect(url_for(tujuan))

    total = 0
    for pid in ids:
        try:
            pid = int(pid)
        except ValueError:
            continue
        res = db.execute("UPDATE pelanggan SET router_id=?, reseller_id=? WHERE id=?",
                          (router_row["id"], router_row["reseller_id"], pid))
        if res.rowcount:
            total += 1
    db.commit()
    _catat_aktivitas("pppoe", "Ganti Router Massal",
                      f"{total} pelanggan dipindah ke {router_row['nama_router']} "
                      f"(via {'Pelanggan POP Site' if tujuan == 'pop_site_pelanggan' else 'Data Customer'})")
    flash(f"{total} pelanggan dipindahkan ke router '{router_row['nama_router']}'. "
          f"Ingat: secret PPPoE di Mikrotik belum otomatis mengikuti, sync manual per pelanggan bila perlu.", "success")
    return redirect(url_for(tujuan))


# ==================== Sub-menu CUSTOMER > Langganan: Stop / Online / Offline ====================
# Tiga menu ini melengkapi grup CUSTOMER (Profile Langganan, Data Customer, Pendaftaran,
# Tagihan) supaya strukturnya sejajar dengan menu "Langganan" di RL Radius yang punya
# Profile langganan, Data langganan, Stop langganan, Langganan online & Langganan offline.
# Ketiganya memakai template yang sama (data_customer_status.html) dan cuma beda cara
# menyaring baris pelanggan-nya saja.

def _kumpulkan_status_online_pppoe(daftar_router_id):
    """Cek ke Mikrotik (per router, dengan cache supaya router yang sama tidak
    di-query berkali-kali) siapa saja username PPPoE yang sesi-nya sedang aktif/online
    sekarang. Dipakai oleh menu 'Langganan Online' & 'Langganan Offline'.
    Mengembalikan (set_username_online, set_router_id_gagal_dihubungi)."""
    online = set()
    gagal = set()
    client_cache = {}
    for rid in daftar_router_id:
        rid = rid or 1
        if rid in client_cache:
            continue
        client_cache[rid] = _get_mikrotik_client(rid)
    for rid, client in client_cache.items():
        if not client:
            gagal.add(rid)
            continue
        try:
            for a in client.get_active_connections():
                nama = a.get("name")
                if nama:
                    online.add(nama)
        except Exception:
            gagal.add(rid)
    return online, gagal


@app.route("/data-customer/stop-langganan")
@login_required
def data_customer_stop_langganan():
    """Menu Customer > Stop Langganan -- daftar pelanggan yang layanannya sudah
    diberhentikan/diisolir (status='isolir'), mengikuti pola menu 'Stop Langganan'
    di RL Radius."""
    db = get_db()
    q = request.args.get("q", "").strip()

    kondisi = ["pl.status = 'isolir'"]
    parameter = []
    if q:
        like = f"%{q}%"
        kondisi.append("(pl.nama LIKE ? OR pl.username_pppoe LIKE ? OR pl.no_hp LIKE ? OR pl.alamat LIKE ?)")
        parameter += [like, like, like, like]
    where_sql = "WHERE " + " AND ".join(kondisi)

    daftar_pelanggan = db.execute(
        f"""SELECT pl.*, pk.nama_paket, pk.harga, r.nama_router, rs.nama_bisnis AS nama_reseller
            FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
            LEFT JOIN router r ON r.id = pl.router_id
            LEFT JOIN reseller rs ON rs.id = pl.reseller_id
            {where_sql}
            ORDER BY pl.id DESC""", parameter
    ).fetchall()

    jumlah_semua = db.execute("SELECT COUNT(*) c FROM pelanggan").fetchone()["c"]
    jumlah_stop = db.execute("SELECT COUNT(*) c FROM pelanggan WHERE status='isolir'").fetchone()["c"]

    hal = _paginate(daftar_pelanggan)
    return render_template(
        "data_customer_status.html", mode="stop",
        judul="Stop Langganan", ikon="bi-slash-circle",
        daftar_pelanggan=hal["items"], q=q,
        jumlah_semua=jumlah_semua, jumlah_stop=jumlah_stop,
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"], total=hal["total"],
    )


@app.route("/data-customer/langganan-online")
@login_required
def data_customer_langganan_online():
    """Menu Customer > Langganan Online -- pelanggan berstatus aktif yang sesi
    PPPoE-nya sedang tersambung (online) sekarang di Mikrotik."""
    db = get_db()
    q = request.args.get("q", "").strip()

    kondisi = ["pl.status = 'aktif'"]
    parameter = []
    if q:
        like = f"%{q}%"
        kondisi.append("(pl.nama LIKE ? OR pl.username_pppoe LIKE ? OR pl.no_hp LIKE ? OR pl.alamat LIKE ?)")
        parameter += [like, like, like, like]
    where_sql = "WHERE " + " AND ".join(kondisi)

    semua_aktif = db.execute(
        f"""SELECT pl.*, pk.nama_paket, pk.harga, r.nama_router, rs.nama_bisnis AS nama_reseller
            FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
            LEFT JOIN router r ON r.id = pl.router_id
            LEFT JOIN reseller rs ON rs.id = pl.reseller_id
            {where_sql}
            ORDER BY pl.id DESC""", parameter
    ).fetchall()

    router_ids = {p["router_id"] for p in semua_aktif}
    online_set, gagal_router = _kumpulkan_status_online_pppoe(router_ids)
    daftar_pelanggan = [p for p in semua_aktif if p["username_pppoe"] in online_set]

    jumlah_semua = db.execute("SELECT COUNT(*) c FROM pelanggan").fetchone()["c"]

    hal = _paginate(daftar_pelanggan)
    return render_template(
        "data_customer_status.html", mode="online",
        judul="Langganan Online", ikon="bi-wifi",
        daftar_pelanggan=hal["items"], q=q,
        jumlah_semua=jumlah_semua, jumlah_online=len(daftar_pelanggan),
        jumlah_aktif_total=len(semua_aktif),
        peringatan_router=bool(gagal_router),
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"], total=hal["total"],
    )


@app.route("/data-customer/langganan-offline")
@login_required
def data_customer_langganan_offline():
    """Menu Customer > Langganan Offline -- pelanggan berstatus aktif (belum
    diisolir) tapi sesi PPPoE-nya sedang TIDAK tersambung ke Mikrotik saat ini
    (kemungkinan mati listrik, ONT/router pelanggan mati, kabel putus, dll)."""
    db = get_db()
    q = request.args.get("q", "").strip()

    kondisi = ["pl.status = 'aktif'"]
    parameter = []
    if q:
        like = f"%{q}%"
        kondisi.append("(pl.nama LIKE ? OR pl.username_pppoe LIKE ? OR pl.no_hp LIKE ? OR pl.alamat LIKE ?)")
        parameter += [like, like, like, like]
    where_sql = "WHERE " + " AND ".join(kondisi)

    semua_aktif = db.execute(
        f"""SELECT pl.*, pk.nama_paket, pk.harga, r.nama_router, rs.nama_bisnis AS nama_reseller
            FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
            LEFT JOIN router r ON r.id = pl.router_id
            LEFT JOIN reseller rs ON rs.id = pl.reseller_id
            {where_sql}
            ORDER BY pl.id DESC""", parameter
    ).fetchall()

    router_ids = {p["router_id"] for p in semua_aktif}
    online_set, gagal_router = _kumpulkan_status_online_pppoe(router_ids)
    daftar_pelanggan = [p for p in semua_aktif if p["username_pppoe"] not in online_set]

    jumlah_semua = db.execute("SELECT COUNT(*) c FROM pelanggan").fetchone()["c"]

    hal = _paginate(daftar_pelanggan)
    return render_template(
        "data_customer_status.html", mode="offline",
        judul="Langganan Offline", ikon="bi-wifi-off",
        daftar_pelanggan=hal["items"], q=q,
        jumlah_semua=jumlah_semua, jumlah_offline=len(daftar_pelanggan),
        jumlah_aktif_total=len(semua_aktif),
        peringatan_router=bool(gagal_router),
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"], total=hal["total"],
    )


@app.route("/pelanggan/laporan")
@login_required
def pelanggan_laporan():
    """Tombol LAPORAN di toolbar menu Pelanggan -- export daftar pelanggan yang
    sedang tampil (sesuai tab & filter aktif) ke file Excel (.xlsx)."""
    db = get_db()
    f_reseller_id = request.args.get("reseller_id", "").strip()
    f_router_id = request.args.get("router_id", "").strip()
    tab_klien = request.args.get("tab", "all").strip().lower()
    if tab_klien not in ("all", "personal", "corporate", "orphaned"):
        tab_klien = "all"

    kondisi = []
    parameter = []
    if f_reseller_id:
        kondisi.append("pl.reseller_id = ?")
        parameter.append(f_reseller_id)
    if f_router_id:
        kondisi.append("pl.router_id = ?")
        parameter.append(f_router_id)
    if tab_klien == "personal":
        kondisi.append("pl.tipe_klien = 'personal'")
    elif tab_klien == "corporate":
        kondisi.append("pl.tipe_klien = 'corporate'")
    elif tab_klien == "orphaned":
        kondisi.append("pl.odp_id IS NULL")
    where_sql = f"WHERE {' AND '.join(kondisi)}" if kondisi else ""

    daftar = db.execute(
        f"""SELECT pl.*, pk.nama_paket, pk.harga, r.nama_router, rs.nama_bisnis AS nama_reseller
            FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
            LEFT JOIN router r ON r.id = pl.router_id
            LEFT JOIN reseller rs ON rs.id = pl.reseller_id
            {where_sql}
            ORDER BY pl.nama""", parameter
    ).fetchall()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Pelanggan"

    kolom = [
        ("ID", 6), ("Nama", 24), ("Tipe", 10), ("Alamat", 30), ("No. HP", 16),
        ("Username PPPoE", 18), ("Paket", 18), ("Harga", 12), ("Kode Unik", 10),
        ("Jatuh Tempo", 12), ("Router/POP", 18), ("Reseller", 18), ("Status", 10),
        ("Tanggal Daftar", 14),
    ]
    header_font = Font(name="Calibri", bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    for idx, (judul_kolom, lebar) in enumerate(kolom, start=1):
        sel = ws.cell(row=1, column=idx, value=judul_kolom)
        sel.font = header_font
        sel.fill = header_fill
        sel.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = lebar
    ws.freeze_panes = "A2"

    for baris, p in enumerate(daftar, start=2):
        nilai = [
            p["id"], p["nama"], (p["tipe_klien"] or "personal").capitalize(), p["alamat"] or "",
            p["no_hp"] or "", p["username_pppoe"], p["nama_paket"] or "-", p["harga"] or 0,
            p["kode_unik"] or "", p["hari_tagihan"] or 20, p["nama_router"] or "Router Utama",
            p["nama_reseller"] or "Admin Master",
            "Aktif" if p["status"] == "aktif" else "Isolir", p["tanggal_daftar"],
        ]
        for kolom_idx, v in enumerate(nilai, start=1):
            ws.cell(row=baris, column=kolom_idx, value=v).alignment = Alignment(vertical="top")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    nama_file = f"pelanggan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    _catat_aktivitas("pppoe", "Laporan", f"Export {len(daftar)} pelanggan ke Excel.")
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=nama_file,
    )


@app.route("/pelanggan/secret-massal", methods=["POST"])
@login_required
def pelanggan_secret_massal():
    """Tombol SECRET di toolbar menu Pelanggan -- ambil detail PPP Secret
    (password, profile, service, status) langsung dari Mikrotik untuk banyak
    pelanggan terpilih sekaligus, dikelompokkan per-router supaya efisien."""
    ids = request.form.getlist("pelanggan_ids")
    if not ids:
        return jsonify(ok=False, message="Pilih dulu minimal satu pelanggan."), 400

    db = get_db()
    id_valid = []
    for pid in ids:
        try:
            id_valid.append(int(pid))
        except ValueError:
            continue
    if not id_valid:
        return jsonify(ok=False, message="Pelanggan tidak valid."), 400

    placeholder = ",".join("?" * len(id_valid))
    daftar = db.execute(
        f"SELECT id, nama, username_pppoe, router_id FROM pelanggan WHERE id IN ({placeholder})",
        id_valid).fetchall()

    hasil = []
    client_cache = {}
    for p in daftar:
        rid = p["router_id"] or 1
        if rid not in client_cache:
            client_cache[rid] = _get_mikrotik_client(rid)
        client = client_cache[rid]
        if not client:
            hasil.append({"nama": p["nama"], "username": p["username_pppoe"],
                          "ok": False, "message": "Router belum diisi host/username."})
            continue
        try:
            data = client.get_secret(p["username_pppoe"])
            if not data:
                hasil.append({"nama": p["nama"], "username": p["username_pppoe"],
                              "ok": False, "message": "Secret tidak ditemukan di Mikrotik."})
            else:
                hasil.append({
                    "nama": p["nama"], "username": p["username_pppoe"], "ok": True,
                    "password": data.get("password", ""), "profile": data.get("profile", "-"),
                    "service": data.get("service", "-"),
                    "disabled": data.get("disabled") == "true",
                    "comment": data.get("comment", ""),
                })
        except RouterOSError as e:
            hasil.append({"nama": p["nama"], "username": p["username_pppoe"],
                          "ok": False, "message": str(e)})
        except Exception as e:
            hasil.append({"nama": p["nama"], "username": p["username_pppoe"],
                          "ok": False, "message": f"Error tak terduga: {e}"})

    return jsonify(ok=True, hasil=hasil)


@app.route("/pelanggan/edit/<int:pid>", methods=["POST"])
@login_required
def edit_pelanggan(pid):
    db = get_db()
    row = db.execute("SELECT * FROM pelanggan WHERE id=?", (pid,)).fetchone()
    if not row:
        flash("Pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("pelanggan"))

    nama = request.form["nama"].strip()
    alamat = request.form.get("alamat", "").strip()
    no_hp = request.form.get("no_hp", "").strip()
    username_pppoe = request.form["username_pppoe"].strip()
    password_pppoe = request.form.get("password_pppoe", "").strip() or row["password_pppoe"]
    paket_id = request.form["paket_id"]
    latitude = request.form.get("latitude", "").strip() or None
    longitude = request.form.get("longitude", "").strip() or None
    odp_id = request.form.get("odp_id", "").strip() or None
    tipe_klien = request.form.get("tipe_klien", "").strip() or row["tipe_klien"] or "personal"
    if tipe_klien not in ("personal", "corporate"):
        tipe_klien = "personal"
    router_id = request.form.get("router_id", "").strip() or str(row["router_id"] or 1)
    router_valid = db.execute("SELECT id, reseller_id FROM router WHERE id=?", (router_id,)).fetchone()
    if not router_valid:
        router_id = str(row["router_id"] or 1)
        router_valid = db.execute("SELECT id, reseller_id FROM router WHERE id=?", (router_id,)).fetchone()
    reseller_id = router_valid["reseller_id"] if router_valid else None

    try:
        db.execute(
            """UPDATE pelanggan
               SET nama=?, alamat=?, no_hp=?, username_pppoe=?, password_pppoe=?, paket_id=?,
                   latitude=?, longitude=?, odp_id=?, router_id=?, reseller_id=?, tipe_klien=?
               WHERE id=?""",
            (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id,
             latitude, longitude, odp_id, router_id, reseller_id, tipe_klien, pid))
        db.commit()
        _catat_aktivitas("pppoe", "Edit Pelanggan", f"{nama} ({username_pppoe})")
        flash("Data pelanggan berhasil diperbarui. Jangan lupa klik 'Sync' agar perubahan ikut ke Mikrotik.", "success")
    except sqlite3.IntegrityError:
        flash("Username PPPoE sudah dipakai pelanggan lain.", "danger")

    return redirect(url_for("pelanggan"))


def _get_mikrotik_client(router_id=None):
    """Bikin koneksi RouterOSAPI ke salah satu router yang terdaftar di tabel `router`.

    Kalau router_id tidak diisi eksplisit: dipakai "router aktif" yang sedang
    dipilih admin di session (session['router_aktif'], diatur lewat menu
    Router/POP -> "Jadikan Aktif"), atau router id=1 ("Router Utama") kalau
    belum pernah memilih. Ini supaya perkakas umum (hotspot, voucher, PPP
    profile, dsb -- yang memang beroperasi per-router, bukan per-pelanggan)
    tetap bisa dipakai untuk router manapun tanpa harus diedit satu-satu,
    sedangkan aksi yang memang spesifik ke satu pelanggan (sync/isolir/monitor)
    tetap mengirim router_id milik pelanggan itu sendiri secara eksplisit."""
    db = get_db()
    if router_id is None:
        router_id = session.get("router_aktif", 1)
    row = db.execute("SELECT * FROM router WHERE id=?", (router_id,)).fetchone()
    if not row or not row["host"]:
        return None
    return RouterOSAPI(row["host"], row["username"], row["password"], port=row["port"] or 8728)


def _client_hotspot_dari_permintaan():
    """Ambil koneksi Mikrotik untuk endpoint hotspot yang dipakai bersama-sama oleh
    admin master DAN dashboard reseller (Server/User/User Profile/Active/Voucher).

    - Admin master: boleh tanpa router_id (pakai 'router aktif' default seperti biasa,
      perilaku lama tidak berubah) atau eksplisit ke router manapun.
    - Reseller: WAJIB mengirim router_id (query string atau form field) milik router
      dia sendiri -- kalau tidak dikirim atau bukan miliknya, ditolak.

    Return tuple (client, pesan_error). client None kalau gagal, pesan_error berisi
    alasannya."""
    router_id_raw = request.values.get("router_id", "").strip()
    router_id = int(router_id_raw) if router_id_raw.isdigit() else None

    if session.get("reseller_id"):
        if not router_id:
            return None, "Pilih Router/POP dahulu."
        db = get_db()
        row = db.execute(
            "SELECT id FROM router WHERE id=? AND reseller_id=?",
            (router_id, session["reseller_id"])).fetchone()
        if not row:
            return None, "Router tidak ditemukan atau bukan milik Anda."

    client = _get_mikrotik_client(router_id)
    if not client:
        return None, "Router ini belum diisi host/username Mikrotik-nya."
    return client, None


def _router_pelanggan(db, pelanggan_row):
    """Ambil baris router (POP) yang jadi tempat satu pelanggan tersambung.
    Fallback ke router id=1 kalau pelanggan lama belum punya router_id."""
    rid = pelanggan_row["router_id"] if pelanggan_row and "router_id" in pelanggan_row.keys() else None
    return db.execute("SELECT * FROM router WHERE id=?", (rid or 1,)).fetchone()


# ---------------------------------------------------------------------------
# Payment Gateway (Tripay)
# ---------------------------------------------------------------------------
def _get_tripay_cfg(db, wajib_aktif=True):
    """Ambil konfigurasi Tripay dari DB. Return None kalau belum diisi/nonaktif
    (kecuali wajib_aktif=False, dipakai di halaman pengaturan supaya tetap bisa
    ditampilkan/dites walau togglenya masih mati)."""
    row = db.execute("SELECT * FROM pengaturan_tripay WHERE id=1").fetchone()
    if not row:
        return None
    if wajib_aktif and not row["aktif"]:
        return None
    if not row["merchant_code"] or not row["api_key"] or not row["private_key"]:
        return None
    return {
        "merchant_code": row["merchant_code"],
        "api_key": row["api_key"],
        "private_key": row["private_key"],
        "mode": row["mode"],
    }


def _buat_merchant_ref(tagihan_id):
    return f"TGH{tagihan_id}{secrets.token_hex(4).upper()}"


def _tes_koneksi_jaringan_tripay(mode):
    """Cek low-level apakah server ini bisa membuka koneksi TCP ke tripay.co.id:443,
    terpisah dari tes API key -- supaya kalau gagal, admin tahu ini masalah
    jaringan/firewall server (DNS/port diblokir) bukan salah kredensial."""
    host = "tripay.co.id"
    try:
        alamat_ip = socket.gethostbyname(host)
    except socket.gaierror as e:
        return False, f"Gagal resolve DNS '{host}': {e}. Cek koneksi internet/DNS server ini."
    try:
        with socket.create_connection((host, 443), timeout=6):
            pass
    except OSError as e:
        return False, (f"DNS '{host}' berhasil di-resolve ({alamat_ip}) tapi port 443 (HTTPS) "
                        f"gagal dibuka: {e}. Kemungkinan diblokir firewall keluar (outbound) di server ini.")
    return True, f"Server ini bisa menjangkau {host} ({alamat_ip}) lewat HTTPS."


def _proses_buat_transaksi_pembayaran(db, tagihan_row, metode, nomor_hp_pelanggan=None):
    """Buat transaksi Tripay baru untuk satu tagihan & simpan ke pembayaran_online.
    Mengembalikan (berhasil: bool, pesan_atau_data)."""
    cfg = _get_tripay_cfg(db)
    if not cfg:
        return False, "Pembayaran online belum diaktifkan/diisi lengkap oleh admin."

    merchant_ref = _buat_merchant_ref(tagihan_row["id"])
    nama_item = f"Tagihan Internet Periode {tagihan_row['periode']}"
    try:
        data = tripay_gateway.buat_transaksi(
            cfg,
            merchant_ref=merchant_ref,
            amount=tagihan_row["jumlah"],
            metode=metode,
            nama_item=nama_item,
            customer_name=tagihan_row["nama"],
            customer_phone=nomor_hp_pelanggan,
            callback_url=url_for("tripay_callback", _external=True),
            return_url=url_for("portal_pelanggan", _external=True),
        )
    except tripay_gateway.TripayError as e:
        return False, f"Gagal membuat transaksi pembayaran: {e}"

    db.execute(
        """INSERT INTO pembayaran_online
           (tagihan_id, merchant_ref, reference, metode, nama_metode, checkout_url,
            jumlah, fee_pelanggan, status, dibuat_tanggal, kadaluarsa_tanggal, pay_code)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (tagihan_row["id"], merchant_ref, data.get("reference"), data.get("payment_method"),
         data.get("payment_name"), data.get("checkout_url"), tagihan_row["jumlah"],
         data.get("fee_customer") or 0, data.get("status") or "UNPAID",
         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), data.get("expired_time_formatted"),
         data.get("pay_code")))
    db.commit()
    return True, data


def _perbarui_status_pembayaran(db, pembayaran_row, status_baru, dibayar_tanggal=None):
    """Update status pembayaran_online + tandai tagihan lunas & aktifkan lagi kalau
    sebelumnya diisolir. Dipakai baik oleh webhook callback maupun cek status manual."""
    db.execute("UPDATE pembayaran_online SET status=?, dibayar_tanggal=? WHERE id=?",
               (status_baru, dibayar_tanggal, pembayaran_row["id"]))
    db.commit()

    if status_baru != "PAID":
        return

    tagihan = db.execute("SELECT * FROM tagihan WHERE id=?", (pembayaran_row["tagihan_id"],)).fetchone()
    if not tagihan or tagihan["status"] == "lunas":
        return

    db.execute("UPDATE tagihan SET status='lunas', tanggal_bayar=? WHERE id=?",
               (date.today().isoformat(), tagihan["id"]))
    db.commit()

    pl = db.execute("SELECT * FROM pelanggan WHERE id=?", (tagihan["pelanggan_id"],)).fetchone()
    if pl and pl["status"] == "isolir":
        client = _get_mikrotik_client()
        if client:
            try:
                client.set_secret_disabled(pl["username_pppoe"], disabled=False)
                db.execute("UPDATE pelanggan SET status='aktif' WHERE id=?", (pl["id"],))
                db.commit()
            except RouterOSError:
                pass


# ---------------------------------------------------------------------------
# Client Area (GenieACS -- kelola WiFi/SSID & restart ONT dari Portal Pelanggan)
# ---------------------------------------------------------------------------
def _get_genieacs_cfg(db, wajib_aktif=True):
    row = db.execute("SELECT * FROM pengaturan_genieacs WHERE id=1").fetchone()
    if not row:
        return None
    if wajib_aktif and not row["aktif"]:
        return None
    if not row["url"]:
        return None
    return dict(row)


def _ambil_onu_pelanggan(db, pelanggan_id):
    """Ambil baris ONU yang terhubung ke satu pelanggan (dipakai untuk tahu Serial
    Number ONT-nya, supaya bisa dicocokkan dengan device di GenieACS)."""
    return db.execute("SELECT * FROM onu WHERE pelanggan_id=? ORDER BY id DESC LIMIT 1", (pelanggan_id,)).fetchone()


def _ambil_device_genieacs_pelanggan(db, pelanggan_id):
    """Return (cfg, device_json) untuk satu pelanggan, atau (cfg_or_None, None) kalau
    fitur nonaktif / ONU belum ada serial number / device belum ketemu di GenieACS."""
    cfg = _get_genieacs_cfg(db)
    if not cfg:
        return None, None
    onu_row = _ambil_onu_pelanggan(db, pelanggan_id)
    if not onu_row or not onu_row["serial_number"]:
        return cfg, None
    try:
        device = genieacs_client.cari_device_by_serial(cfg, onu_row["serial_number"])
    except genieacs_client.GenieACSError:
        return cfg, None
    return cfg, device


def _warna_redaman(rx_power):
    """Konvensi warna redaman ala GPON: bagus (hijau) -8 s/d -25 dBm, waspada (kuning)
    -25 s/d -28 dBm, kritis (merah) di luar itu. Ini perkiraan umum industri, admin
    tetap harus mengacu ke standar dari OLT/ONT yang dipakai untuk ambang pasti."""
    if rx_power is None:
        return "secondary"
    if -25 <= rx_power <= -8:
        return "success"
    if -28 <= rx_power < -25:
        return "warning"
    return "danger"


def _buat_komentar_billing(nama, alamat="", no_hp=""):
    """Bentuk string comment PPP Secret di Mikrotik dari data billing.
    Format: billing:Nama|Alamat|No HP  (supaya alamat & no HP ikut tersimpan di Mikrotik
    dan bisa ditarik balik utuh saat import dari Mikrotik)."""
    nama = (nama or "").replace("|", "/").strip()
    alamat = (alamat or "").replace("|", "/").strip()
    no_hp = (no_hp or "").replace("|", "/").strip()
    return f"billing:{nama}|{alamat}|{no_hp}"


def _uraikan_komentar_billing(comment, default_nama):
    """Uraikan comment PPP Secret Mikrotik menjadi (nama, alamat, no_hp).
    Format baru : billing:Nama|Alamat|No HP   (alamat & no HP opsional)
    Format lama : billing:Nama                 (tetap didukung, alamat & no HP kosong)
    Kalau comment tidak berformat 'billing:...', nama diisi dari username PPPoE."""
    if not comment or not comment.startswith("billing:"):
        return default_nama, "", ""
    bagian = [b.strip() for b in comment[len("billing:"):].split("|")]
    nama = bagian[0] if bagian[0] else default_nama
    alamat = bagian[1] if len(bagian) > 1 else ""
    no_hp = bagian[2] if len(bagian) > 2 else ""
    return nama, alamat, no_hp


_RSC_KV_RE = re.compile(r'(\w+)=("(?:[^"\\]|\\.)*"|\S+)')
_MSRADIUS_KOMENTAR_RE = re.compile(
    r'A/N\s+(.+?)\s+\S+\s+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+MAINTENANCE', re.IGNORECASE)


def _parse_ppp_secret_rsc(isi_file):
    """Uraikan isi file .rsc (mis. hasil 'PPP > Secrets > Export' dari Mikrotik, atau
    backup dari router/RADIUS lain berformat sama) menjadi list dict
    {name, password, profile, comment, disabled}. Baris yang bukan '/ppp secret add'
    (mis. komentar diawali '#', atau perintah lain) diabaikan, tidak fatal."""
    hasil = []
    isi_file = isi_file.replace("\r\n", "\n").replace("\r", "\n")
    for baris in isi_file.split("\n"):
        baris = baris.strip()
        if not baris.lower().startswith("/ppp secret add"):
            continue
        baris = baris.rstrip(";").strip()
        data = {}
        for m in _RSC_KV_RE.finditer(baris):
            key, val = m.group(1), m.group(2)
            if val.startswith('"') and val.endswith('"'):
                val = val[1:-1]
            data[key] = val
        if not data.get("name"):
            continue
        hasil.append({
            "name": data.get("name"),
            "password": data.get("password", ""),
            "profile": data.get("profile") or "default",
            "comment": data.get("comment", ""),
            "disabled": str(data.get("disabled", "no")).lower() == "yes",
        })
    return hasil


def _uraikan_komentar_umum(comment, default_nama):
    """Coba uraikan comment PPP Secret dari berbagai sumber jadi (nama, alamat, no_hp):
    1. Format billing aplikasi ini: billing:Nama|Alamat|No HP
    2. Format backup MSRADIUS/RADIUS lain: '...A/N NAMA <ID> YYYY-MM-DD HH:MM:SS MAINTENANCE'
    3. Kalau tidak cocok keduanya, nama diambil dari username PPPoE."""
    if comment and comment.startswith("billing:"):
        return _uraikan_komentar_billing(comment, default_nama)
    if comment:
        m = _MSRADIUS_KOMENTAR_RE.search(comment)
        if m:
            return m.group(1).strip().title(), "", ""
    return default_nama, "", ""


@app.route("/pelanggan/import-rsc", methods=["POST"])
@login_required
def import_pelanggan_rsc():
    """Import pelanggan PPPoE dari file .rsc yang diupload (mis. backup/export dari
    MSRADIUS atau router lain), TANPA perlu koneksi langsung ke Mikrotik.

    router_id WAJIB diikutkan dari form (dropdown "Router/POP tujuan" di modal Import)
    supaya pelanggan hasil import ini langsung tertaut ke router/POP yang benar dan
    kebaca di menu POP Site > Pelanggan POP Site -- sebelumnya kolom pelanggan.router_id
    tidak pernah diisi sama sekali."""
    db = get_db()
    router_id_raw = request.form.get("router_id", "").strip()
    router = None
    if router_id_raw.isdigit():
        router = db.execute("SELECT * FROM router WHERE id=?", (int(router_id_raw),)).fetchone()
    if not router:
        return jsonify(ok=False, message="Pilih Router/POP tujuan terlebih dahulu."), 200

    file = request.files.get("file_rsc")
    if not file or file.filename == "":
        return jsonify(ok=False, message="Pilih file .rsc terlebih dahulu."), 200
    if not file.filename.lower().endswith((".rsc", ".txt")):
        return jsonify(ok=False, message="Format file tidak didukung. Gunakan file .rsc atau .txt."), 200

    try:
        isi_file = file.read().decode("utf-8", errors="ignore")
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal membaca file: {e}"), 200

    daftar_secret = _parse_ppp_secret_rsc(isi_file)
    if not daftar_secret:
        return jsonify(ok=False, message=(
            "Tidak ditemukan baris '/ppp secret add ...' yang valid di file ini. "
            "Pastikan file ini hasil export PPP Secret dari Mikrotik atau backup "
            "router/RADIUS lain dengan format serupa.")), 200

    hanya_aktif = request.form.get("hanya_aktif", "0") == "1"

    daftar_paket = db.execute("SELECT * FROM paket").fetchall()
    peta_profile_ke_paket = {p["profile_mikrotik"]: p["id"] for p in daftar_paket}

    ditambahkan = 0
    dilewati = 0
    dilewati_nonaktif = 0
    paket_baru_dibuat = 0

    for s in daftar_secret:
        username = s["name"]
        disabled = s["disabled"]
        if hanya_aktif and disabled:
            dilewati_nonaktif += 1
            continue

        sudah_ada = db.execute(
            "SELECT id FROM pelanggan WHERE username_pppoe=?", (username,)).fetchone()
        if sudah_ada:
            dilewati += 1
            continue

        profile = s["profile"]
        paket_id = peta_profile_ke_paket.get(profile)
        if not paket_id:
            cur = db.execute(
                "INSERT INTO paket (nama_paket, kecepatan, harga, profile_mikrotik) VALUES (?,?,?,?)",
                (f"Paket {profile}", "-", 0, profile))
            paket_id = cur.lastrowid
            peta_profile_ke_paket[profile] = paket_id
            paket_baru_dibuat += 1

        nama, alamat, no_hp = _uraikan_komentar_umum(s["comment"], username)

        db.execute(
            """INSERT INTO pelanggan
               (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id, status,
                tanggal_daftar, router_id, reseller_id)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (nama, alamat, no_hp, username, s["password"], paket_id,
             "isolir" if disabled else "aktif", date.today().isoformat(),
             router["id"], router["reseller_id"]))
        ditambahkan += 1

    db.commit()
    if ditambahkan:
        _catat_aktivitas("pppoe", "Import dari file .rsc",
                          f"{ditambahkan} pelanggan diimpor ke router {router['nama_router']}")

    pesan = f"{ditambahkan} pelanggan berhasil diimpor dari file .rsc, {dilewati} dilewati (sudah ada di billing)."
    if hanya_aktif:
        pesan += f" {dilewati_nonaktif} dilewati karena berstatus disabled=yes di file."
    if paket_baru_dibuat:
        pesan += (f" {paket_baru_dibuat} paket baru otomatis dibuat (harga masih Rp 0, "
                  f"silakan edit harga & nama paketnya di menu Paket Internet).")
    return jsonify(ok=True, message=pesan)


@app.route("/pelanggan/sync/<int:pid>", methods=["POST"])
@admin_atau_reseller_required
def sync_pelanggan(pid):
    db = get_db()
    row = db.execute(
        """SELECT pl.*, pk.profile_mikrotik FROM pelanggan pl
           JOIN paket pk ON pk.id = pl.paket_id WHERE pl.id=?""", (pid,)).fetchone()
    if not row:
        return jsonify(ok=False, message="Pelanggan tidak ditemukan"), 404
    if not _boleh_akses_pelanggan(row):
        return jsonify(ok=False, message="Anda tidak berhak mengakses pelanggan ini."), 403

    client = _get_mikrotik_client(row["router_id"])
    if not client:
        return jsonify(ok=False, message="Router pelanggan ini belum diisi host/username. Cek menu Router/POP."), 400

    try:
        client.add_or_update_secret(
            name=row["username_pppoe"],
            password=row["password_pppoe"],
            profile=row["profile_mikrotik"],
            comment=_buat_komentar_billing(row["nama"], row["alamat"], row["no_hp"]),
        )
        _catat_aktivitas("pppoe", "Sync ke Mikrotik", f"{row['nama']} ({row['username_pppoe']})")
        return jsonify(ok=True, message=f"Berhasil sync '{row['username_pppoe']}' ke Mikrotik.")
    except RouterOSError as e:
        return jsonify(ok=False, message=f"Gagal sync: {e}"), 200
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal sync (error tak terduga): {e}"), 200


@app.route("/pelanggan/import-mikrotik", methods=["POST"])
@login_required
def import_pelanggan_mikrotik():
    """Tarik semua PPPoE Secret yang sudah ada di Mikrotik, masukkan ke database billing
    (untuk pelanggan yang sudah lebih dulu dibuat langsung di Mikrotik/Winbox).

    router_id WAJIB diikutkan dari form (dropdown "Pilih Router/POP" di modal Import):
    dipakai buat (1) nentuin Mikrotik mana yang ditarik datanya, dan (2) disimpan balik
    ke kolom pelanggan.router_id/reseller_id supaya pelanggan hasil import langsung
    kebaca di menu POP Site > Pelanggan POP Site sesuai router asalnya -- sebelumnya
    kolom ini tidak pernah diisi sama sekali sehingga pelanggan hasil import router
    reseller manapun selalu "tanpa POP" dan tidak muncul kalau difilter per-router."""
    db = get_db()
    router_id_raw = request.form.get("router_id", "").strip()
    router = None
    if router_id_raw.isdigit():
        router = db.execute("SELECT * FROM router WHERE id=?", (int(router_id_raw),)).fetchone()
    if not router:
        return jsonify(ok=False, message="Pilih Router/POP yang mau ditarik datanya terlebih dahulu."), 400

    client = _get_mikrotik_client(router["id"])
    if not client:
        return jsonify(ok=False, message="Router ini belum diisi host/username Mikrotik-nya. Cek menu Router/POP."), 400

    try:
        secrets = client.get_ppp_secrets()
    except RouterOSError as e:
        return jsonify(ok=False, message=f"Gagal ambil data dari Mikrotik: {e}"), 200
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal ambil data dari Mikrotik (error tak terduga): {e}"), 200

    hanya_aktif = request.form.get("hanya_aktif", "1") == "1"

    daftar_paket = db.execute("SELECT * FROM paket").fetchall()
    peta_profile_ke_paket = {p["profile_mikrotik"]: p["id"] for p in daftar_paket}

    ditambahkan = 0
    dilewati = 0
    diperbarui_pop = 0
    dilewati_nonaktif = 0
    paket_baru_dibuat = 0

    for s in secrets:
        username = s.get("name")
        if not username:
            continue

        disabled = s.get("disabled", "false") == "true"
        if hanya_aktif and disabled:
            dilewati_nonaktif += 1
            continue

        sudah_ada = db.execute(
            "SELECT id, router_id FROM pelanggan WHERE username_pppoe=?", (username,)).fetchone()
        if sudah_ada:
            # Pelanggan ini sudah ada di billing (mungkin dibuat sebelum fitur
            # kaitan router_id/POP Site ada, jadi router_id-nya masih kosong
            # atau menempel ke router lain). Supaya tidak "hilang" alias tidak
            # pernah muncul saat difilter per-POP di menu POP Site > Pelanggan
            # POP Site, kaitkan/perbarui router_id & reseller_id-nya ke router
            # yang sedang ditarik datanya sekarang, alih-alih dilewati diam-diam.
            if sudah_ada["router_id"] != router["id"]:
                db.execute(
                    "UPDATE pelanggan SET router_id=?, reseller_id=? WHERE id=?",
                    (router["id"], router["reseller_id"], sudah_ada["id"]))
                diperbarui_pop += 1
            else:
                dilewati += 1
            continue

        profile = s.get("profile", "default")
        paket_id = peta_profile_ke_paket.get(profile)

        # kalau profile ini belum ada di daftar Paket Internet, buat otomatis
        # supaya pelanggan tetap bisa diimpor (harga & nama bisa diedit belakangan)
        if not paket_id:
            cur = db.execute(
                "INSERT INTO paket (nama_paket, kecepatan, harga, profile_mikrotik) VALUES (?,?,?,?)",
                (f"Paket {profile}", "-", 0, profile))
            paket_id = cur.lastrowid
            peta_profile_ke_paket[profile] = paket_id
            paket_baru_dibuat += 1

        password = s.get("password", "")
        comment = s.get("comment", "")
        nama, alamat, no_hp = _uraikan_komentar_billing(comment, username)

        db.execute(
            """INSERT INTO pelanggan
               (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id, status,
                tanggal_daftar, router_id, reseller_id)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (nama, alamat, no_hp, username, password, paket_id,
             "isolir" if disabled else "aktif", date.today().isoformat(),
             router["id"], router["reseller_id"]))
        ditambahkan += 1

    db.commit()
    if ditambahkan or diperbarui_pop:
        _catat_aktivitas("pppoe", "Import dari Mikrotik",
                          f"{ditambahkan} pelanggan diimpor dari router {router['nama_router']}")

    pesan = (f"{ditambahkan} pelanggan berhasil diimpor dari Mikrotik, "
             f"{diperbarui_pop} pelanggan lama dikaitkan ke POP ini, "
             f"{dilewati} dilewati (sudah ada di billing & sudah terkait POP ini).")
    if hanya_aktif:
        pesan += f" {dilewati_nonaktif} dilewati karena berstatus nonaktif/isolir di Mikrotik."
    if paket_baru_dibuat:
        pesan += (f" {paket_baru_dibuat} paket baru otomatis dibuat (harga masih Rp 0, "
                  f"silakan edit harga & nama paketnya di menu Paket Internet).")
    total_pelanggan_router = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE router_id=?", (router["id"],)).fetchone()["c"]
    return jsonify(ok=True, message=pesan, total_pelanggan=total_pelanggan_router)


@app.route("/pelanggan/isolir/<int:pid>", methods=["POST"])
@admin_atau_reseller_required
def toggle_isolir(pid):
    db = get_db()
    row = db.execute("SELECT * FROM pelanggan WHERE id=?", (pid,)).fetchone()
    if not row:
        return jsonify(ok=False, message="Pelanggan tidak ditemukan"), 404
    if not _boleh_akses_pelanggan(row):
        return jsonify(ok=False, message="Anda tidak berhak mengakses pelanggan ini."), 403

    status_baru = "isolir" if row["status"] == "aktif" else "aktif"
    client = _get_mikrotik_client(row["router_id"])
    if not client:
        return jsonify(ok=False, message="Router pelanggan ini belum diisi host/username. Cek menu Router/POP."), 400

    try:
        client.set_secret_disabled(row["username_pppoe"], disabled=(status_baru == "isolir"))
        db.execute("UPDATE pelanggan SET status=? WHERE id=?", (status_baru, pid))
        db.commit()
        _catat_aktivitas("pppoe", f"Ubah Status Jadi {status_baru.capitalize()}",
                          f"{row['nama']} ({row['username_pppoe']})")
        return jsonify(ok=True, status=status_baru,
                        message=f"Status diubah menjadi {status_baru} & disinkron ke Mikrotik.")
    except RouterOSError as e:
        return jsonify(ok=False, message=f"Gagal ubah status: {e}"), 200
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal ubah status (error tak terduga): {e}"), 200


# ---------------------------------------------------------------------------
# ODP (Optical Distribution Point) & Peta Jaringan
# ---------------------------------------------------------------------------
@app.route("/odp", methods=["GET", "POST"])
@login_required
def odp():
    db = get_db()
    if request.method == "POST":
        nama = request.form["nama"].strip()
        alamat = request.form.get("alamat", "").strip()
        latitude = request.form.get("latitude", "").strip() or None
        longitude = request.form.get("longitude", "").strip() or None
        kapasitas = request.form.get("kapasitas", "8").strip() or "8"
        olt_id = request.form.get("olt_id", "").strip() or None
        odp_induk_id = request.form.get("odp_induk_id", "").strip() or None
        keterangan = request.form.get("keterangan", "").strip()
        tanggal_pasang = request.form.get("tanggal_pasang", "").strip() or date.today().isoformat()

        if not latitude or not longitude:
            flash("Lokasi ODP wajib dipilih di peta (klik peta pada form tambah ODP).", "danger")
            return redirect(url_for("odp"))

        db.execute(
            """INSERT INTO odp (nama, alamat, latitude, longitude, kapasitas, olt_id, odp_induk_id, keterangan, tanggal_pasang)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (nama, alamat, latitude, longitude, kapasitas, olt_id, odp_induk_id, keterangan, tanggal_pasang))
        db.commit()
        flash("ODP ditambahkan.", "success")
        return redirect(url_for("odp"))

    daftar_odp = db.execute(
        """SELECT od.*, ol.nama AS nama_olt,
                  (SELECT COUNT(*) FROM pelanggan pl WHERE pl.odp_id = od.id) AS jumlah_pelanggan
           FROM odp od LEFT JOIN olt_device ol ON ol.id = od.olt_id
           ORDER BY od.id DESC"""
    ).fetchall()
    daftar_olt_pilihan = db.execute("SELECT id, nama FROM olt_device ORDER BY nama").fetchall()
    daftar_odp_pilihan = db.execute("SELECT id, nama FROM odp ORDER BY nama").fetchall()
    return render_template("odp.html", daftar_odp=daftar_odp, daftar_olt_pilihan=daftar_olt_pilihan,
                           daftar_odp_pilihan=daftar_odp_pilihan)


@app.route("/odp/edit/<int:odp_id>", methods=["POST"])
@login_required
def edit_odp(odp_id):
    db = get_db()
    row = db.execute("SELECT * FROM odp WHERE id=?", (odp_id,)).fetchone()
    if not row:
        flash("ODP tidak ditemukan.", "danger")
        return redirect(url_for("odp"))

    nama = request.form["nama"].strip()
    alamat = request.form.get("alamat", "").strip()
    latitude = request.form.get("latitude", "").strip() or row["latitude"]
    longitude = request.form.get("longitude", "").strip() or row["longitude"]
    kapasitas = request.form.get("kapasitas", "8").strip() or "8"
    olt_id = request.form.get("olt_id", "").strip() or None
    odp_induk_id = request.form.get("odp_induk_id", "").strip() or None
    keterangan = request.form.get("keterangan", "").strip()

    if odp_induk_id and int(odp_induk_id) == odp_id:
        flash("ODP tidak boleh dijadikan induk untuk dirinya sendiri.", "danger")
        return redirect(url_for("odp"))

    db.execute(
        """UPDATE odp SET nama=?, alamat=?, latitude=?, longitude=?, kapasitas=?, olt_id=?, odp_induk_id=?, keterangan=?
           WHERE id=?""",
        (nama, alamat, latitude, longitude, kapasitas, olt_id, odp_induk_id, keterangan, odp_id))
    db.commit()
    flash("ODP diperbarui.", "success")
    return redirect(url_for("odp"))


@app.route("/odp/hapus/<int:odp_id>", methods=["POST"])
@login_required
def hapus_odp(odp_id):
    db = get_db()
    db.execute("UPDATE pelanggan SET odp_id=NULL WHERE odp_id=?", (odp_id,))
    db.execute("UPDATE odp SET odp_induk_id=NULL WHERE odp_induk_id=?", (odp_id,))
    db.execute("DELETE FROM odp WHERE id=?", (odp_id,))
    db.commit()
    flash("ODP dihapus. Pelanggan/ODP turunan yang terhubung ke ODP ini jadi belum tertaut.", "success")
    return redirect(url_for("odp"))


# ---------------------------------------------------------------------------
# Network > Fleet -- inventaris perangkat (router, ONT/ONU, switch, dsb)
# ---------------------------------------------------------------------------
@app.route("/fleet", methods=["GET", "POST"])
@login_required
def fleet():
    db = get_db()
    if request.method == "POST":
        nama = request.form["nama"].strip()
        tipe = request.form.get("tipe", "Router").strip() or "Router"
        vendor = request.form.get("vendor", "").strip()
        model = request.form.get("model", "").strip()
        serial_number = request.form.get("serial_number", "").strip()
        mac_address = request.form.get("mac_address", "").strip()
        status = request.form.get("status", "gudang").strip() or "gudang"
        router_id = request.form.get("router_id", "").strip() or None
        catatan = request.form.get("catatan", "").strip()

        db.execute(
            """INSERT INTO fleet_perangkat
               (nama, tipe, vendor, model, serial_number, mac_address, status, router_id, tanggal_masuk, catatan)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (nama, tipe, vendor or None, model or None, serial_number or None, mac_address or None,
             status, router_id, date.today().isoformat(), catatan or None))
        db.commit()
        flash("Perangkat ditambahkan ke Fleet.", "success")
        return redirect(url_for("fleet"))

    daftar_fleet = db.execute(
        """SELECT f.*, r.nama_router
           FROM fleet_perangkat f LEFT JOIN router r ON r.id = f.router_id
           ORDER BY f.id DESC"""
    ).fetchall()
    daftar_router_pilihan = db.execute("SELECT id, nama_router FROM router ORDER BY nama_router").fetchall()
    return render_template("fleet.html", daftar_fleet=daftar_fleet, daftar_router_pilihan=daftar_router_pilihan)


@app.route("/fleet/edit/<int:fleet_id>", methods=["POST"])
@login_required
def edit_fleet(fleet_id):
    db = get_db()
    row = db.execute("SELECT * FROM fleet_perangkat WHERE id=?", (fleet_id,)).fetchone()
    if not row:
        flash("Perangkat tidak ditemukan.", "danger")
        return redirect(url_for("fleet"))

    nama = request.form["nama"].strip()
    tipe = request.form.get("tipe", "Router").strip() or "Router"
    vendor = request.form.get("vendor", "").strip()
    model = request.form.get("model", "").strip()
    serial_number = request.form.get("serial_number", "").strip()
    mac_address = request.form.get("mac_address", "").strip()
    status = request.form.get("status", "gudang").strip() or "gudang"
    router_id = request.form.get("router_id", "").strip() or None
    catatan = request.form.get("catatan", "").strip()

    db.execute(
        """UPDATE fleet_perangkat
           SET nama=?, tipe=?, vendor=?, model=?, serial_number=?, mac_address=?, status=?, router_id=?, catatan=?
           WHERE id=?""",
        (nama, tipe, vendor or None, model or None, serial_number or None, mac_address or None,
         status, router_id, catatan or None, fleet_id))
    db.commit()
    flash("Data perangkat Fleet diperbarui.", "success")
    return redirect(url_for("fleet"))


@app.route("/fleet/hapus/<int:fleet_id>", methods=["POST"])
@login_required
def hapus_fleet(fleet_id):
    db = get_db()
    db.execute("DELETE FROM fleet_perangkat WHERE id=?", (fleet_id,))
    db.commit()
    flash("Perangkat dihapus dari Fleet.", "success")
    return redirect(url_for("fleet"))


# ---------------------------------------------------------------------------
# Network > IP Pools -- blok alamat IP untuk pelanggan PPPoE/statis
# ---------------------------------------------------------------------------
@app.route("/ip-pools", methods=["GET", "POST"])
@login_required
def ip_pools():
    db = get_db()
    if request.method == "POST":
        nama = request.form["nama"].strip()
        network_cidr = request.form["network_cidr"].strip()
        gateway = request.form.get("gateway", "").strip()
        dns_server = request.form.get("dns_server", "").strip()
        router_id = request.form.get("router_id", "").strip() or None
        status = request.form.get("status", "aktif").strip() or "aktif"
        keterangan = request.form.get("keterangan", "").strip()

        db.execute(
            """INSERT INTO ip_pool (nama, network_cidr, gateway, dns_server, router_id, status, keterangan, dibuat_tanggal)
               VALUES (?,?,?,?,?,?,?,?)""",
            (nama, network_cidr, gateway or None, dns_server or None, router_id, status,
             keterangan or None, date.today().isoformat()))
        db.commit()
        flash("IP Pool ditambahkan.", "success")
        return redirect(url_for("ip_pools"))

    daftar_ip_pool = db.execute(
        """SELECT p.*, r.nama_router
           FROM ip_pool p LEFT JOIN router r ON r.id = p.router_id
           ORDER BY p.id DESC"""
    ).fetchall()
    daftar_router_pilihan = db.execute("SELECT id, nama_router FROM router ORDER BY nama_router").fetchall()
    return render_template("ip_pools.html", daftar_ip_pool=daftar_ip_pool, daftar_router_pilihan=daftar_router_pilihan)


@app.route("/ip-pools/edit/<int:pool_id>", methods=["POST"])
@login_required
def edit_ip_pool(pool_id):
    db = get_db()
    row = db.execute("SELECT * FROM ip_pool WHERE id=?", (pool_id,)).fetchone()
    if not row:
        flash("IP Pool tidak ditemukan.", "danger")
        return redirect(url_for("ip_pools"))

    nama = request.form["nama"].strip()
    network_cidr = request.form["network_cidr"].strip()
    gateway = request.form.get("gateway", "").strip()
    dns_server = request.form.get("dns_server", "").strip()
    router_id = request.form.get("router_id", "").strip() or None
    status = request.form.get("status", "aktif").strip() or "aktif"
    keterangan = request.form.get("keterangan", "").strip()

    db.execute(
        """UPDATE ip_pool SET nama=?, network_cidr=?, gateway=?, dns_server=?, router_id=?, status=?, keterangan=?
           WHERE id=?""",
        (nama, network_cidr, gateway or None, dns_server or None, router_id, status, keterangan or None, pool_id))
    db.commit()
    flash("IP Pool diperbarui.", "success")
    return redirect(url_for("ip_pools"))


@app.route("/ip-pools/hapus/<int:pool_id>", methods=["POST"])
@login_required
def hapus_ip_pool(pool_id):
    db = get_db()
    db.execute("DELETE FROM ip_pool WHERE id=?", (pool_id,))
    db.commit()
    flash("IP Pool dihapus.", "success")
    return redirect(url_for("ip_pools"))


# ---------------------------------------------------------------------------
# Network > LinkNet -- link/jalur backbone antar NAS (POP)
# ---------------------------------------------------------------------------
@app.route("/linknet", methods=["GET", "POST"])
@login_required
def linknet():
    db = get_db()
    if request.method == "POST":
        nama_link = request.form["nama_link"].strip()
        nas_asal_id = request.form.get("nas_asal_id", "").strip() or None
        nas_tujuan_id = request.form.get("nas_tujuan_id", "").strip() or None
        tipe = request.form.get("tipe", "Fiber").strip() or "Fiber"
        kapasitas = request.form.get("kapasitas", "").strip()
        status = request.form.get("status", "up").strip() or "up"
        keterangan = request.form.get("keterangan", "").strip()

        db.execute(
            """INSERT INTO link_jaringan (nama_link, nas_asal_id, nas_tujuan_id, tipe, kapasitas, status, keterangan, dibuat_tanggal)
               VALUES (?,?,?,?,?,?,?,?)""",
            (nama_link, nas_asal_id, nas_tujuan_id, tipe, kapasitas or None, status,
             keterangan or None, date.today().isoformat()))
        db.commit()
        flash("Link ditambahkan.", "success")
        return redirect(url_for("linknet"))

    daftar_link = db.execute(
        """SELECT l.*, ra.nama_router AS nama_nas_asal, rt.nama_router AS nama_nas_tujuan
           FROM link_jaringan l
           LEFT JOIN router ra ON ra.id = l.nas_asal_id
           LEFT JOIN router rt ON rt.id = l.nas_tujuan_id
           ORDER BY l.id DESC"""
    ).fetchall()
    daftar_router_pilihan = db.execute("SELECT id, nama_router FROM router ORDER BY nama_router").fetchall()
    return render_template("linknet.html", daftar_link=daftar_link, daftar_router_pilihan=daftar_router_pilihan)


@app.route("/linknet/edit/<int:link_id>", methods=["POST"])
@login_required
def edit_linknet(link_id):
    db = get_db()
    row = db.execute("SELECT * FROM link_jaringan WHERE id=?", (link_id,)).fetchone()
    if not row:
        flash("Link tidak ditemukan.", "danger")
        return redirect(url_for("linknet"))

    nama_link = request.form["nama_link"].strip()
    nas_asal_id = request.form.get("nas_asal_id", "").strip() or None
    nas_tujuan_id = request.form.get("nas_tujuan_id", "").strip() or None
    tipe = request.form.get("tipe", "Fiber").strip() or "Fiber"
    kapasitas = request.form.get("kapasitas", "").strip()
    status = request.form.get("status", "up").strip() or "up"
    keterangan = request.form.get("keterangan", "").strip()

    db.execute(
        """UPDATE link_jaringan SET nama_link=?, nas_asal_id=?, nas_tujuan_id=?, tipe=?, kapasitas=?, status=?, keterangan=?
           WHERE id=?""",
        (nama_link, nas_asal_id, nas_tujuan_id, tipe, kapasitas or None, status, keterangan or None, link_id))
    db.commit()
    flash("Link diperbarui.", "success")
    return redirect(url_for("linknet"))


@app.route("/linknet/hapus/<int:link_id>", methods=["POST"])
@login_required
def hapus_linknet(link_id):
    db = get_db()
    db.execute("DELETE FROM link_jaringan WHERE id=?", (link_id,))
    db.commit()
    flash("Link dihapus.", "success")
    return redirect(url_for("linknet"))


# ---------------------------------------------------------------------------
# Network > Topology -- ringkasan hierarki NAS -> ODP -> Pelanggan, dan
# daftar link backbone antar NAS, dirangkum dari data yang sudah ada.
# ---------------------------------------------------------------------------
@app.route("/topology")
@login_required
def topology():
    db = get_db()
    daftar_router = db.execute(
        """SELECT r.*,
                  (SELECT COUNT(*) FROM pelanggan pl WHERE pl.router_id = r.id) AS jumlah_pelanggan
           FROM router r ORDER BY r.nama_router"""
    ).fetchall()
    daftar_odp = db.execute(
        """SELECT od.*, ol.nama AS nama_olt,
                  (SELECT COUNT(*) FROM pelanggan pl WHERE pl.odp_id = od.id) AS jumlah_pelanggan
           FROM odp od LEFT JOIN olt_device ol ON ol.id = od.olt_id
           ORDER BY od.nama"""
    ).fetchall()
    daftar_link = db.execute(
        """SELECT l.*, ra.nama_router AS nama_nas_asal, rt.nama_router AS nama_nas_tujuan
           FROM link_jaringan l
           LEFT JOIN router ra ON ra.id = l.nas_asal_id
           LEFT JOIN router rt ON rt.id = l.nas_tujuan_id
           ORDER BY l.id DESC"""
    ).fetchall()
    daftar_olt = db.execute("SELECT * FROM olt_device ORDER BY nama").fetchall()
    return render_template("topology.html", daftar_router=daftar_router, daftar_odp=daftar_odp,
                           daftar_link=daftar_link, daftar_olt=daftar_olt)


@app.route("/peta")
@login_required
def peta():
    db = get_db()
    daftar_paket = db.execute("SELECT id, nama_paket, kecepatan, harga FROM paket ORDER BY nama_paket").fetchall()
    daftar_odp = db.execute("SELECT id, nama FROM odp ORDER BY nama").fetchall()
    return render_template("peta.html", daftar_paket=daftar_paket, daftar_odp=daftar_odp)


@app.route("/api/peta/data")
@login_required
def api_peta_data():
    """Data gabungan untuk peta: lokasi pelanggan (client), ODP, dan server (OLT)
    yang sudah diisi koordinat."""
    db = get_db()
    pelanggan_rows = db.execute(
        """SELECT pl.id, pl.nama, pl.alamat, pl.no_hp, pl.status, pl.latitude, pl.longitude,
                  pl.odp_id, pl.username_pppoe, pl.alamat_ip, pk.nama_paket
           FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
           WHERE pl.latitude IS NOT NULL AND pl.longitude IS NOT NULL"""
    ).fetchall()
    odp_rows = db.execute(
        """SELECT od.id, od.nama, od.alamat, od.latitude, od.longitude, od.kapasitas, od.keterangan,
                  od.olt_id, od.odp_induk_id,
                  (SELECT COUNT(*) FROM pelanggan pl WHERE pl.odp_id = od.id) AS jumlah_pelanggan
           FROM odp od
           WHERE od.latitude IS NOT NULL AND od.longitude IS NOT NULL"""
    ).fetchall()
    server_rows = db.execute(
        """SELECT id, nama, alamat, latitude, longitude, host, tipe, brand, keterangan
           FROM olt_device
           WHERE latitude IS NOT NULL AND longitude IS NOT NULL"""
    ).fetchall()
    total_tanpa_koordinat = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE latitude IS NULL OR longitude IS NULL"
    ).fetchone()["c"]

    data_pelanggan = [
        dict(id=r["id"], nama=r["nama"], alamat=r["alamat"], no_hp=r["no_hp"], status=r["status"],
             lat=r["latitude"], lng=r["longitude"], odp_id=r["odp_id"], paket=r["nama_paket"],
             username_pppoe=r["username_pppoe"], alamat_ip=r["alamat_ip"])
        for r in pelanggan_rows
    ]
    data_odp = [
        dict(id=r["id"], nama=r["nama"], alamat=r["alamat"], lat=r["latitude"], lng=r["longitude"],
             kapasitas=r["kapasitas"], jumlah_pelanggan=r["jumlah_pelanggan"], keterangan=r["keterangan"],
             olt_id=r["olt_id"], odp_induk_id=r["odp_induk_id"])
        for r in odp_rows
    ]
    data_server = [
        dict(id=r["id"], nama=r["nama"], alamat=r["alamat"], lat=r["latitude"], lng=r["longitude"],
             host=r["host"], tipe=r["tipe"], brand=r["brand"], keterangan=r["keterangan"])
        for r in server_rows
    ]
    return jsonify(ok=True, pelanggan=data_pelanggan, odp=data_odp, server=data_server,
                   total_tanpa_koordinat=total_tanpa_koordinat)


@app.route("/api/mikrotik/ppp-secrets-tersedia")
@login_required
def api_ppp_secrets_tersedia():
    """Daftar secret PPPoE di Mikrotik yang BELUM terdaftar di billing -- dipakai fitur
    'Tambah Pelanggan Cepat' di Peta: pilih user, sistem otomatis menarik IP (statis dari
    remote-address kalau diisi, atau dinamis dari sesi aktif kalau user itu sedang online)
    beserta password aslinya, jadi tidak perlu isi manual satu-satu."""
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.", data=[])
    try:
        db = get_db()
        sudah_terdaftar = {r["username_pppoe"] for r in db.execute("SELECT username_pppoe FROM pelanggan").fetchall()}

        secrets = client.get_ppp_secrets()
        aktif_by_name = {a.get("name"): a for a in client.get_active_connections()}

        hasil = []
        for s in secrets:
            nama = s.get("name")
            if not nama or nama in sudah_terdaftar:
                continue
            sesi_aktif = aktif_by_name.get(nama)
            ip_statis = s.get("remote-address") or ""
            ip_dinamis = sesi_aktif.get("address") if sesi_aktif else ""
            hasil.append({
                "username": nama,
                "password": s.get("password", ""),
                "profile": s.get("profile", "-"),
                "comment": s.get("comment", ""),
                "online": sesi_aktif is not None,
                "ip": ip_dinamis or ip_statis or "",
                "tipe_ip": "dinamis" if (ip_dinamis and not ip_statis) else ("statis" if ip_statis else ""),
            })
        hasil.sort(key=lambda x: x["username"].lower())
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/pelanggan/tambah-cepat", methods=["POST"])
@login_required
def tambah_pelanggan_cepat():
    """Tambah pelanggan kilat dari Peta: koordinat sudah ditandai lewat klik di peta,
    username/password/IP ditarik otomatis dari secret PPPoE Mikrotik yang dipilih."""
    db = get_db()
    username_pppoe = request.form.get("username_pppoe", "").strip()
    password_pppoe = request.form.get("password_pppoe", "").strip()
    nama = request.form.get("nama", "").strip()
    alamat = request.form.get("alamat", "").strip()
    no_hp = request.form.get("no_hp", "").strip()
    alamat_ip = request.form.get("alamat_ip", "").strip() or None
    paket_id = request.form.get("paket_id") or None
    odp_id = request.form.get("odp_id") or None
    latitude = request.form.get("latitude", "").strip() or None
    longitude = request.form.get("longitude", "").strip() or None

    if not username_pppoe or not nama or not latitude or not longitude:
        return jsonify(ok=False, message="Username PPPoE, Nama, dan titik lokasi di peta wajib diisi.")
    if not password_pppoe:
        return jsonify(ok=False, message="Password PPPoE tidak terbaca dari Mikrotik. Isi manual dulu, atau tambah lewat menu Pelanggan.")

    try:
        db.execute(
            """INSERT INTO pelanggan (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id,
                                       status, tanggal_daftar, latitude, longitude, odp_id, alamat_ip)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (nama, alamat, no_hp, username_pppoe, password_pppoe, paket_id,
             "aktif", date.today().isoformat(), float(latitude), float(longitude), odp_id, alamat_ip))
        db.commit()
        _catat_aktivitas("pppoe", "Tambah Pelanggan (Peta)", f"{nama} ({username_pppoe})")
        return jsonify(ok=True, message=f"Pelanggan '{nama}' ({username_pppoe}) berhasil ditambahkan ke peta.")
    except sqlite3.IntegrityError:
        return jsonify(ok=False, message="Username PPPoE itu sudah terdaftar di billing.")
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal menyimpan: {e}")


# ---------------------------------------------------------------------------
# Tagihan
# ---------------------------------------------------------------------------
@app.route("/tagihan")
@login_required
def tagihan():
    db = get_db()
    periode = request.args.get("periode", date.today().strftime("%Y-%m"))
    daftar_tagihan = db.execute(
        """SELECT t.*, p.nama, p.username_pppoe, p.status AS status_pelanggan
           FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.periode = ?
           ORDER BY t.status ASC, p.nama ASC""", (periode,)).fetchall()
    return render_template("tagihan.html", daftar_tagihan=daftar_tagihan, periode=periode)


@app.route("/tagihan/export")
@login_required
def tagihan_export():
    """Tombol EXPORT FILE di toolbar menu Tagihan -- export daftar tagihan periode
    yang sedang tampil ke file Excel (.xlsx)."""
    db = get_db()
    periode = request.args.get("periode", date.today().strftime("%Y-%m"))
    daftar_tagihan = db.execute(
        """SELECT t.*, p.nama, p.username_pppoe, p.status AS status_pelanggan
           FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.periode = ?
           ORDER BY t.status ASC, p.nama ASC""", (periode,)).fetchall()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Tagihan"

    kolom = [
        ("ID", 6), ("Pelanggan", 24), ("Username PPPoE", 18), ("Jumlah", 14),
        ("Jatuh Tempo", 14), ("Status", 14), ("Tanggal Bayar", 14), ("Status Layanan", 14),
    ]
    header_font = Font(name="Calibri", bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    for idx, (judul_kolom, lebar) in enumerate(kolom, start=1):
        sel = ws.cell(row=1, column=idx, value=judul_kolom)
        sel.font = header_font
        sel.fill = header_fill
        sel.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = lebar
    ws.freeze_panes = "A2"

    for baris, t in enumerate(daftar_tagihan, start=2):
        nilai = [
            t["id"], t["nama"], t["username_pppoe"], t["jumlah"] or 0,
            t["tanggal_jatuh_tempo"] or "-",
            "Lunas" if t["status"] == "lunas" else "Belum Lunas",
            t["tanggal_bayar"] or "-",
            "Aktif" if t["status_pelanggan"] == "aktif" else "Isolir",
        ]
        for kolom_idx, v in enumerate(nilai, start=1):
            ws.cell(row=baris, column=kolom_idx, value=v).alignment = Alignment(vertical="top")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    nama_file = f"tagihan_{periode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    _catat_aktivitas("billing", "Export Tagihan", f"Export {len(daftar_tagihan)} tagihan periode {periode} ke Excel.")
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=nama_file,
    )


@app.route("/tagihan/edit-massal", methods=["POST"])
@login_required
def tagihan_edit_massal():
    """Tombol EDIT di toolbar menu Tagihan -- ubah jumlah tagihan dan/atau tanggal
    jatuh tempo untuk satu atau beberapa tagihan terpilih sekaligus."""
    db = get_db()
    ids = request.form.getlist("tagihan_ids")
    periode = request.form.get("periode", date.today().strftime("%Y-%m"))
    jumlah_baru = request.form.get("jumlah", "").strip()
    jatuh_tempo_baru = request.form.get("tanggal_jatuh_tempo", "").strip()

    if not ids:
        flash("Pilih dulu minimal satu tagihan (centang di tabel) sebelum edit.", "danger")
        return redirect(url_for("tagihan", periode=periode))
    if not jumlah_baru and not jatuh_tempo_baru:
        flash("Isi jumlah baru dan/atau tanggal jatuh tempo baru dulu.", "danger")
        return redirect(url_for("tagihan", periode=periode))

    total = 0
    for tid in ids:
        try:
            tid = int(tid)
        except ValueError:
            continue
        if jumlah_baru:
            try:
                db.execute("UPDATE tagihan SET jumlah=? WHERE id=?", (int(jumlah_baru), tid))
            except ValueError:
                pass
        if jatuh_tempo_baru:
            db.execute("UPDATE tagihan SET tanggal_jatuh_tempo=? WHERE id=?", (jatuh_tempo_baru, tid))
        total += 1
    db.commit()
    _catat_aktivitas("billing", "Edit Tagihan", f"{total} tagihan diubah (massal).")
    flash(f"{total} tagihan berhasil diubah.", "success")
    return redirect(url_for("tagihan", periode=periode))


@app.route("/tagihan/hapus-massal", methods=["POST"])
@login_required
def tagihan_hapus_massal():
    """Tombol HAPUS di toolbar menu Tagihan -- hapus banyak tagihan sekaligus."""
    db = get_db()
    ids = request.form.getlist("tagihan_ids")
    periode = request.form.get("periode", date.today().strftime("%Y-%m"))
    if not ids:
        flash("Pilih dulu minimal satu tagihan yang mau dihapus.", "danger")
        return redirect(url_for("tagihan", periode=periode))

    total = 0
    for tid in ids:
        try:
            tid = int(tid)
        except ValueError:
            continue
        row = db.execute("SELECT id FROM tagihan WHERE id=?", (tid,)).fetchone()
        if not row:
            continue
        db.execute("DELETE FROM tagihan WHERE id=?", (tid,))
        total += 1
    db.commit()
    _catat_aktivitas("billing", "Hapus Tagihan", f"{total} tagihan dihapus (massal).")
    flash(f"{total} tagihan dihapus.", "success")
    return redirect(url_for("tagihan", periode=periode))


@app.route("/tagihan/generate", methods=["POST"])
@login_required
def generate_tagihan():
    """Generate tagihan bulan berjalan untuk semua pelanggan aktif yang belum punya tagihan periode ini.
    Jatuh tempo mengikuti hari_tagihan masing-masing pelanggan (diatur lewat tombol
    "Set Billing" di menu Pelanggan) kalau ada, kalau tidak fallback ke tanggal 20.
    Kalau pelanggan punya kode_unik, nominal tagihan otomatis ditambah kode unik itu
    supaya gampang dicocokkan sama mutasi rekening/e-wallet."""
    db = get_db()
    periode = date.today().strftime("%Y-%m")
    hari_ini = date.today()

    pelanggan_list = db.execute(
        """SELECT pl.id, pk.harga, pl.hari_tagihan, pl.kode_unik FROM pelanggan pl
           JOIN paket pk ON pk.id = pl.paket_id"""
    ).fetchall()

    dibuat = 0
    for p in pelanggan_list:
        sudah_ada = db.execute(
            "SELECT id FROM tagihan WHERE pelanggan_id=? AND periode=?",
            (p["id"], periode)).fetchone()
        if sudah_ada:
            continue
        hari = p["hari_tagihan"] or 20
        hari = max(1, min(28, hari))
        jatuh_tempo = hari_ini.replace(day=hari).isoformat()
        jumlah = p["harga"] + (p["kode_unik"] or 0)
        db.execute(
            """INSERT INTO tagihan (pelanggan_id, periode, jumlah, status, tanggal_jatuh_tempo)
               VALUES (?,?,?, 'belum_lunas', ?)""",
            (p["id"], periode, jumlah, jatuh_tempo))
        dibuat += 1
    db.commit()
    flash(f"{dibuat} tagihan baru dibuat untuk periode {periode}.", "success")
    return redirect(url_for("tagihan", periode=periode))


def _reaktivasi_jika_isolir(db, pelanggan_id):
    """Kalau pelanggan sebelumnya berstatus isolir, otomatis aktifkan lagi di billing
    & Mikrotik begitu tagihannya lunas (dipakai tandai_lunas & penerimaan transfer bank)."""
    pl = db.execute("SELECT * FROM pelanggan WHERE id=?", (pelanggan_id,)).fetchone()
    if pl and pl["status"] == "isolir":
        client = _get_mikrotik_client(pl["router_id"])
        if client:
            try:
                client.set_secret_disabled(pl["username_pppoe"], disabled=False)
                db.execute("UPDATE pelanggan SET status='aktif' WHERE id=?", (pl["id"],))
                db.commit()
            except RouterOSError:
                pass


@app.route("/tagihan/lunas/<int:tid>", methods=["POST"])
@login_required
def tandai_lunas(tid):
    db = get_db()
    db.execute(
        "UPDATE tagihan SET status='lunas', tanggal_bayar=? WHERE id=?",
        (date.today().isoformat(), tid))
    db.commit()
    row = db.execute("SELECT pelanggan_id FROM tagihan WHERE id=?", (tid,)).fetchone()
    if row:
        _reaktivasi_jika_isolir(db, row["pelanggan_id"])
    flash("Tagihan ditandai lunas.", "success")
    return redirect(request.referrer or url_for("tagihan"))


@app.route("/tagihan/invoice/<int:tid>")
@login_required
def cetak_invoice(tid):
    """Halaman invoice yang bisa dicetak/disimpan sebagai PDF untuk satu tagihan."""
    db = get_db()
    t = db.execute(
        """SELECT t.*, p.nama, p.alamat, p.no_hp, p.username_pppoe,
                  pk.nama_paket, pk.kecepatan
           FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           LEFT JOIN paket pk ON pk.id = p.paket_id
           WHERE t.id=?""", (tid,)).fetchone()
    if not t:
        flash("Tagihan tidak ditemukan.", "danger")
        return redirect(url_for("tagihan"))

    pengaturan = db.execute("SELECT nama_aplikasi, logo_path, alamat, telepon FROM pengaturan_umum WHERE id=1").fetchone()
    pembayaran_online = db.execute(
        "SELECT * FROM pembayaran_online WHERE tagihan_id=? ORDER BY id DESC LIMIT 1", (tid,)).fetchone()
    nomor_invoice = f"INV-{t['periode'].replace('-', '')}-{t['id']:04d}"
    return render_template(
        "cetak_invoice.html",
        t=t,
        nomor_invoice=nomor_invoice,
        nama_aplikasi=pengaturan["nama_aplikasi"] if pengaturan else "Billing Portal",
        logo_url=pengaturan["logo_path"] if pengaturan else None,
        alamat_perusahaan=pengaturan["alamat"] if pengaturan else None,
        telepon_perusahaan=pengaturan["telepon"] if pengaturan else None,
        pembayaran_online=pembayaran_online,
    )


@app.route("/tagihan/bayar/<int:tid>", methods=["GET", "POST"])
@login_required
def admin_bayar_tagihan(tid):
    """Halaman admin untuk membuatkan link pembayaran online (Tripay) untuk satu
    tagihan -- misalnya untuk dikirim manual ke pelanggan lewat WhatsApp/chat."""
    db = get_db()
    t = db.execute(
        """SELECT t.*, p.nama, p.no_hp FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id WHERE t.id=?""", (tid,)).fetchone()
    if not t:
        flash("Tagihan tidak ditemukan.", "danger")
        return redirect(url_for("tagihan"))
    if t["status"] == "lunas":
        flash("Tagihan ini sudah lunas.", "success")
        return redirect(url_for("tagihan"))

    cfg = _get_tripay_cfg(db)

    if request.method == "POST":
        metode = request.form.get("metode", "").strip()
        if not metode:
            flash("Pilih metode pembayaran dulu.", "danger")
            return redirect(url_for("admin_bayar_tagihan", tid=tid))
        berhasil, hasil = _proses_buat_transaksi_pembayaran(db, t, metode, t["no_hp"])
        if not berhasil:
            flash(hasil, "danger")
        return redirect(url_for("admin_bayar_tagihan", tid=tid))

    pembayaran_pending = db.execute(
        """SELECT * FROM pembayaran_online WHERE tagihan_id=? AND status='UNPAID'
           ORDER BY id DESC LIMIT 1""", (tid,)).fetchone()

    channel = []
    error_channel = None
    if cfg and not pembayaran_pending:
        try:
            channel = [c for c in (tripay_gateway.ambil_channel_pembayaran(cfg) or []) if c.get("active")]
        except tripay_gateway.TripayError as e:
            error_channel = str(e)

    daftar_rekening_bank = db.execute(
        "SELECT * FROM rekening_bank WHERE aktif=1 ORDER BY urutan ASC, id ASC").fetchall()
    konfirmasi_transfer_pending = db.execute(
        """SELECT * FROM konfirmasi_transfer_bank WHERE tagihan_id=? AND status='menunggu'
           ORDER BY id DESC LIMIT 1""", (tid,)).fetchone()

    return render_template(
        "admin_bayar.html", t=t, tripay_aktif=bool(cfg),
        pembayaran_pending=pembayaran_pending, channel=channel, error_channel=error_channel,
        daftar_rekening_bank=daftar_rekening_bank,
        konfirmasi_transfer_pending=konfirmasi_transfer_pending,
    )


@app.route("/tagihan/bayar/<int:tid>/cek-status", methods=["POST"])
@login_required
def admin_cek_status_bayar(tid):
    db = get_db()
    pembayaran = db.execute(
        "SELECT * FROM pembayaran_online WHERE tagihan_id=? ORDER BY id DESC LIMIT 1", (tid,)).fetchone()
    cfg = _get_tripay_cfg(db)
    if not pembayaran or not cfg:
        flash("Belum ada transaksi pembayaran online untuk tagihan ini.", "danger")
        return redirect(url_for("admin_bayar_tagihan", tid=tid))

    try:
        data = tripay_gateway.ambil_detail_transaksi(cfg, pembayaran["reference"])
        status_baru = data.get("status") or pembayaran["status"]
        _perbarui_status_pembayaran(
            db, pembayaran, status_baru,
            date.today().isoformat() if status_baru == "PAID" else None)
        if status_baru == "PAID":
            flash("Pembayaran dikonfirmasi lunas via Tripay.", "success")
            return redirect(url_for("tagihan"))
        flash(f"Status transaksi saat ini: {status_baru}.", "warning")
    except tripay_gateway.TripayError as e:
        flash(f"Gagal cek status ke Tripay: {e}", "danger")

    return redirect(url_for("admin_bayar_tagihan", tid=tid))


# ---------------------------------------------------------------------------
# Transfer Bank: rekening perusahaan (CRUD) + konfirmasi transfer manual pelanggan
# ---------------------------------------------------------------------------
def _terima_konfirmasi_transfer(db, konfirmasi_row):
    """Tandai satu konfirmasi transfer bank sebagai 'diterima' & lunaskan tagihan
    terkait (plus reaktivasi pelanggan kalau sebelumnya isolir)."""
    db.execute(
        "UPDATE konfirmasi_transfer_bank SET status='diterima', diproses_tanggal=? WHERE id=?",
        (datetime.now().isoformat(timespec="seconds"), konfirmasi_row["id"]))
    db.execute(
        "UPDATE tagihan SET status='lunas', tanggal_bayar=? WHERE id=?",
        (date.today().isoformat(), konfirmasi_row["tagihan_id"]))
    db.commit()
    _reaktivasi_jika_isolir(db, konfirmasi_row["pelanggan_id"])


@app.route("/transfer-bank")
@login_required
def transfer_bank():
    """Halaman kelola rekening bank perusahaan + proses konfirmasi transfer manual
    dari pelanggan (menunggu -> diterima/ditolak)."""
    db = get_db()
    daftar_rekening = db.execute(
        "SELECT * FROM rekening_bank ORDER BY urutan ASC, id ASC").fetchall()
    daftar_pending = db.execute(
        """SELECT k.*, p.nama AS nama_pelanggan, p.no_hp, t.periode, t.jumlah AS jumlah_tagihan
           FROM konfirmasi_transfer_bank k
           JOIN pelanggan p ON p.id = k.pelanggan_id
           JOIN tagihan t ON t.id = k.tagihan_id
           WHERE k.status='menunggu' ORDER BY k.id DESC"""
    ).fetchall()
    daftar_riwayat = db.execute(
        """SELECT k.*, p.nama AS nama_pelanggan, t.periode
           FROM konfirmasi_transfer_bank k
           JOIN pelanggan p ON p.id = k.pelanggan_id
           JOIN tagihan t ON t.id = k.tagihan_id
           WHERE k.status != 'menunggu' ORDER BY k.id DESC LIMIT 30"""
    ).fetchall()
    tagihan_belum_lunas = db.execute(
        """SELECT t.id, t.periode, t.jumlah, p.nama FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.status='belum_lunas' ORDER BY p.nama ASC"""
    ).fetchall()
    return render_template(
        "transfer_bank.html", daftar_rekening=daftar_rekening,
        daftar_pending=daftar_pending, daftar_riwayat=daftar_riwayat,
        tagihan_belum_lunas=tagihan_belum_lunas, hari_ini=date.today().isoformat(),
    )


@app.route("/transfer-bank/rekening/simpan", methods=["POST"])
@login_required
def simpan_rekening_bank():
    db = get_db()
    rekening_id = request.form.get("rekening_id", "").strip()
    nama_bank = request.form.get("nama_bank", "").strip()
    no_rekening = request.form.get("no_rekening", "").strip()
    atas_nama = request.form.get("atas_nama", "").strip()
    keterangan = request.form.get("keterangan", "").strip()
    aktif = 1 if request.form.get("aktif") == "on" else 0

    if not nama_bank or not no_rekening or not atas_nama:
        flash("Nama bank, nomor rekening, dan atas nama wajib diisi.", "danger")
        return redirect(url_for("transfer_bank"))

    if rekening_id:
        db.execute(
            """UPDATE rekening_bank SET nama_bank=?, no_rekening=?, atas_nama=?,
               keterangan=?, aktif=? WHERE id=?""",
            (nama_bank, no_rekening, atas_nama, keterangan, aktif, rekening_id))
        flash("Rekening bank berhasil diperbarui.", "success")
    else:
        urutan = db.execute("SELECT COALESCE(MAX(urutan), 0) + 1 u FROM rekening_bank").fetchone()["u"]
        db.execute(
            """INSERT INTO rekening_bank (nama_bank, no_rekening, atas_nama, keterangan, aktif, urutan)
               VALUES (?,?,?,?,?,?)""",
            (nama_bank, no_rekening, atas_nama, keterangan, aktif, urutan))
        flash("Rekening bank berhasil ditambahkan.", "success")
    db.commit()
    return redirect(url_for("transfer_bank"))


@app.route("/transfer-bank/rekening/hapus/<int:rid>", methods=["POST"])
@login_required
def hapus_rekening_bank(rid):
    db = get_db()
    db.execute("DELETE FROM rekening_bank WHERE id=?", (rid,))
    db.commit()
    flash("Rekening bank dihapus.", "success")
    return redirect(url_for("transfer_bank"))


@app.route("/transfer-bank/terima/<int:kid>", methods=["POST"])
@login_required
def terima_konfirmasi_transfer(kid):
    db = get_db()
    row = db.execute("SELECT * FROM konfirmasi_transfer_bank WHERE id=?", (kid,)).fetchone()
    if not row:
        flash("Konfirmasi transfer tidak ditemukan.", "danger")
        return redirect(request.referrer or url_for("transfer_bank"))
    if row["status"] != "menunggu":
        flash("Konfirmasi ini sudah diproses sebelumnya.", "warning")
        return redirect(request.referrer or url_for("transfer_bank"))
    _terima_konfirmasi_transfer(db, row)
    flash("Transfer diterima & tagihan ditandai lunas.", "success")
    return redirect(request.referrer or url_for("transfer_bank"))


@app.route("/transfer-bank/tolak/<int:kid>", methods=["POST"])
@login_required
def tolak_konfirmasi_transfer(kid):
    db = get_db()
    catatan_admin = request.form.get("catatan_admin", "").strip()
    db.execute(
        "UPDATE konfirmasi_transfer_bank SET status='ditolak', diproses_tanggal=?, catatan_admin=? WHERE id=?",
        (datetime.now().isoformat(timespec="seconds"), catatan_admin, kid))
    db.commit()
    flash("Konfirmasi transfer ditolak.", "success")
    return redirect(request.referrer or url_for("transfer_bank"))


@app.route("/transfer-bank/catat-manual", methods=["POST"])
@login_required
def catat_transfer_manual():
    """Admin langsung mencatat & menerima transfer bank yang sudah diverifikasi sendiri
    lewat mutasi rekening (mis. pelanggan transfer tanpa lapor lewat Portal Pelanggan)."""
    db = get_db()
    tagihan_id = request.form.get("tagihan_id", "").strip()
    bank_pengirim = request.form.get("bank_pengirim", "").strip()
    nama_pengirim = request.form.get("nama_pengirim", "").strip()
    jumlah = request.form.get("jumlah", "").strip()
    tanggal_transfer = request.form.get("tanggal_transfer", "").strip()
    catatan = request.form.get("catatan", "").strip()
    rekening_id = request.form.get("rekening_tujuan_id") or None

    if not tagihan_id or not bank_pengirim or not nama_pengirim or not jumlah or not tanggal_transfer:
        flash("Pilih tagihan, isi bank pengirim, nama pengirim, jumlah, dan tanggal transfer.", "danger")
        return redirect(url_for("transfer_bank"))

    t = db.execute("SELECT * FROM tagihan WHERE id=?", (tagihan_id,)).fetchone()
    if not t:
        flash("Tagihan tidak ditemukan.", "danger")
        return redirect(url_for("transfer_bank"))
    if t["status"] == "lunas":
        flash("Tagihan ini sudah lunas.", "warning")
        return redirect(url_for("transfer_bank"))

    try:
        jumlah_int = int(jumlah)
    except ValueError:
        flash("Jumlah transfer harus berupa angka.", "danger")
        return redirect(url_for("transfer_bank"))

    cur = db.execute(
        """INSERT INTO konfirmasi_transfer_bank
           (tagihan_id, pelanggan_id, rekening_tujuan_id, bank_pengirim, nama_pengirim,
            jumlah, tanggal_transfer, catatan, status, dibuat_tanggal)
           VALUES (?,?,?,?,?,?,?,?, 'menunggu', ?)""",
        (tagihan_id, t["pelanggan_id"], rekening_id, bank_pengirim, nama_pengirim,
         jumlah_int, tanggal_transfer, catatan, datetime.now().isoformat(timespec="seconds")))
    db.commit()
    row = db.execute("SELECT * FROM konfirmasi_transfer_bank WHERE id=?", (cur.lastrowid,)).fetchone()
    _terima_konfirmasi_transfer(db, row)
    flash("Transfer bank dicatat & tagihan langsung ditandai lunas.", "success")
    return redirect(url_for("transfer_bank"))


# ---------------------------------------------------------------------------
# Withdraw / Kas Keluar: pencatatan manual dana yang ditarik keluar (BUKAN lewat
# Tripay) -- misalnya setoran hasil tagihan ke rekening pribadi, biaya operasional,
# gaji, dsb. Murni pembukuan supaya kelihatan berapa saldo kas yang sebenarnya.
# ---------------------------------------------------------------------------
KATEGORI_WITHDRAW = {
    "setoran": "Setoran ke Rekening Pribadi",
    "operasional": "Biaya Operasional",
    "gaji": "Gaji / Honor",
    "lainnya": "Lainnya",
}


@app.route("/kas-withdraw")
@login_required
def kas_withdraw():
    db = get_db()
    periode = request.args.get("periode", date.today().strftime("%Y-%m"))

    daftar = db.execute(
        """SELECT * FROM kas_withdraw WHERE substr(tanggal,1,7)=?
           ORDER BY tanggal DESC, id DESC""", (periode,)).fetchall()
    total_withdraw_periode = sum(r["jumlah"] for r in daftar)

    total_pemasukan_periode = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) t FROM tagihan WHERE status='lunas' AND periode=?",
        (periode,)).fetchone()["t"]

    total_pemasukan_semua = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) t FROM tagihan WHERE status='lunas'").fetchone()["t"]
    total_withdraw_semua = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) t FROM kas_withdraw").fetchone()["t"]
    saldo_kas = total_pemasukan_semua - total_withdraw_semua

    return render_template(
        "kas_withdraw.html", daftar=daftar, periode=periode,
        total_withdraw_periode=total_withdraw_periode,
        total_pemasukan_periode=total_pemasukan_periode,
        saldo_kas=saldo_kas, kategori_withdraw=KATEGORI_WITHDRAW,
        hari_ini=date.today().isoformat(),
    )


@app.route("/kas-withdraw/simpan", methods=["POST"])
@login_required
def simpan_kas_withdraw():
    db = get_db()
    tanggal = request.form.get("tanggal", "").strip() or date.today().isoformat()
    jumlah = request.form.get("jumlah", "").strip()
    kategori = request.form.get("kategori", "lainnya").strip()
    tujuan = request.form.get("tujuan", "").strip()
    keterangan = request.form.get("keterangan", "").strip()

    if not jumlah:
        flash("Jumlah withdraw wajib diisi.", "danger")
        return redirect(url_for("kas_withdraw"))
    try:
        jumlah_int = int(jumlah)
    except ValueError:
        flash("Jumlah withdraw harus berupa angka.", "danger")
        return redirect(url_for("kas_withdraw"))
    if jumlah_int <= 0:
        flash("Jumlah withdraw harus lebih dari 0.", "danger")
        return redirect(url_for("kas_withdraw"))
    if kategori not in KATEGORI_WITHDRAW:
        kategori = "lainnya"

    db.execute(
        """INSERT INTO kas_withdraw (tanggal, jumlah, kategori, tujuan, keterangan, dicatat_oleh, dibuat_tanggal)
           VALUES (?,?,?,?,?,?,?)""",
        (tanggal, jumlah_int, kategori, tujuan, keterangan,
         session.get("admin_nama") or session.get("admin_username"),
         datetime.now().isoformat(timespec="seconds")))
    db.commit()
    flash("Withdraw berhasil dicatat.", "success")
    return redirect(url_for("kas_withdraw", periode=tanggal[:7]))


@app.route("/kas-withdraw/hapus/<int:wid>", methods=["POST"])
@login_required
def hapus_kas_withdraw(wid):
    db = get_db()
    row = db.execute("SELECT tanggal FROM kas_withdraw WHERE id=?", (wid,)).fetchone()
    db.execute("DELETE FROM kas_withdraw WHERE id=?", (wid,))
    db.commit()
    flash("Catatan withdraw dihapus.", "success")
    return redirect(url_for("kas_withdraw", periode=row["tanggal"][:7] if row else None))


@app.route("/pengaturan/payment-gateway", methods=["GET", "POST"])
@login_required
def payment_gateway():
    """Halaman pengaturan Payment Gateway (Tripay) -- menu tersendiri, terpisah dari
    Pengaturan Admin, supaya lebih mudah ditemukan & dikelola."""
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi")

        if aksi == "simpan_tripay":
            merchant_code = request.form.get("merchant_code", "").strip()
            api_key = request.form.get("api_key", "").strip()
            private_key_baru = request.form.get("private_key", "").strip()
            mode = "sandbox" if request.form.get("mode") == "sandbox" else "production"
            aktif = 1 if request.form.get("aktif") == "on" else 0

            if private_key_baru:
                private_key = private_key_baru
            else:
                lama = db.execute("SELECT private_key FROM pengaturan_tripay WHERE id=1").fetchone()
                private_key = lama["private_key"] if lama else ""

            db.execute(
                "UPDATE pengaturan_tripay SET merchant_code=?, api_key=?, private_key=?, mode=?, aktif=? WHERE id=1",
                (merchant_code, api_key, private_key, mode, aktif))
            db.commit()
            flash("Pengaturan payment gateway Tripay berhasil disimpan.", "success")

        elif aksi == "tes_tripay":
            baris = db.execute("SELECT mode FROM pengaturan_tripay WHERE id=1").fetchone()
            mode_saat_ini = baris["mode"] if baris else "production"

            ok_jaringan, pesan_jaringan = _tes_koneksi_jaringan_tripay(mode_saat_ini)
            if not ok_jaringan:
                flash(f"Tes jaringan gagal: {pesan_jaringan}", "danger")
            else:
                flash(f"Tes jaringan berhasil: {pesan_jaringan}", "success")
                cfg = _get_tripay_cfg(db, wajib_aktif=False)
                if not cfg:
                    flash("Jaringan OK, tapi Kode Merchant/API Key/Private Key belum lengkap diisi.", "warning")
                else:
                    try:
                        channel = tripay_gateway.ambil_channel_pembayaran(cfg)
                        jumlah_aktif = len([c for c in channel if c.get("active")]) if channel else 0
                        flash(f"Autentikasi API berhasil ({cfg['mode']}). {jumlah_aktif} metode pembayaran "
                              f"aktif ditemukan di akun Tripay kamu.", "success")
                    except tripay_gateway.TripayError as e:
                        flash(f"Jaringan OK, tapi autentikasi API gagal: {e} "
                              f"(cek ulang Kode Merchant/API Key/Private Key & mode Production/Sandbox).", "danger")

        return redirect(url_for("payment_gateway"))

    pengaturan_tripay_row = db.execute("SELECT * FROM pengaturan_tripay WHERE id=1").fetchone()
    riwayat_transaksi = db.execute(
        """SELECT po.*, t.periode, p.nama AS nama_pelanggan
           FROM pembayaran_online po
           JOIN tagihan t ON t.id = po.tagihan_id
           JOIN pelanggan p ON p.id = t.pelanggan_id
           ORDER BY po.id DESC LIMIT 20"""
    ).fetchall()
    return render_template(
        "payment_gateway.html", pengaturan_tripay=pengaturan_tripay_row, riwayat_transaksi=riwayat_transaksi)


@app.route("/pengaturan/wa-gateway", methods=["GET", "POST"])
@login_required
def wa_gateway_settings():
    """Halaman pengaturan WA Gateway (Wablas) -- dipakai untuk mengirim notifikasi
    WhatsApp otomatis (mis. reminder tagihan) & tes kirim pesan manual."""
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi")

        if aksi == "simpan_wa":
            domain = request.form.get("domain", "").strip()
            token_baru = request.form.get("token", "").strip()
            secret_key_baru = request.form.get("secret_key", "").strip()
            nomor_pengirim = request.form.get("nomor_pengirim", "").strip()
            aktif = 1 if request.form.get("aktif") == "on" else 0

            lama = db.execute("SELECT token, secret_key FROM pengaturan_wa_gateway WHERE id=1").fetchone()
            token = token_baru if token_baru else (lama["token"] if lama else "")
            secret_key = secret_key_baru if secret_key_baru else (lama["secret_key"] if lama else "")

            db.execute(
                "UPDATE pengaturan_wa_gateway SET domain=?, token=?, secret_key=?, nomor_pengirim=?, aktif=? "
                "WHERE id=1",
                (domain, token, secret_key, nomor_pengirim, aktif))
            db.commit()
            flash("Pengaturan WA Gateway berhasil disimpan.", "success")

        elif aksi == "tes_wa":
            cfg_row = db.execute("SELECT * FROM pengaturan_wa_gateway WHERE id=1").fetchone()
            cfg = dict(cfg_row) if cfg_row else {}
            if not cfg.get("domain") or not cfg.get("token"):
                flash("Domain server & Token Wablas belum diisi.", "warning")
            else:
                try:
                    info = wa_gateway.cek_perangkat(cfg)
                    flash(f"Koneksi ke Wablas berhasil. Balasan server: {info}", "success")
                except wa_gateway.WablasError as e:
                    flash(f"Tes koneksi ke Wablas gagal: {e}", "danger")

        elif aksi == "tes_kirim_wa":
            nomor_tes = request.form.get("nomor_tes", "").strip()
            cfg_row = db.execute("SELECT * FROM pengaturan_wa_gateway WHERE id=1").fetchone()
            cfg = dict(cfg_row) if cfg_row else {}
            if not cfg.get("domain") or not cfg.get("token"):
                flash("Domain server & Token Wablas belum diisi.", "warning")
            elif not nomor_tes:
                flash("Nomor tujuan tes belum diisi.", "warning")
            else:
                pesan_tes = ("Ini pesan tes dari SafeNode (WA Gateway) — kalau kamu menerima ini, "
                             "berarti pengaturan WA Gateway kamu sudah benar.")
                try:
                    wa_gateway.kirim_pesan(cfg, nomor_tes, pesan_tes)
                    flash(f"Pesan tes berhasil dikirim ke {nomor_tes}.", "success")
                    catat_log_pesan_gateway(db, "wa", "keluar", nomor_tes, pesan_tes, "terkirim")
                except wa_gateway.WablasError as e:
                    flash(f"Gagal mengirim pesan tes: {e}", "danger")
                    catat_log_pesan_gateway(db, "wa", "keluar", nomor_tes, pesan_tes, "gagal", str(e))

        return redirect(url_for("wa_gateway_settings"))

    pengaturan_wa_row = db.execute("SELECT * FROM pengaturan_wa_gateway WHERE id=1").fetchone()
    log_wa = db.execute(
        "SELECT * FROM log_pesan_gateway WHERE provider='wa' ORDER BY id DESC LIMIT 50").fetchall()
    webhook_wa_url = url_for("wa_gateway_webhook", _external=True)
    return render_template("wa_gateway.html", pengaturan_wa=pengaturan_wa_row,
                            log_wa=log_wa, webhook_wa_url=webhook_wa_url)


@app.route("/gateway/wa/webhook", methods=["POST"])
def wa_gateway_webhook():
    """Endpoint webhook publik (tanpa login) untuk menerima notifikasi pesan masuk
    dari Wablas -- diarahkan lewat pengaturan Webhook di dashboard Wablas device kamu,
    supaya balasan pelanggan langsung tercatat & tampil di halaman WA Gateway aplikasi
    ini, tanpa perlu buka dashboard Wablas secara terpisah. Format payload Wablas bisa
    beda-beda tergantung versi/paket akun, jadi field nomor & isi pesan dicoba dibaca
    dari beberapa nama field yang umum dipakai."""
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    nomor = (data.get("phone") or data.get("from") or data.get("sender")
             or data.get("nomor") or "-")
    isi = (data.get("message") or data.get("text") or data.get("pesan") or "")
    if not isi:
        return jsonify(ok=False, message="Payload tidak berisi pesan yang dikenali."), 400
    db = get_db()
    catat_log_pesan_gateway(db, "wa", "masuk", nomor, isi, "diterima")
    return jsonify(ok=True)


@app.route("/pengaturan/telegram-gateway", methods=["GET", "POST"])
@login_required
def telegram_gateway_settings():
    """Halaman pengaturan Telegram Gateway -- dipakai untuk mengirim notifikasi
    lewat bot Telegram (mis. reminder tagihan) & tes kirim pesan manual."""
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi")

        if aksi == "simpan_telegram":
            bot_token_baru = request.form.get("bot_token", "").strip()
            chat_id_default = request.form.get("chat_id_default", "").strip()
            aktif = 1 if request.form.get("aktif") == "on" else 0

            lama = db.execute("SELECT bot_token FROM pengaturan_telegram_gateway WHERE id=1").fetchone()
            bot_token = bot_token_baru if bot_token_baru else (lama["bot_token"] if lama else "")

            db.execute(
                "UPDATE pengaturan_telegram_gateway SET bot_token=?, chat_id_default=?, aktif=? WHERE id=1",
                (bot_token, chat_id_default, aktif))
            db.commit()
            flash("Pengaturan Telegram Gateway berhasil disimpan.", "success")

        elif aksi == "tes_telegram":
            cfg_row = db.execute("SELECT * FROM pengaturan_telegram_gateway WHERE id=1").fetchone()
            cfg = dict(cfg_row) if cfg_row else {}
            if not cfg.get("bot_token"):
                flash("Bot Token Telegram belum diisi.", "warning")
            else:
                try:
                    info = telegram_gateway.cek_bot(cfg)
                    nama_bot = info.get("username") if isinstance(info, dict) else info
                    flash(f"Koneksi ke bot Telegram berhasil. Username bot: @{nama_bot}", "success")
                except telegram_gateway.TelegramError as e:
                    flash(f"Tes koneksi ke Telegram gagal: {e}", "danger")

        elif aksi == "tes_kirim_telegram":
            chat_id_tes = request.form.get("chat_id_tes", "").strip()
            cfg_row = db.execute("SELECT * FROM pengaturan_telegram_gateway WHERE id=1").fetchone()
            cfg = dict(cfg_row) if cfg_row else {}
            if not cfg.get("bot_token"):
                flash("Bot Token Telegram belum diisi.", "warning")
            elif not chat_id_tes and not cfg.get("chat_id_default"):
                flash("Chat ID tujuan tes belum diisi.", "warning")
            else:
                tujuan_log = chat_id_tes or cfg.get("chat_id_default")
                pesan_tes = ("Ini pesan tes dari SafeNode (Telegram Gateway) — kalau kamu menerima ini, "
                             "berarti pengaturan Telegram Gateway kamu sudah benar.")
                try:
                    telegram_gateway.kirim_pesan(cfg, chat_id_tes, pesan_tes)
                    flash(f"Pesan tes berhasil dikirim ke {tujuan_log}.", "success")
                    catat_log_pesan_gateway(db, "telegram", "keluar", tujuan_log, pesan_tes, "terkirim")
                except telegram_gateway.TelegramError as e:
                    flash(f"Gagal mengirim pesan tes: {e}", "danger")
                    catat_log_pesan_gateway(db, "telegram", "keluar", tujuan_log, pesan_tes, "gagal", str(e))

        return redirect(url_for("telegram_gateway_settings"))

    pengaturan_telegram_row = db.execute("SELECT * FROM pengaturan_telegram_gateway WHERE id=1").fetchone()
    log_telegram_keluar = db.execute(
        "SELECT * FROM log_pesan_gateway WHERE provider='telegram' AND arah='keluar' "
        "ORDER BY id DESC LIMIT 50").fetchall()

    pesan_masuk_telegram = []
    pesan_masuk_telegram_error = None
    if pengaturan_telegram_row and pengaturan_telegram_row["bot_token"]:
        try:
            pesan_masuk_telegram = telegram_gateway.ambil_pesan_masuk(dict(pengaturan_telegram_row))
        except telegram_gateway.TelegramError as e:
            pesan_masuk_telegram_error = str(e)

    return render_template(
        "telegram_gateway.html", pengaturan_telegram=pengaturan_telegram_row,
        log_telegram_keluar=log_telegram_keluar, pesan_masuk_telegram=pesan_masuk_telegram,
        pesan_masuk_telegram_error=pesan_masuk_telegram_error)


@app.route("/pengaturan/email-gateway", methods=["GET", "POST"])
@login_required
def email_gateway_settings():
    """Halaman pengaturan Email Gateway (SMTP) -- dipakai untuk mengirim notifikasi
    email otomatis (mis. reminder tagihan) & tes kirim email manual. Pengaturan ini
    memakai tabel yang sama dengan SMTP di menu Pengaturan Admin (satu sumber data),
    supaya fitur "Lupa Password" & notifikasi lain tetap konsisten pakai 1 konfigurasi."""
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi")

        if aksi == "simpan_email":
            smtp_host = request.form.get("smtp_host", "").strip()
            try:
                smtp_port = int(request.form.get("smtp_port", "587").strip() or 587)
            except ValueError:
                smtp_port = 587
            smtp_username = request.form.get("smtp_username", "").strip()
            smtp_password_baru = request.form.get("smtp_password", "")
            smtp_gunakan_tls = 1 if request.form.get("smtp_gunakan_tls") == "on" else 0
            email_pengirim = request.form.get("email_pengirim", "").strip()
            nama_pengirim = request.form.get("nama_pengirim", "").strip() or None

            if smtp_password_baru:
                smtp_password = smtp_password_baru
            else:
                lama = db.execute("SELECT smtp_password FROM pengaturan_smtp WHERE id=1").fetchone()
                smtp_password = lama["smtp_password"] if lama else ""

            db.execute(
                "UPDATE pengaturan_smtp SET smtp_host=?, smtp_port=?, smtp_username=?, smtp_password=?, "
                "smtp_gunakan_tls=?, email_pengirim=?, nama_pengirim=? WHERE id=1",
                (smtp_host, smtp_port, smtp_username, smtp_password, smtp_gunakan_tls,
                 email_pengirim, nama_pengirim))
            db.commit()
            flash("Pengaturan Email Gateway (SMTP) berhasil disimpan.", "success")

        elif aksi == "tes_kirim_email":
            email_tes = request.form.get("email_tes", "").strip()
            if not email_tes:
                flash("Email tujuan tes belum diisi.", "warning")
            else:
                berhasil, error = kirim_email_tes_gateway(email_tes)
                if berhasil:
                    flash(f"Email tes berhasil dikirim ke {email_tes}. Cek inbox/spam.", "success")
                else:
                    flash(f"Gagal mengirim email tes: {error}", "danger")

        return redirect(url_for("email_gateway_settings"))

    pengaturan_email_row = db.execute("SELECT * FROM pengaturan_smtp WHERE id=1").fetchone()
    return render_template("email_gateway.html", pengaturan_email=pengaturan_email_row)


@app.route("/tripay/callback", methods=["POST"])
def tripay_callback():
    """Webhook yang dipanggil Tripay setiap ada perubahan status transaksi.
    Endpoint ini publik (tanpa login) tapi divalidasi lewat signature HMAC,
    sesuai mekanisme resmi Tripay -- jangan hapus validasi ini."""
    db = get_db()
    cfg_row = db.execute("SELECT * FROM pengaturan_tripay WHERE id=1").fetchone()
    if not cfg_row or not cfg_row["private_key"]:
        return jsonify(success=False, message="Payment gateway belum dikonfigurasi."), 400

    raw_body = request.get_data()
    signature = request.headers.get("X-Callback-Signature", "")
    if not tripay_gateway.verifikasi_signature_callback(cfg_row["private_key"], raw_body, signature):
        return jsonify(success=False, message="Invalid signature"), 403

    if request.headers.get("X-Callback-Event") != "payment_status":
        return jsonify(success=True, message="Event diabaikan.")

    data = request.get_json(silent=True) or {}
    merchant_ref = data.get("merchant_ref")
    status_baru = data.get("status")
    if not merchant_ref or not status_baru:
        return jsonify(success=False, message="Payload tidak lengkap."), 400

    pembayaran = db.execute(
        "SELECT * FROM pembayaran_online WHERE merchant_ref=?", (merchant_ref,)).fetchone()
    if not pembayaran:
        return jsonify(success=False, message="Transaksi tidak ditemukan."), 404

    dibayar_tanggal = None
    if status_baru == "PAID" and data.get("paid_at"):
        try:
            dibayar_tanggal = datetime.fromtimestamp(int(data["paid_at"])).date().isoformat()
        except (ValueError, OSError, OverflowError):
            dibayar_tanggal = date.today().isoformat()
    elif status_baru == "PAID":
        dibayar_tanggal = date.today().isoformat()

    _perbarui_status_pembayaran(db, pembayaran, status_baru, dibayar_tanggal)
    return jsonify(success=True)


@app.route("/tagihan/jalankan-isolir-otomatis", methods=["POST"])
@login_required
def jalankan_isolir_otomatis():
    """Isolir semua pelanggan dengan tagihan lewat jatuh tempo & belum lunas."""
    db = get_db()
    today = date.today().isoformat()
    overdue = db.execute(
        """SELECT DISTINCT p.* FROM tagihan t
           JOIN pelanggan p ON p.id = t.pelanggan_id
           WHERE t.status='belum_lunas' AND t.tanggal_jatuh_tempo < ? AND p.status='aktif'""",
        (today,)).fetchall()

    if not overdue:
        flash("Tidak ada pelanggan yang perlu diisolir otomatis saat ini.", "info")
        return redirect(url_for("tagihan"))

    # Pelanggan overdue bisa tersebar di banyak router (multi-router/reseller),
    # jadi koneksi Mikrotik-nya dibuat per-router (di-cache) bukan cuma satu klien global.
    klien_per_router = {}
    jumlah = 0
    gagal_router = set()
    for p in overdue:
        rid = p["router_id"] or 1
        if rid not in klien_per_router:
            klien_per_router[rid] = _get_mikrotik_client(rid)
        client = klien_per_router[rid]
        if not client:
            gagal_router.add(rid)
            continue
        try:
            client.set_secret_disabled(p["username_pppoe"], disabled=True)
            db.execute("UPDATE pelanggan SET status='isolir' WHERE id=?", (p["id"],))
            jumlah += 1
        except RouterOSError:
            continue
    db.commit()
    pesan = f"{jumlah} pelanggan diisolir otomatis karena telat bayar."
    if gagal_router:
        pesan += f" ({len(gagal_router)} router gagal terhubung, cek menu Router/POP.)"
    flash(pesan, "warning")
    return redirect(url_for("tagihan"))


# ---------------------------------------------------------------------------
# Tiket Gangguan (Maintenance) -- pelanggan lapor gangguan dari Portal Pelanggan,
# admin kelola & update status di sini.
# ---------------------------------------------------------------------------
STATUS_TIKET_LABEL = {
    "baru": "Baru",
    "menuju_lokasi": "Teknisi Menuju Lokasi",
    "on_progress": "Teknisi On Progress",
    "selesai": "Perbaikan Selesai",
    "ditutup": "Ditutup",
}

# Tombol aksi cepat di halaman detail tiket -> (status_baru, catatan_default yang otomatis
# tercatat di timeline & langsung sinkron tampil ke halaman pelanggan).
AKSI_CEPAT_TIKET = {
    "menuju_lokasi": ("menuju_lokasi", "Teknisi sedang menuju lokasi pelanggan."),
    "on_progress": ("on_progress", "Teknisi sedang mengerjakan perbaikan di lokasi (on progress)."),
    "selesai": ("selesai", "Perbaikan sudah selesai dikerjakan."),
}


def _kirim_notifikasi_tiket_telegram(db, tiket_id, judul, nama_pelanggan, status_label, aksi):
    """Kirim notifikasi ke Group Telegram yang diatur lewat tombol Setting di
    menu Tiket Gangguan (dipakai saat tiket baru dibuat & saat status berubah).
    Diam-diam dilewati kalau ID Group atau Bot Token belum diisi, supaya fitur
    ini tidak wajib dikonfigurasi buat yang tidak butuh."""
    group_id = ""
    pesan = ""
    try:
        cfg_notif = db.execute(
            "SELECT telegram_group_id FROM pengaturan_notifikasi_tiket WHERE id=1").fetchone()
        group_id = ((cfg_notif["telegram_group_id"] if cfg_notif else "") or "").strip()
        if not group_id:
            return
        cfg_bot_row = db.execute("SELECT * FROM pengaturan_telegram_gateway WHERE id=1").fetchone()
        cfg_bot = dict(cfg_bot_row) if cfg_bot_row else {}
        if not cfg_bot.get("aktif") or not cfg_bot.get("bot_token"):
            return
        pesan = (f"\U0001F3AB Tiket #{tiket_id} {aksi}\n"
                 f"Pelanggan: {nama_pelanggan}\n"
                 f"Judul: {judul}\n"
                 f"Status: {status_label}")
        telegram_gateway.kirim_pesan(cfg_bot, group_id, pesan)
        catat_log_pesan_gateway(db, "telegram", "keluar", group_id, pesan, "terkirim")
    except telegram_gateway.TelegramError as e:
        catat_log_pesan_gateway(db, "telegram", "keluar", group_id, pesan, "gagal", str(e))
    except Exception:
        pass


def _hitung_laporan_tiket(db, bulan, tahun):
    """Hitung ringkasan & data harian tiket gangguan untuk satu bulan tertentu --
    dipakai bareng oleh halaman Laporan Tiket & ketiga tombol export PDF-nya
    (PDF Grafik, PDF Rekap, PDF Lengkap) supaya angkanya selalu konsisten."""
    bulan_str = f"{tahun:04d}-{bulan:02d}"
    hari_dalam_bulan = calendar.monthrange(tahun, bulan)[1]

    tiket_masuk = db.execute(
        "SELECT COUNT(*) c FROM tiket_gangguan WHERE substr(tanggal_lapor,1,7)=?", (bulan_str,)
    ).fetchone()["c"]
    tiket_selesai = db.execute(
        "SELECT COUNT(*) c FROM tiket_gangguan WHERE status IN ('selesai','ditutup') "
        "AND substr(COALESCE(tanggal_update,tanggal_lapor),1,7)=?", (bulan_str,)
    ).fetchone()["c"]
    masih_terbuka = db.execute(
        "SELECT COUNT(*) c FROM tiket_gangguan WHERE status NOT IN ('selesai','ditutup')"
    ).fetchone()["c"]
    layanan_berulang = db.execute(
        "SELECT COUNT(*) c FROM (SELECT pelanggan_id FROM tiket_gangguan "
        "WHERE substr(tanggal_lapor,1,7)=? GROUP BY pelanggan_id HAVING COUNT(*) > 1)", (bulan_str,)
    ).fetchone()["c"]

    # SLA respons 4 jam: dihitung dari selisih waktu tiket dibuat -> entri riwayat
    # pertama setelah status "baru" (tanda tiket itu mulai direspon/ditindaklanjuti).
    tiket_bulan_ini = db.execute(
        "SELECT id, tanggal_lapor FROM tiket_gangguan WHERE substr(tanggal_lapor,1,7)=?", (bulan_str,)
    ).fetchall()
    direspon, tepat_sla = 0, 0
    for tk in tiket_bulan_ini:
        riwayat_pertama = db.execute(
            "SELECT waktu FROM tiket_riwayat WHERE tiket_id=? AND status != 'baru' "
            "ORDER BY waktu ASC LIMIT 1", (tk["id"],)
        ).fetchone()
        if not riwayat_pertama:
            continue
        try:
            t_lapor = datetime.strptime(tk["tanggal_lapor"][:19], "%Y-%m-%d %H:%M:%S")
            t_respon = datetime.strptime(riwayat_pertama["waktu"][:19], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        direspon += 1
        if (t_respon - t_lapor).total_seconds() <= 4 * 3600:
            tepat_sla += 1
    sla_persen = round((tepat_sla / direspon) * 100) if direspon else None

    data_harian = []
    total_resolusi_jam, jumlah_resolusi = 0.0, 0
    for d in range(1, hari_dalam_bulan + 1):
        tgl = f"{bulan_str}-{d:02d}"
        masuk_hari = db.execute(
            "SELECT COUNT(*) c FROM tiket_gangguan WHERE substr(tanggal_lapor,1,10)=?", (tgl,)
        ).fetchone()["c"]
        selesai_rows = db.execute(
            "SELECT tanggal_lapor, tanggal_update FROM tiket_gangguan "
            "WHERE status IN ('selesai','ditutup') AND substr(COALESCE(tanggal_update,tanggal_lapor),1,10)=?",
            (tgl,)
        ).fetchall()
        resolusi_jam_hari = []
        for r in selesai_rows:
            try:
                t1 = datetime.strptime(r["tanggal_lapor"][:19], "%Y-%m-%d %H:%M:%S")
                t2 = datetime.strptime((r["tanggal_update"] or r["tanggal_lapor"])[:19], "%Y-%m-%d %H:%M:%S")
                resolusi_jam_hari.append(max((t2 - t1).total_seconds() / 3600, 0))
            except ValueError:
                continue
        rata_resolusi_hari = round(sum(resolusi_jam_hari) / len(resolusi_jam_hari), 2) if resolusi_jam_hari else 0
        total_resolusi_jam += sum(resolusi_jam_hari)
        jumlah_resolusi += len(resolusi_jam_hari)
        data_harian.append({
            "tanggal": d, "masuk": masuk_hari, "selesai": len(selesai_rows), "rata_resolusi": rata_resolusi_hari,
        })

    rata_resolusi_bulan = round(total_resolusi_jam / jumlah_resolusi, 2) if jumlah_resolusi else None

    return {
        "bulan": bulan, "tahun": tahun, "bulan_str": bulan_str,
        "tiket_masuk": tiket_masuk, "tiket_selesai": tiket_selesai, "masih_terbuka": masih_terbuka,
        "layanan_berulang": layanan_berulang, "sla_persen": sla_persen,
        "rata_resolusi_bulan": rata_resolusi_bulan, "data_harian": data_harian,
    }


def _query_tiket_gangguan(db):
    """Ambil daftar tiket gangguan sesuai filter (?status, ?prioritas, ?kategori, ?q)
    yang sedang aktif di URL. Dipakai bareng oleh halaman /tiket dan /tiket/export
    supaya hasil export selalu cocok dengan apa yang lagi ditampilkan/difilter admin."""
    status_filter = request.args.get("status", "semua")
    prioritas_filter = request.args.get("prioritas", "semua")
    kategori_filter = request.args.get("kategori", "semua")
    q = request.args.get("q", "").strip()

    query = """SELECT tk.*, p.nama, p.username_pppoe, p.no_hp
               FROM tiket_gangguan tk
               JOIN pelanggan p ON p.id = tk.pelanggan_id WHERE 1=1"""
    params = []
    if status_filter != "semua":
        query += " AND tk.status=?"
        params.append(status_filter)
    if prioritas_filter != "semua":
        query += " AND tk.prioritas=?"
        params.append(prioritas_filter)
    if kategori_filter != "semua":
        query += " AND tk.kategori=?"
        params.append(kategori_filter)
    if q:
        query += " AND (tk.judul LIKE ? OR p.nama LIKE ? OR p.username_pppoe LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    query += " ORDER BY tk.id DESC"
    daftar = db.execute(query, params).fetchall()
    return daftar, status_filter, prioritas_filter, kategori_filter, q


@app.route("/tiket")
@login_required
def tiket_gangguan():
    db = get_db()
    daftar_tiket_semua, status_filter, prioritas_filter, kategori_filter, q = _query_tiket_gangguan(db)

    jumlah_per_status = {
        s: db.execute("SELECT COUNT(*) c FROM tiket_gangguan WHERE status=?", (s,)).fetchone()["c"]
        for s in STATUS_TIKET_LABEL
    }
    total_tiket = db.execute("SELECT COUNT(*) c FROM tiket_gangguan").fetchone()["c"]

    # Daftar pelanggan buat dropdown pilih pelanggan di form "Buat Tiket"
    daftar_pelanggan_pilihan = db.execute(
        "SELECT id, nama, username_pppoe, alamat, no_hp FROM pelanggan ORDER BY nama").fetchall()
    # Daftar teknisi (admin level='teknisi') buat dropdown "Assign Teknisi"
    daftar_teknisi = db.execute(
        "SELECT id, nama, username FROM admin WHERE level='teknisi' ORDER BY nama").fetchall()
    setting_notif = db.execute(
        "SELECT telegram_group_id FROM pengaturan_notifikasi_tiket WHERE id=1").fetchone()
    telegram_group_id = (setting_notif["telegram_group_id"] if setting_notif else "") or ""

    hal = _paginate(daftar_tiket_semua)

    return render_template(
        "tiket.html", daftar_tiket=hal["items"], status_filter=status_filter,
        prioritas_filter=prioritas_filter, kategori_filter=kategori_filter, q=q,
        jumlah_per_status=jumlah_per_status, total_tiket=total_tiket,
        status_label=STATUS_TIKET_LABEL, prioritas_label=PRIORITAS_LABEL,
        stat_label=CUSTOMER_TICKET_STAT_LABEL,
        daftar_pelanggan_pilihan=daftar_pelanggan_pilihan,
        daftar_teknisi=daftar_teknisi, telegram_group_id=telegram_group_id,
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total=hal["total"], total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"])


@app.route("/tiket/export")
@login_required
def tiket_export():
    """Export daftar tiket gangguan (sesuai filter yang sedang aktif) ke file Excel (.xlsx)."""
    db = get_db()
    daftar_tiket, status_filter, prioritas_filter, kategori_filter, q = _query_tiket_gangguan(db)

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Tiket Gangguan"

    kolom = [
        ("ID", 6), ("Judul", 30), ("Customer", 22), ("Username PPPoE", 18),
        ("No. HP", 16), ("Kategori", 14), ("Status", 18), ("Prioritas", 12),
        ("Tanggal Lapor", 18), ("Deskripsi", 40), ("Catatan Admin", 40),
    ]
    header_font = Font(name="Calibri", bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    for idx, (judul_kolom, lebar) in enumerate(kolom, start=1):
        sel = ws.cell(row=1, column=idx, value=judul_kolom)
        sel.font = header_font
        sel.fill = header_fill
        sel.alignment = Alignment(vertical="center")
        ws.column_dimensions[get_column_letter(idx)].width = lebar
    ws.freeze_panes = "A2"

    for baris, tk in enumerate(daftar_tiket, start=2):
        nilai = [
            tk["id"], tk["judul"], tk["nama"], tk["username_pppoe"], tk["no_hp"] or "",
            (tk["kategori"] or "").capitalize(),
            STATUS_TIKET_LABEL.get(tk["status"], tk["status"]),
            PRIORITAS_LABEL.get(tk["prioritas"], tk["prioritas"]),
            tk["tanggal_lapor"],
            tk["deskripsi"] or "",
            tk["catatan_admin"] or "",
        ]
        for kolom_idx, v in enumerate(nilai, start=1):
            cell = ws.cell(row=baris, column=kolom_idx, value=v)
            cell.alignment = Alignment(vertical="top", wrap_text=kolom_idx in (10, 11))

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    nama_file = f"tiket-gangguan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    _catat_aktivitas("tiket", "export", f"Export {len(daftar_tiket)} tiket gangguan ke Excel.")
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=nama_file,
    )


@app.route("/tiket/tambah", methods=["POST"])
@login_required
def tiket_tambah():
    """Admin bikin tiket gangguan baru langsung dari menu Tiket Gangguan
    (mis. tiket hasil telepon/WA pelanggan yang dicatat manual oleh admin)."""
    db = get_db()
    pelanggan_id = request.form.get("pelanggan_id", "").strip()
    kategori = request.form.get("kategori", "lainnya").strip() or "lainnya"
    judul = request.form.get("judul", "").strip()
    deskripsi = request.form.get("deskripsi", "").strip()
    prioritas = request.form.get("prioritas", "medium")
    if prioritas not in PRIORITAS_LABEL:
        prioritas = "medium"
    alamat_koordinat = request.form.get("alamat_koordinat", "").strip() or None
    no_whatsapp = request.form.get("no_whatsapp", "").strip() or None
    assigned_teknisi_id = request.form.get("assigned_teknisi_id", "").strip() or None
    kirim_notif_wa = request.form.get("notifikasi_wa") == "on"

    if not pelanggan_id or not judul or not deskripsi:
        flash("Pelanggan, judul, dan deskripsi wajib diisi.", "danger")
        return redirect(url_for("tiket_gangguan"))

    pelanggan = db.execute("SELECT id, nama, no_hp FROM pelanggan WHERE id=?", (pelanggan_id,)).fetchone()
    if not pelanggan:
        flash("Pelanggan tidak ditemukan.", "danger")
        return redirect(url_for("tiket_gangguan"))

    cur = db.execute(
        """INSERT INTO tiket_gangguan (pelanggan_id, kategori, judul, deskripsi, status, tanggal_lapor,
           prioritas, dept, assigned_teknisi_id, alamat_koordinat, no_whatsapp)
           VALUES (?,?,?,?, 'baru', ?, ?, 'support', ?, ?, ?)""",
        (pelanggan_id, kategori, judul, deskripsi, _sekarang(), prioritas,
         assigned_teknisi_id, alamat_koordinat, no_whatsapp or pelanggan["no_hp"]))
    db.commit()
    tiket_id = cur.lastrowid
    _catat_riwayat_tiket(db, tiket_id, "baru", f"Tiket dibuat manual oleh {_nama_admin_aktif()}.")

    _kirim_notifikasi_tiket_telegram(db, tiket_id, judul, pelanggan["nama"], STATUS_TIKET_LABEL["baru"], "baru dibuat")

    if kirim_notif_wa:
        nomor_wa = no_whatsapp or pelanggan["no_hp"]
        if nomor_wa:
            try:
                cfg_wa_row = db.execute("SELECT * FROM pengaturan_wa_gateway WHERE id=1").fetchone()
                cfg_wa = dict(cfg_wa_row) if cfg_wa_row else {}
                if cfg_wa.get("aktif"):
                    pesan_wa = (f"Halo {pelanggan['nama']}, tiket gangguan #{tiket_id} \"{judul}\" "
                                f"sudah kami terima dan akan segera ditindaklanjuti. Terima kasih.")
                    wa_gateway.kirim_pesan(cfg_wa, nomor_wa, pesan_wa)
                    catat_log_pesan_gateway(db, "wa", "keluar", nomor_wa, pesan_wa, "terkirim")
            except wa_gateway.WablasError as e:
                catat_log_pesan_gateway(db, "wa", "keluar", nomor_wa, pesan_wa, "gagal", str(e))
            except Exception:
                pass

    flash(f"Tiket baru #{tiket_id} untuk {pelanggan['nama']} berhasil dibuat.", "success")
    return redirect(url_for("tiket_gangguan"))


@app.route("/tiket/setting-notifikasi", methods=["POST"])
@login_required
def tiket_setting_notifikasi():
    """Tombol Setting di toolbar menu Tiket Gangguan -- simpan ID Group Telegram
    tujuan notifikasi tiket (Bot Token-nya dipakai bareng dengan Pengaturan > Telegram Gateway)."""
    db = get_db()
    group_id = request.form.get("telegram_group_id", "").strip()
    db.execute("UPDATE pengaturan_notifikasi_tiket SET telegram_group_id=? WHERE id=1", (group_id,))
    db.commit()
    if group_id:
        flash("Pengaturan notifikasi tiket berhasil disimpan.", "success")
    else:
        flash("ID Group Telegram dikosongkan -- notifikasi tiket ke Telegram dimatikan.", "success")
    return redirect(url_for("tiket_gangguan"))


@app.route("/tiket/laporan")
@login_required
def tiket_laporan():
    """Tombol Laporan di toolbar menu Tiket Gangguan -- dashboard ringkasan tiket
    per bulan (tiket masuk/selesai/masih terbuka/SLA respons/layanan berulang)."""
    db = get_db()
    now = datetime.now()
    try:
        bulan = int(request.args.get("bulan", now.month))
        tahun = int(request.args.get("tahun", now.year))
    except ValueError:
        bulan, tahun = now.month, now.year
    if bulan < 1 or bulan > 12:
        bulan = now.month

    laporan = _hitung_laporan_tiket(db, bulan, tahun)
    return render_template("laporan_tiket.html", laporan=laporan)


@app.route("/tiket/laporan/pdf")
@login_required
def tiket_laporan_pdf():
    """Tiga tombol PDF di halaman Laporan Tiket (Grafik / Rekap / Lengkap) --
    dibedakan lewat ?jenis=grafik|rekap|lengkap."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics.charts.lineplots import LinePlot
    from reportlab.graphics.charts.legends import Legend

    db = get_db()
    now = datetime.now()
    try:
        bulan = int(request.args.get("bulan", now.month))
        tahun = int(request.args.get("tahun", now.year))
    except ValueError:
        bulan, tahun = now.month, now.year
    jenis = request.args.get("jenis", "rekap")
    if jenis not in ("grafik", "rekap", "lengkap"):
        jenis = "rekap"

    laporan = _hitung_laporan_tiket(db, bulan, tahun)
    nama_bulan = calendar.month_name[bulan]
    styles = getSampleStyleSheet()
    elemen = [
        Paragraph(f"Laporan Tiket Gangguan -- {nama_bulan} {tahun}", styles["Title"]),
        Spacer(1, 0.4 * cm),
    ]

    if jenis in ("rekap", "lengkap"):
        data_rekap = [
            ["Tiket Masuk", str(laporan["tiket_masuk"])],
            ["Tiket Selesai", str(laporan["tiket_selesai"])],
            ["Masih Terbuka", str(laporan["masih_terbuka"])],
            ["SLA Respons 4 Jam", f"{laporan['sla_persen']}%" if laporan["sla_persen"] is not None else "Belum terukur"],
            ["Layanan Berulang", str(laporan["layanan_berulang"])],
            ["Rata-rata Waktu Penyelesaian", f"{laporan['rata_resolusi_bulan']} jam" if laporan["rata_resolusi_bulan"] is not None else "-"],
        ]
        tabel_rekap = Table(data_rekap, colWidths=[8 * cm, 6 * cm])
        tabel_rekap.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#1F4E78")),
            ("TEXTCOLOR", (0, 0), (0, -1), colors.white),
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
        ]))
        elemen += [tabel_rekap, Spacer(1, 0.6 * cm)]

    if jenis in ("grafik", "lengkap"):
        data_harian = laporan["data_harian"]
        pts_masuk = [(d["tanggal"], d["masuk"]) for d in data_harian]
        pts_selesai = [(d["tanggal"], d["selesai"]) for d in data_harian]
        drawing = Drawing(480, 220)
        lp = LinePlot()
        lp.x = 40
        lp.y = 30
        lp.height = 160
        lp.width = 400
        lp.data = [pts_masuk, pts_selesai]
        lp.lines[0].strokeColor = colors.HexColor("#6366f1")
        lp.lines[1].strokeColor = colors.HexColor("#22c55e")
        lp.lines[0].strokeWidth = 2
        lp.lines[1].strokeWidth = 2
        lp.xValueAxis.valueMin = 1
        lp.xValueAxis.valueMax = max(1, len(data_harian))
        lp.yValueAxis.valueMin = 0
        maks_y = max([m for m, _ in pts_masuk] + [s for _, s in pts_selesai] + [1])
        lp.yValueAxis.valueMax = maks_y + 1
        legenda = Legend()
        legenda.x = 440
        legenda.y = 160
        legenda.colorNamePairs = [(colors.HexColor("#6366f1"), "Tiket Masuk"), (colors.HexColor("#22c55e"), "Tiket Selesai")]
        drawing.add(lp)
        drawing.add(legenda)
        elemen += [Paragraph("Grafik Tiket Harian", styles["Heading3"]), drawing, Spacer(1, 0.6 * cm)]

    if jenis == "lengkap":
        daftar_tiket_bulan = db.execute(
            """SELECT tk.id, tk.judul, p.nama, tk.status, tk.prioritas, tk.tanggal_lapor
               FROM tiket_gangguan tk JOIN pelanggan p ON p.id = tk.pelanggan_id
               WHERE substr(tk.tanggal_lapor,1,7)=? ORDER BY tk.id ASC""",
            (laporan["bulan_str"],)
        ).fetchall()
        data_tabel = [["ID", "Judul", "Pelanggan", "Status", "Prioritas", "Tgl Lapor"]]
        for tk in daftar_tiket_bulan:
            data_tabel.append([
                f"#{tk['id']}", tk["judul"], tk["nama"], STATUS_TIKET_LABEL.get(tk["status"], tk["status"]),
                PRIORITAS_LABEL.get(tk["prioritas"], tk["prioritas"]), tk["tanggal_lapor"],
            ])
        tabel_lengkap = Table(data_tabel, colWidths=[1.5 * cm, 5 * cm, 4 * cm, 3.5 * cm, 2.5 * cm, 3 * cm], repeatRows=1)
        tabel_lengkap.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E78")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elemen += [Paragraph("Daftar Tiket Bulan Ini", styles["Heading3"]), tabel_lengkap]

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=1.5 * cm, bottomMargin=1.5 * cm)
    doc.build(elemen)
    buf.seek(0)
    nama_file = f"laporan-tiket_{jenis}_{tahun}{bulan:02d}.pdf"
    _catat_aktivitas("tiket", "Laporan PDF", f"Export laporan tiket ({jenis}) periode {nama_bulan} {tahun}.")
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=nama_file)


@app.route("/tiket/<int:tiket_id>", methods=["GET", "POST"])
@login_required
def detail_tiket(tiket_id):
    db = get_db()
    tk = db.execute(
        """SELECT tk.*, p.nama, p.alamat, p.no_hp, p.username_pppoe, p.status AS status_pelanggan
           FROM tiket_gangguan tk
           JOIN pelanggan p ON p.id = tk.pelanggan_id
           WHERE tk.id=?""", (tiket_id,)).fetchone()
    if not tk:
        flash("Tiket tidak ditemukan.", "danger")
        return redirect(url_for("tiket_gangguan"))

    if request.method == "POST":
        aksi_cepat = request.form.get("aksi_cepat")
        if aksi_cepat in AKSI_CEPAT_TIKET:
            status_baru, catatan_default = AKSI_CEPAT_TIKET[aksi_cepat]
            _catat_riwayat_tiket(db, tiket_id, status_baru, catatan_default)
            flash(f"Status tiket diperbarui: {STATUS_TIKET_LABEL[status_baru]}.", "success")
        else:
            status_baru = request.form.get("status", tk["status"])
            catatan_admin = request.form.get("catatan_admin", "").strip() or None
            _catat_riwayat_tiket(db, tiket_id, status_baru, catatan_admin)
            flash("Tiket berhasil diperbarui.", "success")
        _kirim_notifikasi_tiket_telegram(
            db, tiket_id, tk["judul"], tk["nama"], STATUS_TIKET_LABEL.get(status_baru, status_baru), "diperbarui")
        return redirect(url_for("detail_tiket", tiket_id=tiket_id))

    riwayat = db.execute(
        "SELECT * FROM tiket_riwayat WHERE tiket_id=? ORDER BY id ASC", (tiket_id,)).fetchall()
    return render_template("detail_tiket.html", tk=tk, riwayat=riwayat, status_label=STATUS_TIKET_LABEL)


@app.route("/tiket/<int:tiket_id>/hapus", methods=["POST"])
@login_required
def hapus_tiket(tiket_id):
    db = get_db()
    db.execute("DELETE FROM tiket_gangguan WHERE id=?", (tiket_id,))
    db.commit()
    flash("Tiket dihapus.", "success")
    return redirect(url_for("tiket_gangguan"))


@app.route("/tiket/hapus-massal", methods=["POST"])
@login_required
def tiket_hapus_massal():
    """Tombol HAPUS di toolbar menu Customer > Tiket Gangguan -- hapus banyak tiket sekaligus."""
    db = get_db()
    ids = request.form.getlist("tiket_ids")
    if not ids:
        flash("Pilih dulu minimal satu tiket yang mau dihapus.", "danger")
        return redirect(url_for("tiket_gangguan"))

    total = 0
    for tid in ids:
        try:
            tid = int(tid)
        except ValueError:
            continue
        row = db.execute("SELECT id FROM tiket_gangguan WHERE id=?", (tid,)).fetchone()
        if not row:
            continue
        db.execute("DELETE FROM tiket_gangguan WHERE id=?", (tid,))
        total += 1
    db.commit()
    flash(f"{total} tiket dihapus.", "success")
    return redirect(url_for("tiket_gangguan"))


# ---------------------------------------------------------------------------
# Hotspot & Voucher
# ---------------------------------------------------------------------------
import random
import string


def _generate_kode(panjang=6, format_kode="kapital_angka"):
    """Menghasilkan kode voucher acak sesuai format yang dipilih admin:
    - kapital       : huruf kapital saja (A-Z)
    - angka         : angka saja (mirip kode PIN)
    - acak          : kombinasi penuh huruf besar, huruf kecil & angka
    - kapital_angka : huruf kapital + angka (bawaan/default, kompatibel dengan versi lama)
    Karakter yang gampang salah baca (0/O, 1/I/l) disingkirkan kecuali pada mode 'angka'
    supaya panjang digit tetap penuh seperti kode PIN pada umumnya."""
    if format_kode == "kapital":
        karakter = string.ascii_uppercase.replace("O", "").replace("I", "")
    elif format_kode == "angka":
        karakter = string.digits
    elif format_kode == "acak":
        karakter = string.ascii_uppercase + string.ascii_lowercase + string.digits
        for c in "0O1Iol":
            karakter = karakter.replace(c, "")
    else:  # "kapital_angka" -- bawaan
        karakter = string.ascii_uppercase + string.digits
        for c in "0O1I":
            karakter = karakter.replace(c, "")
    return "".join(random.choice(karakter) for _ in range(panjang))


def _template_voucher_default():
    db = get_db()
    row = db.execute("SELECT voucher_desain_default FROM pengaturan_umum WHERE id=1").fetchone()
    return (row["voucher_desain_default"] if row and row["voucher_desain_default"] else "bizfiber")


@app.route("/hotspot")
@app.route("/modul-inti/hotspot")
@login_required
def hotspot():
    db = get_db()
    batch_terbaru = db.execute(
        "SELECT batch, COUNT(*) jumlah, MIN(dibuat_tanggal) tanggal FROM voucher GROUP BY batch ORDER BY tanggal DESC LIMIT 15"
    ).fetchall()
    total_voucher = db.execute("SELECT COUNT(*) c FROM voucher").fetchone()["c"]
    belum_terpakai = db.execute("SELECT COUNT(*) c FROM voucher WHERE status='belum_terpakai'").fetchone()["c"]
    daftar_profil_voucher = db.execute(
        "SELECT * FROM hotspot_voucher_profile WHERE aktif=1 ORDER BY nama_profile").fetchall()
    return render_template("hotspot.html", batch_terbaru=batch_terbaru,
                            total_voucher=total_voucher, belum_terpakai=belum_terpakai,
                            daftar_profil_voucher=daftar_profil_voucher)


def _hitung_stok_voucher():
    """Rekap stok voucher per Profile Hotspot -- dipakai halaman Stok Voucher.
    Menggabungkan data lokal tabel voucher dengan data harga/HPP/komisi dari
    hotspot_voucher_profile (kalau nama profile-nya cocok)."""
    db = get_db()
    baris = db.execute(
        """SELECT profile_hotspot,
                  COUNT(*) total,
                  SUM(CASE WHEN status='belum_terpakai' THEN 1 ELSE 0 END) sisa,
                  SUM(CASE WHEN status='terpakai' THEN 1 ELSE 0 END) terjual
           FROM voucher GROUP BY profile_hotspot ORDER BY profile_hotspot"""
    ).fetchall()
    profil_map = {p["nama_profile"]: p for p in
                  db.execute("SELECT * FROM hotspot_voucher_profile").fetchall()}
    hasil = []
    for b in baris:
        p = profil_map.get(b["profile_hotspot"])
        hasil.append({
            "profile_hotspot": b["profile_hotspot"],
            "total": b["total"], "sisa": b["sisa"], "terjual": b["terjual"],
            "harga": p["harga"] if p else None,
            "hpp": p["hpp"] if p else None,
            "komisi": p["komisi"] if p else None,
            "nilai_stok": (p["harga"] * b["sisa"]) if p else None,
        })
    return hasil


@app.route("/hotspot/profil-voucher")
@login_required
def hotspot_profil_voucher():
    db = get_db()
    daftar = [dict(r) for r in db.execute(
        """SELECT hvp.*,
                  (SELECT COUNT(*) FROM voucher v WHERE v.profile_voucher_id = hvp.id) AS jumlah_voucher
           FROM hotspot_voucher_profile hvp ORDER BY hvp.nama_profile""").fetchall()]
    daftar_profil_mikrotik = []
    client = _get_mikrotik_client()
    if client:
        try:
            daftar_profil_mikrotik = [p.get("name") for p in client.get_hotspot_profiles() if p.get("name")]
        except Exception:
            daftar_profil_mikrotik = []
    return render_template("hotspot_profil_voucher.html", daftar=daftar,
                            daftar_profil_mikrotik=daftar_profil_mikrotik)


@app.route("/hotspot/profil-voucher/simpan", methods=["POST"])
@login_required
def hotspot_profil_voucher_simpan():
    db = get_db()
    profil_id = request.form.get("id", "").strip()
    nama_profile = request.form.get("nama_profile", "").strip()
    if not nama_profile:
        flash("Nama profile wajib diisi.", "danger")
        return redirect(url_for("hotspot_profil_voucher"))

    data = dict(
        nama_profile=nama_profile,
        warna=request.form.get("warna", "").strip() or "#007BFF",
        profile_mikrotik=request.form.get("profile_mikrotik", "").strip(),
        group_reseller=request.form.get("group_reseller", "").strip(),
        addresslist=request.form.get("addresslist", "").strip(),
        rate_limit=request.form.get("rate_limit", "").strip(),
        shared_users=int(request.form.get("shared_users") or 1),
        kuota=request.form.get("kuota", "").strip(),
        durasi=request.form.get("durasi", "").strip(),
        masa_aktif=request.form.get("masa_aktif", "").strip(),
        aktif=1 if request.form.get("aktif") == "on" else 0,
        hpp=int(request.form.get("hpp") or 0),
        komisi=int(request.form.get("komisi") or 0),
        harga=int(request.form.get("harga") or 0),
    )

    try:
        if profil_id:
            db.execute(
                """UPDATE hotspot_voucher_profile SET nama_profile=:nama_profile,
                   warna=:warna, profile_mikrotik=:profile_mikrotik, group_reseller=:group_reseller,
                   addresslist=:addresslist, rate_limit=:rate_limit, shared_users=:shared_users,
                   kuota=:kuota, durasi=:durasi, masa_aktif=:masa_aktif, aktif=:aktif,
                   hpp=:hpp, komisi=:komisi, harga=:harga
                   WHERE id=:id""", {**data, "id": profil_id})
            _catat_aktivitas("hotspot", "Ubah Profile Voucher", nama_profile)
            flash("Profile voucher berhasil diperbarui.", "success")
        else:
            db.execute(
                """INSERT INTO hotspot_voucher_profile
                   (nama_profile, warna, profile_mikrotik, group_reseller, addresslist, rate_limit,
                    shared_users, kuota, durasi, masa_aktif, aktif, hpp, komisi, harga, dibuat_tanggal)
                   VALUES (:nama_profile, :warna, :profile_mikrotik, :group_reseller, :addresslist, :rate_limit,
                    :shared_users, :kuota, :durasi, :masa_aktif, :aktif, :hpp, :komisi, :harga, :dibuat_tanggal)""",
                {**data, "dibuat_tanggal": date.today().isoformat()})
            _catat_aktivitas("hotspot", "Tambah Profile Voucher", nama_profile)
            flash("Profile voucher berhasil ditambahkan.", "success")
        db.commit()
    except sqlite3.IntegrityError:
        flash(f"Nama profile '{nama_profile}' sudah dipakai.", "danger")
    return redirect(url_for("hotspot_profil_voucher"))


@app.route("/hotspot/profil-voucher/bulk", methods=["POST"])
@login_required
def hotspot_profil_voucher_bulk():
    """Aksi massal dari tombol MENU di toolbar tabel Profile Voucher:
    Set Aktif / Non Aktif / Hapus untuk semua baris yang dicentang."""
    db = get_db()
    aksi = request.form.get("aksi", "")
    ids = [i for i in request.form.getlist("ids") if i.isdigit()]
    if not ids:
        flash("Pilih minimal satu Profile Voucher terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_profil_voucher"))

    placeholder = ",".join("?" * len(ids))
    if aksi == "aktifkan":
        db.execute(f"UPDATE hotspot_voucher_profile SET aktif=1 WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"{len(ids)} Profile Voucher diset Aktif.", "success")
    elif aksi == "nonaktifkan":
        db.execute(f"UPDATE hotspot_voucher_profile SET aktif=0 WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"{len(ids)} Profile Voucher diset Non Aktif.", "success")
    elif aksi == "hapus":
        db.execute(f"DELETE FROM hotspot_voucher_profile WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"{len(ids)} Profile Voucher dihapus.", "success")
    else:
        flash("Aksi tidak dikenali.", "danger")
    _catat_aktivitas("hotspot", f"Aksi massal Profile Voucher ({aksi})", f"{len(ids)} data")
    return redirect(url_for("hotspot_profil_voucher"))


@app.route("/hotspot/profil-voucher/hapus/<int:profil_id>", methods=["POST"])
@login_required
def hotspot_profil_voucher_hapus(profil_id):
    db = get_db()
    row = db.execute("SELECT nama_profile FROM hotspot_voucher_profile WHERE id=?", (profil_id,)).fetchone()
    db.execute("DELETE FROM hotspot_voucher_profile WHERE id=?", (profil_id,))
    db.commit()
    if row:
        _catat_aktivitas("hotspot", "Hapus Profile Voucher", row["nama_profile"])
    flash("Profile voucher dihapus.", "success")
    return redirect(url_for("hotspot_profil_voucher"))


@app.route("/hotspot/stok-voucher")
@login_required
def hotspot_stok_voucher():
    db = get_db()
    stok = _hitung_stok_voucher()
    total_sisa = sum(s["sisa"] or 0 for s in stok)
    total_terjual = sum(s["terjual"] or 0 for s in stok)
    total_nilai_stok = sum(s["nilai_stok"] or 0 for s in stok if s["nilai_stok"] is not None)

    # Listing per-voucher (bukan cuma rekap per profile) -- dipakai tabel & toolbar
    # ala menu Stok Voucher RL Radius (filter profile/router/mitra/tanggal, cari, dsb).
    daftar_voucher = db.execute(
        """SELECT v.id, v.username, v.password, v.profile_hotspot, v.batch, v.status,
                  v.dibuat_tanggal, v.harga AS harga_voucher, v.kunci_mac, v.nonaktif,
                  r.nama_router, rs.nama_bisnis AS nama_mitra,
                  hvp.hpp, hvp.komisi, hvp.harga AS harga_profile
           FROM voucher v
           LEFT JOIN router r ON r.id = v.router_id
           LEFT JOIN reseller rs ON rs.id = v.reseller_id
           LEFT JOIN hotspot_voucher_profile hvp ON hvp.nama_profile = v.profile_hotspot
           WHERE v.status = 'belum_terpakai'
           ORDER BY v.dibuat_tanggal DESC, v.id DESC"""
    ).fetchall()
    total_stok = len(daftar_voucher)
    total_hpp = sum((v["hpp"] or 0) for v in daftar_voucher)
    total_komisi = sum((v["komisi"] or 0) for v in daftar_voucher)
    total_harga = sum((v["harga_profile"] if v["harga_profile"] is not None else v["harga_voucher"]) for v in daftar_voucher)

    daftar_profil_hotspot = sorted({v["profile_hotspot"] for v in daftar_voucher})
    daftar_router = db.execute("SELECT id, nama_router FROM router ORDER BY nama_router").fetchall()
    daftar_mitra = db.execute("SELECT id, nama_bisnis FROM reseller ORDER BY nama_bisnis").fetchall()
    daftar_profil_voucher_aktif = db.execute(
        "SELECT id, nama_profile, hpp, komisi, harga FROM hotspot_voucher_profile WHERE aktif=1 ORDER BY nama_profile"
    ).fetchall()
    daftar_server = db.execute("SELECT id, nama FROM server_name_master ORDER BY nama").fetchall()
    daftar_outlet = db.execute(
        """SELECT o.*, rs.nama_bisnis AS nama_mitra,
                  (SELECT COUNT(*) FROM voucher v WHERE v.outlet_id = o.id AND v.status='belum_terpakai') AS stok_vc
           FROM outlet o LEFT JOIN reseller rs ON rs.id = o.reseller_id
           ORDER BY o.tanggal_dibuat DESC"""
    ).fetchall()
    pengaturan_hotspot = db.execute(
        "SELECT nama_hotspot, dns_name_hotspot, logo_hotspot_path, cs_phone_hotspot FROM pengaturan_umum WHERE id=1"
    ).fetchone()

    # Riwayat Pembuatan Voucher (modal "Riwayat") -- direkap per batch, difilter
    # bulan/tahun (default bulan berjalan) + pencarian bebas kode/mitra/outlet.
    riwayat_bulan = request.args.get("riwayat_bulan") or str(date.today().month)
    riwayat_tahun = request.args.get("riwayat_tahun") or str(date.today().year)
    riwayat_cari = request.args.get("riwayat_cari", "").strip()
    riwayat_rows = db.execute(
        """SELECT v.batch, MIN(v.dibuat_tanggal) tgl, rs.nama_bisnis AS nama_mitra, o.nama_outlet,
                  v.profile_hotspot, COUNT(*) qty,
                  SUM(CASE WHEN v.status='belum_terpakai' THEN 1 ELSE 0 END) stok,
                  SUM(CASE WHEN v.status='terpakai' THEN 1 ELSE 0 END) terjual,
                  SUM(COALESCE(v.hpp, hvp.hpp, 0)) total_hpp,
                  SUM(COALESCE(v.komisi, hvp.komisi, 0)) total_komisi,
                  SUM(COALESCE(NULLIF(v.harga, 0), hvp.harga, 0)) total_harga
           FROM voucher v
           LEFT JOIN reseller rs ON rs.id = v.reseller_id
           LEFT JOIN outlet o ON o.id = v.outlet_id
           LEFT JOIN hotspot_voucher_profile hvp ON hvp.nama_profile = v.profile_hotspot
           WHERE strftime('%m', v.dibuat_tanggal) = :bulan AND strftime('%Y', v.dibuat_tanggal) = :tahun
           GROUP BY v.batch ORDER BY tgl DESC""",
        {"bulan": riwayat_bulan.zfill(2), "tahun": riwayat_tahun}
    ).fetchall()
    if riwayat_cari:
        needle = riwayat_cari.lower()
        riwayat_rows = [r for r in riwayat_rows if
                         needle in (r["batch"] or "").lower()
                         or needle in (r["nama_mitra"] or "").lower()
                         or needle in (r["nama_outlet"] or "").lower()]

    return render_template("hotspot_stok_voucher.html", stok=stok, total_sisa=total_sisa,
                            total_terjual=total_terjual, total_nilai_stok=total_nilai_stok,
                            daftar_voucher=daftar_voucher, total_stok=total_stok,
                            total_hpp=total_hpp, total_komisi=total_komisi, total_harga=total_harga,
                            daftar_profil_hotspot=daftar_profil_hotspot,
                            daftar_router=daftar_router, daftar_mitra=daftar_mitra,
                            daftar_profil_voucher_aktif=daftar_profil_voucher_aktif,
                            daftar_server=daftar_server, daftar_outlet=daftar_outlet,
                            pengaturan_hotspot=pengaturan_hotspot,
                            riwayat_rows=riwayat_rows, riwayat_bulan=riwayat_bulan,
                            riwayat_tahun=riwayat_tahun, riwayat_cari=riwayat_cari,
                            buka_modal=request.args.get("buka", ""))


@app.route("/hotspot/stok-voucher/hapus-terpilih", methods=["POST"])
@login_required
def hotspot_stok_voucher_hapus_terpilih():
    """Hapus banyak voucher stok sekaligus -- dipicu dari tombol MENU > Hapus
    di toolbar tabel Stok Voucher, untuk baris-baris yang dicentang saja
    (beda dengan hapus_batch_voucher yang menghapus satu batch penuh)."""
    db = get_db()
    ids = [i for i in request.form.getlist("ids") if i.isdigit()]
    if not ids:
        flash("Pilih minimal satu voucher terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_stok_voucher"))
    client = _get_mikrotik_client()
    placeholder = ",".join("?" * len(ids))
    daftar = db.execute(f"SELECT username FROM voucher WHERE id IN ({placeholder})", ids).fetchall()
    if client:
        for v in daftar:
            try:
                client.remove_hotspot_user(v["username"])
            except Exception:
                pass
    db.execute(f"DELETE FROM voucher WHERE id IN ({placeholder})", ids)
    db.commit()
    _catat_aktivitas("hotspot", "Hapus voucher stok (terpilih)", f"{len(ids)} voucher")
    flash(f"{len(ids)} voucher dihapus.", "success")
    return redirect(url_for("hotspot_stok_voucher"))


@app.route("/hotspot/stok-voucher/bulk", methods=["POST"])
@login_required
def hotspot_stok_voucher_bulk():
    """Aksi massal dari tombol MENU di toolbar Stok Voucher (ala RL Radius):
    Lock MAC / Unlock MAC, Set Aktif / Non Aktif, dan Ganti Router untuk
    baris-baris voucher yang dicentang saja."""
    db = get_db()
    aksi = request.form.get("aksi", "")
    ids = [i for i in request.form.getlist("ids") if i.isdigit()]
    if not ids:
        flash("Pilih minimal satu voucher terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_stok_voucher"))

    placeholder = ",".join("?" * len(ids))
    baris = db.execute(f"SELECT id, username FROM voucher WHERE id IN ({placeholder})", ids).fetchall()

    if aksi == "lock_mac":
        db.execute(f"UPDATE voucher SET kunci_mac=1 WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"{len(baris)} voucher dikunci ke MAC Address pertama yang connect.", "success")

    elif aksi == "unlock_mac":
        db.execute(f"UPDATE voucher SET kunci_mac=0 WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"Kunci MAC {len(baris)} voucher dibuka.", "success")

    elif aksi in ("set_aktif", "non_aktif"):
        nonaktif_baru = 0 if aksi == "set_aktif" else 1
        db.execute(f"UPDATE voucher SET nonaktif=? WHERE id IN ({placeholder})", [nonaktif_baru] + ids)
        db.commit()
        # Best-effort sinkron ke Mikrotik (kalau router lagi online); kalau gagal/offline,
        # status lokal di atas tetap tersimpan supaya bisa disusulkan nanti.
        client = _get_mikrotik_client()
        if client:
            for v in baris:
                try:
                    client.set_hotspot_user_disabled(v["username"], disabled=bool(nonaktif_baru))
                except Exception:
                    pass
        flash(f"{len(baris)} voucher diset {'Non Aktif' if nonaktif_baru else 'Aktif'}.", "success")

    elif aksi == "ganti_router":
        router_id = request.form.get("router_id", "").strip()
        if not router_id.isdigit():
            flash("Pilih router tujuan terlebih dahulu.", "warning")
            return redirect(url_for("hotspot_stok_voucher"))
        db.execute(f"UPDATE voucher SET router_id=? WHERE id IN ({placeholder})", [int(router_id)] + ids)
        db.commit()
        flash(f"{len(baris)} voucher dipindahkan ke router baru.", "success")

    else:
        flash("Aksi tidak dikenali.", "danger")
        return redirect(url_for("hotspot_stok_voucher"))

    _catat_aktivitas("hotspot", f"Aksi massal Stok Voucher ({aksi})", f"{len(baris)} voucher")
    return redirect(url_for("hotspot_stok_voucher"))


@app.route("/hotspot/stok-voucher/sync", methods=["POST"])
@login_required
def hotspot_stok_voucher_sync():
    """Toolbar Stok Voucher > Sync: tarik user hotspot yang sudah ADA di Mikrotik
    (dibuat manual lewat Winbox/WebFig, bukan lewat Buat VC/Buat User SafeNode)
    supaya ikut muncul di tabel Stok Voucher. Username yang sudah tercatat di
    SafeNode tidak diduplikasi -- cuma status Kunci MAC & Non Aktif-nya yang
    disamakan dengan kondisi terkini di Mikrotik."""
    db = get_db()
    router_id_raw = request.form.get("router_id", "").strip()
    if not router_id_raw.isdigit():
        flash("Pilih Router yang mau disinkron terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_stok_voucher"))
    router_id = int(router_id_raw)

    router_row = db.execute("SELECT nama_router FROM router WHERE id=?", (router_id,)).fetchone()
    if not router_row:
        flash("Router tidak ditemukan.", "danger")
        return redirect(url_for("hotspot_stok_voucher"))

    client = _get_mikrotik_client(router_id)
    if not client:
        flash(f"Router '{router_row['nama_router']}' belum diisi host/username Mikrotik-nya.", "danger")
        return redirect(url_for("hotspot_stok_voucher"))

    try:
        daftar_mikrotik = client.get_hotspot_users()
    except Exception as e:
        flash(f"Gagal konek/ambil data dari Mikrotik '{router_row['nama_router']}': {e}", "danger")
        return redirect(url_for("hotspot_stok_voucher"))

    existing_usernames = {row["username"] for row in db.execute("SELECT username FROM voucher").fetchall()}
    hari_ini = date.today().isoformat()
    ditambah = diperbarui = dilewati = 0

    for u in daftar_mikrotik:
        username = (u.get("name") or "").strip()
        if not username:
            continue
        kunci_mac = 1 if (u.get("mac-address") or "").strip() else 0
        nonaktif = 1 if u.get("disabled") == "true" else 0
        profile = u.get("profile") or "default"

        if username in existing_usernames:
            db.execute(
                "UPDATE voucher SET kunci_mac=?, nonaktif=?, router_id=? WHERE username=?",
                (kunci_mac, nonaktif, router_id, username))
            diperbarui += 1
            continue

        try:
            db.execute(
                """INSERT INTO voucher
                   (username, password, profile_hotspot, harga, status, batch, dibuat_tanggal,
                    router_id, kunci_mac, nonaktif, channel)
                   VALUES (?, ?, ?, 0, 'belum_terpakai', ?, ?, ?, ?, ?, 'offline')""",
                (username, u.get("password") or "", profile, "SYNC-" + hari_ini, hari_ini,
                 router_id, kunci_mac, nonaktif))
            existing_usernames.add(username)
            ditambah += 1
        except sqlite3.IntegrityError:
            dilewati += 1

    db.commit()
    _catat_aktivitas("hotspot", "Sync voucher dari Mikrotik", router_row["nama_router"] +
                      f" ({ditambah} baru, {diperbarui} diperbarui, {dilewati} dilewati)")
    pesan = f"Sync dari '{router_row['nama_router']}' selesai: {ditambah} voucher baru, {diperbarui} diperbarui"
    pesan += f", {dilewati} dilewati (bentrok username)." if dilewati else "."
    flash(pesan, "success")
    return redirect(url_for("hotspot_stok_voucher"))


@app.route("/hotspot/stok-voucher/buat-vc", methods=["POST"])
@login_required
def hotspot_stok_voucher_buat_vc():
    """Toolbar Stok Voucher > Buat VC: modal 'Buat Voucher Massal' (generate banyak
    voucher sekaligus, lengkap dengan Mitra/Outlet/Router/Kunci MAC/HPP/Komisi)."""
    db = get_db()
    reseller_id = request.form.get("mitra_id") or None
    potong_saldo = 1 if request.form.get("potong_saldo") == "YES" else 0
    router_id = request.form.get("router_id") or None
    server_id = request.form.get("server_id") or None
    jenis_voucher = request.form.get("jenis_voucher", "username_password")
    kode_kombinasi = request.form.get("kode_kombinasi", "kapital_angka")
    if kode_kombinasi not in ("kapital", "angka", "acak", "kapital_angka"):
        kode_kombinasi = "kapital_angka"
    prefix = (request.form.get("prefix") or "").strip()
    outlet_id = request.form.get("outlet_id") or None
    profile_voucher_id = request.form.get("profile_voucher_id") or None
    jumlah = max(1, min(int(request.form.get("jumlah") or 1), 500))
    panjang_kode = max(4, min(int(request.form.get("panjang_karakter") or 6), 12))
    kunci_mac = 1 if request.form.get("kunci_mac") == "on" else 0
    hpp = int(request.form.get("hpp") or 0)
    harga = int(request.form.get("harga") or 0)
    komisi = int(request.form.get("komisi") or 0)

    profil = db.execute("SELECT * FROM hotspot_voucher_profile WHERE id=?",
                         (profile_voucher_id,)).fetchone() if profile_voucher_id else None
    if not profil:
        flash("Profile wajib dipilih.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="buat_vc"))

    nama_profile = profil["nama_profile"]
    profile_mikrotik = profil["profile_mikrotik"] or nama_profile
    server_row = db.execute("SELECT nama FROM server_name_master WHERE id=?",
                             (server_id,)).fetchone() if server_id else None
    server_name = server_row["nama"] if server_row else None
    client = _get_mikrotik_client(int(router_id)) if router_id else _get_mikrotik_client()

    batch = f"V{datetime.now().strftime('%y%m%d-%H%M%S')}"
    dibuat, gagal = 0, []
    for _ in range(jumlah):
        kode = prefix + _generate_kode(panjang_kode, kode_kombinasi)
        for _percobaan in range(5):
            if not db.execute("SELECT id FROM voucher WHERE username=?", (kode,)).fetchone():
                break
            kode = prefix + _generate_kode(panjang_kode, kode_kombinasi)
        password = kode if jenis_voucher != "username_only" else _generate_kode(panjang_kode, kode_kombinasi)
        if client:
            try:
                client.add_hotspot_user(username=kode, password=password, profile=profile_mikrotik,
                                         comment=f"voucher:{batch}")
            except Exception as e:
                gagal.append(str(e))
                continue
        try:
            db.execute(
                """INSERT INTO voucher (username, password, profile_hotspot, harga, status, batch,
                   dibuat_tanggal, channel, profile_voucher_id, router_id, reseller_id, outlet_id,
                   kunci_mac, server_name, hpp, komisi, potong_saldo_mitra)
                   VALUES (?,?,?,?, 'belum_terpakai', ?, ?, 'offline', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (kode, password, nama_profile, harga, batch, date.today().isoformat(),
                 profile_voucher_id, router_id or None, reseller_id or None, outlet_id or None,
                 kunci_mac, server_name, hpp, komisi, potong_saldo))
            dibuat += 1
        except sqlite3.IntegrityError:
            gagal.append(f"username {kode} sudah ada")

    if potong_saldo and reseller_id and dibuat:
        db.execute("UPDATE reseller SET saldo_deposit = saldo_deposit - ? WHERE id=?", (hpp * dibuat, reseller_id))
    db.commit()

    if dibuat:
        _catat_aktivitas("hotspot", "Buat Voucher Massal", f"{dibuat} voucher (batch {batch})")
        pesan = f"{dibuat} voucher berhasil dibuat (batch {batch})."
        if not client:
            pesan += " Catatan: belum tersinkron ke Mikrotik (pengaturan Mikrotik belum diisi/valid)."
        if gagal:
            pesan += f" {len(gagal)} gagal."
        flash(pesan, "success")
        return redirect(url_for("hotspot_stok_voucher"))
    flash("Tidak ada voucher yang berhasil dibuat." + (f" ({gagal[0]})" if gagal else ""), "danger")
    return redirect(url_for("hotspot_stok_voucher", buka="buat_vc"))


@app.route("/hotspot/stok-voucher/buat-user", methods=["POST"])
@login_required
def hotspot_stok_voucher_buat_user():
    """Toolbar Stok Voucher > Buat User: modal 'Buat User' untuk membuat SATU
    voucher/user hotspot dengan username & password ditentukan manual."""
    db = get_db()
    reseller_id = request.form.get("mitra_id") or None
    potong_saldo = 1 if request.form.get("potong_saldo") == "YES" else 0
    username = (request.form.get("username") or "").strip()
    password = (request.form.get("password") or "").strip()
    router_id = request.form.get("router_id") or None
    server_id = request.form.get("server_id") or None
    kunci_mac = 1 if request.form.get("kunci_mac") == "on" else 0
    outlet_id = request.form.get("outlet_id") or None
    profile_voucher_id = request.form.get("profile_voucher_id") or None
    hpp = int(request.form.get("hpp") or 0)
    harga = int(request.form.get("harga") or 0)
    komisi = int(request.form.get("komisi") or 0)

    if not username or not password:
        flash("Username & Password wajib diisi.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="buat_user"))
    profil = db.execute("SELECT * FROM hotspot_voucher_profile WHERE id=?",
                         (profile_voucher_id,)).fetchone() if profile_voucher_id else None
    if not profil:
        flash("Profile wajib dipilih.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="buat_user"))
    if db.execute("SELECT id FROM voucher WHERE username=?", (username,)).fetchone():
        flash(f"Username '{username}' sudah dipakai.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="buat_user"))

    nama_profile = profil["nama_profile"]
    profile_mikrotik = profil["profile_mikrotik"] or nama_profile
    server_row = db.execute("SELECT nama FROM server_name_master WHERE id=?",
                             (server_id,)).fetchone() if server_id else None
    server_name = server_row["nama"] if server_row else None
    client = _get_mikrotik_client(int(router_id)) if router_id else _get_mikrotik_client()
    if client:
        try:
            client.add_hotspot_user(username=username, password=password, profile=profile_mikrotik,
                                     comment="voucher:manual")
        except Exception as e:
            flash(f"Gagal sinkron ke Mikrotik: {e}", "danger")
            return redirect(url_for("hotspot_stok_voucher", buka="buat_user"))

    db.execute(
        """INSERT INTO voucher (username, password, profile_hotspot, harga, status, batch,
           dibuat_tanggal, channel, profile_voucher_id, router_id, reseller_id, outlet_id,
           kunci_mac, server_name, hpp, komisi, potong_saldo_mitra)
           VALUES (?,?,?,?, 'belum_terpakai', 'MANUAL', ?, 'offline', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (username, password, nama_profile, harga, date.today().isoformat(), profile_voucher_id,
         router_id or None, reseller_id or None, outlet_id or None, kunci_mac, server_name, hpp, komisi, potong_saldo))
    if potong_saldo and reseller_id:
        db.execute("UPDATE reseller SET saldo_deposit = saldo_deposit - ? WHERE id=?", (hpp, reseller_id))
    db.commit()
    _catat_aktivitas("hotspot", "Buat User Voucher", username)
    flash(f"User voucher '{username}' berhasil dibuat.", "success")
    return redirect(url_for("hotspot_stok_voucher"))


@app.route("/hotspot/outlet/simpan", methods=["POST"])
@login_required
def hotspot_outlet_simpan():
    """Toolbar Stok Voucher > Outlet > Tambah: modal 'Data Outlet'."""
    db = get_db()
    reseller_id = request.form.get("mitra_id") or None
    nama_outlet = (request.form.get("nama_outlet") or "").strip()
    pemilik = (request.form.get("pemilik") or "").strip() or None
    phone = (request.form.get("phone") or "").strip() or None
    alamat = (request.form.get("alamat") or "").strip() or None
    if not nama_outlet:
        flash("Nama outlet wajib diisi.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="outlet"))
    db.execute(
        "INSERT INTO outlet (reseller_id, nama_outlet, pemilik, phone, alamat, tanggal_dibuat) VALUES (?,?,?,?,?,?)",
        (reseller_id, nama_outlet, pemilik, phone, alamat, date.today().isoformat()))
    db.commit()
    _catat_aktivitas("hotspot", "Tambah Outlet", nama_outlet)
    flash(f"Outlet '{nama_outlet}' berhasil ditambahkan.", "success")
    return redirect(url_for("hotspot_stok_voucher", buka="outlet"))


@app.route("/hotspot/outlet/hapus/<int:outlet_id>", methods=["POST"])
@login_required
def hotspot_outlet_hapus(outlet_id):
    db = get_db()
    row = db.execute("SELECT nama_outlet FROM outlet WHERE id=?", (outlet_id,)).fetchone()
    db.execute("DELETE FROM outlet WHERE id=?", (outlet_id,))
    db.commit()
    if row:
        _catat_aktivitas("hotspot", "Hapus Outlet", row["nama_outlet"])
    flash("Outlet dihapus.", "success")
    return redirect(url_for("hotspot_stok_voucher", buka="outlet"))


@app.route("/hotspot/setting/simpan", methods=["POST"])
@login_required
def hotspot_setting_simpan():
    """Toolbar Stok Voucher > Setting: modal 'Setting Hotspot'."""
    db = get_db()
    nama_hotspot = (request.form.get("nama_hotspot") or "RL HOTSPOT").strip()
    dns_name = (request.form.get("dns_name_hotspot") or "").strip() or None
    cs_phone = (request.form.get("cs_phone_hotspot") or "").strip() or None
    file = request.files.get("logo_hotspot")

    db.execute("UPDATE pengaturan_umum SET nama_hotspot=?, dns_name_hotspot=?, cs_phone_hotspot=? WHERE id=1",
               (nama_hotspot, dns_name, cs_phone))

    if file and file.filename:
        ekstensi = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
        if ekstensi not in EKSTENSI_LOGO_DIIZINKAN:
            flash("Format logo tidak didukung. Gunakan PNG, JPG, JPEG, WEBP, GIF, atau BMP.", "danger")
            db.commit()
            return redirect(url_for("hotspot_stok_voucher", buka="setting"))
        try:
            gambar = Image.open(file.stream).convert("RGBA")
        except UnidentifiedImageError:
            flash("File yang diupload bukan gambar yang valid.", "danger")
            db.commit()
            return redirect(url_for("hotspot_stok_voucher", buka="setting"))
        row = db.execute("SELECT logo_hotspot_path FROM pengaturan_umum WHERE id=1").fetchone()
        logo_lama = row["logo_hotspot_path"] if row else None
        nama_file = secure_filename(f"logo_hotspot_{secrets.token_hex(6)}.png")
        gambar.save(os.path.join(UPLOAD_FOLDER, nama_file), format="PNG")
        db.execute("UPDATE pengaturan_umum SET logo_hotspot_path=? WHERE id=1", (f"uploads/{nama_file}",))
        if logo_lama:
            path_lama = os.path.join(app.root_path, "static", logo_lama)
            if os.path.isfile(path_lama):
                try:
                    os.remove(path_lama)
                except OSError:
                    pass

    db.commit()
    _catat_aktivitas("hotspot", "Ubah Setting Hotspot", nama_hotspot)
    flash("Setting hotspot berhasil disimpan.", "success")
    return redirect(url_for("hotspot_stok_voucher"))


@app.route("/hotspot/stok-voucher/import", methods=["POST"])
@login_required
def hotspot_stok_voucher_import():
    """Toolbar Stok Voucher > Import: modal 'Import Voucher' (file EXCEL/CSV/TXT/JSON)."""
    db = get_db()
    file = request.files.get("file_import")
    reseller_id = request.form.get("mitra_id") or None
    potong_saldo = 1 if request.form.get("potong_saldo") == "YES" else 0
    router_id = request.form.get("router_id") or None
    server_id = request.form.get("server_id") or None
    outlet_id = request.form.get("outlet_id") or None
    kunci_mac = 1 if request.form.get("kunci_mac") == "YES" else 0
    profile_voucher_id = request.form.get("profile_voucher_id") or None
    hpp = int(request.form.get("hpp") or 0)
    komisi = int(request.form.get("komisi") or 0)
    harga = int(request.form.get("harga") or 0)

    if not file or not file.filename:
        flash("Pilih file untuk diimport.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="import"))
    profil = db.execute("SELECT * FROM hotspot_voucher_profile WHERE id=?",
                         (profile_voucher_id,)).fetchone() if profile_voucher_id else None
    if not profil:
        flash("Profile wajib dipilih.", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="import"))
    nama_profile = profil["nama_profile"]
    profile_mikrotik = profil["profile_mikrotik"] or nama_profile

    ekstensi = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    try:
        isi = file.read().decode("utf-8", errors="ignore")
    except Exception as e:
        flash(f"Gagal membaca file: {e}", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="import"))

    baris_data = []
    try:
        if ekstensi == "json":
            data = json.loads(isi)
            for item in data:
                if isinstance(item, dict):
                    u = str(item.get("username") or item.get("kode") or "").strip()
                    p = str(item.get("password") or u).strip()
                else:
                    u = str(item).strip()
                    p = u
                if u:
                    baris_data.append((u, p))
        else:
            for baris in isi.splitlines():
                baris = baris.strip()
                if not baris:
                    continue
                bagian = [b.strip() for b in re.split(r"[,;\t]", baris)] if ("," in baris or ";" in baris or "\t" in baris) \
                    else baris.split()
                if not bagian or not bagian[0] or bagian[0].lower() in ("username", "kode"):
                    continue
                u = bagian[0]
                p = bagian[1] if len(bagian) > 1 and bagian[1] else u
                baris_data.append((u, p))
    except Exception as e:
        flash(f"Gagal membaca isi file: {e}", "danger")
        return redirect(url_for("hotspot_stok_voucher", buka="import"))

    if not baris_data:
        flash("File tidak berisi data voucher yang valid.", "warning")
        return redirect(url_for("hotspot_stok_voucher", buka="import"))

    server_row = db.execute("SELECT nama FROM server_name_master WHERE id=?",
                             (server_id,)).fetchone() if server_id else None
    server_name = server_row["nama"] if server_row else None
    client = _get_mikrotik_client(int(router_id)) if router_id else _get_mikrotik_client()
    batch = f"IMP{datetime.now().strftime('%y%m%d-%H%M%S')}"
    dibuat, dilewati = 0, 0
    for u, p in baris_data:
        if db.execute("SELECT id FROM voucher WHERE username=?", (u,)).fetchone():
            dilewati += 1
            continue
        if client:
            try:
                client.add_hotspot_user(username=u, password=p, profile=profile_mikrotik,
                                         comment=f"voucher:{batch}")
            except Exception:
                dilewati += 1
                continue
        db.execute(
            """INSERT INTO voucher (username, password, profile_hotspot, harga, status, batch,
               dibuat_tanggal, channel, profile_voucher_id, router_id, reseller_id, outlet_id,
               kunci_mac, server_name, hpp, komisi, potong_saldo_mitra)
               VALUES (?,?,?,?, 'belum_terpakai', ?, ?, 'offline', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (u, p, nama_profile, harga, batch, date.today().isoformat(), profile_voucher_id,
             router_id or None, reseller_id or None, outlet_id or None, kunci_mac, server_name, hpp, komisi, potong_saldo))
        dibuat += 1

    if potong_saldo and reseller_id and dibuat:
        db.execute("UPDATE reseller SET saldo_deposit = saldo_deposit - ? WHERE id=?", (hpp * dibuat, reseller_id))
    db.commit()
    _catat_aktivitas("hotspot", "Import Voucher", f"{dibuat} berhasil, {dilewati} dilewati (batch {batch})")
    flash(f"Import selesai: {dibuat} voucher berhasil dibuat, {dilewati} dilewati (duplikat/gagal).",
          "success" if dibuat else "warning")
    return redirect(url_for("hotspot_stok_voucher"))


@app.route("/hotspot/stok-voucher/import/format")
@login_required
def hotspot_stok_voucher_import_format():
    isi = "username,password\nCONTOH01,CONTOH01\nCONTOH02,CONTOH02\n"
    buf = io.BytesIO(isi.encode("utf-8"))
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="format-import-voucher.csv")


@app.route("/hotspot/stok-voucher/export")
@login_required
def hotspot_stok_voucher_export():
    """Toolbar Stok Voucher > Export: modal 'Export Voucher' (filter Mitra/Outlet/Profile)."""
    db = get_db()
    fmt = request.args.get("format", "csv")
    mitra_id = request.args.get("mitra_id") or None
    outlet_id = request.args.get("outlet_id") or None
    profile_voucher_id = request.args.get("profile_voucher_id") or None

    query = """SELECT v.username, v.password, v.profile_hotspot, v.harga, v.batch, v.dibuat_tanggal,
                      rs.nama_bisnis AS nama_mitra, o.nama_outlet
               FROM voucher v
               LEFT JOIN reseller rs ON rs.id = v.reseller_id
               LEFT JOIN outlet o ON o.id = v.outlet_id
               WHERE v.status='belum_terpakai'"""
    params = []
    if mitra_id:
        query += " AND v.reseller_id = ?"
        params.append(mitra_id)
    if outlet_id:
        query += " AND v.outlet_id = ?"
        params.append(outlet_id)
    if profile_voucher_id:
        query += " AND v.profile_voucher_id = ?"
        params.append(profile_voucher_id)
    daftar = db.execute(query, params).fetchall()

    if fmt == "json":
        data = [dict(r) for r in daftar]
        buf = io.BytesIO(json.dumps(data, indent=2).encode("utf-8"))
        return send_file(buf, mimetype="application/json", as_attachment=True, download_name="export-voucher.json")
    if fmt == "txt":
        baris = [f"{r['username']}:{r['password']}" for r in daftar]
        buf = io.BytesIO("\n".join(baris).encode("utf-8"))
        return send_file(buf, mimetype="text/plain", as_attachment=True, download_name="export-voucher.txt")

    buf_str = io.StringIO()
    penulis = csv.writer(buf_str)
    penulis.writerow(["Username", "Password", "Profile", "Harga", "Mitra", "Outlet", "Batch", "Tanggal"])
    for r in daftar:
        penulis.writerow([r["username"], r["password"], r["profile_hotspot"], r["harga"],
                           r["nama_mitra"] or "", r["nama_outlet"] or "", r["batch"], r["dibuat_tanggal"]])
    buf = io.BytesIO(buf_str.getvalue().encode("utf-8"))
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="export-voucher.csv")


@app.route("/hotspot/stok-voucher/riwayat/hapus-qty0", methods=["POST"])
@login_required
def hotspot_stok_voucher_riwayat_hapus_qty0():
    """Toolbar modal Riwayat > 'Hapus Qty 0': buang batch yang stoknya sudah habis (0)."""
    db = get_db()
    batches = db.execute(
        """SELECT batch FROM voucher GROUP BY batch
           HAVING SUM(CASE WHEN status='belum_terpakai' THEN 1 ELSE 0 END) = 0"""
    ).fetchall()
    if not batches:
        flash("Tidak ada batch dengan stok 0.", "info")
        return redirect(url_for("hotspot_stok_voucher", buka="riwayat"))
    daftar_batch = [b["batch"] for b in batches]
    placeholder = ",".join("?" * len(daftar_batch))
    db.execute(f"DELETE FROM voucher WHERE batch IN ({placeholder})", daftar_batch)
    db.commit()
    _catat_aktivitas("hotspot", "Hapus Riwayat Qty 0", f"{len(daftar_batch)} batch")
    flash(f"{len(daftar_batch)} batch dengan stok 0 berhasil dihapus.", "success")
    return redirect(url_for("hotspot_stok_voucher", buka="riwayat"))


def _sinkronkan_status_voucher_dari_mikrotik():
    """Tandai voucher 'terpakai' berdasarkan pemakaian riil di Mikrotik: kalau user
    hotspot voucher itu sudah pernah dipakai (uptime tercatat > 0 di router), berarti
    voucher itu sudah laku/terjual & dipakai pelanggan -- bukan cuma tergenerate."""
    client = _get_mikrotik_client()
    if not client:
        return 0
    db = get_db()
    try:
        pengguna_mikrotik = {u.get("name"): u for u in client.get_hotspot_users()}
    except Exception:
        return 0

    def _uptime_ke_detik(txt):
        if not txt:
            return 0
        total, angka = 0, ""
        for ch in txt:
            if ch.isdigit():
                angka += ch
            else:
                if not angka:
                    continue
                n = int(angka)
                total += {"w": n * 604800, "d": n * 86400, "h": n * 3600,
                          "m": n * 60, "s": n}.get(ch, 0)
                angka = ""
        return total

    diperbarui = 0
    belum = db.execute("SELECT id, username FROM voucher WHERE status='belum_terpakai'").fetchall()
    for v in belum:
        u = pengguna_mikrotik.get(v["username"])
        if not u:
            continue
        pakai = _uptime_ke_detik(u.get("uptime")) > 0 or int(u.get("bytes-in", 0) or 0) > 0
        if pakai:
            db.execute("UPDATE voucher SET status='terpakai', terpakai_tanggal=? WHERE id=?",
                       (date.today().isoformat(), v["id"]))
            diperbarui += 1
    if diperbarui:
        db.commit()
    return diperbarui


def _sesi_hotspot_aktif_map():
    """Ambil sesi hotspot aktif dari Mikrotik dan kembalikan sebagai dict
    {username: {...}} -- dipakai menu Voucher Online (ala RL Radius) untuk
    menampilkan kolom Interface/Server/IP Address/MAC Addr & tombol Kick User,
    tanpa perlu nyimpen data sesi ke database (selalu live dari router)."""
    client = _get_mikrotik_client()
    if not client:
        return {}
    try:
        peta_interface = {}
        try:
            for s in client.get_hotspot_servers():
                peta_interface[s.get("name", "")] = s.get("interface", "-")
        except Exception:
            pass
        hasil = {}
        for a in client.get_hotspot_active():
            user = a.get("user", "")
            if not user:
                continue
            server = a.get("server", "-")
            hasil[user] = {
                "id": a.get(".id", ""),
                "interface": peta_interface.get(server, server or "-"),
                "server": server,
                "address": a.get("address", "-"),
                "mac_address": a.get("mac-address", "-"),
                "uptime": a.get("uptime", "-"),
            }
        return hasil
    except Exception:
        return {}


def _format_bytes(n):
    """Format angka byte jadi teks ringkas (mis. 1.2 GB) -- dipakai kolom
    Download/Upload di menu Voucher Offline (ala RL Radius)."""
    try:
        n = float(n or 0)
    except (TypeError, ValueError):
        n = 0
    for satuan in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024 or satuan == "TB":
            return f"{n:,.1f} {satuan}" if satuan != "B" else f"{int(n)} {satuan}"
        n /= 1024


def _perbarui_riwayat_sesi_hotspot():
    """Refresh live tiap menu Voucher Online/Offline dibuka: nyimpen jejak sesi
    terakhir tiap voucher (Interface/Server/IP/MAC saat online, total download/
    upload kumulatif, & timestamp terakhir online/offline) berdasarkan data
    Mikrotik saat ini -- dipakai kolom-kolom tambahan ala menu Voucher Offline
    RL Radius. Mikrotik nggak nyimpen histori lengkap (alasan disconnect dsb),
    jadi ini cuma nynapshot kondisi tiap kali menu dibuka/disinkron."""
    client = _get_mikrotik_client()
    if not client:
        return
    db = get_db()
    try:
        sesi_aktif = _sesi_hotspot_aktif_map()
        try:
            pengguna = {u.get("name"): u for u in client.get_hotspot_users()}
        except Exception:
            pengguna = {}
    except Exception:
        return
    if not sesi_aktif and not pengguna:
        return

    sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    baris = db.execute(
        "SELECT id, username, terakhir_online_tanggal, terakhir_offline_tanggal FROM voucher"
    ).fetchall()
    for v in baris:
        u = v["username"]
        sesi = sesi_aktif.get(u)
        info = pengguna.get(u)
        if not sesi and not info:
            continue
        if sesi:
            db.execute(
                """UPDATE voucher SET terakhir_interface=?, terakhir_server=?, terakhir_ip=?,
                       terakhir_mac=?, terakhir_online_tanggal=? WHERE id=?""",
                (sesi["interface"], sesi["server"], sesi["address"], sesi["mac_address"],
                 sekarang, v["id"]))
        elif v["terakhir_online_tanggal"] and not v["terakhir_offline_tanggal"]:
            # Baru terdeteksi offline sejak terakhir kali online tercatat.
            db.execute("UPDATE voucher SET terakhir_offline_tanggal=? WHERE id=?",
                       (sekarang, v["id"]))
        if info:
            # Dari sudut pandang router: bytes-out (router -> client) = Download
            # buat pelanggan, bytes-in (client -> router) = Upload buat pelanggan.
            db.execute(
                "UPDATE voucher SET total_download=?, total_upload=? WHERE id=?",
                (int(info.get("bytes-out", 0) or 0), int(info.get("bytes-in", 0) or 0), v["id"]))
    db.commit()


@app.route("/hotspot/voucher-terjual")
@login_required
def hotspot_voucher_terjual():
    db = get_db()
    # Listing lengkap (bukan cuma username/harga) -- dipakai toolbar & tabel ala
    # menu Voucher Terjual RL Radius (MENU aksi massal, filter profile/router/mitra,
    # kolom Router/Server/Mitra/Outlet/HPP/Komisi/Saldo).
    daftar = db.execute(
        """SELECT v.*, r.nama_router, rs.nama_bisnis AS nama_mitra, rs.saldo_deposit AS saldo_mitra,
                  o.nama_outlet, hvp.hpp AS hpp_profile, hvp.komisi AS komisi_profile
           FROM voucher v
           LEFT JOIN router r ON r.id = v.router_id
           LEFT JOIN reseller rs ON rs.id = v.reseller_id
           LEFT JOIN outlet o ON o.id = v.outlet_id
           LEFT JOIN hotspot_voucher_profile hvp ON hvp.nama_profile = v.profile_hotspot
           WHERE v.status='terpakai'
           ORDER BY v.terpakai_tanggal DESC, v.id DESC LIMIT 500"""
    ).fetchall()
    total_omzet = db.execute("SELECT COALESCE(SUM(harga),0) t FROM voucher WHERE status='terpakai'").fetchone()["t"]
    jumlah_terjual = len(daftar)
    total_bulan_ini = db.execute(
        "SELECT COALESCE(SUM(harga),0) t FROM voucher WHERE status='terpakai' AND strftime('%Y-%m', terpakai_tanggal)=?",
        (date.today().strftime("%Y-%m"),)
    ).fetchone()["t"]
    # Catatan: skema voucher belum menyimpan tanggal expired terpisah (mis. masa
    # aktif voucher hotspot), jadi kartu "Jumlah Expired" belum bisa dihitung
    # sungguhan -- ditampilkan 0 dulu sampai kolom itu ditambahkan.
    jumlah_expired = 0

    daftar_profil_hotspot = sorted({v["profile_hotspot"] for v in daftar})
    daftar_router = db.execute("SELECT id, nama_router FROM router ORDER BY nama_router").fetchall()
    daftar_mitra = db.execute("SELECT id, nama_bisnis FROM reseller ORDER BY nama_bisnis").fetchall()
    daftar_outlet = db.execute("SELECT id, nama_outlet FROM outlet ORDER BY nama_outlet").fetchall()

    return render_template("hotspot_voucher_terjual.html", daftar=daftar, total_omzet=total_omzet,
                            jumlah_terjual=jumlah_terjual, total_bulan_ini=total_bulan_ini,
                            jumlah_expired=jumlah_expired, daftar_profil_hotspot=daftar_profil_hotspot,
                            daftar_router=daftar_router, daftar_mitra=daftar_mitra, daftar_outlet=daftar_outlet)


@app.route("/hotspot/voucher-terjual/sinkron", methods=["POST"])
@login_required
def hotspot_voucher_terjual_sinkron():
    if not _get_mikrotik_client():
        flash("Pengaturan Mikrotik belum diisi, tidak bisa sinkron status pemakaian voucher.", "danger")
        return redirect(url_for("hotspot_voucher_terjual"))
    jumlah = _sinkronkan_status_voucher_dari_mikrotik()
    _catat_aktivitas("hotspot", "Sinkron Voucher Terjual", f"{jumlah} voucher ditandai terpakai")
    flash(f"Sinkron selesai. {jumlah} voucher ditandai terpakai/terjual.", "success")
    return redirect(url_for("hotspot_voucher_terjual"))


@app.route("/hotspot/voucher-terjual/bulk", methods=["POST"])
@login_required
def hotspot_voucher_terjual_bulk():
    """Aksi massal dari tombol MENU di toolbar Voucher Terjual (ala RL Radius):
    Lock MAC / Unlock MAC, Reset Counter, Set Aktif / Non Aktif, dan Refund
    (mengembalikan voucher terjual jadi stok lagi) untuk baris yang dicentang."""
    db = get_db()
    aksi = request.form.get("aksi", "")
    ids = [i for i in request.form.getlist("ids") if i.isdigit()]
    if not ids:
        flash("Pilih minimal satu voucher terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_voucher_terjual"))

    placeholder = ",".join("?" * len(ids))
    baris = db.execute(f"SELECT id, username FROM voucher WHERE id IN ({placeholder})", ids).fetchall()

    if aksi == "lock_mac":
        db.execute(f"UPDATE voucher SET kunci_mac=1 WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"{len(baris)} voucher dikunci ke MAC Address pertama yang connect.", "success")

    elif aksi == "unlock_mac":
        db.execute(f"UPDATE voucher SET kunci_mac=0 WHERE id IN ({placeholder})", ids)
        db.commit()
        flash(f"Kunci MAC {len(baris)} voucher dibuka.", "success")

    elif aksi == "reset_counter":
        client = _get_mikrotik_client()
        berhasil, gagal = 0, 0
        if not client:
            flash("Pengaturan Mikrotik belum diisi, tidak bisa reset counter.", "danger")
            return redirect(url_for("hotspot_voucher_terjual"))
        for v in baris:
            try:
                client.reset_hotspot_user_counters(v["username"])
                berhasil += 1
            except Exception:
                gagal += 1
        pesan = f"Reset counter selesai: {berhasil} berhasil"
        pesan += f", {gagal} gagal (user tidak ditemukan di Mikrotik)." if gagal else "."
        flash(pesan, "success" if berhasil else "danger")

    elif aksi in ("set_aktif", "non_aktif"):
        nonaktif_baru = 0 if aksi == "set_aktif" else 1
        db.execute(f"UPDATE voucher SET nonaktif=? WHERE id IN ({placeholder})", [nonaktif_baru] + ids)
        db.commit()
        client = _get_mikrotik_client()
        if client:
            for v in baris:
                try:
                    client.set_hotspot_user_disabled(v["username"], disabled=bool(nonaktif_baru))
                except Exception:
                    pass
        flash(f"{len(baris)} voucher diset {'Non Aktif' if nonaktif_baru else 'Aktif'}.", "success")

    elif aksi == "refund":
        db.execute(
            f"UPDATE voucher SET status='belum_terpakai', terpakai_tanggal=NULL WHERE id IN ({placeholder}) AND status='terpakai'",
            ids)
        db.commit()
        flash(f"{len(baris)} voucher di-refund, dikembalikan ke Stok Voucher.", "success")

    else:
        flash("Aksi tidak dikenali.", "danger")
        return redirect(url_for("hotspot_voucher_terjual"))

    _catat_aktivitas("hotspot", f"Aksi massal Voucher Terjual ({aksi})", f"{len(baris)} voucher")
    return redirect(url_for("hotspot_voucher_terjual"))


def _query_voucher_terjual_filter(mitra_id=None, outlet_id=None, dari_tanggal=None, sampai_tanggal=None):
    """Helper query bersama untuk Export / Rekap Penjualan / Hapus Voucher Terjual --
    semuanya memfilter voucher status='terpakai' berdasarkan Mitra/Outlet & rentang
    tanggal terpakai (dipakai juga sebagai acuan 'tanggal expired' voucher itu,
    karena skema saat ini belum menyimpan tanggal expired terpisah dari tanggal
    pemakaian voucher hotspot)."""
    db = get_db()
    query = """SELECT v.*, r.nama_router, rs.nama_bisnis AS nama_mitra, o.nama_outlet,
                      hvp.hpp AS hpp_profile, hvp.komisi AS komisi_profile
               FROM voucher v
               LEFT JOIN router r ON r.id = v.router_id
               LEFT JOIN reseller rs ON rs.id = v.reseller_id
               LEFT JOIN outlet o ON o.id = v.outlet_id
               LEFT JOIN hotspot_voucher_profile hvp ON hvp.nama_profile = v.profile_hotspot
               WHERE v.status='terpakai'"""
    params = []
    if mitra_id:
        query += " AND v.reseller_id = ?"
        params.append(mitra_id)
    if outlet_id:
        query += " AND v.outlet_id = ?"
        params.append(outlet_id)
    if dari_tanggal:
        query += " AND v.terpakai_tanggal >= ?"
        params.append(dari_tanggal)
    if sampai_tanggal:
        query += " AND v.terpakai_tanggal <= ?"
        params.append(sampai_tanggal)
    query += " ORDER BY v.terpakai_tanggal DESC, v.id DESC"
    return db.execute(query, params).fetchall()


@app.route("/hotspot/voucher-terjual/export")
@login_required
def hotspot_voucher_terjual_export():
    """Toolbar Voucher Terjual > Export: modal filter Mitra + rentang Tanggal Terpakai."""
    mitra_id = request.args.get("mitra_id") or None
    dari_tanggal = request.args.get("dari_tanggal") or None
    sampai_tanggal = request.args.get("sampai_tanggal") or None
    daftar = _query_voucher_terjual_filter(mitra_id=mitra_id, dari_tanggal=dari_tanggal, sampai_tanggal=sampai_tanggal)

    buf_str = io.StringIO()
    penulis = csv.writer(buf_str)
    penulis.writerow(["Username", "Profile", "Router", "Mitra", "Outlet", "Harga", "Komisi",
                       "Batch", "Tanggal Dibuat", "Tanggal Terpakai"])
    for r in daftar:
        komisi = r["komisi"] if r["komisi"] is not None else r["komisi_profile"]
        penulis.writerow([r["username"], r["profile_hotspot"], r["nama_router"] or "", r["nama_mitra"] or "",
                           r["nama_outlet"] or "", r["harga"], komisi or 0, r["batch"],
                           r["dibuat_tanggal"], r["terpakai_tanggal"] or ""])
    buf = io.BytesIO(buf_str.getvalue().encode("utf-8"))
    _catat_aktivitas("hotspot", "Export Voucher Terjual", f"{len(daftar)} baris")
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="export-voucher-terjual.csv")


@app.route("/hotspot/voucher-terjual/rekap")
@login_required
def hotspot_voucher_terjual_rekap():
    """Toolbar Voucher Terjual > Rekap: modal 'Rekap Penjualan' (Mitra/Outlet/rentang
    tanggal) -> halaman cetak ringkasan (Print / Simpan sebagai PDF lewat browser)."""
    db = get_db()
    mitra_id = request.args.get("mitra_id") or None
    outlet_id = request.args.get("outlet_id") or None
    dari_tanggal = request.args.get("dari_tanggal") or None
    sampai_tanggal = request.args.get("sampai_tanggal") or None
    daftar = _query_voucher_terjual_filter(mitra_id=mitra_id, outlet_id=outlet_id,
                                            dari_tanggal=dari_tanggal, sampai_tanggal=sampai_tanggal)

    total_qty = len(daftar)
    total_omzet = sum(r["harga"] or 0 for r in daftar)
    total_komisi = sum((r["komisi"] if r["komisi"] is not None else (r["komisi_profile"] or 0)) for r in daftar)

    per_profile = {}
    for r in daftar:
        p = per_profile.setdefault(r["profile_hotspot"], {"qty": 0, "omzet": 0})
        p["qty"] += 1
        p["omzet"] += r["harga"] or 0

    nama_mitra_row = db.execute("SELECT nama_bisnis FROM reseller WHERE id=?", (mitra_id,)).fetchone() if mitra_id else None
    nama_outlet_row = db.execute("SELECT nama_outlet FROM outlet WHERE id=?", (outlet_id,)).fetchone() if outlet_id else None
    pengaturan_umum = db.execute("SELECT nama_aplikasi, logo_path FROM pengaturan_umum WHERE id=1").fetchone()

    return render_template("hotspot_voucher_terjual_rekap.html", daftar=daftar, total_qty=total_qty,
                            total_omzet=total_omzet, total_komisi=total_komisi, per_profile=per_profile,
                            nama_mitra=nama_mitra_row["nama_bisnis"] if nama_mitra_row else "Semua Mitra",
                            nama_outlet=nama_outlet_row["nama_outlet"] if nama_outlet_row else "Semua Outlet",
                            dari_tanggal=dari_tanggal, sampai_tanggal=sampai_tanggal,
                            pengaturan_umum=pengaturan_umum)


@app.route("/hotspot/voucher-terjual/laporan")
@login_required
def hotspot_voucher_terjual_laporan():
    """Toolbar Voucher Terjual > Laporan: laporan bulanan (ala RL Radius) -- omzet,
    bagian operator (komisi), harga rata-rata, sell-through, stok menganggur, dan
    perbandingan dengan bulan lalu, plus grafik kumulatif harian."""
    db = get_db()
    bulan = int(request.args.get("bulan") or date.today().month)
    tahun = int(request.args.get("tahun") or date.today().year)
    periode = f"{tahun:04d}-{bulan:02d}"

    daftar_bulan_ini = db.execute(
        "SELECT * FROM voucher WHERE status='terpakai' AND strftime('%Y-%m', terpakai_tanggal)=?",
        (periode,)).fetchall()
    omzet = sum(r["harga"] or 0 for r in daftar_bulan_ini)
    qty = len(daftar_bulan_ini)
    hvp_map = {r["nama_profile"]: r for r in db.execute(
        "SELECT nama_profile, hpp, komisi FROM hotspot_voucher_profile").fetchall()}
    komisi_total = sum((r["komisi"] if r["komisi"] is not None
                         else (hvp_map.get(r["profile_hotspot"], {}).get("komisi") or 0)) for r in daftar_bulan_ini)
    harga_rata = round(omzet / qty) if qty else 0

    dicetak_bulan_ini = db.execute(
        "SELECT COUNT(*) c FROM voucher WHERE strftime('%Y-%m', dibuat_tanggal)=?", (periode,)).fetchone()["c"]
    sell_through = round(qty / dicetak_bulan_ini * 100, 1) if dicetak_bulan_ini else None

    stok_menganggur = db.execute("SELECT COUNT(*) c FROM voucher WHERE status='belum_terpakai'").fetchone()["c"]

    bulan_lalu_dt = date(tahun, bulan, 1) - timedelta(days=1)
    periode_lalu = bulan_lalu_dt.strftime("%Y-%m")
    omzet_lalu = db.execute(
        "SELECT COALESCE(SUM(harga),0) t FROM voucher WHERE status='terpakai' AND strftime('%Y-%m', terpakai_tanggal)=?",
        (periode_lalu,)).fetchone()["t"]
    if omzet_lalu:
        vs_bulan_lalu = round((omzet - omzet_lalu) / omzet_lalu * 100, 1)
    else:
        vs_bulan_lalu = None
    NAMA_BULAN_ID = ["", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
                      "Agustus", "September", "Oktober", "November", "Desember"]
    nama_bulan_lalu = f"{NAMA_BULAN_ID[bulan_lalu_dt.month]} {bulan_lalu_dt.year}"

    jumlah_hari = calendar.monthrange(tahun, bulan)[1]
    per_hari = {h: 0 for h in range(1, jumlah_hari + 1)}
    for r in daftar_bulan_ini:
        try:
            hari = int(r["terpakai_tanggal"][8:10])
            per_hari[hari] = per_hari.get(hari, 0) + (r["harga"] or 0)
        except (TypeError, ValueError, IndexError):
            continue
    kumulatif = []
    total_lari = 0
    for h in range(1, jumlah_hari + 1):
        total_lari += per_hari.get(h, 0)
        kumulatif.append(total_lari)

    return render_template("hotspot_voucher_terjual_laporan.html", bulan=bulan, tahun=tahun,
                            nama_bulan=NAMA_BULAN_ID[bulan], omzet=omzet, qty=qty, komisi_total=komisi_total,
                            harga_rata=harga_rata, sell_through=sell_through, dicetak_bulan_ini=dicetak_bulan_ini,
                            stok_menganggur=stok_menganggur, vs_bulan_lalu=vs_bulan_lalu,
                            nama_bulan_lalu=nama_bulan_lalu, jumlah_hari=jumlah_hari,
                            label_hari=list(range(1, jumlah_hari + 1)), data_kumulatif=kumulatif,
                            data_harian=[per_hari.get(h, 0) for h in range(1, jumlah_hari + 1)])


@app.route("/hotspot/voucher-terjual/hapus-expired", methods=["POST"])
@login_required
def hotspot_voucher_terjual_hapus_expired():
    """Toolbar Voucher Terjual > Hapus: modal 'Hapus Voucher Expired' (Mitra/Outlet/
    rentang tanggal) -- hapus permanen baris voucher terjual yang cocok. Dipakai
    untuk beres-beres riwayat voucher terjual yang sudah lama/kadaluarsa."""
    db = get_db()
    mitra_id = request.form.get("mitra_id") or None
    outlet_id = request.form.get("outlet_id") or None
    dari_tanggal = request.form.get("dari_tanggal") or None
    sampai_tanggal = request.form.get("sampai_tanggal") or None

    if not dari_tanggal or not sampai_tanggal:
        flash("Isi rentang tanggal terlebih dahulu sebelum menghapus.", "warning")
        return redirect(url_for("hotspot_voucher_terjual"))

    query = "SELECT id FROM voucher WHERE status='terpakai' AND terpakai_tanggal >= ? AND terpakai_tanggal <= ?"
    params = [dari_tanggal, sampai_tanggal]
    if mitra_id:
        query += " AND reseller_id = ?"
        params.append(mitra_id)
    if outlet_id:
        query += " AND outlet_id = ?"
        params.append(outlet_id)
    ids = [row["id"] for row in db.execute(query, params).fetchall()]

    if not ids:
        flash("Tidak ada voucher terjual yang cocok dengan filter tersebut.", "warning")
        return redirect(url_for("hotspot_voucher_terjual"))

    placeholder = ",".join("?" * len(ids))
    db.execute(f"DELETE FROM voucher WHERE id IN ({placeholder})", ids)
    db.commit()
    _catat_aktivitas("hotspot", "Hapus Voucher Terjual (Expired)", f"{len(ids)} voucher")
    flash(f"{len(ids)} voucher terjual berhasil dihapus.", "success")
    return redirect(url_for("hotspot_voucher_terjual"))


def _daftar_voucher_per_channel(channel):
    db = get_db()
    daftar = db.execute(
        """SELECT v.*, r.nama_router FROM voucher v
           LEFT JOIN router r ON r.id = v.router_id
           WHERE v.channel=? ORDER BY v.id DESC LIMIT 500""", (channel,)).fetchall()
    total = db.execute("SELECT COUNT(*) c FROM voucher WHERE channel=?", (channel,)).fetchone()["c"]
    sisa = db.execute("SELECT COUNT(*) c FROM voucher WHERE channel=? AND status='belum_terpakai'",
                       (channel,)).fetchone()["c"]
    return daftar, total, sisa


@app.route("/hotspot/voucher-online")
@login_required
def hotspot_voucher_online():
    _perbarui_riwayat_sesi_hotspot()
    daftar, total, sisa = _daftar_voucher_per_channel("online")
    sesi_aktif = _sesi_hotspot_aktif_map()
    return render_template("hotspot_voucher_channel.html", daftar=daftar, total=total, sisa=sisa,
                            channel="online", judul="Voucher Online",
                            keterangan="Voucher yang dibuat/dijual lewat kanal online (mis. self-service, marketplace, atau digenerate dengan channel Online).",
                            sesi_aktif=sesi_aktif, format_bytes=_format_bytes)


@app.route("/hotspot/voucher-online/kick", methods=["POST"])
@login_required
def hotspot_voucher_online_kick():
    """Toolbar Voucher Online > Kick User (ala RL Radius): putuskan sesi hotspot
    aktif untuk voucher-voucher yang dicentang di tabel."""
    usernames = [u for u in request.form.getlist("usernames") if u]
    if not usernames:
        flash("Pilih minimal satu voucher terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_voucher_online"))

    client = _get_mikrotik_client()
    if not client:
        flash("Pengaturan Mikrotik belum diisi, tidak bisa kick user.", "danger")
        return redirect(url_for("hotspot_voucher_online"))

    sesi_aktif = _sesi_hotspot_aktif_map()
    berhasil, tidak_online = 0, 0
    for u in usernames:
        sesi = sesi_aktif.get(u)
        if not sesi or not sesi.get("id"):
            tidak_online += 1
            continue
        try:
            client.kick_hotspot_active(sesi["id"])
            berhasil += 1
        except Exception:
            tidak_online += 1

    _catat_aktivitas("hotspot", "Kick User Voucher Online", f"{berhasil} sesi diputus")
    pesan = f"{berhasil} user berhasil di-kick."
    if tidak_online:
        pesan += f" {tidak_online} user tidak sedang online/gagal diputus."
    flash(pesan, "success" if berhasil else "warning")
    return redirect(url_for("hotspot_voucher_online"))


@app.route("/hotspot/voucher-online/hapus", methods=["POST"])
@login_required
def hotspot_voucher_online_hapus():
    """Toolbar Voucher Online > Hapus (ala RL Radius): hapus permanen voucher
    channel online yang dicentang di tabel."""
    ids = [i for i in request.form.getlist("ids") if i.isdigit()]
    if not ids:
        flash("Pilih minimal satu voucher terlebih dahulu.", "warning")
        return redirect(url_for("hotspot_voucher_online"))

    db = get_db()
    placeholder = ",".join("?" * len(ids))
    # Dibatasi channel='online' supaya tombol Hapus di menu ini nggak bisa
    # kepakai buat ngehapus voucher channel lain.
    baris = db.execute(
        f"SELECT id FROM voucher WHERE id IN ({placeholder}) AND channel='online'", ids).fetchall()
    if not baris:
        flash("Voucher yang dipilih tidak ditemukan di channel Online.", "warning")
        return redirect(url_for("hotspot_voucher_online"))
    ids_valid = [str(b["id"]) for b in baris]
    placeholder_valid = ",".join("?" * len(ids_valid))
    db.execute(f"DELETE FROM voucher WHERE id IN ({placeholder_valid})", ids_valid)
    db.commit()
    _catat_aktivitas("hotspot", "Hapus Voucher Online", f"{len(ids_valid)} voucher")
    flash(f"{len(ids_valid)} voucher online berhasil dihapus.", "success")
    return redirect(url_for("hotspot_voucher_online"))


@app.route("/hotspot/voucher-online/sinkron", methods=["POST"])
@login_required
def hotspot_voucher_online_sinkron():
    """Toolbar Voucher Online > Sinkronkan (ala RL Radius): sinkron ulang data
    sesi dengan Mikrotik -- menandai voucher yang sudah dipakai & me-refresh
    kolom Interface/Server/IP Address/MAC Addr dari sesi aktif router."""
    if not _get_mikrotik_client():
        flash("Pengaturan Mikrotik belum diisi, tidak bisa sinkron data session.", "danger")
        return redirect(url_for("hotspot_voucher_online"))
    jumlah = _sinkronkan_status_voucher_dari_mikrotik()
    _perbarui_riwayat_sesi_hotspot()
    _catat_aktivitas("hotspot", "Sinkron Voucher Online", f"{jumlah} voucher ditandai terpakai")
    flash(f"Sinkron data session selesai. {jumlah} voucher ditandai terpakai.", "success")
    return redirect(url_for("hotspot_voucher_online"))


@app.route("/hotspot/voucher-offline")
@login_required
def hotspot_voucher_offline():
    _perbarui_riwayat_sesi_hotspot()
    daftar, total, sisa = _daftar_voucher_per_channel("offline")
    return render_template("hotspot_voucher_channel.html", daftar=daftar, total=total, sisa=sisa,
                            channel="offline", judul="Voucher Offline",
                            keterangan="Voucher yang dicetak & dijual manual di loket/kasir (default untuk voucher yang digenerate tanpa memilih kanal Online).",
                            format_bytes=_format_bytes)


DAFTAR_TEMPLATE_VOUCHER = [
    {"kode": "klasik", "nama": "Klasik (Barcode)",
     "deskripsi": "Desain sederhana hitam-putih dengan barcode, hemat tinta untuk cetak massal."},
    {"kode": "bizfiber", "nama": "Tiket Kupon (QR)",
     "deskripsi": "Gaya tiket kupon berwarna dengan kode QR, tampilan paling umum dipakai."},
    {"kode": "gradient", "nama": "Gradient Modern (QR)",
     "deskripsi": "Latar gradasi warna modern dengan kode QR, cocok untuk branding yang lebih fresh."},
    {"kode": "garis", "nama": "Garis Minimalis (QR)",
     "deskripsi": "Desain minimalis bergaris dengan kode QR, tampilan bersih & profesional."},
]

# Daftar tag placeholder yang boleh dipakai di editor Template Voucher Kustom
# (menu Hotspot > Template, bagian "Editor Template (Kode HTML)"). Ditampilkan
# apa adanya ke admin di sidebar "# DAFTAR PARAMETER".
DAFTAR_PARAMETER_TEMPLATE_VOUCHER_CUSTOM = [
    ("#username#", "Username voucher"),
    ("#password#", "Password voucher"),
    ("#profile#", "Nama profile hotspot"),
    ("#harga#", "Harga jual voucher"),
    ("#durasi#", "Durasi (dari Profile Voucher)"),
    ("#kuota#", "Kuota (dari Profile Voucher)"),
    ("#color#", "Warna profile voucher"),
    ("#dns#", "DNS Name hotspot"),
    ("#hsname#", "Nama hotspot"),
    ("#logo#", "Logo hotspot (URL gambar)"),
    ("#printdate#", "Tanggal cetak"),
    ("#printtime#", "Jam cetak"),
    ("#mitra#", "Nama aplikasi / mitra"),
    ("#outlet#", "Nama outlet"),
    ("#nomor#", "Nomor urut voucher di halaman"),
    ("#kode#", "Kode batch pembuatan"),
    ("#mitraphone#", "Nomor HP mitra"),
    ("#csphone#", "Nomor HP CS"),
    ("#kodevoucher#", "Kode voucher besar (1 baris)"),
    ("#usernamepassword#", "Format \"U : username / P : password\" (1 baris)"),
]

# Contoh bawaan "EXAMPLE" untuk editor Template Voucher Kustom -- dipakai sebagai
# titik awal supaya admin tinggal ADA isinya, tinggal TAMBAH/UPDATE sesuai selera
# (mirip struktur HEADER/ROW/FOOTER di menu Template Voucher RL Radius).
_TEMPLATE_VOUCHER_CUSTOM_CONTOH_HEADER = """<!DOCTYPE html>
<html>
<head>
<title>PRINT VOUCHER</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="pragma" content="no-cache" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
<style>
body { color:#000; background-color:#FFFFFF; font-family:Tahoma,Arial,sans-serif; margin:10px; }
.lembar { display:flex; flex-wrap:wrap; }
</style>
</head>
<body>
<div class="lembar">"""

_TEMPLATE_VOUCHER_CUSTOM_CONTOH_ROW = """<table style="display:inline-block; border:1px solid #666; margin:2px; width:180px; overflow:hidden;">
<thead>
<tr style="border-bottom:1px solid #color#;">
<th valign="top" style="width:60%; text-align:left; padding:3px;">
<img style="height:16px;" src="#logo#">
</th>
<th valign="top" style="width:40%; text-align:right; padding:3px;">
<div style="font-weight:bold; font-family:Tahoma; font-size:12px;">#hsname#</div>
</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="2" valign="top" style="padding:4px; color:#000;">
<div style="margin:2px 0;">
<div style="font-weight:bold; font-size:16px; color:#color#;">#kodevoucher#</div>
<div style="font-weight:bold; font-size:11px; color:#color#;">#usernamepassword#</div>
</div>
<div style="text-align:left; font-size:8px; margin:2px 0 0;">
<b>#profile#</b><br>
Harga : Rp #harga#<br>
Durasi : #durasi# | Kuota : #kuota#<br>
DNS : #dns#<br>
CS : #csphone#
</div>
</td>
</tr>
</tbody>
</table>"""

_TEMPLATE_VOUCHER_CUSTOM_CONTOH_FOOTER = """</div>
</body>
</html>"""


def _daftar_template_voucher_custom():
    db = get_db()
    return db.execute("SELECT * FROM template_voucher_custom ORDER BY nama COLLATE NOCASE").fetchall()


def _slugify_kode_template(nama):
    kode = re.sub(r"[^a-z0-9]+", "-", (nama or "").strip().lower()).strip("-")
    return kode or "template"


def _substitusi_placeholder_template(teks, mapping):
    if not teks:
        return ""
    hasil = teks
    for tag, nilai in mapping.items():
        hasil = hasil.replace(tag, "" if nilai is None else str(nilai))
    return hasil


def _konteks_global_template_voucher_custom(batch=""):
    db = get_db()
    pengaturan = db.execute(
        "SELECT nama_aplikasi, telepon, nama_hotspot, dns_name_hotspot, logo_hotspot_path, "
        "cs_phone_hotspot FROM pengaturan_umum WHERE id=1").fetchone()
    logo_url = ""
    if pengaturan and pengaturan["logo_hotspot_path"]:
        logo_url = url_for("static", filename=pengaturan["logo_hotspot_path"])
    sekarang = datetime.now()
    return {
        "#hsname#": (pengaturan["nama_hotspot"] if pengaturan else "") or "",
        "#dns#": (pengaturan["dns_name_hotspot"] if pengaturan else "") or "",
        "#logo#": logo_url,
        "#mitra#": (pengaturan["nama_aplikasi"] if pengaturan else "") or "",
        "#mitraphone#": (pengaturan["telepon"] if pengaturan else "") or "",
        "#csphone#": (pengaturan["cs_phone_hotspot"] if pengaturan else "") or "",
        "#outlet#": "-",
        "#printdate#": sekarang.strftime("%d/%m/%Y"),
        "#printtime#": sekarang.strftime("%H:%M"),
        "#kode#": batch,
    }


def _render_template_voucher_custom(tpl, daftar_voucher, batch=""):
    """Gabungkan header_html + row_html (diulang per voucher, placeholder diganti
    data asli) + footer_html jadi satu halaman HTML utuh, siap dicetak/dipratinjau."""
    db = get_db()
    ctx_global = _konteks_global_template_voucher_custom(batch)
    baris_html = []
    for i, v in enumerate(daftar_voucher, start=1):
        durasi, kuota, warna = "-", "-", warna_voucher(v["harga"])["utama"]
        if v["profile_voucher_id"]:
            profil = db.execute(
                "SELECT durasi, kuota, warna FROM hotspot_voucher_profile WHERE id=?",
                (v["profile_voucher_id"],)).fetchone()
            if profil:
                durasi = profil["durasi"] or "-"
                kuota = profil["kuota"] or "-"
                warna = profil["warna"] or warna
        mapping = dict(ctx_global)
        mapping.update({
            "#nomor#": i,
            "#username#": v["username"],
            "#password#": v["password"],
            "#profile#": v["profile_hotspot"],
            "#harga#": "{:,}".format(v["harga"]).replace(",", "."),
            "#durasi#": durasi,
            "#kuota#": kuota,
            "#color#": warna,
            "#kodevoucher#": v["username"],
            "#usernamepassword#": f"U : {v['username']} / P : {v['password']}",
        })
        baris_html.append(_substitusi_placeholder_template(tpl["row_html"], mapping))
    header = _substitusi_placeholder_template(tpl["header_html"], ctx_global)
    footer = _substitusi_placeholder_template(tpl["footer_html"], ctx_global)
    return header + "\n" + "\n".join(baris_html) + "\n" + footer


@app.route("/hotspot/template")
@login_required
def hotspot_template_voucher():
    db = get_db()
    default_saat_ini = db.execute(
        "SELECT voucher_desain_default FROM pengaturan_umum WHERE id=1").fetchone()
    default_saat_ini = default_saat_ini["voucher_desain_default"] if default_saat_ini else "bizfiber"
    daftar_template_custom = _daftar_template_voucher_custom()
    return render_template("hotspot_template_voucher.html", daftar_template=DAFTAR_TEMPLATE_VOUCHER,
                            daftar_template_custom=daftar_template_custom,
                            daftar_parameter=DAFTAR_PARAMETER_TEMPLATE_VOUCHER_CUSTOM,
                            default_saat_ini=default_saat_ini)


@app.route("/hotspot/template/simpan", methods=["POST"])
@login_required
def hotspot_template_voucher_simpan():
    kode = request.form.get("desain", "bizfiber").strip()
    kode_valid = {t["kode"] for t in DAFTAR_TEMPLATE_VOUCHER} | {t["kode"] for t in _daftar_template_voucher_custom()}
    if kode not in kode_valid:
        kode = "bizfiber"
    db = get_db()
    db.execute("UPDATE pengaturan_umum SET voucher_desain_default=? WHERE id=1", (kode,))
    db.commit()
    _catat_aktivitas("hotspot", "Ubah Template Voucher Default", kode)
    flash("Template voucher default berhasil diperbarui.", "success")
    return redirect(url_for("hotspot_template_voucher"))


@app.route("/hotspot/template/custom/simpan", methods=["POST"])
@login_required
def hotspot_template_voucher_custom_simpan():
    """TAMBAH (id kosong) atau UPDATE (id terisi) template kustom dari editor
    kode HTML (HEADER/ROW/FOOTER) di menu Hotspot > Template."""
    db = get_db()
    id_template = (request.form.get("id") or "").strip()
    nama = (request.form.get("nama") or "").strip()
    header_html = request.form.get("header_html") or ""
    row_html = request.form.get("row_html") or ""
    footer_html = request.form.get("footer_html") or ""

    if not nama:
        flash("Nama template wajib diisi.", "danger")
        return redirect(url_for("hotspot_template_voucher"))
    if not row_html.strip():
        flash("Bagian ROW template tidak boleh kosong (dipakai berulang per voucher).", "danger")
        return redirect(url_for("hotspot_template_voucher"))

    if id_template:
        baris = db.execute("SELECT * FROM template_voucher_custom WHERE id=?", (id_template,)).fetchone()
        if not baris:
            flash("Template kustom tidak ditemukan.", "danger")
            return redirect(url_for("hotspot_template_voucher"))
        db.execute(
            "UPDATE template_voucher_custom SET nama=?, header_html=?, row_html=?, footer_html=? WHERE id=?",
            (nama, header_html, row_html, footer_html, id_template))
        db.commit()
        _catat_aktivitas("hotspot", "Update Template Voucher Kustom", nama)
        flash(f'Template "{nama}" berhasil diperbarui.', "success")
    else:
        kode = _slugify_kode_template(nama)
        kode_asli, urutan = kode, 2
        while db.execute("SELECT id FROM template_voucher_custom WHERE kode=?", (kode,)).fetchone():
            kode = f"{kode_asli}-{urutan}"
            urutan += 1
        db.execute(
            """INSERT INTO template_voucher_custom (kode, nama, header_html, row_html, footer_html, dibuat_tanggal)
               VALUES (?,?,?,?,?,?)""",
            (kode, nama, header_html, row_html, footer_html, date.today().isoformat()))
        db.commit()
        _catat_aktivitas("hotspot", "Tambah Template Voucher Kustom", nama)
        flash(f'Template "{nama}" berhasil ditambahkan.', "success")
    return redirect(url_for("hotspot_template_voucher"))


@app.route("/hotspot/template/custom/hapus/<int:id_template>", methods=["POST"])
@login_required
def hotspot_template_voucher_custom_hapus(id_template):
    db = get_db()
    baris = db.execute("SELECT * FROM template_voucher_custom WHERE id=?", (id_template,)).fetchone()
    if not baris:
        flash("Template kustom tidak ditemukan.", "danger")
        return redirect(url_for("hotspot_template_voucher"))
    db.execute("DELETE FROM template_voucher_custom WHERE id=?", (id_template,))
    default_saat_ini = db.execute("SELECT voucher_desain_default FROM pengaturan_umum WHERE id=1").fetchone()
    if default_saat_ini and default_saat_ini["voucher_desain_default"] == baris["kode"]:
        db.execute("UPDATE pengaturan_umum SET voucher_desain_default='bizfiber' WHERE id=1")
    db.commit()
    _catat_aktivitas("hotspot", "Hapus Template Voucher Kustom", baris["nama"])
    flash(f'Template "{baris["nama"]}" berhasil dihapus.', "success")
    return redirect(url_for("hotspot_template_voucher"))


@app.route("/hotspot/template/preview/<kode>")
@login_required
def hotspot_template_voucher_preview(kode):
    """PREVIEW untuk desain bawaan (Klasik/Tiket Kupon/Gradient Modern/Garis Minimalis):
    render 6 contoh voucher dummy pakai desain aslinya (cetak_voucher.html), tanpa perlu
    generate voucher asli dulu -- sama seperti tombol Pratinjau di template kustom.
    Dropdown "Desain Voucher" di halaman ini tetap bisa dipakai ganti-ganti pratinjau
    (baca override dari query string ?desain=...)."""
    db = get_db()
    desain = request.args.get("desain") or kode
    contoh = [
        {"username": f"A1B2C{i}", "password": f"A1B2C{i}", "profile_hotspot": "1 Hari 5Mbps",
         "harga": 3000 * i, "profile_voucher_id": None}
        for i in range(1, 7)
    ]
    tpl_custom = db.execute("SELECT * FROM template_voucher_custom WHERE kode=?", (desain,)).fetchone()
    if tpl_custom:
        html = _render_template_voucher_custom(tpl_custom, contoh, batch="PRATINJAU")
        return Response(html, mimetype="text/html")
    if desain not in {t["kode"] for t in DAFTAR_TEMPLATE_VOUCHER}:
        flash("Desain tidak ditemukan.", "danger")
        return redirect(url_for("hotspot_template_voucher"))
    return render_template("cetak_voucher.html", daftar=contoh, batch="PRATINJAU", desain=desain,
                            daftar_template_custom=_daftar_template_voucher_custom())


@app.route("/hotspot/template/custom/preview/<int:id_template>")
@login_required
def hotspot_template_voucher_custom_preview(id_template):
    """PREVIEW: render 6 contoh voucher dummy pakai HEADER/ROW/FOOTER template ini,
    supaya admin bisa lihat hasilnya tanpa harus generate voucher asli dulu."""
    db = get_db()
    tpl = db.execute("SELECT * FROM template_voucher_custom WHERE id=?", (id_template,)).fetchone()
    if not tpl:
        flash("Template kustom tidak ditemukan.", "danger")
        return redirect(url_for("hotspot_template_voucher"))
    contoh = [
        {"username": f"CONTOH{i}", "password": f"CONTOH{i}", "profile_hotspot": "1 Hari 5Mbps",
         "harga": 5000 * i, "profile_voucher_id": None}
        for i in range(1, 7)
    ]
    html = _render_template_voucher_custom(tpl, contoh, batch="PRATINJAU")
    return Response(html, mimetype="text/html")


@app.route("/hotspot/generate", methods=["POST"])
@login_required
def generate_voucher():
    db = get_db()
    jumlah = int(request.form.get("jumlah", 1))
    jumlah = max(1, min(jumlah, 200))  # batasi 1-200 sekali generate
    profile = request.form["profile_hotspot"].strip()
    harga = int(request.form.get("harga") or 0)
    panjang_kode = int(request.form.get("panjang_kode") or 6)
    panjang_kode = max(4, min(panjang_kode, 12))
    format_kode = request.form.get("format_kode", "kapital_angka").strip()
    if format_kode not in ("kapital", "angka", "acak", "kapital_angka"):
        format_kode = "kapital_angka"
    channel = request.form.get("channel", "offline").strip()
    if channel not in ("online", "offline"):
        channel = "offline"
    profile_voucher_id = request.form.get("profile_voucher_id") or None

    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi. Buka menu Pengaturan Mikrotik."), 400

    batch = f"V{datetime.now().strftime('%y%m%d-%H%M%S')}"
    dibuat = 0
    gagal = []

    for _ in range(jumlah):
        kode = _generate_kode(panjang_kode, format_kode)
        # pastikan unik di database lokal
        for _percobaan in range(5):
            bentrok = db.execute("SELECT id FROM voucher WHERE username=?", (kode,)).fetchone()
            if not bentrok:
                break
            kode = _generate_kode(panjang_kode, format_kode)

        try:
            client.add_hotspot_user(username=kode, password=kode, profile=profile,
                                     comment=f"voucher:{batch}")
            db.execute(
                """INSERT INTO voucher (username, password, profile_hotspot, harga, status, batch,
                   dibuat_tanggal, channel, profile_voucher_id)
                   VALUES (?,?,?,?, 'belum_terpakai', ?, ?, ?, ?)""",
                (kode, kode, profile, harga, batch, date.today().isoformat(), channel, profile_voucher_id))
            dibuat += 1
        except RouterOSError as e:
            gagal.append(str(e))
        except Exception as e:
            gagal.append(str(e))

    db.commit()
    if dibuat:
        _catat_aktivitas("hotspot", "Generate Voucher", f"{dibuat} voucher (batch {batch})")

    pesan = f"{dibuat} voucher berhasil dibuat & disinkron ke Mikrotik (batch {batch})."
    if gagal:
        pesan += f" {len(gagal)} gagal: {gagal[0]}"
    return jsonify(ok=dibuat > 0, message=pesan, batch=batch)


@app.route("/hotspot/cetak/<batch>")
@login_required
def cetak_voucher(batch):
    db = get_db()
    # COLLATE NOCASE: jaga-jaga kalau kode batch di tautan/tombol Print kebetulan
    # beda kapitalisasi dari batch asli tersimpan (mis. dari data-kode yang sengaja
    # dibikin huruf kecil di tabel Stok Voucher untuk keperluan cari/urut) --
    # supaya halaman cetak tidak tampil putih kosong hanya gara-gara beda huruf besar/kecil.
    daftar = db.execute(
        "SELECT * FROM voucher WHERE batch=? COLLATE NOCASE ORDER BY id", (batch,)).fetchall()
    desain = request.args.get("desain") or _template_voucher_default()
    tpl_custom = db.execute("SELECT * FROM template_voucher_custom WHERE kode=?", (desain,)).fetchone()
    if tpl_custom:
        html = _render_template_voucher_custom(tpl_custom, daftar, batch=batch)
        return Response(html, mimetype="text/html")
    return render_template("cetak_voucher.html", daftar=daftar, batch=batch, desain=desain,
                            daftar_template_custom=_daftar_template_voucher_custom())


@app.route("/hotspot/cetak-cepat/<batch>")
@login_required
def cetak_voucher_cepat(batch):
    """Versi 'Quick Print': satu voucher ditampilkan besar & langsung memicu dialog
    cetak otomatis -- dipakai kasir untuk cetak cepat 1 voucher ke pelanggan walk-in
    (lebih ringkas dibanding halaman Cetak biasa yang berisi grid banyak voucher)."""
    db = get_db()
    daftar = db.execute(
        "SELECT * FROM voucher WHERE batch=? COLLATE NOCASE ORDER BY id", (batch,)).fetchall()
    if not daftar:
        flash("Voucher tidak ditemukan.", "danger")
        return redirect(url_for("hotspot"))
    desain = request.args.get("desain") or _template_voucher_default()
    tpl_custom = db.execute("SELECT * FROM template_voucher_custom WHERE kode=?", (desain,)).fetchone()
    if tpl_custom:
        html = _render_template_voucher_custom(tpl_custom, daftar, batch=batch)
        return Response(html, mimetype="text/html")
    return render_template("cetak_voucher_cepat.html", daftar=daftar, batch=batch, desain=desain,
                            daftar_template_custom=_daftar_template_voucher_custom())


@app.route("/hotspot/hapus-batch/<batch>", methods=["POST"])
@login_required
def hapus_batch_voucher(batch):
    db = get_db()
    daftar = db.execute("SELECT * FROM voucher WHERE batch=?", (batch,)).fetchall()
    client = _get_mikrotik_client()
    dihapus = 0
    for v in daftar:
        if client:
            try:
                client.remove_hotspot_user(v["username"])
            except Exception:
                pass
        db.execute("DELETE FROM voucher WHERE id=?", (v["id"],))
        dihapus += 1
    db.commit()
    if dihapus:
        _catat_aktivitas("hotspot", "Hapus Batch Voucher", f"{dihapus} voucher (batch {batch})")
    flash(f"{dihapus} voucher pada batch {batch} dihapus (termasuk dari Mikrotik).", "success")
    return redirect(url_for("hotspot"))


@app.route("/api/mikrotik/client-aktif")
@login_required
def api_client_aktif():
    """Gabungan sesi aktif PPPoE + Hotspot untuk ditampilkan di Dashboard.
    Terima parameter opsional ?router_id=X supaya bisa dipakai juga untuk
    memantau pelanggan aktif per router tertentu dari menu Router/POP."""
    router_id = request.args.get("router_id", type=int)
    client = _get_mikrotik_client(router_id)
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.", data=[], total=0)
    try:
        db = get_db()
        peta_pelanggan = {
            row["username_pppoe"]: row["nama"]
            for row in db.execute("SELECT username_pppoe, nama FROM pelanggan").fetchall()
        }
        hasil = []
        try:
            for a in client.get_active_connections():
                username = a.get("name", "")
                hasil.append({
                    "tipe": "PPPoE",
                    "username": username,
                    "nama_billing": peta_pelanggan.get(username, "-"),
                    "address": a.get("address", "-"),
                    "uptime": a.get("uptime", "-"),
                })
        except RouterOSError:
            pass
        try:
            for a in client.get_hotspot_active():
                hasil.append({
                    "tipe": "Hotspot",
                    "username": a.get("user", "-"),
                    "nama_billing": "-",
                    "address": a.get("address", "-"),
                    "uptime": a.get("uptime", "-"),
                })
        except RouterOSError:
            pass
        return jsonify(ok=True, data=hasil, total=len(hasil))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[], total=0)


@app.route("/api/pelanggan/ringkasan")
@login_required
def api_pelanggan_ringkasan():
    """Ringkasan jumlah pelanggan aktif/total untuk widget 'Pelanggan Online (Aktif)'
    di panel Realtime Dashboard. Di-poll berkala lewat JS supaya bar & angkanya ikut
    naik otomatis begitu ada pelanggan baru ditambahkan, tanpa perlu refresh halaman."""
    db = get_db()
    total_pelanggan = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE reseller_id IS NULL").fetchone()["c"]
    total_aktif = db.execute(
        "SELECT COUNT(*) c FROM pelanggan WHERE status='aktif' AND reseller_id IS NULL").fetchone()["c"]
    kapasitas_pelanggan = _kapasitas_display_pelanggan(total_aktif, total_pelanggan)
    pct_aktif = round((total_aktif / kapasitas_pelanggan * 100)) if kapasitas_pelanggan else 0
    return jsonify(ok=True, total_pelanggan=total_pelanggan, total_aktif=total_aktif,
                   pct_aktif=pct_aktif, kapasitas_pelanggan=kapasitas_pelanggan)


_cache_system_resource = {"waktu": 0.0, "hasil": None}
_cache_system_resource_lock = threading.Lock()


@app.route("/api/mikrotik/system-resource")
@login_required
def api_system_resource():
    """Info uptime, CPU, RAM, dan storage router untuk panel Dashboard.
    Di-cache 1 detik di server: kalau ada beberapa tab/admin buka Dashboard bersamaan
    (masing-masing polling tiap detik biar Uptime & CPU Load selalu mengikuti angka
    real-time Mikrotik), router cuma di-query sekali per detik -- bukan sekali per detik
    PER tab, yang bisa membebani koneksi API Mikrotik kalau viewer-nya banyak."""
    sekarang = time.monotonic()
    with _cache_system_resource_lock:
        cache = _cache_system_resource
        if cache["hasil"] is not None and (sekarang - cache["waktu"]) < 1.0:
            return jsonify(**cache["hasil"])

    client = _get_mikrotik_client()
    if not client:
        hasil = dict(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.")
    else:
        try:
            info = client.get_system_resource()
            if not info:
                hasil = dict(ok=False, message="Tidak ada data dari router.")
            else:
                hasil = dict(ok=True, data={
                    "uptime": info.get("uptime", "-"),
                    "versi": info.get("version", "-"),
                    "board": info.get("board-name", "-"),
                    "cpu_load": info.get("cpu-load", "-"),
                    "total_ram_mb": round(int(info.get("total-memory", 0)) / 1024 / 1024) if info.get("total-memory") else None,
                    "free_ram_mb": round(int(info.get("free-memory", 0)) / 1024 / 1024) if info.get("free-memory") else None,
                    "total_hdd_gb": round(int(info.get("total-hdd-space", 0)) / 1024 / 1024 / 1024, 2) if info.get("total-hdd-space") else None,
                    "free_hdd_gb": round(int(info.get("free-hdd-space", 0)) / 1024 / 1024 / 1024, 2) if info.get("free-hdd-space") else None,
                })
        except RouterOSError as e:
            hasil = dict(ok=False, message=f"Gagal ambil info router: {e}")
        except Exception as e:
            hasil = dict(ok=False, message=f"Error tak terduga: {e}")

    with _cache_system_resource_lock:
        _cache_system_resource["waktu"] = sekarang
        _cache_system_resource["hasil"] = hasil
    return jsonify(**hasil)


@app.route("/api/mikrotik/ppp-active")
@login_required
def api_ppp_active():
    """Ambil daftar sesi PPPoE yang sedang aktif/online langsung dari Mikrotik (real-time)."""
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.", data=[])
    try:
        aktif = client.get_active_connections()
        # cocokkan dengan data pelanggan di billing (nama, paket) kalau ada
        db = get_db()
        peta_pelanggan = {
            row["username_pppoe"]: row["nama"]
            for row in db.execute("SELECT username_pppoe, nama FROM pelanggan").fetchall()
        }
        hasil = []
        for a in aktif:
            username = a.get("name", "")
            hasil.append({
                "username": username,
                "nama_billing": peta_pelanggan.get(username, "(tidak terdaftar di billing)"),
                "address": a.get("address", "-"),
                "uptime": a.get("uptime", "-"),
                "caller_id": a.get("caller-id", "-"),
            })
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/traffic/<username>")
@login_required
def api_traffic_pelanggan(username):
    """Ambil traffic RX/TX real-time (sesaat) untuk 1 pelanggan berdasarkan
    username PPPoE-nya. Dipakai fitur 'lihat traffic' saat pelanggan diklik
    di halaman Pelanggan."""
    client = _get_mikrotik_client(request.args.get("router_id", type=int))
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.")
    try:
        sesi = client.get_active_connection_by_username(username)
        if not sesi:
            return jsonify(ok=False, offline=True,
                            message="Pelanggan ini sedang tidak online (tidak ada sesi PPPoE aktif).")

        interface_name = f"<pppoe-{username}>"
        traffic = client.get_interface_traffic(interface_name)

        rx_bps = int(traffic.get("rx-bits-per-second", 0) or 0)
        tx_bps = int(traffic.get("tx-bits-per-second", 0) or 0)

        return jsonify(
            ok=True,
            offline=False,
            username=username,
            uptime=sesi.get("uptime", "-"),
            address=sesi.get("address", "-"),
            rx_bps=rx_bps,
            tx_bps=tx_bps,
            rx_mbps=round(rx_bps / 1_000_000, 2),
            tx_mbps=round(tx_bps / 1_000_000, 2),
        )
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


def _parse_kecepatan_mbps(kecepatan_text):
    """Ambil angka Mbps pertama dari teks kecepatan paket, misal '10M/10M' -> 10.0,
    '20 Mbps' -> 20.0. Kembalikan None kalau tidak ada angka yang bisa dibaca."""
    if not kecepatan_text:
        return None
    m = re.search(r"(\d+(?:[.,]\d+)?)", str(kecepatan_text))
    if not m:
        return None
    try:
        return float(m.group(1).replace(",", "."))
    except ValueError:
        return None


_cache_traffic_summary = {"waktu": 0.0, "hasil": None}
_cache_traffic_summary_lock = threading.Lock()


@app.route("/api/mikrotik/traffic-summary")
@login_required
def api_traffic_summary():
    """Ringkasan pemakaian trafik pelanggan aktif, dikelompokkan jadi 3 kategori
    untuk grafik donat di Dashboard:
      - full     : trafik sedang tinggi (>= 70% kecepatan paketnya, atau >= 5 Mbps
                   kalau kecepatan paket tidak bisa dibaca sebagai angka)
      - sedang   : online dan ada trafik, tapi belum mencapai batas 'full'
      - tidak_ada: offline (tidak ada sesi PPPoE aktif) ATAU online tapi trafiknya nyaris nol
    Di-cache 5 detik di server supaya tidak membebani API Mikrotik kalau banyak
    admin membuka Dashboard bersamaan."""
    sekarang = time.monotonic()
    with _cache_traffic_summary_lock:
        cache = _cache_traffic_summary
        if cache["hasil"] is not None and (sekarang - cache["waktu"]) < 5.0:
            return jsonify(**cache["hasil"])

    db = get_db()
    daftar_aktif = db.execute(
        """SELECT pl.username_pppoe, pk.kecepatan
           FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
           WHERE pl.status='aktif' AND pl.reseller_id IS NULL"""
    ).fetchall()
    total = len(daftar_aktif)

    def _simpan_dan_kirim(hasil):
        with _cache_traffic_summary_lock:
            _cache_traffic_summary["waktu"] = sekarang
            _cache_traffic_summary["hasil"] = hasil
        return jsonify(**hasil)

    if total == 0:
        return _simpan_dan_kirim(dict(
            ok=True, total=0,
            full={"jumlah": 0, "persen": 0},
            sedang={"jumlah": 0, "persen": 0},
            tidak_ada={"jumlah": 0, "persen": 0}))

    peta_kecepatan = {
        row["username_pppoe"]: _parse_kecepatan_mbps(row["kecepatan"])
        for row in daftar_aktif
    }

    client = _get_mikrotik_client()
    if not client:
        # Mikrotik belum diatur -> tidak ada data trafik real-time, anggap semua
        # pelanggan aktif masuk kategori 'tidak ada pemakaian'.
        return _simpan_dan_kirim(dict(
            ok=True, total=total,
            full={"jumlah": 0, "persen": 0},
            sedang={"jumlah": 0, "persen": 0},
            tidak_ada={"jumlah": total, "persen": 100},
            keterangan="Pengaturan Mikrotik belum diisi/disimpan."))

    try:
        aktif_conn = client.get_active_connections()
        username_online = {a.get("name", "") for a in aktif_conn}

        # Batasi jumlah query monitor-traffic per pemuatan biar tidak membebani
        # router kalau jumlah client online sangat banyak.
        BATAS_JUMLAH_CEK_TRAFFIC = 100
        username_dicek = list(username_online & set(peta_kecepatan.keys()))[:BATAS_JUMLAH_CEK_TRAFFIC]
        traffic_map = client.get_bulk_pppoe_traffic(username_dicek)

        jumlah_full = jumlah_sedang = jumlah_tidak_ada = 0

        for username, limit_mbps in peta_kecepatan.items():
            if username not in username_online:
                jumlah_tidak_ada += 1
                continue
            t = traffic_map.get(username)
            if not t:
                jumlah_tidak_ada += 1
                continue
            total_mbps = (t["rx_bps"] + t["tx_bps"]) / 1_000_000
            if total_mbps < 0.05:
                jumlah_tidak_ada += 1
                continue
            batas_full = (limit_mbps * 0.7) if limit_mbps else 5.0
            if total_mbps >= batas_full:
                jumlah_full += 1
            else:
                jumlah_sedang += 1

        def _pct(x):
            return round(x / total * 100) if total else 0

        hasil = dict(
            ok=True, total=total,
            full={"jumlah": jumlah_full, "persen": _pct(jumlah_full)},
            sedang={"jumlah": jumlah_sedang, "persen": _pct(jumlah_sedang)},
            tidak_ada={"jumlah": jumlah_tidak_ada, "persen": _pct(jumlah_tidak_ada)},
        )
    except RouterOSError as e:
        hasil = dict(ok=False, message=str(e))
    except Exception as e:
        hasil = dict(ok=False, message=f"Error tak terduga: {e}")

    return _simpan_dan_kirim(hasil)


_cache_traffic_top = {"waktu": 0.0, "hasil": None}
_cache_traffic_top_lock = threading.Lock()


@app.route("/api/mikrotik/traffic-top")
@login_required
def api_traffic_top():
    """Daftar client PPPoE aktif dengan pemakaian trafik saat ini, dikelompokkan
    3 tingkat untuk Dashboard: 'tinggi' (paling banyak), 'menengah', dan 'sedang'.
    Memakai batas yang sama dengan /api/mikrotik/traffic-summary supaya konsisten
    dengan grafik donat di atasnya (>=70% kecepatan paket / >=5 Mbps = tinggi,
    setengah dari batas itu = menengah, sisanya yang masih ada trafik = sedang).
    Di-cache 5 detik di server untuk alasan yang sama seperti traffic-summary."""
    sekarang = time.monotonic()
    with _cache_traffic_top_lock:
        cache = _cache_traffic_top
        if cache["hasil"] is not None and (sekarang - cache["waktu"]) < 5.0:
            return jsonify(**cache["hasil"])

    db = get_db()
    daftar_aktif = db.execute(
        """SELECT pl.username_pppoe, pl.nama, pk.kecepatan
           FROM pelanggan pl LEFT JOIN paket pk ON pk.id = pl.paket_id
           WHERE pl.status='aktif' AND pl.reseller_id IS NULL"""
    ).fetchall()
    peta = {
        row["username_pppoe"]: {"nama": row["nama"], "limit": _parse_kecepatan_mbps(row["kecepatan"])}
        for row in daftar_aktif
    }

    def _simpan_dan_kirim(hasil):
        with _cache_traffic_top_lock:
            _cache_traffic_top["waktu"] = sekarang
            _cache_traffic_top["hasil"] = hasil
        return jsonify(**hasil)

    client = _get_mikrotik_client()
    if not client:
        return _simpan_dan_kirim(dict(
            ok=False, message="Pengaturan Mikrotik belum diisi/disimpan."))

    LIMIT_PER_KATEGORI = 8
    BATAS_JUMLAH_CEK_TRAFFIC = 100

    try:
        aktif_conn = client.get_active_connections()
        username_online = [a.get("name", "") for a in aktif_conn if a.get("name") in peta]
        username_dicek = username_online[:BATAS_JUMLAH_CEK_TRAFFIC]
        traffic_map = client.get_bulk_pppoe_traffic(username_dicek)

        semua = []
        for username, t in traffic_map.items():
            info = peta.get(username)
            if not info:
                continue
            total_mbps = (t["rx_bps"] + t["tx_bps"]) / 1_000_000
            if total_mbps < 0.05:
                continue
            limit_mbps = info["limit"]
            batas_tinggi = (limit_mbps * 0.7) if limit_mbps else 5.0
            batas_menengah = batas_tinggi / 2
            if total_mbps >= batas_tinggi:
                kategori = "tinggi"
            elif total_mbps >= batas_menengah:
                kategori = "menengah"
            else:
                kategori = "sedang"
            semua.append({
                "username": username,
                "nama": info["nama"] or username,
                "mbps": round(total_mbps, 2),
                "kategori": kategori,
            })

        semua.sort(key=lambda x: x["mbps"], reverse=True)
        hasil = dict(
            ok=True,
            tinggi=[h for h in semua if h["kategori"] == "tinggi"][:LIMIT_PER_KATEGORI],
            menengah=[h for h in semua if h["kategori"] == "menengah"][:LIMIT_PER_KATEGORI],
            sedang=[h for h in semua if h["kategori"] == "sedang"][:LIMIT_PER_KATEGORI],
        )
    except RouterOSError as e:
        hasil = dict(ok=False, message=str(e))
    except Exception as e:
        hasil = dict(ok=False, message=f"Error tak terduga: {e}")

    return _simpan_dan_kirim(hasil)


# ---------------------------------------------------------------------------
# Hotspot: Server / User / User Profile / Active (perluasan menu Hotspot)
# ---------------------------------------------------------------------------
@app.route("/api/mikrotik/hotspot-servers")
@admin_atau_reseller_required
def api_hotspot_servers():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot, data=[])
    try:
        data = client.get_hotspot_servers()
        hasil = [{
            "name": d.get("name", "-"),
            "interface": d.get("interface", "-"),
            "profile": d.get("profile", "-"),
            "address_pool": d.get("address-pool", "-"),
            "disabled": d.get("disabled", "false"),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/hotspot-users")
@admin_atau_reseller_required
def api_hotspot_users():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot, data=[])
    try:
        data = client.get_hotspot_users()
        hasil = [{
            "name": d.get("name", "-"),
            "password": d.get("password", ""),
            "profile": d.get("profile", "-"),
            "comment": d.get("comment", ""),
            "disabled": d.get("disabled", "false"),
            "uptime": d.get("uptime", "-"),
            "bytes_in": d.get("bytes-in", "0"),
            "bytes_out": d.get("bytes-out", "0"),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/hotspot-users/simpan", methods=["POST"])
@admin_atau_reseller_required
def api_hotspot_user_simpan():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot), 400
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()
    profile = request.form.get("profile", "").strip()
    comment = request.form.get("comment", "").strip()
    if not username or not password or not profile:
        return jsonify(ok=False, message="Username, password, dan profile wajib diisi.")
    try:
        client.add_hotspot_user(username=username, password=password, profile=profile, comment=comment)
        _catat_aktivitas("hotspot", "Simpan User Hotspot", username)
        return jsonify(ok=True, message=f"User hotspot '{username}' berhasil disimpan.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/hotspot-users/hapus", methods=["POST"])
@admin_atau_reseller_required
def api_hotspot_user_hapus():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot), 400
    username = request.form.get("username", "").strip()
    try:
        client.remove_hotspot_user(username)
        _catat_aktivitas("hotspot", "Hapus User Hotspot", username)
        return jsonify(ok=True, message=f"User hotspot '{username}' dihapus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/hotspot-user-profiles/simpan", methods=["POST"])
@admin_atau_reseller_required
def api_hotspot_profile_simpan():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot), 400
    name = request.form.get("name", "").strip()
    rate_limit = request.form.get("rate_limit", "").strip()
    shared_users = request.form.get("shared_users", "1").strip()
    session_timeout = request.form.get("session_timeout", "").strip()
    idle_timeout = request.form.get("idle_timeout", "").strip()
    if not name:
        return jsonify(ok=False, message="Nama profile wajib diisi.")
    try:
        client.add_or_update_hotspot_profile(
            name=name, rate_limit=rate_limit, shared_users=shared_users,
            session_timeout=session_timeout, idle_timeout=idle_timeout)
        return jsonify(ok=True, message=f"User Profile '{name}' berhasil disimpan.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/hotspot-user-profiles/hapus", methods=["POST"])
@admin_atau_reseller_required
def api_hotspot_profile_hapus():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot), 400
    name = request.form.get("name", "").strip()
    try:
        client.remove_hotspot_profile(name)
        return jsonify(ok=True, message=f"User Profile '{name}' dihapus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/hotspot-active")
@admin_atau_reseller_required
def api_hotspot_active():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot, data=[])
    try:
        data = client.get_hotspot_active()
        hasil = [{
            "id": d.get(".id", ""),
            "user": d.get("user", "-"),
            "address": d.get("address", "-"),
            "mac_address": d.get("mac-address", "-"),
            "uptime": d.get("uptime", "-"),
            "bytes_in": int(d.get("bytes-in", 0) or 0),
            "bytes_out": int(d.get("bytes-out", 0) or 0),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/hotspot-user/toggle", methods=["POST"])
@admin_atau_reseller_required
def api_hotspot_user_toggle():
    """Aktifkan/nonaktifkan akun user hotspot (voucher) langsung dari Dashboard,
    dipakai tombol Disable/Enable pada daftar Hotspot Aktif."""
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot), 400
    username = request.form.get("username", "").strip()
    aksi = request.form.get("aksi", "").strip()  # 'disable' atau 'enable'
    if not username or aksi not in ("disable", "enable"):
        return jsonify(ok=False, message="Data tidak lengkap.")
    try:
        client.set_hotspot_user_disabled(username, disabled=(aksi == "disable"))
        pesan = "dinonaktifkan" if aksi == "disable" else "diaktifkan"
        _catat_aktivitas("hotspot", f"User Hotspot {pesan.capitalize()}", username)
        return jsonify(ok=True, message=f"User hotspot '{username}' berhasil {pesan}.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/hotspot-active/putus", methods=["POST"])
@admin_atau_reseller_required
def api_hotspot_active_putus():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot), 400
    session_id = request.form.get("id", "").strip()
    try:
        client.kick_hotspot_active(session_id)
        _catat_aktivitas("hotspot", "Putus Sesi Hotspot", session_id)
        return jsonify(ok=True, message="Sesi berhasil diputus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/hotspot-profiles-detail")
@admin_atau_reseller_required
def api_hotspot_profiles_detail():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot, data=[])
    try:
        data = client.get_hotspot_profiles()
        hasil = [{
            "name": d.get("name", "-"),
            "rate_limit": d.get("rate-limit", ""),
            "shared_users": d.get("shared-users", ""),
            "session_timeout": d.get("session-timeout", ""),
            "idle_timeout": d.get("idle-timeout", ""),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/hotspot-profiles")
@admin_atau_reseller_required
def api_mikrotik_hotspot_profiles():
    client, _err_hotspot = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_hotspot, profiles=[])
    try:
        data = client.get_hotspot_profiles()
        profiles = [d.get("name") for d in data if d.get("name")]
        return jsonify(ok=True, profiles=profiles)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), profiles=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", profiles=[])


# ---------------------------------------------------------------------------
# Pengaturan Mikrotik
# ---------------------------------------------------------------------------
@app.route("/pengaturan/mikrotik", methods=["GET", "POST"])
@login_required
def pengaturan_mikrotik():
    """Editor lanjutan untuk Router Utama (id=1) -- mendukung VPN Bawaan Billing.
    Halaman ini juga menampilkan tabel status semua router/perangkat Mikrotik
    yang sudah terpasang (termasuk yang ditambah lewat menu Router / POP),
    lengkap dengan aksi hapus massal."""
    db = get_db()
    if request.method == "POST":
        host = request.form["host"].strip()
        port = int(request.form.get("port") or 8728)
        username = request.form["username"].strip()
        password = request.form.get("password", "")
        metode_koneksi = request.form.get("metode_koneksi", "langsung").strip() or "langsung"
        nama_tunnel = request.form.get("nama_tunnel", "").strip() or None
        db.execute(
            """UPDATE router SET host=?, port=?, username=?, password=?,
               metode_koneksi=?, nama_tunnel=? WHERE id=1""",
            (host, port, username, password, metode_koneksi, nama_tunnel))
        db.commit()
        flash("Pengaturan Router Utama disimpan.", "success")
        return redirect(url_for("pengaturan_mikrotik"))

    row = db.execute("SELECT * FROM router WHERE id=1").fetchone()
    klien_vpn = db.execute("SELECT * FROM vpn_client WHERE aktif=1 ORDER BY nama").fetchall()
    daftar_router = db.execute(
        """SELECT r.*, (SELECT COUNT(*) FROM pelanggan WHERE router_id = r.id) AS jumlah_pelanggan
           FROM router r WHERE r.reseller_id IS NULL ORDER BY r.id"""
    ).fetchall()
    return render_template("pengaturan_mikrotik.html", row=row, klien_vpn=klien_vpn,
                            daftar_router=daftar_router)


def _hapus_router_dan_ppp(db, router_id):
    """Hapus satu router/perangkat Mikrotik: hapus dulu PPP secret pelanggan
    terkait langsung dari perangkat Mikrotik-nya (kalau bisa konek), lalu
    hapus juga data pelanggan yang terpasang di router itu dari billing
    (karena pelanggan tanpa router jadi tidak berguna), lalu hapus baris
    router-nya (khusus id=1/Router Utama, barisnya tetap ada tapi data
    koneksinya dikosongkan karena dibutuhkan sistem). Mengembalikan dict
    ringkasan."""
    router_row = db.execute("SELECT * FROM router WHERE id=?", (router_id,)).fetchone()
    if not router_row:
        return None
    daftar_pelanggan = db.execute(
        "SELECT username_pppoe FROM pelanggan WHERE router_id=?", (router_id,)).fetchall()

    jumlah_secret_terhapus = 0
    error_koneksi = None
    if daftar_pelanggan:
        client = _get_mikrotik_client(router_id)
        if client:
            for p in daftar_pelanggan:
                try:
                    client.remove_secret(p["username_pppoe"])
                    jumlah_secret_terhapus += 1
                except Exception as e:
                    if error_koneksi is None:
                        error_koneksi = str(e)
        else:
            error_koneksi = "Router tidak bisa dihubungi, PPP secret di perangkat tidak ikut terhapus (hanya data di billing)."

    # Data pelanggan yang terpasang di router ini ikut dihapus dari billing
    # (bukan cuma dilepas relasinya) supaya tidak ada "pelanggan hantu" tanpa
    # router yang masih muncul di menu Pelanggan. Tagihan pelanggan tsb ikut
    # terhapus otomatis lewat ON DELETE CASCADE di tabel tagihan.
    db.execute("DELETE FROM pelanggan WHERE router_id=?", (router_id,))

    if router_id == 1:
        db.execute(
            """UPDATE router SET host='', port=8728, username='', password='',
               metode_koneksi='langsung', nama_tunnel=NULL WHERE id=1""")
    else:
        db.execute("DELETE FROM router WHERE id=?", (router_id,))

    db.commit()
    return {
        "nama_router": router_row["nama_router"] if "nama_router" in router_row.keys() else "Router Utama",
        "jumlah_pelanggan": len(daftar_pelanggan),
        "jumlah_secret_terhapus": jumlah_secret_terhapus,
        "error_koneksi": error_koneksi,
    }


@app.route("/pengaturan/mikrotik/hapus", methods=["POST"])
@login_required
def pengaturan_mikrotik_hapus():
    """Hapus/putuskan pengaturan koneksi Router Utama (id=1) yang sudah
    dipasang. PPP secret pelanggan yang masih memakai router ini otomatis
    dihapus dari perangkat Mikrotik-nya juga (kalau router masih bisa
    dihubungi), lalu data pelanggan yang terpasang di router ini ikut
    dihapus dari billing. Baris id=1 tetap ada (dibutuhkan sistem), yang
    dihapus cuma data koneksinya."""
    db = get_db()
    ringkasan = _hapus_router_dan_ppp(db, 1)
    pesan = "Pengaturan Mikrotik/perangkat yang terpasang berhasil dihapus."
    if ringkasan["jumlah_pelanggan"]:
        pesan += (f" {ringkasan['jumlah_secret_terhapus']} dari {ringkasan['jumlah_pelanggan']} "
                  f"PPP secret pelanggan ikut dihapus dari perangkat, dan {ringkasan['jumlah_pelanggan']} "
                  f"data pelanggan yang terpasang di router ini ikut dihapus dari billing.")
    flash(pesan, "success")
    if ringkasan["error_koneksi"]:
        flash(f"Catatan: {ringkasan['error_koneksi']}", "warning")
    return redirect(url_for("pengaturan_mikrotik"))


@app.route("/pengaturan/mikrotik/hapus-terpilih", methods=["POST"])
@login_required
def pengaturan_mikrotik_hapus_terpilih():
    """Hapus banyak router/perangkat Mikrotik sekaligus dari tabel status di
    menu Pengaturan Mikrotik. Untuk tiap router yang dipilih, PPP secret
    pelanggan terkait dihapus otomatis dari perangkatnya, baru data
    pelanggan yang terpasang di router itu ikut dihapus dari billing, dan
    baris router dihapus (Router Utama/id=1 dikosongkan saja, tidak ikut
    terhapus barisnya)."""
    db = get_db()
    router_ids = request.form.getlist("router_ids")
    if not router_ids:
        flash("Pilih dulu minimal satu router/perangkat yang mau dihapus.", "danger")
        return redirect(url_for("pengaturan_mikrotik"))

    total_router = 0
    total_secret = 0
    ada_error_koneksi = False
    for rid in router_ids:
        try:
            rid = int(rid)
        except ValueError:
            continue
        ringkasan = _hapus_router_dan_ppp(db, rid)
        if ringkasan:
            total_router += 1
            total_secret += ringkasan["jumlah_secret_terhapus"]
            if ringkasan["error_koneksi"]:
                ada_error_koneksi = True

    flash(f"{total_router} router/perangkat berhasil dihapus, "
          f"{total_secret} PPP secret pelanggan ikut dihapus otomatis dari perangkatnya, "
          f"dan data pelanggan yang terpasang di router-router tsb ikut dihapus dari billing.", "success")
    if ada_error_koneksi:
        flash("Catatan: sebagian router tidak bisa dihubungi saat proses hapus, jadi PPP secret di "
              "perangkat itu mungkin belum ikut terhapus (data pelanggan di billing tetap sudah dihapus).",
              "warning")
    return redirect(url_for("pengaturan_mikrotik"))


@app.route("/pengaturan/mikrotik/test", methods=["POST"])
@login_required
def test_mikrotik():
    client = _get_mikrotik_client(1)
    if not client:
        return jsonify(ok=False, message="Isi host/username terlebih dahulu, lalu Simpan dulu sebelum Tes Koneksi.")
    try:
        identity = client.test_connection()
        return jsonify(ok=True, message=f"Berhasil konek! Identity router: {identity}")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal konek (error tak terduga): {e}")


# ---------------------------------------------------------------------------
# VPN Mikrotik -- VPN Server bawaan billing (WireGuard) supaya billing bisa
# menyediakan layanan VPN sendiri untuk router Mikrotik konek masuk, tanpa
# tergantung layanan tunnel pihak ketiga.
# ---------------------------------------------------------------------------
def _daftar_klien_vpn(db):
    return db.execute("SELECT * FROM vpn_client ORDER BY id DESC").fetchall()


@app.route("/vpn")
@login_required
def vpn_mikrotik():
    db = get_db()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    klien = _daftar_klien_vpn(db)
    return render_template(
        "vpn_mikrotik.html",
        pengaturan=pengaturan,
        klien=klien,
        wg_tersedia=vpn_manager.wg_tersedia(),
        alasan_tidak_tersedia=vpn_manager.alasan_tidak_tersedia() if not vpn_manager.wg_tersedia() else None,
        interface_hidup=vpn_manager.interface_aktif(pengaturan["interface_name"]) if pengaturan["server_pubkey"] else False,
    )


@app.route("/vpn/server/simpan", methods=["POST"])
@login_required
def vpn_server_simpan():
    db = get_db()
    interface_name = (request.form.get("interface_name") or "wg-billing").strip()
    listen_port = int(request.form.get("listen_port") or 51820)
    subnet_cidr = (request.form.get("subnet_cidr") or "10.77.77.0/24").strip()
    endpoint_host = (request.form.get("endpoint_host") or "").strip()
    try:
        ipaddress.ip_network(subnet_cidr, strict=False)
    except ValueError:
        flash("Subnet VPN tidak valid, contoh yang benar: 10.77.77.0/24", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute(
        """UPDATE pengaturan_vpn SET interface_name=?, listen_port=?, subnet_cidr=?, endpoint_host=?
           WHERE id=1""",
        (interface_name, listen_port, subnet_cidr, endpoint_host))
    db.commit()
    flash("Pengaturan server VPN disimpan. Jangan lupa klik \"Hidupkan VPN\" kalau server belum aktif.", "success")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/server/generate-key", methods=["POST"])
@login_required
def vpn_server_generate_key():
    if not vpn_manager.wg_tersedia():
        flash(vpn_manager.alasan_tidak_tersedia(), "danger")
        return redirect(url_for("vpn_mikrotik"))
    db = get_db()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    if pengaturan["aktif"]:
        flash("Matikan VPN dulu sebelum mengganti key server (supaya semua klien tidak mendadak putus dengan key lama).", "warning")
        return redirect(url_for("vpn_mikrotik"))
    try:
        privkey, pubkey = vpn_manager.buat_keypair()
    except vpn_manager.VPNError as e:
        flash(f"Gagal membuat key server: {e}", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute("UPDATE pengaturan_vpn SET server_privkey=?, server_pubkey=? WHERE id=1", (privkey, pubkey))
    db.commit()
    flash("Key server VPN berhasil dibuat. Setelah ini tambahkan klien lalu Hidupkan VPN.", "success")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/server/hidupkan", methods=["POST"])
@login_required
def vpn_server_hidupkan():
    db = get_db()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    if not pengaturan["server_pubkey"]:
        flash("Generate key server VPN dulu sebelum menghidupkan.", "warning")
        return redirect(url_for("vpn_mikrotik"))
    if not pengaturan["endpoint_host"]:
        flash("Isi \"Alamat/Domain Publik Server\" dulu di Pengaturan Server VPN, supaya script buat Mikrotik nanti benar.", "warning")
        return redirect(url_for("vpn_mikrotik"))
    klien = _daftar_klien_vpn(db)
    try:
        vpn_manager.start_interface(pengaturan, klien)
    except vpn_manager.VPNError as e:
        flash(f"Gagal menghidupkan VPN: {e}", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute("UPDATE pengaturan_vpn SET aktif=1 WHERE id=1")
    db.commit()
    flash(f"VPN Server aktif di UDP port {pengaturan['listen_port']}. Router Mikrotik sekarang bisa konek masuk.", "success")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/server/matikan", methods=["POST"])
@login_required
def vpn_server_matikan():
    db = get_db()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    try:
        vpn_manager.stop_interface(pengaturan["interface_name"])
    except vpn_manager.VPNError as e:
        flash(f"Gagal mematikan VPN: {e}", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute("UPDATE pengaturan_vpn SET aktif=0 WHERE id=1")
    db.commit()
    flash("VPN Server dimatikan. Semua router Mikrotik yang konek lewat VPN ini akan terputus.", "info")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/klien/tambah", methods=["POST"])
@login_required
def vpn_klien_tambah():
    db = get_db()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    if not pengaturan["server_pubkey"]:
        flash("Generate key server VPN dulu (di bagian Pengaturan Server) sebelum menambah klien.", "warning")
        return redirect(url_for("vpn_mikrotik"))
    nama = (request.form.get("nama") or "").strip()
    keterangan = (request.form.get("keterangan") or "").strip()
    if not nama:
        flash("Nama klien (mis. nama router/lokasi) wajib diisi.", "danger")
        return redirect(url_for("vpn_mikrotik"))
    if not vpn_manager.wg_tersedia():
        flash(vpn_manager.alasan_tidak_tersedia(), "danger")
        return redirect(url_for("vpn_mikrotik"))
    ip_terpakai = [r["ip_address"] for r in db.execute("SELECT ip_address FROM vpn_client").fetchall()]
    try:
        ip_baru = vpn_manager.ip_berikutnya(pengaturan["subnet_cidr"], ip_terpakai)
        privkey, pubkey = vpn_manager.buat_keypair()
    except vpn_manager.VPNError as e:
        flash(f"Gagal menambah klien: {e}", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute(
        """INSERT INTO vpn_client (nama, keterangan, client_privkey, client_pubkey, ip_address, aktif, dibuat_tanggal)
           VALUES (?, ?, ?, ?, ?, 1, ?)""",
        (nama, keterangan, privkey, pubkey, ip_baru, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    db.commit()
    if pengaturan["aktif"]:
        try:
            vpn_manager.sinkronkan_peer(pengaturan, _daftar_klien_vpn(db))
        except vpn_manager.VPNError as e:
            flash(f"Klien tersimpan, tapi gagal langsung diterapkan ke VPN yang sedang jalan: {e}. "
                  f"Coba matikan lalu hidupkan lagi VPN Server.", "warning")
            return redirect(url_for("vpn_mikrotik"))
    flash(f"Klien VPN '{nama}' dibuat dengan IP tunnel {ip_baru}. Salin script Mikrotik-nya lewat tombol \"Script Mikrotik\".", "success")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/klien/<int:kid>/toggle", methods=["POST"])
@login_required
def vpn_klien_toggle(kid):
    db = get_db()
    row = db.execute("SELECT * FROM vpn_client WHERE id=?", (kid,)).fetchone()
    if not row:
        flash("Klien VPN tidak ditemukan.", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute("UPDATE vpn_client SET aktif=? WHERE id=?", (0 if row["aktif"] else 1, kid))
    db.commit()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    if pengaturan["aktif"]:
        try:
            vpn_manager.sinkronkan_peer(pengaturan, _daftar_klien_vpn(db))
        except vpn_manager.VPNError as e:
            flash(f"Status tersimpan, tapi gagal diterapkan ke VPN yang sedang jalan: {e}", "warning")
            return redirect(url_for("vpn_mikrotik"))
    flash(("Klien VPN diaktifkan kembali." if not row["aktif"] else "Klien VPN dinonaktifkan (diputus dari VPN)."), "success")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/klien/<int:kid>/hapus", methods=["POST"])
@login_required
def vpn_klien_hapus(kid):
    db = get_db()
    row = db.execute("SELECT * FROM vpn_client WHERE id=?", (kid,)).fetchone()
    if not row:
        flash("Klien VPN tidak ditemukan.", "danger")
        return redirect(url_for("vpn_mikrotik"))
    db.execute("DELETE FROM vpn_client WHERE id=?", (kid,))
    db.commit()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    if pengaturan["aktif"]:
        try:
            vpn_manager.sinkronkan_peer(pengaturan, _daftar_klien_vpn(db))
        except vpn_manager.VPNError as e:
            flash(f"Klien dihapus dari billing, tapi gagal diterapkan ke VPN yang sedang jalan: {e}", "warning")
            return redirect(url_for("vpn_mikrotik"))
    flash(f"Klien VPN '{row['nama']}' dihapus.", "success")
    return redirect(url_for("vpn_mikrotik"))


@app.route("/vpn/klien/<int:kid>/script")
@login_required
def vpn_klien_script(kid):
    db = get_db()
    row = db.execute("SELECT * FROM vpn_client WHERE id=?", (kid,)).fetchone()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    if not row or not pengaturan["server_pubkey"]:
        return jsonify(ok=False, message="Klien atau key server belum lengkap.")
    return jsonify(ok=True, script=vpn_manager.script_routeros(pengaturan, row))


@app.route("/api/vpn/status")
@login_required
def api_vpn_status():
    db = get_db()
    pengaturan = db.execute("SELECT * FROM pengaturan_vpn WHERE id=1").fetchone()
    klien = _daftar_klien_vpn(db)
    hidup = vpn_manager.interface_aktif(pengaturan["interface_name"]) if pengaturan["server_pubkey"] else False
    status_semua = vpn_manager.status_peer(pengaturan["interface_name"]) if hidup else {}
    hasil = []
    for k in klien:
        st = status_semua.get(k["client_pubkey"], {})
        hasil.append({
            "id": k["id"],
            "online": bool(st.get("online")),
            "terakhir_terhubung": vpn_manager.format_terakhir_terhubung(st.get("latest_handshake")),
            "endpoint": st.get("endpoint"),
        })
    return jsonify(ok=True, interface_hidup=hidup, klien=hasil)


@app.route("/pengaturan/genieacs", methods=["GET", "POST"])
@login_required
def pengaturan_genieacs():
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi", "simpan")

        if aksi == "simpan":
            url = request.form.get("url", "").strip().rstrip("/")
            username = request.form.get("username", "").strip()
            password_baru = request.form.get("password", "")
            aktif = 1 if request.form.get("aktif") == "on" else 0

            if password_baru:
                password = password_baru
            else:
                lama = db.execute("SELECT password FROM pengaturan_genieacs WHERE id=1").fetchone()
                password = lama["password"] if lama else ""

            path_ssid = request.form.get("path_ssid", "").strip() or "InternetGatewayDevice.LANDevice.1.WLANConfiguration.{idx}.SSID"
            path_ssid_enable = request.form.get("path_ssid_enable", "").strip() or "InternetGatewayDevice.LANDevice.1.WLANConfiguration.{idx}.Enable"
            path_password = request.form.get("path_password", "").strip() or "InternetGatewayDevice.LANDevice.1.WLANConfiguration.{idx}.KeyPassphrase"
            path_rx_power = request.form.get("path_rx_power", "").strip()
            path_uptime = request.form.get("path_uptime", "").strip() or "InternetGatewayDevice.DeviceInfo.UpTime"
            path_hosts = request.form.get("path_hosts", "").strip()

            db.execute(
                """UPDATE pengaturan_genieacs SET url=?, username=?, password=?, aktif=?,
                   path_ssid=?, path_ssid_enable=?, path_password=?, path_rx_power=?,
                   path_uptime=?, path_hosts=? WHERE id=1""",
                (url, username, password, aktif, path_ssid, path_ssid_enable, path_password,
                 path_rx_power, path_uptime, path_hosts))
            db.commit()
            flash("Pengaturan GenieACS berhasil disimpan.", "success")

        elif aksi == "tes":
            cfg = _get_genieacs_cfg(db, wajib_aktif=False)
            if not cfg:
                flash("Isi dulu URL GenieACS sebelum menguji koneksi.", "danger")
            else:
                try:
                    genieacs_client.tes_koneksi(cfg)
                    flash("Koneksi ke server GenieACS berhasil.", "success")
                except genieacs_client.GenieACSError as e:
                    flash(f"Koneksi ke GenieACS gagal: {e}", "danger")

        return redirect(url_for("pengaturan_genieacs"))

    row = db.execute("SELECT * FROM pengaturan_genieacs WHERE id=1").fetchone()
    return render_template("pengaturan_genieacs.html", row=row)


# ---------------------------------------------------------------------------
# Sistem -- Status Sistem & integrasi UptimeRobot
# ---------------------------------------------------------------------------
@app.route("/sistem", methods=["GET", "POST"])
@login_required
def sistem_status():
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi", "simpan")

        if aksi == "simpan":
            api_key = request.form.get("api_key", "").strip()
            aktif = 1 if request.form.get("aktif") == "on" else 0
            db.execute(
                "UPDATE pengaturan_uptimerobot SET api_key=?, aktif=? WHERE id=1",
                (api_key, aktif))
            db.commit()
            flash("Pengaturan UptimeRobot berhasil disimpan.", "success")

        elif aksi == "tes":
            row = db.execute("SELECT * FROM pengaturan_uptimerobot WHERE id=1").fetchone()
            api_key = (row["api_key"] or "").strip() if row else ""
            if not api_key:
                flash("Isi dulu API Key UptimeRobot sebelum menguji koneksi.", "danger")
            else:
                try:
                    info = uptimerobot_client.tes_koneksi(api_key)
                    flash(f"Koneksi ke UptimeRobot berhasil. Monitor terpakai: "
                          f"{info['monitor_terpakai']} / {info['monitor_limit']}.", "success")
                except uptimerobot_client.UptimeRobotError as e:
                    flash(f"Koneksi ke UptimeRobot gagal: {e}", "danger")

        return redirect(url_for("sistem_status"))

    row = db.execute("SELECT * FROM pengaturan_uptimerobot WHERE id=1").fetchone()
    return render_template("sistem.html", row=row)


@app.route("/sistem/monitors")
@login_required
def sistem_monitors_ajax():
    """Endpoint AJAX (dipanggil dari halaman Status Sistem) untuk ambil daftar
    monitor UptimeRobot terkini tanpa reload halaman."""
    db = get_db()
    row = db.execute("SELECT * FROM pengaturan_uptimerobot WHERE id=1").fetchone()
    if not row or not row["aktif"] or not row["api_key"]:
        return jsonify(ok=False, message="Integrasi UptimeRobot belum diaktifkan/diisi API Key-nya.")
    try:
        monitors = uptimerobot_client.ambil_monitors(row["api_key"])
        return jsonify(ok=True, monitors=monitors)
    except uptimerobot_client.UptimeRobotError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal mengambil status (error tak terduga): {e}")


# ---------------------------------------------------------------------------
# OLT & ONU (monitoring via SNMP)
# ---------------------------------------------------------------------------
def _get_snmp_client(olt_row):
    return SNMPClient(
        olt_row["host"],
        community=olt_row["snmp_community"],
        port=olt_row["snmp_port"] or 161,
    )


def _snmp_discover_onu(db, olt_row):
    """SNMP WALK ke tabel status (& nama interface kalau ada) untuk menemukan semua index
    ONU yang OLT ini kenal. Dipakai bareng oleh endpoint scan manual & auto-sync saat simpan
    pengaturan OLT. Return list of dict, atau raise SNMPError kalau gagal total."""
    if not olt_row["oid_status"]:
        raise SNMPError("OID Status ONU belum diisi di pengaturan OLT ini.")

    client = _get_snmp_client(olt_row)
    prefix_status = olt_row["oid_status"].rstrip(".")
    hasil_status = client.walk(prefix_status)
    if not hasil_status:
        raise SNMPError("OLT tidak mengembalikan data apapun untuk OID Status ini "
                         "(cek lagi OID-nya, atau community-nya kurang akses).")

    nama_per_index = {}
    if olt_row["oid_nama_interface"]:
        try:
            for oid_str, nilai in client.walk(olt_row["oid_nama_interface"].rstrip(".")):
                idx = oid_str.rsplit(".", 1)[-1]
                if isinstance(nilai, str) and nilai not in ("noSuchObject", "noSuchInstance"):
                    nama_per_index[idx] = nilai
        except SNMPError:
            pass  # nama interface gagal diambil -> tetap lanjut tanpa nama, tidak fatal

    sudah_terdaftar = {
        row["oid_index"] for row in db.execute("SELECT oid_index FROM onu WHERE olt_id=?", (olt_row["id"],)).fetchall()
    }

    data = []
    for oid_str, nilai in hasil_status:
        idx = oid_str[len(prefix_status) + 1:]  # bagian OID setelah prefix = index ONU
        data.append({
            "oid_index": idx,
            "status": status_dari_nilai(nilai),
            "nama_interface": nama_per_index.get(idx),
            "sudah_terdaftar": idx in sudah_terdaftar,
        })
    return data


def _auto_sync_onu_dari_olt(db, olt_id):
    """Dipanggil otomatis setiap kali pengaturan SNMP sebuah OLT disimpan -- supaya ONU-nya
    langsung muncul di billing tanpa admin perlu klik "Scan Otomatis" secara manual.
    Diam-diam gagal (tidak melempar error) kalau SNMP belum bisa diakses -- itu wajar terjadi
    kalau admin baru mengisi sebagian pengaturan, atau OLT sedang tidak terjangkau; import
    manual/"Scan Otomatis" tetap tersedia kalau ini gagal. Return jumlah ONU baru yang masuk."""
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row or not olt_row["host"]:
        return 0
    try:
        temuan = _snmp_discover_onu(db, olt_row)
    except SNMPError:
        return 0
    except Exception:
        return 0

    sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ditambahkan = 0
    for o in temuan:
        if o["sudah_terdaftar"]:
            continue
        label = o["nama_interface"] or f"ONU {o['oid_index']}"
        db.execute(
            """INSERT INTO onu (olt_id, label, oid_index, port_pon, status_terakhir, dicek_terakhir)
               VALUES (?,?,?,1,?,?)""",
            (olt_id, label, o["oid_index"], o["status"], sekarang))
        ditambahkan += 1
    if ditambahkan:
        db.commit()
    return ditambahkan


@app.route("/olt", methods=["GET", "POST"])
@login_required
def olt():
    db = get_db()
    if request.method == "POST":
        nama = request.form["nama"].strip()
        host = request.form.get("host", "").strip()
        snmp_port = int(request.form.get("snmp_port") or 161)
        snmp_community = request.form.get("snmp_community", "public").strip() or "public"
        oid_status = request.form.get("oid_status", "").strip() or OID_IF_OPER_STATUS
        oid_rx_power = request.form.get("oid_rx_power", "").strip() or None
        oid_tx_power = request.form.get("oid_tx_power", "").strip() or None
        oid_temperature = request.form.get("oid_temperature", "").strip() or None
        oid_mac_address = request.form.get("oid_mac_address", "").strip() or None
        oid_nama_interface = request.form.get("oid_nama_interface", "").strip() or OID_IF_DESCR
        keterangan = request.form.get("keterangan", "").strip()
        tipe = request.form.get("tipe", "GPON").strip() or "GPON"
        brand = request.form.get("brand", "").strip()
        alamat = request.form.get("alamat", "").strip()
        latitude = request.form.get("latitude", "").strip() or None
        longitude = request.form.get("longitude", "").strip() or None
        username_login = request.form.get("username_login", "").strip()
        password_login = request.form.get("password_login", "").strip()
        url_akses = request.form.get("url_akses", "").strip()
        jumlah_port = request.form.get("jumlah_port", "").strip() or None
        software_version = request.form.get("software_version", "").strip() or None
        revisi = request.form.get("revisi", "").strip() or None
        mac_address = request.form.get("mac_address", "").strip() or None
        ssh_port = int(request.form.get("ssh_port") or 22)
        ssh_username = request.form.get("ssh_username", "").strip() or None
        ssh_password = request.form.get("ssh_password", "").strip() or None
        ssh_command = request.form.get("ssh_command", "").strip() or "show mac address-table"
        cur = db.execute(
            """INSERT INTO olt_device
               (nama, host, snmp_port, snmp_community, oid_status, oid_rx_power, oid_tx_power,
                oid_temperature, oid_mac_address, oid_nama_interface, keterangan,
                tipe, brand, alamat, latitude, longitude, username_login, password_login, url_akses, jumlah_port,
                software_version, revisi, mac_address, ssh_port, ssh_username, ssh_password, ssh_command)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (nama, host, snmp_port, snmp_community, oid_status, oid_rx_power, oid_tx_power,
             oid_temperature, oid_mac_address, oid_nama_interface, keterangan,
             tipe, brand, alamat, latitude, longitude, username_login, password_login, url_akses, jumlah_port,
             software_version, revisi, mac_address, ssh_port, ssh_username, ssh_password, ssh_command))
        db.commit()
        jumlah_sync = _auto_sync_onu_dari_olt(db, cur.lastrowid)
        if jumlah_sync:
            flash(f"Perangkat OLT ditambahkan, dan {jumlah_sync} ONU langsung tersinkron otomatis lewat SNMP.", "success")
        else:
            flash("Perangkat OLT ditambahkan. Data ONU belum bisa ditarik otomatis (cek OID/koneksi SNMP) "
                  "-- bisa dicoba manual lewat tombol \"Scan Otomatis dari OLT\" di halaman Kelola ONU.", "success")
        return redirect(url_for("olt"))

    daftar_olt = db.execute("SELECT * FROM olt_device ORDER BY id DESC").fetchall()
    jumlah_onu = {
        row["olt_id"]: row["c"]
        for row in db.execute("SELECT olt_id, COUNT(*) c FROM onu GROUP BY olt_id").fetchall()
    }
    onu_online = {
        row["olt_id"]: row["c"]
        for row in db.execute(
            "SELECT olt_id, COUNT(*) c FROM onu WHERE status_terakhir='online' GROUP BY olt_id").fetchall()
    }
    return render_template(
        "olt.html", daftar_olt=daftar_olt, jumlah_onu=jumlah_onu, onu_online=onu_online,
        oid_status_default=OID_IF_OPER_STATUS, oid_nama_default=OID_IF_DESCR,
    )


@app.route("/olt/hapus/<int:olt_id>", methods=["POST"])
@login_required
def hapus_olt(olt_id):
    db = get_db()
    db.execute("DELETE FROM olt_device WHERE id=?", (olt_id,))
    db.commit()
    flash("Perangkat OLT dihapus (beserta data ONU di bawahnya).", "success")
    return redirect(url_for("olt"))


@app.route("/olt/edit/<int:olt_id>", methods=["POST"])
@login_required
def edit_olt(olt_id):
    db = get_db()
    nama = request.form["nama"].strip()
    host = request.form.get("host", "").strip()
    snmp_port = int(request.form.get("snmp_port") or 161)
    snmp_community = request.form.get("snmp_community", "public").strip() or "public"
    oid_status = request.form.get("oid_status", "").strip() or OID_IF_OPER_STATUS
    oid_rx_power = request.form.get("oid_rx_power", "").strip() or None
    oid_tx_power = request.form.get("oid_tx_power", "").strip() or None
    oid_temperature = request.form.get("oid_temperature", "").strip() or None
    oid_mac_address = request.form.get("oid_mac_address", "").strip() or None
    oid_nama_interface = request.form.get("oid_nama_interface", "").strip() or OID_IF_DESCR
    keterangan = request.form.get("keterangan", "").strip()
    tipe = request.form.get("tipe", "GPON").strip() or "GPON"
    brand = request.form.get("brand", "").strip()
    alamat = request.form.get("alamat", "").strip()
    latitude = request.form.get("latitude", "").strip() or None
    longitude = request.form.get("longitude", "").strip() or None
    username_login = request.form.get("username_login", "").strip()
    password_login = request.form.get("password_login", "").strip()
    url_akses = request.form.get("url_akses", "").strip()
    jumlah_port = request.form.get("jumlah_port", "").strip() or None
    software_version = request.form.get("software_version", "").strip() or None
    revisi = request.form.get("revisi", "").strip() or None
    mac_address = request.form.get("mac_address", "").strip() or None
    ssh_port = int(request.form.get("ssh_port") or 22)
    ssh_username = request.form.get("ssh_username", "").strip() or None
    ssh_password_baru = request.form.get("ssh_password", "").strip()
    if ssh_password_baru:
        ssh_password = ssh_password_baru
    else:
        lama = db.execute("SELECT ssh_password FROM olt_device WHERE id=?", (olt_id,)).fetchone()
        ssh_password = lama["ssh_password"] if lama else None
    ssh_command = request.form.get("ssh_command", "").strip() or "show mac address-table"
    db.execute(
        """UPDATE olt_device SET nama=?, host=?, snmp_port=?, snmp_community=?,
           oid_status=?, oid_rx_power=?, oid_tx_power=?, oid_temperature=?, oid_mac_address=?,
           oid_nama_interface=?, keterangan=?,
           tipe=?, brand=?, alamat=?, latitude=?, longitude=?,
           username_login=?, password_login=?, url_akses=?, jumlah_port=?,
           software_version=?, revisi=?, mac_address=?,
           ssh_port=?, ssh_username=?, ssh_password=?, ssh_command=? WHERE id=?""",
        (nama, host, snmp_port, snmp_community, oid_status, oid_rx_power, oid_tx_power,
         oid_temperature, oid_mac_address, oid_nama_interface, keterangan,
         tipe, brand, alamat, latitude, longitude, username_login, password_login, url_akses, jumlah_port,
         software_version, revisi, mac_address, ssh_port, ssh_username, ssh_password, ssh_command, olt_id))
    db.commit()
    jumlah_sync = _auto_sync_onu_dari_olt(db, olt_id)
    if jumlah_sync:
        flash(f"Perangkat OLT diperbarui, dan {jumlah_sync} ONU baru langsung tersinkron otomatis lewat SNMP.", "success")
    else:
        flash("Perangkat OLT diperbarui.", "success")
    if request.form.get("kembali_ke") == "login":
        return redirect(url_for("olt_login", olt_id=olt_id))
    return redirect(url_for("olt"))


@app.route("/olt/<int:olt_id>/test", methods=["POST"])
@login_required
def test_olt(olt_id):
    db = get_db()
    row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not row:
        return jsonify(ok=False, message="OLT tidak ditemukan.")
    try:
        client = _get_snmp_client(row)
        identity = client.test_koneksi()
        return jsonify(ok=True, message=f"Berhasil konek SNMP! Balasan sysDescr: {identity}")
    except SNMPError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal konek (error tak terduga): {e}")


def _parse_tabel_mac_onu(teks):
    """Parse teks hasil copy-paste dari SSH OLT (perintah semacam 'show mac address-table' /
    'show bridge mac-address-table' -- namanya beda-beda tiap merk, tapi bentuk baris tabelnya
    biasanya sama: index, MAC Address, VLAN, tipe (Dynamic/Static), age, lalu nama port ONU
    (mis. 'onu_0/1:18', 'epon0/1:5', dst).

    Dipakai untuk OLT yang OID SNMP privat vendornya tidak diketahui/tidak bisa diakses --
    solusi darurat: admin SSH manual ke OLT, copy hasil tabelnya, tempel di sini.

    Return list of dict: {mac, port_mentah, port_pon, onu_id, baris_asli}. Baris yang tidak
    cocok pola sederhana ini diabaikan (tidak fatal, cuma tidak ikut ke-import)."""
    pola_mac = re.compile(r"([0-9A-Fa-f]{2}(?:[:\-]?[0-9A-Fa-f]{2}){5})")
    pola_port = re.compile(r"(\d+)\s*/\s*(\d+)\s*[:.](\d+)")  # slot/port:onu_id
    hasil = []
    for baris in teks.splitlines():
        baris = baris.strip()
        if not baris:
            continue
        cocok_mac = pola_mac.search(baris)
        cocok_port = pola_port.search(baris)
        if not cocok_mac or not cocok_port:
            continue
        mac_mentah = cocok_mac.group(1).replace("-", ":").upper()
        # normalisasi jadi AA:BB:CC:DD:EE:FF kalau formatnya tanpa pemisah/beda gaya
        mac_bersih = re.sub(r"[^0-9A-F]", "", mac_mentah)
        if len(mac_bersih) != 12:
            continue
        mac = ":".join(mac_bersih[i:i + 2] for i in range(0, 12, 2))
        slot, port, onu_id = cocok_port.groups()
        hasil.append({
            "mac": mac,
            "port_mentah": f"onu_{slot}/{port}:{onu_id}",
            "port_pon": int(port),
            "onu_id": onu_id,
            "baris_asli": baris,
        })
    return hasil


@app.route("/olt/<int:olt_id>/import-mac", methods=["POST"])
@login_required
def import_mac_onu(olt_id):
    """Import ONU dari teks tabel MAC yang ditempel admin (hasil SSH ke OLT) -- alternatif
    untuk OLT yang OID SNMP-nya tidak diketahui/tidak bisa dipakai untuk auto-sync biasa."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        flash("Perangkat OLT tidak ditemukan.", "danger")
        return redirect(url_for("olt"))

    teks = request.form.get("teks_mac", "")
    temuan = _parse_tabel_mac_onu(teks)
    if not temuan:
        flash("Tidak ada baris yang cocok dikenali. Pastikan tabel berisi kolom MAC Address "
              "dan nama port ONU (format seperti 'onu_0/1:18'), lalu coba lagi.", "danger")
        return redirect(url_for("onu_list", olt_id=olt_id))

    baris_ada = {
        row["oid_index"]: row["id"]
        for row in db.execute("SELECT id, oid_index FROM onu WHERE olt_id=?", (olt_id,)).fetchall()
    }
    sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ditambahkan, diperbarui = 0, 0
    for t in temuan:
        if t["port_mentah"] in baris_ada:
            db.execute(
                "UPDATE onu SET mac_address=?, status_terakhir='online', dicek_terakhir=? WHERE id=?",
                (t["mac"], sekarang, baris_ada[t["port_mentah"]]))
            diperbarui += 1
        else:
            db.execute(
                """INSERT INTO onu (olt_id, label, oid_index, mac_address, port_pon,
                                     status_terakhir, dicek_terakhir)
                   VALUES (?,?,?,?,?, 'online', ?)""",
                (olt_id, t["port_mentah"], t["port_mentah"], t["mac"], t["port_pon"], sekarang))
            ditambahkan += 1
    db.commit()

    dilewati = len(teks.splitlines()) - len(temuan)
    pesan = f"Import selesai: {ditambahkan} ONU baru ditambahkan, {diperbarui} diperbarui."
    if dilewati > 0:
        pesan += f" ({dilewati} baris tidak dikenali formatnya, dilewati.)"
    flash(pesan, "success")
    return redirect(url_for("onu_list", olt_id=olt_id))


@app.route("/api/olt/<int:olt_id>/sync-ssh", methods=["POST"])
@login_required
def api_olt_sync_ssh(olt_id):
    """Versi otomatis dari 'Import dari SSH': konek sendiri ke OLT pakai kredensial yang
    tersimpan, jalankan perintah tabel MAC, lalu sinkronkan -- termasuk menandai ONU yang
    MAC-nya sudah tidak muncul lagi di tabel OLT sebagai 'offline' (bukan cuma nambah baris
    baru), supaya tombol ini benar-benar mencerminkan status OLT terkini, bukan snapshot beku."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        return jsonify(ok=False, message="OLT tidak ditemukan.")

    try:
        teks = olt_ssh.ambil_tabel_mac_ssh(dict(olt_row))
    except olt_ssh.SSHSyncError as e:
        return jsonify(ok=False, message=str(e))

    temuan = _parse_tabel_mac_onu(teks)
    if not temuan:
        return jsonify(ok=False, message=(
            "Konek SSH berhasil, tapi tidak ada baris yang dikenali dari hasil perintah "
            f"'{olt_row['ssh_command']}'. Cek lagi isi perintahnya di menu Edit OLT."))

    port_ditemukan_sekarang = {t["port_mentah"] for t in temuan}
    baris_ada = {
        row["oid_index"]: row
        for row in db.execute("SELECT * FROM onu WHERE olt_id=?", (olt_id,)).fetchall()
    }
    sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ditambahkan, diperbarui, dioffline = 0, 0, 0

    for t in temuan:
        if t["port_mentah"] in baris_ada:
            db.execute(
                "UPDATE onu SET mac_address=?, status_terakhir='online', dicek_terakhir=? WHERE id=?",
                (t["mac"], sekarang, baris_ada[t["port_mentah"]]["id"]))
            diperbarui += 1
        else:
            db.execute(
                """INSERT INTO onu (olt_id, label, oid_index, mac_address, port_pon,
                                     status_terakhir, dicek_terakhir)
                   VALUES (?,?,?,?,?, 'online', ?)""",
                (olt_id, t["port_mentah"], t["port_mentah"], t["mac"], t["port_pon"], sekarang))
            ditambahkan += 1

    # ONU yang berasal dari import/sync SSH (oid_index-nya berformat "onu_slot/port:id") tapi
    # MAC-nya sudah tidak ada lagi di tabel OLT saat ini -> tandai offline. ONU yang oid_index-nya
    # bukan dari SSH (mis. hasil scan SNMP manual dengan index numerik) sengaja tidak disentuh,
    # supaya sync SSH tidak menimpa data yang dikelola lewat jalur SNMP.
    for oid_index, row in baris_ada.items():
        if (oid_index.startswith("onu_") and oid_index not in port_ditemukan_sekarang
                and row["status_terakhir"] != "offline"):
            db.execute("UPDATE onu SET status_terakhir='offline', dicek_terakhir=? WHERE id=?",
                       (sekarang, row["id"]))
            dioffline += 1

    db.commit()
    pesan = f"Sync SSH berhasil: {ditambahkan} ONU baru, {diperbarui} online, {dioffline} jadi offline."
    return jsonify(ok=True, message=pesan)


@app.route("/olt/<int:olt_id>/onu", methods=["GET", "POST"])
@login_required
def onu_list(olt_id):
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        flash("Perangkat OLT tidak ditemukan.", "danger")
        return redirect(url_for("olt"))

    if request.method == "POST":
        label = request.form["label"].strip()
        oid_index = request.form["oid_index"].strip()
        serial_number = request.form.get("serial_number", "").strip()
        mac_address = request.form.get("mac_address", "").strip() or None
        pelanggan_id = request.form.get("pelanggan_id") or None
        port_pon = int(request.form.get("port_pon") or 1)
        db.execute(
            """INSERT INTO onu (olt_id, pelanggan_id, label, oid_index, serial_number, mac_address, port_pon)
               VALUES (?,?,?,?,?,?,?)""",
            (olt_id, pelanggan_id, label, oid_index, serial_number, mac_address, port_pon))
        db.commit()
        flash("ONU ditambahkan. Klik 'Cek Status Sekarang' untuk mengambil status via SNMP.", "success")
        return redirect(url_for("onu_list", olt_id=olt_id))

    filter_port = request.args.get("port", "").strip()
    query = """SELECT o.*, p.nama AS nama_pelanggan, p.username_pppoe
               FROM onu o LEFT JOIN pelanggan p ON p.id = o.pelanggan_id
               WHERE o.olt_id=?"""
    params = [olt_id]
    if filter_port:
        query += " AND o.port_pon=?"
        params.append(int(filter_port))
    query += " ORDER BY o.id DESC"
    daftar_onu = db.execute(query, params).fetchall()
    daftar_pelanggan = db.execute("SELECT id, nama, username_pppoe FROM pelanggan ORDER BY nama").fetchall()
    return render_template(
        "onu.html", olt_row=olt_row, daftar_onu=daftar_onu, daftar_pelanggan=daftar_pelanggan,
        filter_port=filter_port)


@app.route("/onu/hapus/<int:onu_id>", methods=["POST"])
@login_required
def hapus_onu(onu_id):
    db = get_db()
    row = db.execute("SELECT olt_id FROM onu WHERE id=?", (onu_id,)).fetchone()
    db.execute("DELETE FROM onu WHERE id=?", (onu_id,))
    db.commit()
    flash("ONU dihapus.", "success")
    return redirect(url_for("onu_list", olt_id=row["olt_id"] if row else 0))


@app.route("/onu/edit/<int:onu_id>", methods=["POST"])
@login_required
def edit_onu(onu_id):
    db = get_db()
    row = db.execute("SELECT * FROM onu WHERE id=?", (onu_id,)).fetchone()
    if not row:
        flash("ONU tidak ditemukan.", "danger")
        return redirect(url_for("olt"))
    label = request.form["label"].strip()
    oid_index = request.form["oid_index"].strip()
    serial_number = request.form.get("serial_number", "").strip()
    mac_address = request.form.get("mac_address", "").strip() or None
    pelanggan_id = request.form.get("pelanggan_id") or None
    port_pon = int(request.form.get("port_pon") or 1)
    db.execute(
        "UPDATE onu SET label=?, oid_index=?, serial_number=?, mac_address=?, pelanggan_id=?, port_pon=? WHERE id=?",
        (label, oid_index, serial_number, mac_address, pelanggan_id, port_pon, onu_id))
    db.commit()
    flash("ONU diperbarui.", "success")
    return redirect(url_for("onu_list", olt_id=row["olt_id"]))


@app.route("/api/olt/<int:olt_id>/scan", methods=["POST"])
@login_required
def api_olt_scan(olt_id):
    """SNMP GET status (dan RX power jika OID diisi) untuk semua ONU terdaftar di satu OLT."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        return jsonify(ok=False, message="OLT tidak ditemukan.", data=[])

    daftar_onu = db.execute("SELECT * FROM onu WHERE olt_id=?", (olt_id,)).fetchall()
    if not daftar_onu:
        return jsonify(ok=False, message="Belum ada ONU terdaftar untuk OLT ini.", data=[])

    client = _get_snmp_client(olt_row)
    hasil = []
    sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ada_error = None
    for onu_row in daftar_onu:
        status = "unknown"
        rx = None
        tx = None
        suhu = None
        mac = onu_row["mac_address"]  # pertahankan nilai manual kalau OID tidak diisi/gagal
        try:
            status_oid = f"{olt_row['oid_status'].rstrip('.')}.{onu_row['oid_index']}"
            nilai_status = client.get(status_oid)
            status = status_dari_nilai(nilai_status)
            if olt_row["oid_rx_power"]:
                rx_oid = f"{olt_row['oid_rx_power'].rstrip('.')}.{onu_row['oid_index']}"
                nilai_rx = client.get(rx_oid)
                if isinstance(nilai_rx, (int, float)):
                    rx = f"{nilai_rx / 10:.1f} dBm"
            if olt_row["oid_tx_power"]:
                tx_oid = f"{olt_row['oid_tx_power'].rstrip('.')}.{onu_row['oid_index']}"
                nilai_tx = client.get(tx_oid)
                if isinstance(nilai_tx, (int, float)):
                    tx = f"{nilai_tx / 10:.1f} dBm"
            if olt_row["oid_temperature"]:
                temp_oid = f"{olt_row['oid_temperature'].rstrip('.')}.{onu_row['oid_index']}"
                nilai_temp = client.get(temp_oid)
                if isinstance(nilai_temp, (int, float)):
                    suhu = f"{nilai_temp:.0f} °C"
            if olt_row["oid_mac_address"]:
                mac_oid = f"{olt_row['oid_mac_address'].rstrip('.')}.{onu_row['oid_index']}"
                nilai_mac = client.get(mac_oid)
                if isinstance(nilai_mac, str) and nilai_mac and nilai_mac not in ("noSuchObject", "noSuchInstance"):
                    mac = nilai_mac
        except SNMPError as e:
            ada_error = str(e)
            status = "unknown"

        db.execute(
            """UPDATE onu SET status_terakhir=?, rx_power_terakhir=?, tx_power_terakhir=?,
               temperatur_terakhir=?, mac_address=?, dicek_terakhir=? WHERE id=?""",
            (status, rx, tx, suhu, mac, sekarang, onu_row["id"]))
        hasil.append({
            "id": onu_row["id"], "label": onu_row["label"],
            "status": status, "rx_power": rx, "tx_power": tx, "temperatur": suhu,
            "mac_address": mac, "dicek_terakhir": sekarang,
        })
    db.commit()
    if ada_error and all(h["status"] == "unknown" for h in hasil):
        return jsonify(ok=False, message=f"Gagal SNMP ke OLT: {ada_error}", data=hasil)
    return jsonify(ok=True, message="Status ONU diperbarui.", data=hasil)


@app.route("/api/olt/<int:olt_id>/discover", methods=["POST"])
@login_required
def api_olt_discover(olt_id):
    """SNMP WALK ke tabel status (& nama interface kalau ada OID-nya) untuk menemukan
    SEMUA index ONU yang OLT punya -- dipakai fitur "Scan Otomatis" (mis. untuk re-sync
    manual kapan saja); auto-sync saat simpan pengaturan OLT memakai fungsi yang sama."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        return jsonify(ok=False, message="OLT tidak ditemukan.", data=[])
    try:
        data = _snmp_discover_onu(db, olt_row)
    except SNMPError as e:
        return jsonify(ok=False, message=f"Gagal SNMP WALK ke OLT: {e}", data=[])
    return jsonify(ok=True, message=f"Ditemukan {len(data)} entri dari OLT.", data=data)


@app.route("/olt/<int:olt_id>/onu/import", methods=["POST"])
@login_required
def import_onu(olt_id):
    """Tambahkan beberapa ONU sekaligus dari hasil "Scan Otomatis" (checkbox terpilih),
    supaya tidak perlu klik "Tambah ONU" satu-satu."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        flash("Perangkat OLT tidak ditemukan.", "danger")
        return redirect(url_for("olt"))

    daftar_index = request.form.getlist("oid_index")
    port_pon = int(request.form.get("port_pon") or 1)

    if not daftar_index:
        flash("Tidak ada ONU yang dicentang untuk ditambahkan.", "warning")
        return redirect(url_for("onu_list", olt_id=olt_id))

    sudah_terdaftar = {
        row["oid_index"] for row in db.execute("SELECT oid_index FROM onu WHERE olt_id=?", (olt_id,)).fetchall()
    }

    ditambahkan = 0
    for idx in daftar_index:
        idx = idx.strip()
        if not idx or idx in sudah_terdaftar:
            continue
        label = request.form.get(f"label_{idx}", "").strip()
        label_final = label or f"ONU {idx}"
        db.execute(
            """INSERT INTO onu (olt_id, label, oid_index, port_pon, status_terakhir)
               VALUES (?,?,?,?, 'unknown')""",
            (olt_id, label_final, idx, port_pon))
        sudah_terdaftar.add(idx)
        ditambahkan += 1

    db.commit()
    if ditambahkan:
        flash(f"{ditambahkan} ONU berhasil diimpor dari OLT. Klik 'Cek Status Sekarang' untuk "
              f"menarik status/redaman terbarunya, lalu hubungkan tiap ONU ke pelanggan lewat 'Edit'.", "success")
    else:
        flash("Semua ONU yang dicentang sudah terdaftar sebelumnya, tidak ada yang baru ditambahkan.", "warning")
    return redirect(url_for("onu_list", olt_id=olt_id))


def _ambil_system_info(olt_row):
    """GET beberapa OID sistem standar MIB-2 dari OLT. Setiap OID gagal -> None (tampil 'N/A' di UI),
    tidak menggagalkan seluruh halaman (banyak OLT hanya membuka sebagian OID lewat SNMP publik).
    Kalau OID pertama sudah timeout (host/IP tidak bisa dihubungi), OID selanjutnya langsung
    dilewati (bukan dicoba lagi satu per satu) -- OLT yang sama pasti akan timeout juga untuk
    OID lain, jadi tidak perlu menahan thread worker berkali-kali lipat dari nilai timeout."""
    info = {
        "system_name": None, "system_description": None, "system_address": None,
        "run_time": None, "error": None,
    }
    if not olt_row["host"]:
        info["error"] = "Host/IP SNMP OLT belum diisi. Isi lewat menu Edit OLT > Pengaturan SNMP."
        return info
    try:
        client = _get_snmp_client(olt_row)
        host_terhubung = True
        for kunci, oid in (
            ("system_name", OID_SYS_NAME),
            ("system_description", OID_SYS_DESCR),
            ("system_address", OID_SYS_LOCATION),
        ):
            if not host_terhubung:
                break
            try:
                info[kunci] = client.get(oid)
            except SNMPError:
                host_terhubung = False
        if host_terhubung:
            try:
                uptime_raw = client.get(OID_SYS_UPTIME)
                info["run_time"] = format_uptime(uptime_raw) if uptime_raw is not None else None
            except SNMPError:
                pass
        if not any([info["system_name"], info["system_description"], info["system_address"], info["run_time"]]):
            info["error"] = "OLT tidak merespon SNMP (cek IP/community, atau OID sistem tidak dibuka OLT ini)."
    except Exception as e:
        info["error"] = f"Gagal menghubungi OLT: {e}"
    return info


def _ambil_ringkasan_port(db, olt_id):
    """Kelompokkan ONU per port PON (mis. 0/1, 0/2, ...) untuk kartu status ala panel MSRadius."""
    baris = db.execute(
        """SELECT COALESCE(port_pon, 1) AS port, COUNT(*) AS total,
                  SUM(CASE WHEN status_terakhir='online' THEN 1 ELSE 0 END) AS online
           FROM onu WHERE olt_id=? GROUP BY COALESCE(port_pon, 1) ORDER BY port""",
        (olt_id,)).fetchall()
    hasil = []
    for row in baris:
        total = row["total"] or 0
        online = row["online"] or 0
        hasil.append({"port": row["port"], "total": total, "online": online, "offline": total - online})
    return hasil


@app.route("/olt/<int:olt_id>/login")
@login_required
def olt_login(olt_id):
    """Panel 'Login OLT' native — menampilkan System Information, CPU & Memory, dan status
    per port PON langsung di dalam billing portal (gaya dashboard MSRadius), tanpa iframe
    embed ke situs OLT eksternal yang sering diblokir/kosong saat ditampilkan tertanam."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        flash("Perangkat OLT tidak ditemukan.", "danger")
        return redirect(url_for("olt"))

    system_info = _ambil_system_info(olt_row)
    ringkasan_port = _ambil_ringkasan_port(db, olt_id)
    waktu_sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return render_template(
        "olt_login.html", olt_row=olt_row, system_info=system_info,
        ringkasan_port=ringkasan_port, waktu_sekarang=waktu_sekarang)


@app.route("/api/olt/<int:olt_id>/systeminfo")
@login_required
def api_olt_systeminfo(olt_id):
    """Versi AJAX dari data panel Login OLT, dipakai tombol 'Refresh' tanpa reload halaman."""
    db = get_db()
    olt_row = db.execute("SELECT * FROM olt_device WHERE id=?", (olt_id,)).fetchone()
    if not olt_row:
        return jsonify(ok=False, message="OLT tidak ditemukan.")
    system_info = _ambil_system_info(olt_row)
    ringkasan_port = _ambil_ringkasan_port(db, olt_id)
    return jsonify(
        ok=True, system_info=system_info, ringkasan_port=ringkasan_port,
        waktu_sekarang=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


@app.route("/monitoring")
@login_required
def monitoring():
    """Gabungan status jaringan: PPPoE aktif (Mikrotik) + status ONU (OLT) per pelanggan."""
    db = get_db()
    daftar = db.execute(
        """SELECT p.id, p.nama, p.username_pppoe, p.status AS status_billing,
                  o.label AS onu_label, o.status_terakhir AS onu_status,
                  o.rx_power_terakhir, o.dicek_terakhir, od.nama AS nama_olt
           FROM pelanggan p
           LEFT JOIN onu o ON o.pelanggan_id = p.id
           LEFT JOIN olt_device od ON od.id = o.olt_id
           ORDER BY p.nama"""
    ).fetchall()
    return render_template("monitoring.html", daftar=daftar)


@app.route("/api/mikrotik/profiles")
@login_required
def api_mikrotik_profiles():
    """Ambil daftar nama PPP Profile yang sudah ada di Mikrotik (untuk dropdown di form Paket)."""
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.", profiles=[])
    try:
        client.connect()
        data = client.talk(["/ppp/profile/print"])
        client.close()
        profiles = [d.get("name") for d in data if d.get("name")]
        return jsonify(ok=True, profiles=profiles)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), profiles=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", profiles=[])


@app.route("/api/mikrotik/ppp-profiles-detail")
@admin_atau_reseller_required
def api_ppp_profiles_detail():
    """Ambil daftar Profil PPPoE (PPP Profile) lengkap dengan detailnya dari Mikrotik,
    dipakai untuk tabel kelola Profil PPPoE di halaman Paket Internet (admin) maupun
    tab Profiles di menu PPPoE reseller (wajib kirim router_id miliknya sendiri)."""
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe, data=[])
    try:
        data = client.get_ppp_profiles()
        hasil = [{
            "name": d.get("name", "-"),
            "local_address": d.get("local-address", ""),
            "remote_address": d.get("remote-address", ""),
            "rate_limit": d.get("rate-limit", ""),
            "only_one": d.get("only-one", ""),
            "parent_queue": d.get("parent-queue", ""),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/ppp-profiles/simpan", methods=["POST"])
@admin_atau_reseller_required
def api_ppp_profile_simpan():
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe), 400
    name = request.form.get("name", "").strip()
    local_address = request.form.get("local_address", "").strip()
    remote_address = request.form.get("remote_address", "").strip()
    rate_limit = request.form.get("rate_limit", "").strip()
    only_one = request.form.get("only_one", "").strip()
    parent_queue = request.form.get("parent_queue", "").strip()
    if not name:
        return jsonify(ok=False, message="Nama Profil PPPoE wajib diisi.")
    try:
        client.add_or_update_ppp_profile(
            name=name, local_address=local_address, remote_address=remote_address,
            rate_limit=rate_limit, only_one=only_one, parent_queue=parent_queue)
        return jsonify(ok=True, message=f"Profil PPPoE '{name}' berhasil disimpan.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/ppp-profiles/hapus", methods=["POST"])
@admin_atau_reseller_required
def api_ppp_profile_hapus():
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe), 400
    name = request.form.get("name", "").strip()
    try:
        client.remove_ppp_profile(name)
        return jsonify(ok=True, message=f"Profil PPPoE '{name}' dihapus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/pppoe-secrets")
@admin_atau_reseller_required
def api_pppoe_secrets():
    """Ambil daftar PPP Secret (mentah, langsung dari Mikrotik) untuk tab Secrets
    di menu PPPoE reseller (wajib router_id miliknya sendiri) maupun admin."""
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe, data=[])
    try:
        data = client.get_ppp_secrets()
        hasil = [{
            "name": d.get("name", "-"),
            "password": d.get("password", ""),
            "profile": d.get("profile", "-"),
            "service": d.get("service", "-"),
            "comment": d.get("comment", ""),
            "disabled": d.get("disabled", "false"),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/pppoe-secrets/simpan", methods=["POST"])
@admin_atau_reseller_required
def api_pppoe_secret_simpan():
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe), 400
    name = request.form.get("name", "").strip()
    password = request.form.get("password", "").strip()
    profile = request.form.get("profile", "").strip()
    service = request.form.get("service", "pppoe").strip() or "pppoe"
    comment = request.form.get("comment", "").strip()
    if not name or not password or not profile:
        return jsonify(ok=False, message="Username, password, dan profile wajib diisi.")
    try:
        client.add_or_update_secret(name=name, password=password, profile=profile,
                                     service=service, comment=comment)
        _catat_aktivitas("pppoe", "Simpan PPP Secret", name)
        return jsonify(ok=True, message=f"Secret '{name}' berhasil disimpan.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/pppoe-secrets/hapus", methods=["POST"])
@admin_atau_reseller_required
def api_pppoe_secret_hapus():
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe), 400
    name = request.form.get("name", "").strip()
    try:
        client.remove_secret(name)
        _catat_aktivitas("pppoe", "Hapus PPP Secret", name)
        return jsonify(ok=True, message=f"Secret '{name}' dihapus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/pppoe-secrets/toggle", methods=["POST"])
@admin_atau_reseller_required
def api_pppoe_secret_toggle():
    """Aktifkan/nonaktifkan (isolir) 1 PPP Secret langsung dari tab Secrets."""
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe), 400
    name = request.form.get("name", "").strip()
    aksi = request.form.get("aksi", "").strip()  # 'disable' atau 'enable'
    if not name or aksi not in ("disable", "enable"):
        return jsonify(ok=False, message="Data tidak lengkap.")
    try:
        client.set_secret_disabled(name, disabled=(aksi == "disable"))
        pesan = "dinonaktifkan" if aksi == "disable" else "diaktifkan"
        _catat_aktivitas("pppoe", f"PPP Secret {pesan.capitalize()}", name)
        return jsonify(ok=True, message=f"Secret '{name}' berhasil {pesan}.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/pppoe-active")
@admin_atau_reseller_required
def api_pppoe_active():
    """Ambil daftar sesi PPPoE yang sedang online (real-time) untuk tab Active
    Connections di menu PPPoE reseller (wajib router_id miliknya sendiri) maupun admin."""
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe, data=[])
    try:
        data = client.get_active_connections()
        hasil = [{
            "id": d.get(".id", ""),
            "user": d.get("name", "-"),
            "address": d.get("address", "-"),
            "caller_id": d.get("caller-id", "-"),
            "uptime": d.get("uptime", "-"),
            "service": d.get("service", "-"),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/pppoe-active/putus", methods=["POST"])
@admin_atau_reseller_required
def api_pppoe_active_putus():
    client, _err_pppoe = _client_hotspot_dari_permintaan()
    if not client:
        return jsonify(ok=False, message=_err_pppoe), 400
    session_id = request.form.get("id", "").strip()
    try:
        client.kick_ppp_active(session_id)
        _catat_aktivitas("pppoe", "Putus Sesi PPPoE", session_id)
        return jsonify(ok=True, message="Sesi PPPoE berhasil diputus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/simple-queues")
@login_required
def api_simple_queues():
    """Ambil daftar Simple Queue lengkap dengan detailnya dari Mikrotik,
    dipakai untuk tabel kelola Simple Queue di halaman Paket Internet."""
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi/disimpan.", data=[])
    try:
        data = client.get_simple_queues()
        hasil = [{
            "name": d.get("name", "-"),
            "target": d.get("target", ""),
            "max_limit": d.get("max-limit", ""),
            "burst_limit": d.get("burst-limit", ""),
            "burst_threshold": d.get("burst-threshold", ""),
            "burst_time": d.get("burst-time", ""),
            "limit_at": d.get("limit-at", ""),
            "priority": d.get("priority", ""),
            "comment": d.get("comment", ""),
            "disabled": d.get("disabled", "false"),
        } for d in data]
        return jsonify(ok=True, data=hasil)
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e), data=[])
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}", data=[])


@app.route("/api/mikrotik/simple-queues/simpan", methods=["POST"])
@login_required
def api_simple_queue_simpan():
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi."), 400
    name = request.form.get("name", "").strip()
    target = request.form.get("target", "").strip()
    max_limit = request.form.get("max_limit", "").strip()
    burst_limit = request.form.get("burst_limit", "").strip()
    burst_threshold = request.form.get("burst_threshold", "").strip()
    burst_time = request.form.get("burst_time", "").strip()
    limit_at = request.form.get("limit_at", "").strip()
    priority = request.form.get("priority", "").strip()
    comment = request.form.get("comment", "").strip()
    if not name:
        return jsonify(ok=False, message="Nama Simple Queue wajib diisi.")
    if not target:
        return jsonify(ok=False, message="Target (IP/Subnet) wajib diisi.")
    try:
        client.add_or_update_simple_queue(
            name=name, target=target, max_limit=max_limit, burst_limit=burst_limit,
            burst_threshold=burst_threshold, burst_time=burst_time, limit_at=limit_at,
            priority=priority, comment=comment)
        return jsonify(ok=True, message=f"Simple Queue '{name}' berhasil disimpan.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/simple-queues/hapus", methods=["POST"])
@login_required
def api_simple_queue_hapus():
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi."), 400
    name = request.form.get("name", "").strip()
    try:
        client.remove_simple_queue(name)
        return jsonify(ok=True, message=f"Simple Queue '{name}' dihapus.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/api/mikrotik/simple-queues/toggle", methods=["POST"])
@login_required
def api_simple_queue_toggle():
    client = _get_mikrotik_client()
    if not client:
        return jsonify(ok=False, message="Pengaturan Mikrotik belum diisi."), 400
    name = request.form.get("name", "").strip()
    disabled = request.form.get("disabled", "") == "1"
    try:
        client.set_simple_queue_disabled(name, disabled=disabled)
        status = "dinonaktifkan" if disabled else "diaktifkan"
        return jsonify(ok=True, message=f"Simple Queue '{name}' {status}.")
    except RouterOSError as e:
        return jsonify(ok=False, message=str(e))
    except Exception as e:
        return jsonify(ok=False, message=f"Error tak terduga: {e}")


@app.route("/pengaturan/logo", methods=["POST"])
@login_required
def upload_logo():
    db = get_db()
    nama_aplikasi = request.form.get("nama_aplikasi", "").strip()
    alamat = request.form.get("alamat", "").strip() or None
    telepon = request.form.get("telepon", "").strip() or None
    file = request.files.get("logo")

    if nama_aplikasi:
        db.execute("UPDATE pengaturan_umum SET nama_aplikasi=?, alamat=?, telepon=? WHERE id=1",
                   (nama_aplikasi, alamat, telepon))
        db.commit()

    if file and file.filename:
        ekstensi = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
        if ekstensi not in EKSTENSI_LOGO_DIIZINKAN:
            flash("Format logo tidak didukung. Gunakan PNG, JPG, JPEG, WEBP, GIF, atau BMP.", "danger")
            return redirect(url_for("pengaturan_admin"))

        # buka gambar apapun formatnya, lalu konversi & simpan sebagai PNG
        try:
            gambar = Image.open(file.stream)
            gambar = gambar.convert("RGBA")
        except UnidentifiedImageError:
            flash("File yang diupload bukan gambar yang valid.", "danger")
            return redirect(url_for("pengaturan_admin"))
        except Exception as e:
            flash(f"Gagal memproses gambar logo: {e}", "danger")
            return redirect(url_for("pengaturan_admin"))

        row = db.execute("SELECT logo_path FROM pengaturan_umum WHERE id=1").fetchone()
        logo_lama = row["logo_path"] if row else None

        nama_file = secure_filename(f"logo_{secrets.token_hex(6)}.png")
        gambar.save(os.path.join(UPLOAD_FOLDER, nama_file), format="PNG")
        logo_path_baru = f"uploads/{nama_file}"

        db.execute("UPDATE pengaturan_umum SET logo_path=? WHERE id=1", (logo_path_baru,))
        db.commit()

        if logo_lama:
            path_lama = os.path.join(app.root_path, "static", logo_lama)
            if os.path.isfile(path_lama):
                try:
                    os.remove(path_lama)
                except OSError:
                    pass

        flash("Logo aplikasi berhasil diperbarui (otomatis dikonversi ke format PNG).", "success")
    elif nama_aplikasi:
        flash("Nama aplikasi berhasil diperbarui.", "success")

    return redirect(url_for("pengaturan_admin"))


@app.route("/pengaturan/logo/hapus", methods=["POST"])
@login_required
def hapus_logo():
    db = get_db()
    row = db.execute("SELECT logo_path FROM pengaturan_umum WHERE id=1").fetchone()
    if row and row["logo_path"]:
        path_lama = os.path.join(app.root_path, "static", row["logo_path"])
        if os.path.isfile(path_lama):
            try:
                os.remove(path_lama)
            except OSError:
                pass
        db.execute("UPDATE pengaturan_umum SET logo_path=NULL WHERE id=1")
        db.commit()
        flash("Logo aplikasi dihapus, kembali ke logo bawaan.", "success")
    return redirect(url_for("pengaturan_admin"))


@app.route("/pengaturan/avatar", methods=["POST"])
@login_required
def upload_avatar():
    """Upload foto profil (avatar) untuk admin yang sedang login, ditampilkan di topbar."""
    db = get_db()
    file = request.files.get("avatar")
    if not file or not file.filename:
        flash("Pilih file foto dulu.", "danger")
        return redirect(url_for("pengaturan_admin"))

    ekstensi = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ekstensi not in EKSTENSI_LOGO_DIIZINKAN:
        flash("Format foto tidak didukung. Gunakan PNG, JPG, JPEG, WEBP, GIF, atau BMP.", "danger")
        return redirect(url_for("pengaturan_admin"))

    try:
        gambar = Image.open(file.stream)
        gambar = gambar.convert("RGBA")
    except UnidentifiedImageError:
        flash("File yang diupload bukan gambar yang valid.", "danger")
        return redirect(url_for("pengaturan_admin"))
    except Exception as e:
        flash(f"Gagal memproses foto: {e}", "danger")
        return redirect(url_for("pengaturan_admin"))

    # crop persegi (dari tengah) & perkecil supaya avatar konsisten & ringan
    lebar, tinggi = gambar.size
    sisi = min(lebar, tinggi)
    kiri, atas = (lebar - sisi) // 2, (tinggi - sisi) // 2
    gambar = gambar.crop((kiri, atas, kiri + sisi, atas + sisi)).resize((256, 256))

    row = db.execute("SELECT avatar_path FROM admin WHERE id=?", (session["admin_id"],)).fetchone()
    avatar_lama = row["avatar_path"] if row else None

    nama_file = secure_filename(f"avatar_{session['admin_id']}_{secrets.token_hex(6)}.png")
    gambar.save(os.path.join(UPLOAD_FOLDER, nama_file), format="PNG")
    avatar_path_baru = f"uploads/{nama_file}"

    db.execute("UPDATE admin SET avatar_path=? WHERE id=?", (avatar_path_baru, session["admin_id"]))
    db.commit()

    if avatar_lama:
        path_lama = os.path.join(app.root_path, "static", avatar_lama)
        if os.path.isfile(path_lama):
            try:
                os.remove(path_lama)
            except OSError:
                pass

    flash("Foto profil berhasil diperbarui.", "success")
    return redirect(url_for("pengaturan_admin"))


@app.route("/pengaturan/avatar/hapus", methods=["POST"])
@login_required
def hapus_avatar():
    db = get_db()
    row = db.execute("SELECT avatar_path FROM admin WHERE id=?", (session["admin_id"],)).fetchone()
    if row and row["avatar_path"]:
        path_lama = os.path.join(app.root_path, "static", row["avatar_path"])
        if os.path.isfile(path_lama):
            try:
                os.remove(path_lama)
            except OSError:
                pass
        db.execute("UPDATE admin SET avatar_path=NULL WHERE id=?", (session["admin_id"],))
        db.commit()
        flash("Foto profil dihapus, kembali ke ikon bawaan.", "success")
    return redirect(url_for("pengaturan_admin"))


@app.route("/pengaturan/backup")
@login_required
def backup_database():
    """Unduh salinan lengkap database saat ini (untuk cadangan/backup)."""
    db = get_db()
    db.commit()  # pastikan semua perubahan tersimpan sebelum disalin

    buffer = io.BytesIO()
    tmp_path = os.path.join(tempfile.gettempdir(), f"billing_backup_{secrets.token_hex(6)}.db")
    try:
        sumber = sqlite3.connect(DB_PATH)
        tujuan = sqlite3.connect(tmp_path)
        with tujuan:
            sumber.backup(tujuan)  # penyalinan aman/konsisten meski db sedang dipakai
        sumber.close()
        tujuan.close()
        with open(tmp_path, "rb") as f:
            buffer.write(f.read())
        buffer.seek(0)
    finally:
        if os.path.isfile(tmp_path):
            os.remove(tmp_path)

    nama_file = f"backup_billing_{datetime.now():%Y%m%d_%H%M%S}.db"
    return send_file(buffer, as_attachment=True, download_name=nama_file, mimetype="application/octet-stream")


@app.route("/pengaturan/restore", methods=["POST"])
@login_required
def restore_database():
    """Pulihkan database dari file backup (.db) yang diupload, menimpa seluruh data saat ini."""
    file = request.files.get("file_backup")
    if not file or not file.filename:
        flash("Pilih file backup (.db) terlebih dahulu.", "danger")
        return redirect(url_for("pengaturan_admin"))

    ekstensi = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ekstensi not in EKSTENSI_BACKUP_DIIZINKAN:
        flash("Format file tidak didukung. Gunakan file .db hasil backup dari aplikasi ini.", "danger")
        return redirect(url_for("pengaturan_admin"))

    tmp_path = os.path.join(tempfile.gettempdir(), f"restore_{secrets.token_hex(6)}.db")
    file.save(tmp_path)

    # validasi: pastikan file yang diupload benar file database billing yang valid
    try:
        cek = sqlite3.connect(tmp_path)
        tabel_ada = {row[0] for row in cek.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        cek.close()
    except sqlite3.DatabaseError:
        os.remove(tmp_path)
        flash("File yang diupload bukan file database SQLite yang valid.", "danger")
        return redirect(url_for("pengaturan_admin"))

    if not TABEL_WAJIB_BACKUP.issubset(tabel_ada):
        os.remove(tmp_path)
        flash("File database tidak cocok. Pastikan file ini adalah hasil backup dari aplikasi billing ini.", "danger")
        return redirect(url_for("pengaturan_admin"))

    # tutup koneksi db yang aktif pada request ini sebelum file database ditimpa
    close_db()

    # buat cadangan otomatis dari database yang sedang berjalan, untuk jaga-jaga sebelum ditimpa
    try:
        nama_cadangan = f"sebelum_restore_{datetime.now():%Y%m%d_%H%M%S}.db"
        shutil.copy2(DB_PATH, os.path.join(BACKUP_FOLDER, nama_cadangan))
    except OSError:
        pass

    shutil.move(tmp_path, DB_PATH)

    session.clear()  # data admin bisa berubah setelah restore, minta login ulang demi keamanan
    flash("Database berhasil dipulihkan dari file backup. Silakan login kembali.", "success")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Domain / Akses Online (Cloudflare Tunnel) -- setup lewat web, tanpa CMD
# ---------------------------------------------------------------------------
_status_login_cloudflare = {"berjalan": False, "pesan_error": None}


def _cari_cloudflared():
    """Cari executable cloudflared: di PATH sistem, atau di folder aplikasi ini
    (cloudflared.exe / cloudflared) -- sama seperti logika di start_tunnel.bat/.sh."""
    ditemukan = shutil.which("cloudflared")
    if ditemukan:
        return ditemukan
    folder = os.path.dirname(os.path.abspath(__file__))
    for nama in ("cloudflared.exe", "cloudflared"):
        kandidat = os.path.join(folder, nama)
        if os.path.isfile(kandidat):
            return kandidat
    return None


def _path_cert_cloudflare():
    """Lokasi cert.pem yang dibuat cloudflared setelah 'tunnel login' berhasil."""
    return os.path.join(os.path.expanduser("~"), ".cloudflared", "cert.pem")


def _sudah_login_cloudflare():
    return os.path.isfile(_path_cert_cloudflare())


def _baca_info_tunnel():
    """Baca tunnel_info.txt (HOSTNAME=... / TUNNEL_NAME=...) kalau ada."""
    if not os.path.isfile(TUNNEL_INFO_PATH):
        return None, None
    hostname, nama_tunnel = None, None
    try:
        with open(TUNNEL_INFO_PATH, "r", encoding="utf-8") as f:
            for baris in f:
                baris = baris.strip()
                if baris.startswith("HOSTNAME="):
                    hostname = baris.split("=", 1)[1].strip()
                elif baris.startswith("TUNNEL_NAME="):
                    nama_tunnel = baris.split("=", 1)[1].strip()
    except OSError:
        return None, None
    if not hostname or not nama_tunnel:
        return None, None
    return hostname, nama_tunnel


def _tulis_info_tunnel(hostname, nama_tunnel):
    with open(TUNNEL_INFO_PATH, "w", encoding="utf-8") as f:
        f.write(f"HOSTNAME={hostname}\nTUNNEL_NAME={nama_tunnel}\n")


def _slug_nama_tunnel(nama_aplikasi):
    s = re.sub(r"[^a-z0-9]+", "-", (nama_aplikasi or "").lower()).strip("-")
    return (s or "billing") + "-tunnel"


def _jalankan_cloudflared(cloudflared_path, *args, timeout=45):
    """Jalankan perintah cloudflared, tunggu selesai, kembalikan (ok, output_gabungan)."""
    kwargs = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        hasil = subprocess.run(
            [cloudflared_path, *args], cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=True, text=True, timeout=timeout, **kwargs)
        keluaran = (hasil.stdout or "") + (hasil.stderr or "")
        return hasil.returncode == 0, keluaran.strip()
    except subprocess.TimeoutExpired:
        return False, "Perintah cloudflared tidak merespon (timeout)."
    except Exception as e:
        return False, f"Gagal menjalankan cloudflared: {e}"


@app.route("/pengaturan/domain")
@login_required
def pengaturan_domain():
    cloudflared_path = _cari_cloudflared()
    hostname, nama_tunnel = _baca_info_tunnel()
    return render_template(
        "pengaturan_domain.html",
        cloudflared_ditemukan=bool(cloudflared_path),
        sudah_login=_sudah_login_cloudflare(),
        hostname=hostname,
        nama_tunnel=nama_tunnel,
    )


@app.route("/pengaturan/domain/cek-cloudflared")
@login_required
def cek_cloudflared():
    path = _cari_cloudflared()
    return jsonify(ditemukan=bool(path), path=path, sudah_login=_sudah_login_cloudflare())


@app.route("/pengaturan/domain/login", methods=["POST"])
@login_required
def login_cloudflare():
    cloudflared_path = _cari_cloudflared()
    if not cloudflared_path:
        return jsonify(ok=False, message="cloudflared belum ditemukan di komputer ini. Install dulu (lihat petunjuk di halaman ini).")
    if _sudah_login_cloudflare():
        return jsonify(ok=True, message="Sudah login sebelumnya.", sudah_login=True)
    if _status_login_cloudflare["berjalan"]:
        return jsonify(ok=True, message="Proses login sedang berjalan, selesaikan dulu di jendela browser yang terbuka.")

    def _proses_login():
        _status_login_cloudflare["berjalan"] = True
        _status_login_cloudflare["pesan_error"] = None
        kwargs = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        try:
            subprocess.run(
                [cloudflared_path, "tunnel", "login"],
                cwd=os.path.dirname(os.path.abspath(__file__)),
                capture_output=True, text=True, timeout=300, **kwargs)
        except subprocess.TimeoutExpired:
            _status_login_cloudflare["pesan_error"] = "Waktu login habis (5 menit). Coba lagi."
        except Exception as e:
            _status_login_cloudflare["pesan_error"] = str(e)
        finally:
            _status_login_cloudflare["berjalan"] = False

    threading.Thread(target=_proses_login, daemon=True).start()
    return jsonify(ok=True, message="Membuka browser untuk login ke akun Cloudflare kamu. Selesaikan proses login di tab yang terbuka, lalu kembali ke sini.")


@app.route("/pengaturan/domain/login-status")
@login_required
def status_login_cloudflare():
    return jsonify(
        sedang_login=_status_login_cloudflare["berjalan"],
        sudah_login=_sudah_login_cloudflare(),
        pesan_error=_status_login_cloudflare["pesan_error"],
    )


@app.route("/pengaturan/domain/hubungkan", methods=["POST"])
@login_required
def hubungkan_domain():
    hostname = request.form.get("hostname", "").strip().lower()
    if not hostname or "." not in hostname:
        return jsonify(ok=False, message="Masukkan subdomain lengkap yang valid, contoh: billing.namadomainkamu.com")

    cloudflared_path = _cari_cloudflared()
    if not cloudflared_path:
        return jsonify(ok=False, message="cloudflared belum ditemukan di komputer ini.")
    if not _sudah_login_cloudflare():
        return jsonify(ok=False, message="Login ke Cloudflare dulu sebelum menghubungkan domain.")

    # pakai nama tunnel yang sudah ada (kalau sebelumnya pernah disetel lewat
    # web ini ATAU lewat setup_tunnel_pertama_kali.bat/.sh), supaya tidak bikin
    # tunnel baru terus-menerus tiap kali disetel ulang.
    _, nama_tunnel_lama = _baca_info_tunnel()
    nama_aplikasi = _ambil_nama_aplikasi()
    nama_tunnel = nama_tunnel_lama or _slug_nama_tunnel(nama_aplikasi)

    ok_buat, keluaran_buat = _jalankan_cloudflared(cloudflared_path, "tunnel", "create", nama_tunnel)
    if not ok_buat and "already exists" not in keluaran_buat.lower():
        return jsonify(ok=False, message=f"Gagal membuat tunnel: {keluaran_buat}")

    port = int(os.environ.get("PORT", "80"))
    ok_route, keluaran_route = _jalankan_cloudflared(cloudflared_path, "tunnel", "route", "dns", nama_tunnel, hostname)
    if not ok_route:
        if "1003" in keluaran_route or "already exists" in keluaran_route.lower():
            return jsonify(ok=False, message=(
                f"Domain {hostname} sudah punya record DNS lain di Cloudflare (kemungkinan sisa setup lama), "
                "jadi tidak bisa dihubungkan ke tunnel ini.\n\n"
                "Cara perbaiki: buka dash.cloudflare.com > pilih domainnya > menu DNS > Records, "
                f"cari record dengan Name \"{hostname.split('.')[0]}\", hapus record itu, lalu klik Hubungkan lagi di sini."
            ))
        return jsonify(ok=False, message=f"Gagal menghubungkan domain {hostname}: {keluaran_route}\n\nPastikan domainnya memang terdaftar di akun Cloudflare yang tadi kamu login.")

    _tulis_info_tunnel(hostname, nama_tunnel)
    return jsonify(ok=True, message=f"Berhasil! Link online kamu: https://{hostname}", hostname=hostname, link_lokal=f"http://localhost:{port}")


@app.route("/pengaturan/domain/hapus", methods=["POST"])
@login_required
def hapus_domain():
    if os.path.isfile(TUNNEL_INFO_PATH):
        try:
            os.remove(TUNNEL_INFO_PATH)
        except OSError:
            pass
        flash("Pengaturan domain online dihapus. Domain lama tidak lagi terhubung ke aplikasi ini (tunnel-nya sendiri masih ada di akun Cloudflare kamu kalau mau dipakai lagi nanti).", "success")
    return redirect(url_for("pengaturan_domain"))


# ---------------------------------------------------------------------------
# About / Cek Update
# ---------------------------------------------------------------------------
def _baca_pengaturan_update(db):
    row = db.execute("SELECT * FROM pengaturan_update WHERE id=1").fetchone()
    if row:
        return dict(row)
    return {"manifest_url": "", "versi_terbaru": None, "catatan_terbaru": None,
            "download_url": None, "changelog_json": None, "terakhir_dicek": None,
            "terakhir_pasang": None}


def _versi_ke_tuple(v):
    """Ubah string versi 'x.y.z' jadi tuple angka supaya bisa dibandingkan
    (lebih besar/kecil), bukan dibandingkan sebagai teks."""
    bagian = re.findall(r"\d+", v or "")
    return tuple(int(b) for b in bagian) or (0,)


@app.route("/about")
@login_required
def about():
    db = get_db()
    pu = _baca_pengaturan_update(db)
    try:
        changelog_online = json.loads(pu["changelog_json"]) if pu["changelog_json"] else None
    except (TypeError, ValueError):
        changelog_online = None
    ada_update = False
    if pu["versi_terbaru"]:
        ada_update = _versi_ke_tuple(pu["versi_terbaru"]) > _versi_ke_tuple(APP_VERSION)
    return render_template(
        "about.html",
        versi_lokal=APP_VERSION,
        python_version=sys.version.split()[0],
        pu=pu,
        ada_update=ada_update,
        changelog=changelog_online or CHANGELOG_BAWAAN,
    )


@app.route("/about/simpan-manifest", methods=["POST"])
@login_required
def about_simpan_manifest():
    db = get_db()
    manifest_url = request.form.get("manifest_url", "").strip()
    db.execute("UPDATE pengaturan_update SET manifest_url=? WHERE id=1", (manifest_url,))
    db.commit()
    flash("URL manifest update disimpan.", "success")
    return redirect(url_for("about"))


@app.route("/about/cek-update", methods=["POST"])
@login_required
def about_cek_update():
    """Tombol 'Cek Update' -- ambil file manifest JSON dari URL yang admin isi sendiri
    (bukan server Anthropic), lalu bandingkan versinya dengan versi lokal.
    Format manifest yang diharapkan (JSON):
        {
          "version": "1.2.0",
          "notes": "Ringkasan singkat rilis ini",
          "download_url": "https://.../billing-portal-safenode-1.2.0.zip",
          "changelog": [
            {"tanggal": "2026-09-01", "catatan": ["Poin 1", "Poin 2"]}
          ]
        }
    """
    db = get_db()
    pu = _baca_pengaturan_update(db)
    manifest_url = request.form.get("manifest_url", "").strip() or pu["manifest_url"]
    if not manifest_url:
        return jsonify(ok=False, message="Isi dulu URL manifest update-nya (lihat catatan di bawah form).")
    if not manifest_url.lower().startswith(("http://", "https://")):
        return jsonify(ok=False, message="URL manifest harus diawali http:// atau https://")

    try:
        req = urllib.request.Request(manifest_url, headers={"User-Agent": "SafeNode-UpdateChecker/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        return jsonify(ok=False, message=f"Gagal mengakses URL manifest: {e}")
    except (ValueError, json.JSONDecodeError):
        return jsonify(ok=False, message="Isi file manifest bukan format JSON yang valid.")
    except Exception as e:
        return jsonify(ok=False, message=f"Gagal cek update: {e}")

    versi_terbaru = str(data.get("version", "")).strip()
    if not versi_terbaru:
        return jsonify(ok=False, message="Manifest tidak punya field 'version'.")
    catatan_terbaru = str(data.get("notes", "")).strip()
    download_url = str(data.get("download_url", "")).strip()
    changelog = data.get("changelog") or []

    sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        """UPDATE pengaturan_update
           SET manifest_url=?, versi_terbaru=?, catatan_terbaru=?, download_url=?,
               changelog_json=?, terakhir_dicek=? WHERE id=1""",
        (manifest_url, versi_terbaru, catatan_terbaru, download_url,
         json.dumps(changelog), sekarang))
    db.commit()
    _catat_aktivitas("sistem", "Cek Update", f"Versi terbaru: {versi_terbaru} (lokal: {APP_VERSION})")

    ada_update = _versi_ke_tuple(versi_terbaru) > _versi_ke_tuple(APP_VERSION)
    return jsonify(ok=True, ada_update=ada_update, versi_lokal=APP_VERSION,
                   versi_terbaru=versi_terbaru, catatan_terbaru=catatan_terbaru,
                   download_url=download_url, changelog=changelog, terakhir_dicek=sekarang)


_progress_lock = threading.Lock()
_progress_pasang_update = {
    "berjalan": False, "persen": 0, "tahap": "", "selesai": True,
    "ok": None, "pesan": "",
}


def _set_progress_update(**kwargs):
    with _progress_lock:
        _progress_pasang_update.update(kwargs)


def _proses_pasang_update_bg(download_url, folder_app, pelaku, versi_terbaru_snapshot):
    """Jalan di THREAD TERPISAH (bukan lagi di dalam request POST /about/pasang-update
    itu sendiri) supaya endpoint bisa langsung balas cepat ke browser, dan browser bisa
    polling progres asli (persen unduhan berdasarkan Content-Length, bukan taksiran) lewat
    /about/pasang-status -- sehingga tombol di UI bisa menampilkan angka % yang berjalan,
    bukan spinner tanpa kabar yang keliatan seperti macet padahal proses tetap jalan."""
    try:
        _set_progress_update(berjalan=True, persen=2, tahap="Menghubungi server unduhan...",
                              selesai=False, ok=None, pesan="")
        folder_kerja = tempfile.mkdtemp(prefix="safenode_update_")
        zip_path = os.path.join(folder_kerja, "update.zip")

        req = urllib.request.Request(download_url, headers={"User-Agent": "SafeNode-UpdateChecker/1.0"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            try:
                total = int(resp.getheader("Content-Length") or 0)
            except (TypeError, ValueError):
                total = 0
            terbaca = 0
            with open(zip_path, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    terbaca += len(chunk)
                    if total:
                        persen = 5 + int(terbaca / total * 65)  # rentang unduh: 5% - 70%
                        tahap = f"Mengunduh update... {terbaca // 1024} KB / {total // 1024} KB"
                    else:
                        # Content-Length tidak diketahui server -- tetap gerak (taksiran halus)
                        # dari jumlah data yang sudah diterima, supaya tidak diam total di layar.
                        persen = min(65, 5 + terbaca // 200000)
                        tahap = f"Mengunduh update... {terbaca // 1024} KB"
                    _set_progress_update(persen=min(70, persen), tahap=tahap)
    except Exception as e:
        _set_progress_update(berjalan=False, persen=0, tahap="", selesai=True, ok=False,
                              pesan=f"Gagal mengunduh file update: {e}")
        return

    if not zipfile.is_zipfile(zip_path):
        _set_progress_update(berjalan=False, persen=0, tahap="", selesai=True, ok=False,
                              pesan="File yang diunduh bukan file .zip yang valid. Cek lagi link download di manifest.")
        return

    _set_progress_update(persen=75, tahap="Memeriksa isi file update...")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    try:
        if os.name == "nt":
            # --- Windows: tulis & jalankan .bat pembantu, detached dari proses ini ---
            _set_progress_update(persen=82, tahap="Menyiapkan script pemasangan (Windows)...")
            bat_path = os.path.join(folder_kerja, "apply_update.bat")
            backup_dir = os.path.join(folder_app, f"backup_update_{stamp}")
            extract_dir = os.path.join(folder_kerja, "extracted")
            isi_bat = f"""@echo off
setlocal EnableDelayedExpansion
timeout /t 3 /nobreak >nul
net stop BentangRadiusBilling >nul 2>&1
timeout /t 2 /nobreak >nul
mkdir "{backup_dir}" >nul 2>&1
if exist "{folder_app}\\billing.db" copy /y "{folder_app}\\billing.db" "{backup_dir}\\" >nul
if exist "{folder_app}\\secret_key.txt" copy /y "{folder_app}\\secret_key.txt" "{backup_dir}\\" >nul
if exist "{folder_app}\\static\\uploads" xcopy /e /i /y "{folder_app}\\static\\uploads" "{backup_dir}\\uploads\\" >nul
powershell -NoProfile -Command "Expand-Archive -LiteralPath '{zip_path}' -DestinationPath '{extract_dir}' -Force"
set "SUMBER={extract_dir}"
if not exist "{extract_dir}\\app.py" (
  for /d %%d in ("{extract_dir}\\*") do if exist "%%d\\app.py" set "SUMBER=%%d"
)
robocopy "!SUMBER!" "{folder_app}" /E /IS /IT /XF billing.db secret_key.txt *.db /XD "static\\uploads" "backup_update_*" ".git" >nul
if exist "{backup_dir}\\billing.db" copy /y "{backup_dir}\\billing.db" "{folder_app}\\billing.db" >nul
if exist "{backup_dir}\\secret_key.txt" copy /y "{backup_dir}\\secret_key.txt" "{folder_app}\\secret_key.txt" >nul
net start BentangRadiusBilling >nul 2>&1
"""
            with open(bat_path, "w", encoding="utf-8") as f:
                f.write(isi_bat)
            _set_progress_update(persen=90, tahap="Menjalankan proses pemasangan...")
            subprocess.Popen(
                ["cmd.exe", "/c", bat_path],
                creationflags=subprocess.CREATE_NEW_CONSOLE,
                cwd=folder_kerja,
            )
            pesan = ("Update sedang dipasang di background. Server akan mati sebentar (±30-60 "
                     "detik) lalu otomatis menyala lagi. Data pelanggan aman, sudah dibackup "
                     f"ke folder backup_update_{stamp}. Refresh halaman ini setelah ~1 menit.")
        else:
            # --- Linux/Mac atau mode non-service: siapkan script, tapi TIDAK bisa
            # menyalakan ulang dirinya sendiri secara otomatis -- admin jalankan manual.
            _set_progress_update(persen=85, tahap="Menyiapkan script pemasangan (Linux)...")
            sh_path = os.path.join(folder_kerja, "apply_update.sh")
            backup_dir = os.path.join(folder_app, f"backup_update_{stamp}")
            extract_dir = os.path.join(folder_kerja, "extracted")
            isi_sh = f"""#!/bin/bash
set -e
mkdir -p "{backup_dir}"
[ -f "{folder_app}/billing.db" ] && cp "{folder_app}/billing.db" "{backup_dir}/"
[ -f "{folder_app}/secret_key.txt" ] && cp "{folder_app}/secret_key.txt" "{backup_dir}/"
[ -d "{folder_app}/static/uploads" ] && cp -r "{folder_app}/static/uploads" "{backup_dir}/uploads"
mkdir -p "{extract_dir}"
unzip -oq "{zip_path}" -d "{extract_dir}"
# Deteksi folder root aplikasi yang SEBENARNYA dengan mencari app.py -- BUKAN sekadar
# ambil folder pertama yang ketemu, karena zip bisa saja tidak dibungkus 1 folder wrapper
# (file app.py langsung di root zip), sehingga folder pertama yang ditemukan `find` bisa
# jadi cuma folder pendukung (mis. static/, templates/) dan app.py yang sebenarnya malah
# tidak ikut ter-copy ke aplikasi (versi tidak pernah berubah walau proses "sukses").
if [ -f "{extract_dir}/app.py" ]; then
  SUMBER="{extract_dir}"
else
  SUMBER=$(find "{extract_dir}" -mindepth 2 -maxdepth 2 -name "app.py" -exec dirname {{}} + | head -n1)
  [ -z "$SUMBER" ] && SUMBER=$(find "{extract_dir}" -mindepth 1 -maxdepth 1 -type d | head -n1)
  [ -z "$SUMBER" ] && SUMBER="{extract_dir}"
fi
echo "Folder sumber terdeteksi: $SUMBER"
rsync -a --exclude 'billing.db' --exclude 'secret_key.txt' --exclude 'static/uploads' "$SUMBER"/ "{folder_app}"/
[ -f "{backup_dir}/billing.db" ] && cp "{backup_dir}/billing.db" "{folder_app}/billing.db"
[ -f "{backup_dir}/secret_key.txt" ] && cp "{backup_dir}/secret_key.txt" "{folder_app}/secret_key.txt"
echo "Selesai. Jalankan ulang aplikasinya (systemctl restart <service> atau ./start.sh)."
"""
            with open(sh_path, "w", encoding="utf-8") as f:
                f.write(isi_sh)
            os.chmod(sh_path, 0o755)
            pesan = (f"File update sudah diunduh & script pemasangan disiapkan di {sh_path}. "
                     "Karena aplikasi tidak jalan sebagai Windows Service, jalankan script itu "
                     "manual di terminal (bash apply_update.sh) lalu restart aplikasinya sendiri "
                     "(atau restart container Docker kalau aplikasi ini jalan di Docker/CasaOS).")
    except Exception as e:
        _set_progress_update(berjalan=False, persen=0, tahap="", selesai=True, ok=False,
                              pesan=f"Gagal menyiapkan proses pemasangan: {e}")
        return

    _set_progress_update(persen=97, tahap="Menyimpan riwayat...")
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("UPDATE pengaturan_update SET terakhir_pasang=? WHERE id=1",
                    (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
        con.execute(
            "INSERT INTO aktivitas_sistem (kategori, aksi, keterangan, status, dibuat_oleh, waktu) "
            "VALUES (?,?,?,?,?,?)",
            ("sistem", "Pasang Update", f"Update ke versi {versi_terbaru_snapshot or '?'} dijalankan.",
             "berhasil", pelaku, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        con.commit()
        con.close()
    except Exception:
        pass

    _set_progress_update(berjalan=False, persen=100, tahap="Selesai.", selesai=True, ok=True, pesan=pesan)


@app.route("/about/pasang-update", methods=["POST"])
@login_required
def about_pasang_update():
    """Tombol 'Download & Pasang Update' -- mulai proses unduh+siapkan-pemasangan di
    THREAD BACKGROUND (lihat _proses_pasang_update_bg), lalu langsung balas ke browser
    supaya browser bisa polling persentase progres lewat GET /about/pasang-status
    (dipakai untuk menggambar progress bar %, bukan spinner tanpa angka).

    Alur pemasangannya sendiri (backup db, extract zip, timpa kode) TIDAK berubah dari
    sebelumnya -- yang berubah hanya CARA melaporkan progresnya ke UI."""
    db = get_db()
    pu = _baca_pengaturan_update(db)
    download_url = request.form.get("download_url", "").strip() or pu["download_url"]
    if not download_url:
        return jsonify(ok=False, message="Belum ada link download update. Klik 'Cek Update' dulu.")
    if not download_url.lower().startswith(("http://", "https://")):
        return jsonify(ok=False, message="URL download update tidak valid.")

    with _progress_lock:
        if _progress_pasang_update["berjalan"]:
            return jsonify(ok=False, message="Proses pemasangan update sebelumnya masih berjalan, tunggu sampai selesai dulu.")

    folder_app = os.path.dirname(os.path.abspath(__file__))
    pelaku = (session.get("admin_username") or session.get("admin_nama")
              or session.get("reseller_username") or session.get("pelanggan_nama") or "-")

    _set_progress_update(berjalan=True, persen=1, tahap="Memulai...", selesai=False, ok=None, pesan="")
    threading.Thread(
        target=_proses_pasang_update_bg,
        args=(download_url, folder_app, pelaku, pu["versi_terbaru"]),
        daemon=True,
    ).start()

    return jsonify(ok=True, started=True, message="Proses download & pemasangan update dimulai.")


@app.route("/about/pasang-status")
@login_required
def about_pasang_status():
    """Dipoll berkala oleh browser (setiap ±700ms) selagi update sedang dipasang, supaya
    tombol di halaman About bisa menampilkan progress bar dengan angka % yang berjalan."""
    with _progress_lock:
        return jsonify(**_progress_pasang_update)


@app.route("/pengaturan/admin", methods=["GET", "POST"])
@login_required
def pengaturan_admin():
    db = get_db()
    if request.method == "POST":
        aksi = request.form.get("aksi")

        if aksi == "tambah":
            if not _wajib_administrator():
                flash("Cuma Administrator yang boleh menambah user admin.", "danger")
                return redirect(url_for("pengaturan_admin"))
            username = request.form["username"].strip()
            nama = request.form.get("nama", "").strip() or None
            email = request.form.get("email", "").strip() or None
            password = request.form["password"]
            level = request.form.get("level", "administrator").strip()
            if level not in LEVEL_ADMIN:
                level = "administrator"
            if len(password) < 6:
                flash("Password minimal 6 karakter.", "danger")
            else:
                try:
                    db.execute("INSERT INTO admin (username, nama, email, password_hash, level) VALUES (?, ?, ?, ?, ?)",
                               (username, nama, email, hash_password(password), level))
                    db.commit()
                    _catat_aktivitas("admin_user", "Tambah User Admin", f"{username} ({LEVEL_ADMIN[level]})")
                    flash(f"User admin '{username}' berhasil ditambahkan.", "success")
                except sqlite3.IntegrityError:
                    flash("Username itu sudah dipakai.", "danger")

        elif aksi == "ubah_level":
            if not _wajib_administrator():
                flash("Cuma Administrator yang boleh mengubah level user admin.", "danger")
                return redirect(url_for("pengaturan_admin"))
            target_id = int(request.form["admin_id"])
            level = request.form.get("level", "administrator").strip()
            if level not in LEVEL_ADMIN:
                flash("Level tidak dikenal.", "danger")
                return redirect(url_for("pengaturan_admin"))
            if target_id == session["admin_id"] and level != "administrator":
                flash("Kamu tidak bisa menurunkan level akun yang sedang kamu pakai sendiri.", "danger")
                return redirect(url_for("pengaturan_admin"))
            if level != "administrator":
                total_administrator = db.execute(
                    "SELECT COUNT(*) c FROM admin WHERE level='administrator' AND id!=?", (target_id,)
                ).fetchone()["c"]
                if total_administrator == 0:
                    flash("Tidak bisa mengubah, minimal harus ada 1 user dengan level Administrator.", "danger")
                    return redirect(url_for("pengaturan_admin"))
            target_row = db.execute("SELECT username FROM admin WHERE id=?", (target_id,)).fetchone()
            db.execute("UPDATE admin SET level=? WHERE id=?", (level, target_id))
            db.commit()
            _catat_aktivitas("admin_user", "Ubah Level User Admin",
                              f"{target_row['username'] if target_row else '-'} -> {LEVEL_ADMIN[level]}")
            flash("Level user admin berhasil diubah.", "success")

        elif aksi == "ubah_profil":
            nama = request.form.get("nama", "").strip() or None
            email = request.form.get("email", "").strip() or None
            db.execute("UPDATE admin SET nama=?, email=? WHERE id=?", (nama, email, session["admin_id"]))
            db.commit()
            session["admin_nama"] = nama or session.get("admin_username")
            _catat_aktivitas("admin_user", "Ubah Profil User Admin", session.get("admin_username"))
            flash("Profil kamu berhasil diperbarui.", "success")

        elif aksi == "ganti_password":
            password_lama = request.form["password_lama"]
            password_baru = request.form["password_baru"]
            row = db.execute("SELECT * FROM admin WHERE id=?", (session["admin_id"],)).fetchone()
            if row["password_hash"] != hash_password(password_lama):
                flash("Password lama salah.", "danger")
            elif len(password_baru) < 6:
                flash("Password baru minimal 6 karakter.", "danger")
            else:
                db.execute("UPDATE admin SET password_hash=? WHERE id=?",
                           (hash_password(password_baru), session["admin_id"]))
                db.commit()
                _catat_aktivitas("admin_user", "Ganti Password User Admin", session.get("admin_username"))
                flash("Password kamu berhasil diganti.", "success")

        elif aksi == "simpan_smtp":
            if not _wajib_administrator():
                flash("Cuma Administrator yang boleh mengubah pengaturan SMTP.", "danger")
                return redirect(url_for("pengaturan_admin"))
            smtp_host = request.form.get("smtp_host", "").strip()
            try:
                smtp_port = int(request.form.get("smtp_port", "587").strip() or 587)
            except ValueError:
                smtp_port = 587
            smtp_username = request.form.get("smtp_username", "").strip()
            smtp_password_baru = request.form.get("smtp_password", "")
            smtp_gunakan_tls = 1 if request.form.get("smtp_gunakan_tls") == "on" else 0
            email_pengirim = request.form.get("email_pengirim", "").strip()
            nama_pengirim = request.form.get("nama_pengirim", "").strip() or None

            # kalau field password dikosongkan, jangan timpa password SMTP yang sudah tersimpan
            if smtp_password_baru:
                smtp_password = smtp_password_baru
            else:
                lama = db.execute("SELECT smtp_password FROM pengaturan_smtp WHERE id=1").fetchone()
                smtp_password = lama["smtp_password"] if lama else ""

            db.execute(
                "UPDATE pengaturan_smtp SET smtp_host=?, smtp_port=?, smtp_username=?, smtp_password=?, "
                "smtp_gunakan_tls=?, email_pengirim=?, nama_pengirim=? WHERE id=1",
                (smtp_host, smtp_port, smtp_username, smtp_password, smtp_gunakan_tls,
                 email_pengirim, nama_pengirim))
            db.commit()
            flash("Pengaturan email (SMTP) berhasil disimpan.", "success")

        elif aksi == "test_smtp":
            if not _wajib_administrator():
                flash("Cuma Administrator yang boleh mengirim email test SMTP.", "danger")
                return redirect(url_for("pengaturan_admin"))
            admin_saya = db.execute("SELECT * FROM admin WHERE id=?", (session["admin_id"],)).fetchone()
            if not admin_saya["email"]:
                flash("Isi dulu email kamu di 'Profil Kamu' sebelum mengirim email test.", "danger")
            else:
                berhasil, error = kirim_email_reset_password(
                    admin_saya["email"], admin_saya["nama"] or admin_saya["username"],
                    url_for("login", _external=True))
                if berhasil:
                    flash(f"Email test berhasil dikirim ke {admin_saya['email']}. Cek inbox/spam.", "success")
                else:
                    flash(f"Gagal mengirim email test: {error}", "danger")

        return redirect(url_for("pengaturan_admin"))

    daftar_admin = db.execute("SELECT id, username, nama, email, level FROM admin ORDER BY id").fetchall()
    admin_saya = db.execute("SELECT * FROM admin WHERE id=?", (session["admin_id"],)).fetchone()
    pengaturan_smtp_row = db.execute("SELECT * FROM pengaturan_smtp WHERE id=1").fetchone()
    pengaturan_umum_row = db.execute("SELECT * FROM pengaturan_umum WHERE id=1").fetchone()
    return render_template("pengaturan_admin.html", daftar_admin=daftar_admin,
                           admin_saya=admin_saya, pengaturan_smtp=pengaturan_smtp_row,
                           pengaturan_umum_row=pengaturan_umum_row,
                           level_admin_pilihan=LEVEL_ADMIN, is_administrator=_wajib_administrator())


@app.route("/pengaturan/admin/hapus/<int:admin_id>", methods=["POST"])
@login_required
def hapus_admin(admin_id):
    db = get_db()
    total_admin = db.execute("SELECT COUNT(*) c FROM admin").fetchone()["c"]
    target_row_cek = db.execute("SELECT level FROM admin WHERE id=?", (admin_id,)).fetchone()
    if total_admin <= 1:
        flash("Tidak bisa menghapus, minimal harus ada 1 user admin.", "danger")
    elif admin_id == session["admin_id"]:
        flash("Tidak bisa menghapus akun yang sedang kamu pakai untuk login.", "danger")
    elif target_row_cek and target_row_cek["level"] == "administrator" and db.execute(
            "SELECT COUNT(*) c FROM admin WHERE level='administrator' AND id!=?", (admin_id,)
    ).fetchone()["c"] == 0:
        flash("Tidak bisa menghapus, minimal harus ada 1 user dengan level Administrator.", "danger")
    else:
        admin_row = db.execute("SELECT username FROM admin WHERE id=?", (admin_id,)).fetchone()
        db.execute("DELETE FROM admin WHERE id=?", (admin_id,))
        db.commit()
        _catat_aktivitas("admin_user", "Hapus User Admin", admin_row["username"] if admin_row else "-")
        flash("User admin dihapus.", "success")
    return redirect(url_for("pengaturan_admin"))


# ---------------------------------------------------------------------------
# Billing > Invoice / Virtual Accounts / Configuration
# ---------------------------------------------------------------------------
BANK_VA_LABEL = {
    "BRIVA": "BRI", "BNIVA": "BNI", "MANDIRIVA": "MANDIRI", "PERMATAVA": "PERMATA",
    "BCAVA": "BCA", "CIMBVA": "CIMB NIAGA", "MUAMALATVA": "MUAMALAT", "BSIVA": "BSI",
    "DANAMONVA": "DANAMON", "SAMPOERNAVA": "SAHABAT SAMPOERNA", "OTHERVA": "BANK LAIN",
    "ALFAMART": "ALFAMART", "INDOMARET": "INDOMARET", "ALFAMIDI": "ALFAMIDI",
}


def _label_bank_va(metode_code):
    """Ubah kode channel Tripay (mis. 'BRIVA') jadi label bank yang gampang dibaca."""
    if not metode_code:
        return "-"
    kode = metode_code.upper()
    if kode in BANK_VA_LABEL:
        return BANK_VA_LABEL[kode]
    if kode.endswith("VA"):
        return kode[:-2]
    return kode


@app.route("/billing/invoice")
@login_required
def billing_invoice():
    """Billing > Invoice: daftar semua tagihan lintas periode (beda dari halaman
    Tagihan lama yang cuma nampilin 1 periode), dengan nomor referensi & filter status."""
    db = get_db()
    q = request.args.get("q", "").strip()
    status_filter = request.args.get("status", "").strip()

    sql = """SELECT t.*, p.nama AS nama_pelanggan, p.username_pppoe, pk.nama_paket
              FROM tagihan t
              JOIN pelanggan p ON p.id = t.pelanggan_id
              LEFT JOIN paket pk ON pk.id = p.paket_id
              WHERE 1=1"""
    params = []
    if q:
        sql += " AND (p.nama LIKE ? OR p.username_pppoe LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    if status_filter:
        sql += " AND t.status = ?"
        params.append(status_filter)
    sql += " ORDER BY t.id DESC LIMIT 300"

    daftar_invoice = []
    for row in db.execute(sql, params).fetchall():
        d = dict(row)
        d["nomor_invoice"] = f"INV-{row['periode'].replace('-', '')}-{row['id']:04d}"
        daftar_invoice.append(d)

    return render_template("billing_invoice.html", daftar_invoice=daftar_invoice,
                           q=q, status_filter=status_filter)


@app.route("/billing/virtual-accounts")
@login_required
def billing_virtual_accounts():
    """Billing > Virtual Accounts: registry nomor VA yang pernah digenerate otomatis
    lewat Tripay untuk pelanggan (BRIVA/BNIVA/dst, termasuk kode bayar Alfamart/Indomaret)."""
    db = get_db()
    q = request.args.get("q", "").strip()

    sql = """SELECT po.*, p.nama AS nama_pelanggan, p.no_hp, t.periode, t.id AS tagihan_id
              FROM pembayaran_online po
              JOIN tagihan t ON t.id = po.tagihan_id
              JOIN pelanggan p ON p.id = t.pelanggan_id
              WHERE (po.metode LIKE '%VA' OR po.metode IN ('ALFAMART', 'INDOMARET', 'ALFAMIDI'))"""
    params = []
    if q:
        sql += " AND (p.nama LIKE ? OR po.reference LIKE ? OR po.pay_code LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    sql += " ORDER BY po.id DESC LIMIT 300"

    daftar_va = []
    for row in db.execute(sql, params).fetchall():
        d = dict(row)
        d["bank_label"] = _label_bank_va(row["metode"])
        d["nomor_va"] = row["pay_code"] or row["reference"]
        daftar_va.append(d)

    return render_template("billing_virtual_accounts.html", daftar_va=daftar_va, q=q)


@app.route("/billing/configuration")
@login_required
def billing_configuration():
    """Billing > Configuration: aturan pajak (PPN) & promo. Rule pajak paling spesifik
    (cabang+paket) menang, lalu cabang, lalu paket, baru default global."""
    db = get_db()
    tab = request.args.get("tab", "pajak")
    daftar_pajak = db.execute(
        """SELECT r.*, pk.nama_paket FROM billing_pajak_rule r
           LEFT JOIN paket pk ON pk.id = r.paket_id
           ORDER BY (r.cabang != 'Any') DESC, (r.paket_id IS NOT NULL) DESC, r.id ASC"""
    ).fetchall()
    daftar_promo = db.execute(
        """SELECT pr.*, pk.nama_paket FROM billing_promo_rule pr
           LEFT JOIN paket pk ON pk.id = pr.paket_id
           ORDER BY pr.id DESC"""
    ).fetchall()
    daftar_paket = db.execute("SELECT id, nama_paket FROM paket ORDER BY nama_paket").fetchall()

    jumlah_overrides = sum(1 for r in daftar_pajak if r["cabang"] != "Any" or r["paket_id"])
    jumlah_default_inclusive = sum(
        1 for r in daftar_pajak if r["cabang"] == "Any" and not r["paket_id"] and r["mode"] == "inclusive")

    return render_template(
        "billing_configuration.html", tab=tab,
        daftar_pajak=daftar_pajak, daftar_promo=daftar_promo, daftar_paket=daftar_paket,
        jumlah_rules=len(daftar_pajak), jumlah_overrides=jumlah_overrides,
        jumlah_default_inclusive=jumlah_default_inclusive,
    )


@app.route("/billing/configuration/pajak/simpan", methods=["POST"])
@login_required
def billing_pajak_simpan():
    db = get_db()
    rule_id = request.form.get("id", "").strip()
    cabang = request.form.get("cabang", "Any").strip() or "Any"
    paket_id = request.form.get("paket_id", "").strip()
    mode = request.form.get("mode", "inclusive").strip()
    rate = request.form.get("rate", "0").strip()
    catatan = request.form.get("catatan", "").strip()

    try:
        rate_val = float(rate)
    except ValueError:
        flash("Rate pajak harus berupa angka.", "danger")
        return redirect(url_for("billing_configuration", tab="pajak"))

    paket_id_val = int(paket_id) if paket_id else None

    if rule_id:
        db.execute(
            "UPDATE billing_pajak_rule SET cabang=?, paket_id=?, mode=?, rate=?, catatan=? WHERE id=?",
            (cabang, paket_id_val, mode, rate_val, catatan, rule_id))
        flash("Rule pajak diperbarui.", "success")
    else:
        db.execute(
            """INSERT INTO billing_pajak_rule (cabang, paket_id, mode, rate, catatan, dibuat_tanggal)
               VALUES (?,?,?,?,?,?)""",
            (cabang, paket_id_val, mode, rate_val, catatan, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        flash("Rule pajak baru ditambahkan.", "success")
    db.commit()
    return redirect(url_for("billing_configuration", tab="pajak"))


@app.route("/billing/configuration/pajak/<int:rule_id>/hapus", methods=["POST"])
@login_required
def billing_pajak_hapus(rule_id):
    db = get_db()
    row = db.execute("SELECT cabang, paket_id FROM billing_pajak_rule WHERE id=?", (rule_id,)).fetchone()
    if row and row["cabang"] == "Any" and not row["paket_id"]:
        flash("Rule default global tidak bisa dihapus, hanya bisa diedit.", "danger")
    else:
        db.execute("DELETE FROM billing_pajak_rule WHERE id=?", (rule_id,))
        db.commit()
        flash("Rule pajak dihapus.", "success")
    return redirect(url_for("billing_configuration", tab="pajak"))


@app.route("/billing/configuration/promo/simpan", methods=["POST"])
@login_required
def billing_promo_simpan():
    db = get_db()
    promo_id = request.form.get("id", "").strip()
    nama = request.form.get("nama", "").strip()
    tipe = request.form.get("tipe", "percent").strip()
    nilai = request.form.get("nilai", "0").strip()
    paket_id = request.form.get("paket_id", "").strip()
    aktif = 1 if request.form.get("aktif") == "on" else 0
    catatan = request.form.get("catatan", "").strip()

    if not nama:
        flash("Nama promo wajib diisi.", "danger")
        return redirect(url_for("billing_configuration", tab="promo"))
    try:
        nilai_val = int(nilai)
    except ValueError:
        flash("Nilai promo harus berupa angka.", "danger")
        return redirect(url_for("billing_configuration", tab="promo"))

    paket_id_val = int(paket_id) if paket_id else None

    if promo_id:
        db.execute(
            """UPDATE billing_promo_rule SET nama=?, tipe=?, nilai=?, paket_id=?, aktif=?, catatan=?
               WHERE id=?""",
            (nama, tipe, nilai_val, paket_id_val, aktif, catatan, promo_id))
        flash("Promo rule diperbarui.", "success")
    else:
        db.execute(
            """INSERT INTO billing_promo_rule (nama, tipe, nilai, paket_id, aktif, catatan, dibuat_tanggal)
               VALUES (?,?,?,?,?,?,?)""",
            (nama, tipe, nilai_val, paket_id_val, aktif, catatan, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        flash("Promo rule baru ditambahkan.", "success")
    db.commit()
    return redirect(url_for("billing_configuration", tab="promo"))


@app.route("/billing/configuration/promo/<int:promo_id>/hapus", methods=["POST"])
@login_required
def billing_promo_hapus(promo_id):
    db = get_db()
    db.execute("DELETE FROM billing_promo_rule WHERE id=?", (promo_id,))
    db.commit()
    flash("Promo rule dihapus.", "success")
    return redirect(url_for("billing_configuration", tab="promo"))


# ---------------------------------------------------------------------------
# Payments > Transactions / Records / Manual Transfers
# ---------------------------------------------------------------------------
BULAN_ID = ["", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
            "Agustus", "September", "Oktober", "November", "Desember"]


def _format_periode_id(periode):
    """'2027-07' -> 'Juli 2027'."""
    try:
        tahun, bulan = periode.split("-")
        return f"{BULAN_ID[int(bulan)]} {tahun}"
    except (ValueError, IndexError):
        return periode


@app.route("/payments/transactions")
@login_required
def payments_transactions():
    """Payments > Transactions: daftar tagihan sebagai transaksi pembayaran, dengan
    tab ALL/UNPAID/PAID/OVERDUE (overdue = belum lunas & sudah lewat jatuh tempo)."""
    db = get_db()
    tab = request.args.get("tab", "all")
    q = request.args.get("q", "").strip()
    hari_ini = date.today().isoformat()

    sql = """SELECT t.*, p.nama AS nama_pelanggan, p.username_pppoe, pk.nama_paket
              FROM tagihan t
              JOIN pelanggan p ON p.id = t.pelanggan_id
              LEFT JOIN paket pk ON pk.id = p.paket_id
              WHERE 1=1"""
    params = []
    if tab == "unpaid":
        sql += " AND t.status='belum_lunas'"
    elif tab == "paid":
        sql += " AND t.status='lunas'"
    elif tab == "overdue":
        sql += " AND t.status='belum_lunas' AND t.tanggal_jatuh_tempo IS NOT NULL AND t.tanggal_jatuh_tempo < ?"
        params.append(hari_ini)
    if q:
        sql += " AND (p.nama LIKE ? OR p.username_pppoe LIKE ? OR t.id LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    sql += " ORDER BY t.id DESC LIMIT 300"

    daftar_transaksi = []
    for row in db.execute(sql, params).fetchall():
        d = dict(row)
        d["nomor_invoice"] = f"INV-{row['periode'].replace('-', '')}-{row['id']:04d}"
        d["periode_label"] = _format_periode_id(row["periode"])
        d["overdue"] = bool(row["status"] == "belum_lunas" and row["tanggal_jatuh_tempo"] and row["tanggal_jatuh_tempo"] < hari_ini)
        daftar_transaksi.append(d)

    return render_template("payments_transactions.html", daftar_transaksi=daftar_transaksi, tab=tab, q=q)


@app.route("/payments/records")
@login_required
def payments_records():
    """Payments > Records: rekap total dana yang terkumpul (online + transfer manual)
    + pencarian riwayat pembayaran per nomor invoice."""
    db = get_db()
    tab = request.args.get("tab", "all")
    invoice_q = request.args.get("invoice", "").strip()

    collected_online = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) s FROM pembayaran_online WHERE status='PAID'").fetchone()["s"]
    collected_manual = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) s FROM konfirmasi_transfer_bank WHERE status='diterima'").fetchone()["s"]
    fees = db.execute(
        "SELECT COALESCE(SUM(fee_pelanggan),0) s FROM pembayaran_online WHERE status='PAID'").fetchone()["s"]
    pending_online = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) s FROM pembayaran_online WHERE status='UNPAID'").fetchone()["s"]
    pending_manual = db.execute(
        "SELECT COALESCE(SUM(jumlah),0) s FROM konfirmasi_transfer_bank WHERE status='menunggu'").fetchone()["s"]

    stats = {
        "collected": collected_online + collected_manual,
        "settled": collected_online,
        "fees": fees,
        "pending": pending_online + pending_manual,
    }

    daftar_record = []
    tagihan_ditemukan = None
    if invoice_q:
        m = re.match(r"^INV-(\d{6})-(\d+)$", invoice_q.upper())
        tid = None
        if m:
            tid = int(m.group(2))
        elif invoice_q.isdigit():
            tid = int(invoice_q)

        if tid:
            tagihan_ditemukan = db.execute(
                """SELECT t.*, p.nama AS nama_pelanggan FROM tagihan t
                   JOIN pelanggan p ON p.id = t.pelanggan_id WHERE t.id=?""", (tid,)).fetchone()

        if tagihan_ditemukan:
            for row in db.execute(
                "SELECT * FROM pembayaran_online WHERE tagihan_id=? ORDER BY id DESC", (tid,)).fetchall():
                status_map = {"PAID": "completed", "UNPAID": "pending",
                              "EXPIRED": "failed", "FAILED": "failed", "REFUND": "failed"}
                daftar_record.append({
                    "channel": row["nama_metode"] or row["metode"] or "Online",
                    "reference": row["reference"] or row["merchant_ref"],
                    "jumlah": row["jumlah"], "fee": row["fee_pelanggan"],
                    "status": row["status"], "status_kelompok": status_map.get(row["status"], "pending"),
                    "tanggal": row["dibayar_tanggal"] or row["dibuat_tanggal"],
                })
            for row in db.execute(
                "SELECT * FROM konfirmasi_transfer_bank WHERE tagihan_id=? ORDER BY id DESC", (tid,)).fetchall():
                status_map = {"diterima": "completed", "menunggu": "pending", "ditolak": "failed"}
                daftar_record.append({
                    "channel": f"Transfer Manual ({row['bank_pengirim']})",
                    "reference": row["nama_pengirim"],
                    "jumlah": row["jumlah"], "fee": 0,
                    "status": row["status"], "status_kelompok": status_map.get(row["status"], "pending"),
                    "tanggal": row["diproses_tanggal"] or row["dibuat_tanggal"],
                })
            if tab != "all":
                daftar_record = [r for r in daftar_record if r["status_kelompok"] == tab]

    return render_template(
        "payments_records.html", stats=stats, invoice_q=invoice_q, tab=tab,
        tagihan_ditemukan=tagihan_ditemukan, daftar_record=daftar_record,
    )


@app.route("/payments/manual-transfers")
@login_required
def payments_manual_transfers():
    """Payments > Manual Transfers: verification queue untuk konfirmasi transfer bank
    manual dari pelanggan, dengan tab Pending/Verified/Rejected -- versi tampilan baru
    dari data yang sama dipakai halaman lama /transfer-bank."""
    db = get_db()
    tab = request.args.get("tab", "pending")
    q = request.args.get("q", "").strip()
    try:
        per_page = max(1, min(int(request.args.get("per_page", 10)), 100))
    except ValueError:
        per_page = 10
    try:
        page = max(1, int(request.args.get("page", 1)))
    except ValueError:
        page = 1

    status_map = {"pending": "menunggu", "verified": "diterima", "rejected": "ditolak"}
    status_db = status_map.get(tab, "menunggu")

    sql = """SELECT k.*, p.nama AS nama_pelanggan, t.periode, t.id AS tagihan_id
              FROM konfirmasi_transfer_bank k
              JOIN pelanggan p ON p.id = k.pelanggan_id
              JOIN tagihan t ON t.id = k.tagihan_id
              WHERE k.status=?"""
    params = [status_db]
    if q:
        sql += " AND (p.nama LIKE ? OR t.id LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    sql += " ORDER BY k.id DESC"

    semua = db.execute(sql, params).fetchall()
    total = len(semua)
    total_halaman = max(1, (total + per_page - 1) // per_page)
    page = min(page, total_halaman)
    awal = (page - 1) * per_page
    daftar_transfer = []
    for row in semua[awal:awal + per_page]:
        d = dict(row)
        d["nomor_invoice"] = f"INV-{row['periode'].replace('-', '')}-{row['tagihan_id']:04d}"
        daftar_transfer.append(d)

    bulan_ini = date.today().strftime("%Y-%m")
    jumlah_pending = db.execute(
        "SELECT COUNT(*) c FROM konfirmasi_transfer_bank WHERE status='menunggu'").fetchone()["c"]
    jumlah_verified_mtd = db.execute(
        "SELECT COUNT(*) c FROM konfirmasi_transfer_bank WHERE status='diterima' AND diproses_tanggal LIKE ?",
        (f"{bulan_ini}%",)).fetchone()["c"]
    jumlah_total_verified = db.execute(
        "SELECT COUNT(*) c FROM konfirmasi_transfer_bank WHERE status='diterima'").fetchone()["c"]

    return render_template(
        "payments_manual_transfers.html", tab=tab, q=q, daftar_transfer=daftar_transfer,
        page=page, per_page=per_page, total=total, total_halaman=total_halaman, awal=awal,
        jumlah_pending=jumlah_pending, jumlah_verified_mtd=jumlah_verified_mtd,
        jumlah_total_verified=jumlah_total_verified,
    )


# ---------------------------------------------------------------------------
# Modul Inti -- Support (Internal Tickets, Customer Tickets, LinkNet Tickets,
# CS Handover) -- 4 sub-menu di grup sidebar "Modul Inti > Support".
# ---------------------------------------------------------------------------
PRIORITAS_LABEL = {"low": "Low", "medium": "Medium", "high": "High", "urgent": "Urgent", "critical": "Critical"}
STATUS_INTERNAL_LABEL = {"open": "Open", "in_progress": "In Progress", "resolved": "Resolved", "closed": "Closed"}
STATUS_LINKNET_LABEL = {"baru": "New", "open": "Open", "in_progress": "In Progress", "resolved": "Resolved", "closed": "Closed"}
STATUS_HANDOVER_LABEL = {"done": "Done", "menunggu_update": "Menunggu Update", "on_progress": "On Progress", "eskalasi": "Eskalasi"}


def _sekarang():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _nama_admin_aktif():
    return session.get("admin_nama") or session.get("admin_username") or "Admin"


# =========================== Support > Internal Tickets ===========================
@app.route("/core-modules/support/tickets")
@login_required
def support_internal_tickets():
    db = get_db()
    status_filter = request.args.get("status", "semua")
    prioritas_filter = request.args.get("prioritas", "semua")
    q = request.args.get("q", "").strip()

    query = "SELECT * FROM tiket_internal WHERE 1=1"
    params = []
    if status_filter != "semua":
        query += " AND status=?"
        params.append(status_filter)
    if prioritas_filter != "semua":
        query += " AND prioritas=?"
        params.append(prioritas_filter)
    if q:
        query += " AND (subjek LIKE ? OR deskripsi LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    query += " ORDER BY id DESC"
    daftar = db.execute(query, params).fetchall()

    jumlah = {s: db.execute("SELECT COUNT(*) c FROM tiket_internal WHERE status=?", (s,)).fetchone()["c"]
              for s in STATUS_INTERNAL_LABEL}
    total = db.execute("SELECT COUNT(*) c FROM tiket_internal").fetchone()["c"]

    return render_template(
        "support_internal_tickets.html", daftar=daftar, jumlah=jumlah, total=total,
        status_filter=status_filter, prioritas_filter=prioritas_filter, q=q,
        status_label=STATUS_INTERNAL_LABEL, prioritas_label=PRIORITAS_LABEL,
    )


@app.route("/core-modules/support/tickets/tambah", methods=["POST"])
@login_required
def support_internal_tickets_tambah():
    db = get_db()
    subjek = request.form.get("subjek", "").strip()
    deskripsi = request.form.get("deskripsi", "").strip()
    kategori = request.form.get("kategori", "lainnya")
    prioritas = request.form.get("prioritas", "medium")
    ditugaskan_ke = request.form.get("ditugaskan_ke", "").strip() or None
    if not subjek or not deskripsi:
        flash("Subjek dan deskripsi wajib diisi.", "danger")
        return redirect(url_for("support_internal_tickets"))
    db.execute(
        """INSERT INTO tiket_internal (subjek, deskripsi, kategori, prioritas, status, ditugaskan_ke, dibuat_oleh, dibuat_pada)
           VALUES (?,?,?,?, 'open', ?, ?, ?)""",
        (subjek, deskripsi, kategori, prioritas, ditugaskan_ke, _nama_admin_aktif(), _sekarang()))
    db.commit()
    flash("Tiket internal berhasil dibuat.", "success")
    return redirect(url_for("support_internal_tickets"))


@app.route("/core-modules/support/tickets/<int:tid>/status", methods=["POST"])
@login_required
def support_internal_tickets_status(tid):
    db = get_db()
    status_baru = request.form.get("status")
    if status_baru not in STATUS_INTERNAL_LABEL:
        flash("Status tidak valid.", "danger")
        return redirect(url_for("support_internal_tickets"))
    db.execute("UPDATE tiket_internal SET status=?, diperbarui_pada=? WHERE id=?",
               (status_baru, _sekarang(), tid))
    db.commit()
    flash("Status tiket internal diperbarui.", "success")
    return redirect(url_for("support_internal_tickets"))


@app.route("/core-modules/support/tickets/<int:tid>/hapus", methods=["POST"])
@login_required
def support_internal_tickets_hapus(tid):
    db = get_db()
    db.execute("DELETE FROM tiket_internal WHERE id=?", (tid,))
    db.commit()
    flash("Tiket internal dihapus.", "success")
    return redirect(url_for("support_internal_tickets"))


# Ringkasan kartu jumlah tiket khusus menu Customer Tickets:
# New / Open / Proses / Pending / Finish (+ Total), dipetakan dari status
# internal yang sudah ada (baru->New, menuju_lokasi->Open, on_progress->Proses,
# selesai->Pending [nunggu ditutup], ditutup->Finish) supaya tidak perlu ubah
# skema/status di menu Tiket Gangguan yang lain.
CUSTOMER_TICKET_STAT_LABEL = {
    "baru": "New",
    "menuju_lokasi": "Open",
    "on_progress": "Proses",
    "selesai": "Pending",
    "ditutup": "Finish",
}
BULAN_LABEL = {
    "1": "Januari", "2": "Februari", "3": "Maret", "4": "April",
    "5": "Mei", "6": "Juni", "7": "Juli", "8": "Agustus",
    "9": "September", "10": "Oktober", "11": "November", "12": "Desember",
}


# =========================== Support > Customer Tickets ===========================
@app.route("/core-modules/support/customer-tickets")
@login_required
def support_customer_tickets():
    db = get_db()
    status_filter = request.args.get("status", "semua")
    prioritas_filter = request.args.get("prioritas", "semua")
    kategori_filter = request.args.get("kategori", "semua")
    q = request.args.get("q", "").strip()

    # --- Filter periode (bulan & tahun) supaya tiket tidak tampil semua sekaligus ---
    tahun_ini = str(datetime.now().year)
    bulan_ini = str(datetime.now().month)
    tahun_filter = request.args.get("tahun", tahun_ini).strip()
    bulan_filter = request.args.get("bulan", bulan_ini).strip()
    if not tahun_filter.isdigit():
        tahun_filter = tahun_ini
    if bulan_filter != "semua" and bulan_filter not in BULAN_LABEL:
        bulan_filter = bulan_ini

    tahun_tersedia = sorted({
        r["thn"] for r in db.execute(
            "SELECT DISTINCT substr(tanggal_lapor,1,4) thn FROM tiket_gangguan WHERE tanggal_lapor IS NOT NULL"
        ).fetchall() if r["thn"]
    } | {tahun_ini, tahun_filter}, reverse=True)

    kondisi_periode = "substr(tk.tanggal_lapor,1,4)=?"
    param_periode = [tahun_filter]
    if bulan_filter != "semua":
        kondisi_periode += " AND substr(tk.tanggal_lapor,6,2)=?"
        param_periode.append(f"{int(bulan_filter):02d}")

    # --- Kartu ringkasan jumlah tiket per status (ikut filter periode saja,
    #     supaya tetap kelihatan gambaran menyeluruh walau tabel di bawah
    #     lagi difilter status/kategori/pencarian tertentu) ---
    jumlah_per_status = {}
    for key in CUSTOMER_TICKET_STAT_LABEL:
        jumlah_per_status[key] = db.execute(
            f"SELECT COUNT(*) c FROM tiket_gangguan tk WHERE {kondisi_periode} AND tk.status=?",
            param_periode + [key]
        ).fetchone()["c"]
    jumlah_total_periode = db.execute(
        f"SELECT COUNT(*) c FROM tiket_gangguan tk WHERE {kondisi_periode}", param_periode
    ).fetchone()["c"]

    query = f"""SELECT tk.*, p.nama, p.username_pppoe, p.no_hp
               FROM tiket_gangguan tk JOIN pelanggan p ON p.id = tk.pelanggan_id
               WHERE {kondisi_periode}"""
    params = list(param_periode)
    if status_filter != "semua":
        query += " AND tk.status=?"
        params.append(status_filter)
    if prioritas_filter != "semua":
        query += " AND tk.prioritas=?"
        params.append(prioritas_filter)
    if kategori_filter != "semua":
        query += " AND tk.kategori=?"
        params.append(kategori_filter)
    if q:
        query += " AND (tk.judul LIKE ? OR p.nama LIKE ? OR tk.mixradius_ticket LIKE ?)"
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    query += " ORDER BY tk.id DESC"
    daftar_semua = db.execute(query, params).fetchall()

    hal = _paginate(daftar_semua)

    return render_template(
        "support_customer_tickets.html", daftar=hal["items"], total=len(daftar_semua),
        page=hal["page"], per_page=hal["per_page"], per_page_options=hal["per_page_options"],
        total_halaman=hal["total_halaman"], mulai=hal["mulai"], selesai=hal["selesai"],
        status_filter=status_filter, prioritas_filter=prioritas_filter, kategori_filter=kategori_filter, q=q,
        bulan_filter=bulan_filter, tahun_filter=tahun_filter, tahun_tersedia=tahun_tersedia,
        bulan_label=BULAN_LABEL,
        jumlah_per_status=jumlah_per_status, jumlah_total_periode=jumlah_total_periode,
        stat_label=CUSTOMER_TICKET_STAT_LABEL,
        status_label=STATUS_TIKET_LABEL, prioritas_label=PRIORITAS_LABEL,
    )


# =========================== Support > LinkNet Tickets ===========================
@app.route("/core-modules/support/linknet-tickets")
@login_required
def support_linknet_tickets():
    db = get_db()
    daftar = db.execute("SELECT * FROM linknet_tiket ORDER BY id DESC").fetchall()
    total = len(daftar)
    total_open = sum(1 for r in daftar if r["status"] in ("baru", "open", "in_progress"))
    total_high = sum(1 for r in daftar if r["severity"] in ("high", "critical"))
    return render_template(
        "support_linknet_tickets.html", daftar=daftar, total=total, total_open=total_open,
        total_high=total_high, status_label=STATUS_LINKNET_LABEL,
    )


@app.route("/core-modules/support/linknet-tickets/tambah", methods=["POST"])
@login_required
def support_linknet_tickets_tambah():
    db = get_db()
    subjek = request.form.get("subjek", "").strip()
    deskripsi = request.form.get("deskripsi", "").strip()
    homepass = request.form.get("homepass", "").strip() or None
    severity = request.form.get("severity", "medium")
    if not subjek:
        flash("Subjek wajib diisi.", "danger")
        return redirect(url_for("support_linknet_tickets"))
    db.execute(
        """INSERT INTO linknet_tiket (ticket_id, homepass, subjek, deskripsi, severity, status, dibuat_oleh, dibuat_pada)
           VALUES (NULL, ?, ?, ?, ?, 'baru', ?, ?)""",
        (homepass, subjek, deskripsi, severity, _nama_admin_aktif(), _sekarang()))
    db.commit()
    flash("Tiket LinkNet berhasil dibuat, menunggu nomor TT dari helpdesk LinkNet.", "success")
    return redirect(url_for("support_linknet_tickets"))


@app.route("/core-modules/support/linknet-tickets/import", methods=["POST"])
@login_required
def support_linknet_tickets_import():
    """Impor tiket berdasarkan nomor TT LinkNet (integrasi API TMF621 belum
    dikonfigurasi -- untuk sekarang nomor TT dicatat manual sebagai referensi)."""
    db = get_db()
    ticket_id = request.form.get("ticket_id", "").strip()
    if not ticket_id:
        flash("Masukkan ticket ID (TT...) yang mau diimpor.", "danger")
        return redirect(url_for("support_linknet_tickets"))
    sudah_ada = db.execute("SELECT id FROM linknet_tiket WHERE ticket_id=?", (ticket_id,)).fetchone()
    if sudah_ada:
        flash(f"Ticket {ticket_id} sudah ada di daftar.", "warning")
        return redirect(url_for("support_linknet_tickets"))
    db.execute(
        """INSERT INTO linknet_tiket (ticket_id, homepass, subjek, deskripsi, severity, status, dibuat_oleh, dibuat_pada)
           VALUES (?, NULL, ?, '', 'medium', 'open', ?, ?)""",
        (ticket_id, f"Tiket {ticket_id} (diimpor)", _nama_admin_aktif(), _sekarang()))
    db.commit()
    flash(f"Ticket {ticket_id} berhasil diimpor. Integrasi API LinkNet belum dikonfigurasi, jadi detail lain perlu dilengkapi manual.", "success")
    return redirect(url_for("support_linknet_tickets"))


@app.route("/core-modules/support/linknet-tickets/<int:tid>/status", methods=["POST"])
@login_required
def support_linknet_tickets_status(tid):
    db = get_db()
    status_baru = request.form.get("status")
    if status_baru not in STATUS_LINKNET_LABEL:
        flash("Status tidak valid.", "danger")
        return redirect(url_for("support_linknet_tickets"))
    db.execute("UPDATE linknet_tiket SET status=?, diperbarui_pada=? WHERE id=?",
               (status_baru, _sekarang(), tid))
    db.commit()
    flash("Status tiket LinkNet diperbarui.", "success")
    return redirect(url_for("support_linknet_tickets"))


# =========================== Support > CS Handover ===========================
@app.route("/core-modules/support/handover")
@login_required
def support_cs_handover():
    db = get_db()
    q = request.args.get("q", "").strip()
    query = "SELECT * FROM cs_handover WHERE 1=1"
    params = []
    if q:
        query += " AND (kontak LIKE ? OR deskripsi LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    query += " ORDER BY id DESC LIMIT 200"
    daftar = db.execute(query, params).fetchall()

    hari_ini = date.today().strftime("%Y-%m-%d")
    hari_ini_count = db.execute(
        "SELECT COUNT(*) c FROM cs_handover WHERE dibuat_pada LIKE ?", (f"{hari_ini}%",)).fetchone()["c"]
    open_items = db.execute(
        "SELECT COUNT(*) c FROM cs_handover WHERE status != 'done'").fetchone()["c"]
    done_hari_ini = db.execute(
        "SELECT COUNT(*) c FROM cs_handover WHERE status='done' AND dibuat_pada LIKE ?",
        (f"{hari_ini}%",)).fetchone()["c"]

    return render_template(
        "support_cs_handover.html", daftar=daftar, q=q, hari_ini_count=hari_ini_count,
        open_items=open_items, done_hari_ini=done_hari_ini, status_label=STATUS_HANDOVER_LABEL,
    )


@app.route("/core-modules/support/handover/tambah", methods=["POST"])
@login_required
def support_cs_handover_tambah():
    db = get_db()
    kontak = request.form.get("kontak", "").strip()
    kategori = request.form.get("kategori", "lainnya")
    deskripsi = request.form.get("deskripsi", "").strip()
    tindakan = request.form.get("tindakan", "").strip()
    status = request.form.get("status", "done")
    shift = request.form.get("shift", "pagi")
    if not kontak:
        flash("No. HP / CID pelanggan wajib diisi.", "danger")
        return redirect(url_for("support_cs_handover"))
    db.execute(
        """INSERT INTO cs_handover (kontak, kategori, deskripsi, tindakan, status, shift, cs_nama, dibuat_pada)
           VALUES (?,?,?,?,?,?,?,?)""",
        (kontak, kategori, deskripsi, tindakan, status, shift, _nama_admin_aktif(), _sekarang()))
    db.commit()
    return redirect(url_for("support_cs_handover"))


@app.route("/core-modules/support/handover/<int:hid>/status", methods=["POST"])
@login_required
def support_cs_handover_status(hid):
    db = get_db()
    status_baru = request.form.get("status")
    if status_baru not in STATUS_HANDOVER_LABEL:
        flash("Status tidak valid.", "danger")
        return redirect(url_for("support_cs_handover"))
    db.execute("UPDATE cs_handover SET status=? WHERE id=?", (status_baru, hid))
    db.commit()
    return redirect(url_for("support_cs_handover"))


@app.route("/core-modules/support/handover/<int:hid>/hapus", methods=["POST"])
@login_required
def support_cs_handover_hapus(hid):
    db = get_db()
    db.execute("DELETE FROM cs_handover WHERE id=?", (hid,))
    db.commit()
    return redirect(url_for("support_cs_handover"))


# ---------------------------------------------------------------------------
# Modul Inti -- RADIUS (Sessions, Isolasi, Konfigurasi, Sesi Hotspot) -- 4
# sub-menu di grup sidebar "Modul Inti > RADIUS". Sessions & Sesi Hotspot
# menampilkan data real-time dari Mikrotik lewat API yang sudah ada
# (/api/mikrotik/pppoe-active & /api/mikrotik/hotspot-active).
# ---------------------------------------------------------------------------

@app.route("/core-modules/radius/sessions")
@login_required
def radius_sessions():
    db = get_db()
    riwayat = db.execute(
        """SELECT * FROM aktivitas_sistem WHERE kategori='pppoe'
           ORDER BY id DESC LIMIT 100"""
    ).fetchall()
    return render_template("radius_sessions.html", riwayat=riwayat)


# =========================== RADIUS > Isolasi ===========================
@app.route("/core-modules/radius/isolation")
@login_required
def radius_isolation():
    db = get_db()
    q = request.args.get("q", "").strip()
    query = "SELECT * FROM radius_isolasi WHERE 1=1"
    params = []
    if q:
        query += " AND (username LIKE ? OR mac_address LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    query += " ORDER BY id DESC"
    daftar = db.execute(query, params).fetchall()
    return render_template("radius_isolation.html", daftar=daftar, q=q)


@app.route("/core-modules/radius/isolation/tambah", methods=["POST"])
@login_required
def radius_isolation_tambah():
    db = get_db()
    username = request.form.get("username", "").strip()
    mac_address = request.form.get("mac_address", "").strip()
    alasan = request.form.get("alasan", "").strip()
    kadaluarsa = request.form.get("kadaluarsa", "").strip() or None
    if not username and not mac_address:
        flash("Isi minimal username atau MAC address.", "danger")
        return redirect(url_for("radius_isolation"))
    db.execute(
        """INSERT INTO radius_isolasi (username, mac_address, alasan, kadaluarsa, dibuat_oleh, dibuat_pada)
           VALUES (?,?,?,?,?,?)""",
        (username or None, mac_address or None, alasan or None, kadaluarsa, _nama_admin_aktif(), _sekarang()))
    db.commit()
    flash("Isolasi RADIUS berhasil ditambahkan.", "success")
    return redirect(url_for("radius_isolation"))


@app.route("/core-modules/radius/isolation/<int:iid>/hapus", methods=["POST"])
@login_required
def radius_isolation_hapus(iid):
    db = get_db()
    db.execute("DELETE FROM radius_isolasi WHERE id=?", (iid,))
    db.commit()
    flash("Isolasi RADIUS dihapus.", "success")
    return redirect(url_for("radius_isolation"))


# =========================== RADIUS > Konfigurasi ===========================
@app.route("/core-modules/radius/configuration")
@login_required
def radius_configuration():
    db = get_db()
    q = request.args.get("q", "").strip()
    query = "SELECT * FROM radius_config WHERE 1=1"
    params = []
    if q:
        query += " AND (nama LIKE ? OR server_alamat LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    query += " ORDER BY id DESC"
    daftar = db.execute(query, params).fetchall()
    return render_template("radius_configuration.html", daftar=daftar, q=q)


@app.route("/core-modules/radius/configuration/simpan", methods=["POST"])
@login_required
def radius_configuration_simpan():
    db = get_db()
    config_id = request.form.get("id", "").strip()
    nama = request.form.get("nama", "").strip()
    server_alamat = request.form.get("server_alamat", "").strip()
    port_auth = request.form.get("port_auth", "1812").strip() or "1812"
    port_acct = request.form.get("port_acct", "1813").strip() or "1813"
    port_coa = request.form.get("port_coa", "3799").strip() or "3799"
    shared_secret = request.form.get("shared_secret", "").strip()
    deskripsi = request.form.get("deskripsi", "").strip()
    if not nama or not server_alamat:
        flash("Nama dan Server wajib diisi.", "danger")
        return redirect(url_for("radius_configuration"))
    if config_id:
        db.execute(
            """UPDATE radius_config SET nama=?, server_alamat=?, port_auth=?, port_acct=?,
               port_coa=?, shared_secret=?, deskripsi=? WHERE id=?""",
            (nama, server_alamat, port_auth, port_acct, port_coa, shared_secret, deskripsi, config_id))
        flash("Konfigurasi RADIUS berhasil diperbarui.", "success")
    else:
        db.execute(
            """INSERT INTO radius_config (nama, server_alamat, port_auth, port_acct, port_coa,
               shared_secret, deskripsi, dibuat_pada) VALUES (?,?,?,?,?,?,?,?)""",
            (nama, server_alamat, port_auth, port_acct, port_coa, shared_secret, deskripsi, _sekarang()))
        flash("Konfigurasi RADIUS berhasil ditambahkan.", "success")
    db.commit()
    return redirect(url_for("radius_configuration"))


@app.route("/core-modules/radius/configuration/<int:cid>/hapus", methods=["POST"])
@login_required
def radius_configuration_hapus(cid):
    db = get_db()
    db.execute("DELETE FROM radius_config WHERE id=?", (cid,))
    db.commit()
    flash("Konfigurasi RADIUS dihapus.", "success")
    return redirect(url_for("radius_configuration"))


# =========================== RADIUS > Sesi Hotspot ===========================
@app.route("/core-modules/radius/hotspot")
@login_required
def radius_hotspot_sessions():
    db = get_db()
    riwayat = db.execute(
        """SELECT * FROM aktivitas_sistem WHERE kategori='hotspot'
           ORDER BY id DESC LIMIT 100"""
    ).fetchall()
    return render_template("radius_hotspot_sessions.html", riwayat=riwayat)


# ---------------------------------------------------------------------------
# ACS (TR-069/CWMP) -- Dashboard, Perangkat, Configuration, Tugas, Profil, Firmware
# Perangkat & Tugas ditarik live dari server GenieACS; Configuration/Profil/Firmware
# disimpan di database billing lalu bisa "di-push" ke perangkat lewat GenieACS NBI.
# ---------------------------------------------------------------------------
EKSTENSI_FIRMWARE_DIIZINKAN = {"bin", "img", "tar", "pkg", "rom", "zip"}


def _acs_get_cfg_aktif(db):
    """Ambil koneksi ACS yang aktif dipakai modul ACS (Devices/Tasks/push):
    pakai baris acs_config yang ditandai default, kalau tidak ada pakai baris
    pertama, kalau tabel kosong fallback ke Pengaturan GenieACS lama (kalau aktif).
    Return (cfg_dict_atau_None, baris_acs_config_atau_None)."""
    row = db.execute("SELECT * FROM acs_config WHERE is_default=1 ORDER BY id LIMIT 1").fetchone()
    if not row:
        row = db.execute("SELECT * FROM acs_config ORDER BY id LIMIT 1").fetchone()
    if row and row["acs_url"]:
        return {"url": row["acs_url"], "username": row["username"], "password": row["password"]}, row
    lama = db.execute("SELECT * FROM pengaturan_genieacs WHERE id=1").fetchone()
    if lama and lama["aktif"] and lama["url"]:
        return {"url": lama["url"], "username": lama["username"], "password": lama["password"]}, None
    return None, row


# =========================== ACS > Dashboard ===========================
@app.route("/core-modules/acs")
@login_required
def modul_inti_acs():
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    ringkasan_device = {"total": 0, "online": 0, "offline": 0}
    ringkasan_tugas = {"total": 0, "pending": 0, "running": 0, "done": 0, "failed": 0}
    error_koneksi = None
    if cfg:
        try:
            ringkasan_device = genieacs_client.hitung_ringkasan_device(cfg)
            ringkasan_tugas = genieacs_client.hitung_ringkasan_tugas(cfg)
        except genieacs_client.GenieACSError as e:
            error_koneksi = str(e)
    total_profil = db.execute("SELECT COUNT(*) c FROM acs_profile").fetchone()["c"]
    total_firmware = db.execute("SELECT COUNT(*) c FROM acs_firmware").fetchone()["c"]
    return render_template(
        "acs_dashboard.html", cfg_ada=bool(cfg), error_koneksi=error_koneksi,
        ringkasan_device=ringkasan_device, ringkasan_tugas=ringkasan_tugas,
        total_profil=total_profil, total_firmware=total_firmware,
    )


# =========================== ACS > Perangkat (Devices) ===========================
@app.route("/core-modules/acs/devices")
@login_required
def acs_devices():
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    manufacturer = request.args.get("manufacturer", "").strip()
    page = max(int(request.args.get("page", 1) or 1), 1)
    per_halaman = 20
    daftar, total = [], 0
    daftar_manufacturer = []
    error_koneksi = None
    if cfg:
        try:
            daftar_semua, _t = genieacs_client.daftar_device(cfg, limit=500)
            daftar_manufacturer = sorted({d["manufacturer"] for d in daftar_semua if d["manufacturer"] and d["manufacturer"] != "-"})
            daftar, total = genieacs_client.daftar_device(
                cfg, q=q or None, status=status or None, manufacturer=manufacturer or None,
                limit=per_halaman, skip=(page - 1) * per_halaman)
        except genieacs_client.GenieACSError as e:
            error_koneksi = str(e)
    total_halaman = max((total + per_halaman - 1) // per_halaman, 1)
    return render_template(
        "acs_devices.html", cfg_ada=bool(cfg), error_koneksi=error_koneksi,
        daftar=daftar, total=total, q=q, status=status, manufacturer=manufacturer,
        daftar_manufacturer=daftar_manufacturer, page=page, total_halaman=total_halaman,
    )


@app.route("/core-modules/acs/devices/<path:device_id>/reboot", methods=["POST"])
@login_required
def acs_devices_reboot(device_id):
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Konfigurasi ACS belum diatur.", "danger")
        return redirect(url_for("acs_devices"))
    try:
        genieacs_client.kirim_reboot_by_id(cfg, device_id)
        flash("Perintah reboot dikirim ke perangkat.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal mengirim perintah reboot: {e}", "danger")
    return redirect(url_for("acs_devices"))


@app.route("/core-modules/acs/devices/<path:device_id>/refresh", methods=["POST"])
@login_required
def acs_devices_refresh(device_id):
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Konfigurasi ACS belum diatur.", "danger")
        return redirect(url_for("acs_devices"))
    try:
        genieacs_client.kirim_refresh_by_id(cfg, device_id)
        flash("Permintaan refresh parameter dikirim ke perangkat.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal me-refresh perangkat: {e}", "danger")
    return redirect(url_for("acs_devices"))


@app.route("/core-modules/acs/devices/<path:device_id>/factory-reset", methods=["POST"])
@login_required
def acs_devices_factory_reset(device_id):
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Konfigurasi ACS belum diatur.", "danger")
        return redirect(url_for("acs_devices"))
    try:
        genieacs_client.kirim_factory_reset(cfg, device_id)
        flash("Perintah factory reset dikirim ke perangkat.", "warning")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal mengirim factory reset: {e}", "danger")
    return redirect(url_for("acs_devices"))


@app.route("/core-modules/acs/devices/<path:device_id>/hapus", methods=["POST"])
@login_required
def acs_devices_hapus(device_id):
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Konfigurasi ACS belum diatur.", "danger")
        return redirect(url_for("acs_devices"))
    try:
        genieacs_client.hapus_device(cfg, device_id)
        flash("Perangkat dihapus dari ACS.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal menghapus perangkat: {e}", "danger")
    return redirect(url_for("acs_devices"))


# =========================== ACS > Configuration ===========================
@app.route("/core-modules/acs/configuration")
@login_required
def acs_configuration():
    db = get_db()
    q = request.args.get("q", "").strip()
    query = "SELECT * FROM acs_config WHERE 1=1"
    params = []
    if q:
        query += " AND (nama LIKE ? OR acs_url LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    query += " ORDER BY is_default DESC, id DESC"
    daftar = db.execute(query, params).fetchall()
    return render_template("acs_configuration.html", daftar=daftar, q=q)


@app.route("/core-modules/acs/configuration/simpan", methods=["POST"])
@login_required
def acs_configuration_simpan():
    db = get_db()
    cid = request.form.get("id", "").strip()
    nama = request.form.get("nama", "").strip()
    deskripsi = request.form.get("deskripsi", "").strip()
    acs_url = request.form.get("acs_url", "").strip()
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()
    inform_interval = request.form.get("inform_interval", "300").strip() or "300"
    stun_aktif = 1 if request.form.get("stun_aktif") else 0
    stun_host = request.form.get("stun_host", "").strip()
    stun_port = request.form.get("stun_port", "3478").strip() or "3478"
    jadikan_default = 1 if request.form.get("is_default") else 0

    if not nama or not acs_url:
        flash("Nama dan ACS URL wajib diisi.", "danger")
        return redirect(url_for("acs_configuration"))

    if jadikan_default:
        db.execute("UPDATE acs_config SET is_default=0")

    if cid:
        if password:
            db.execute(
                """UPDATE acs_config SET nama=?, deskripsi=?, acs_url=?, username=?, password=?,
                   inform_interval=?, stun_aktif=?, stun_host=?, stun_port=?, is_default=? WHERE id=?""",
                (nama, deskripsi, acs_url, username, password, inform_interval, stun_aktif,
                 stun_host, stun_port, jadikan_default, cid))
        else:
            db.execute(
                """UPDATE acs_config SET nama=?, deskripsi=?, acs_url=?, username=?,
                   inform_interval=?, stun_aktif=?, stun_host=?, stun_port=?, is_default=? WHERE id=?""",
                (nama, deskripsi, acs_url, username, inform_interval, stun_aktif,
                 stun_host, stun_port, jadikan_default, cid))
        flash("Konfigurasi ACS berhasil diperbarui.", "success")
    else:
        cur = db.execute("SELECT COUNT(*) c FROM acs_config").fetchone()
        if cur["c"] == 0:
            jadikan_default = 1  # config pertama otomatis jadi default
        db.execute(
            """INSERT INTO acs_config (nama, deskripsi, acs_url, username, password, inform_interval,
               stun_aktif, stun_host, stun_port, is_default, dibuat_pada) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (nama, deskripsi, acs_url, username, password, inform_interval, stun_aktif,
             stun_host, stun_port, jadikan_default, _sekarang()))
        flash("Konfigurasi ACS berhasil ditambahkan.", "success")
    db.commit()
    return redirect(url_for("acs_configuration"))


@app.route("/core-modules/acs/configuration/<int:cid>/hapus", methods=["POST"])
@login_required
def acs_configuration_hapus(cid):
    db = get_db()
    db.execute("DELETE FROM acs_config WHERE id=?", (cid,))
    db.commit()
    flash("Konfigurasi ACS dihapus.", "success")
    return redirect(url_for("acs_configuration"))


@app.route("/core-modules/acs/configuration/<int:cid>/push", methods=["POST"])
@login_required
def acs_configuration_push(cid):
    """Dorong pengaturan koneksi (ACS URL, periodic inform, STUN) profil ini ke semua
    perangkat yang saat ini dikenal ACS, lewat setParameterValues ke cabang
    ManagementServer TR-069 (path default gaya TR-098)."""
    db = get_db()
    row = db.execute("SELECT * FROM acs_config WHERE id=?", (cid,)).fetchone()
    if not row:
        flash("Konfigurasi tidak ditemukan.", "danger")
        return redirect(url_for("acs_configuration"))
    cfg, _ = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Belum ada koneksi ACS aktif untuk mengirim perintah push.", "danger")
        return redirect(url_for("acs_configuration"))
    try:
        daftar_device, _total = genieacs_client.daftar_device(cfg, limit=500)
        pasangan = [
            ("InternetGatewayDevice.ManagementServer.URL", row["acs_url"]),
            ("InternetGatewayDevice.ManagementServer.PeriodicInformInterval", str(row["inform_interval"])),
            ("InternetGatewayDevice.ManagementServer.PeriodicInformEnable", "true"),
            ("InternetGatewayDevice.ManagementServer.STUNEnable", "true" if row["stun_aktif"] else "false"),
        ]
        if row["username"]:
            pasangan.append(("InternetGatewayDevice.ManagementServer.Username", row["username"]))
        if row["password"]:
            pasangan.append(("InternetGatewayDevice.ManagementServer.Password", row["password"]))
        if row["stun_aktif"] and row["stun_host"]:
            pasangan.append(("InternetGatewayDevice.ManagementServer.STUNServerAddress", row["stun_host"]))
            pasangan.append(("InternetGatewayDevice.ManagementServer.STUNServerPort", str(row["stun_port"] or 3478)))
        terkirim = 0
        for d in daftar_device:
            try:
                genieacs_client.kirim_set_parameter_by_id(cfg, d["id"], pasangan)
                terkirim += 1
            except genieacs_client.GenieACSError:
                pass
        flash(f"Konfigurasi '{row['nama']}' dikirim ke {terkirim} dari {len(daftar_device)} perangkat.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal push konfigurasi: {e}", "danger")
    return redirect(url_for("acs_configuration"))


# =========================== ACS > Tugas (Task Queue) ===========================
@app.route("/core-modules/acs/tasks")
@login_required
def acs_tasks():
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    q = request.args.get("q", "").strip()
    page = max(int(request.args.get("page", 1) or 1), 1)
    per_halaman = 20
    daftar, total = [], 0
    ringkasan = {"total": 0, "pending": 0, "running": 0, "done": 0, "failed": 0}
    error_koneksi = None
    if cfg:
        try:
            daftar, total = genieacs_client.daftar_tugas(cfg, q=q or None, limit=per_halaman, skip=(page - 1) * per_halaman)
            ringkasan = genieacs_client.hitung_ringkasan_tugas(cfg)
        except genieacs_client.GenieACSError as e:
            error_koneksi = str(e)
    total_halaman = max((total + per_halaman - 1) // per_halaman, 1)
    return render_template(
        "acs_tasks.html", cfg_ada=bool(cfg), error_koneksi=error_koneksi,
        daftar=daftar, total=total, ringkasan=ringkasan, q=q, page=page, total_halaman=total_halaman,
    )


@app.route("/core-modules/acs/tasks/<path:task_id>/hapus", methods=["POST"])
@login_required
def acs_tasks_hapus(task_id):
    db = get_db()
    cfg, _row = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Konfigurasi ACS belum diatur.", "danger")
        return redirect(url_for("acs_tasks"))
    try:
        genieacs_client.hapus_tugas(cfg, task_id)
        flash("Tugas dibatalkan/dihapus dari antrean.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal menghapus tugas: {e}", "danger")
    return redirect(url_for("acs_tasks"))


# =========================== ACS > Profil (Configuration Profiles) ===========================
@app.route("/core-modules/acs/profiles")
@login_required
def acs_profiles():
    db = get_db()
    tipe = request.args.get("tipe", "").strip()
    vendor = request.args.get("vendor", "").strip()
    query = "SELECT * FROM acs_profile WHERE 1=1"
    params = []
    if tipe:
        query += " AND tipe=?"
        params.append(tipe)
    if vendor:
        query += " AND vendor=?"
        params.append(vendor)
    query += " ORDER BY prioritas DESC, id DESC"
    daftar = db.execute(query, params).fetchall()
    daftar_vendor = db.execute(
        "SELECT DISTINCT vendor FROM acs_profile WHERE vendor IS NOT NULL AND vendor<>'' ORDER BY vendor").fetchall()
    return render_template(
        "acs_profiles.html", daftar=daftar, tipe=tipe, vendor=vendor,
        daftar_vendor=[v["vendor"] for v in daftar_vendor],
    )


@app.route("/core-modules/acs/profiles/simpan", methods=["POST"])
@login_required
def acs_profiles_simpan():
    db = get_db()
    pid = request.form.get("id", "").strip()
    nama = request.form.get("nama", "").strip()
    tipe = request.form.get("tipe", "bootstrap").strip()
    vendor = request.form.get("vendor", "").strip()
    match_oui = request.form.get("match_oui", "").strip()
    match_class = request.form.get("match_class", "").strip()
    match_desc = request.form.get("match_desc", "").strip() or "Any device"
    prioritas = request.form.get("prioritas", "100").strip() or "100"
    status = request.form.get("status", "aktif").strip()
    deskripsi = request.form.get("deskripsi", "").strip()

    if not nama:
        flash("Nama profil wajib diisi.", "danger")
        return redirect(url_for("acs_profiles"))

    if pid:
        db.execute(
            """UPDATE acs_profile SET nama=?, tipe=?, vendor=?, match_oui=?, match_class=?,
               match_desc=?, prioritas=?, status=?, deskripsi=? WHERE id=?""",
            (nama, tipe, vendor, match_oui, match_class, match_desc, prioritas, status, deskripsi, pid))
        flash("Profil ACS berhasil diperbarui.", "success")
    else:
        db.execute(
            """INSERT INTO acs_profile (nama, tipe, vendor, match_oui, match_class, match_desc,
               prioritas, status, deskripsi, dibuat_pada) VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (nama, tipe, vendor, match_oui, match_class, match_desc, prioritas, status, deskripsi, _sekarang()))
        flash("Profil ACS berhasil ditambahkan.", "success")
    db.commit()
    return redirect(url_for("acs_profiles"))


@app.route("/core-modules/acs/profiles/<int:pid>/hapus", methods=["POST"])
@login_required
def acs_profiles_hapus(pid):
    db = get_db()
    db.execute("DELETE FROM acs_profile WHERE id=?", (pid,))
    db.commit()
    flash("Profil ACS dihapus.", "success")
    return redirect(url_for("acs_profiles"))


@app.route("/core-modules/acs/profiles/<int:pid>/push", methods=["POST"])
@login_required
def acs_profiles_push(pid):
    """Dorong profil ke device yang cocok kriteria (OUI/Product Class kalau diisi;
    kalau tidak diisi sama sekali berarti berlaku untuk semua device)."""
    db = get_db()
    row = db.execute("SELECT * FROM acs_profile WHERE id=?", (pid,)).fetchone()
    if not row:
        flash("Profil tidak ditemukan.", "danger")
        return redirect(url_for("acs_profiles"))
    cfg, _ = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Belum ada koneksi ACS aktif untuk push profil.", "danger")
        return redirect(url_for("acs_profiles"))
    try:
        daftar_device, _total = genieacs_client.daftar_device(cfg, limit=500)
        cocok = []
        for d in daftar_device:
            if row["match_oui"] and d["oui"] != row["match_oui"]:
                continue
            if row["match_class"] and d["product_class"] != row["match_class"]:
                continue
            cocok.append(d)
        pasangan = json.loads(row["parameter_json"]) if row["parameter_json"] else []
        terkirim = 0
        for d in cocok:
            try:
                if pasangan:
                    genieacs_client.kirim_set_parameter_by_id(cfg, d["id"], pasangan)
                else:
                    genieacs_client.kirim_refresh_by_id(cfg, d["id"])
                terkirim += 1
            except genieacs_client.GenieACSError:
                pass
        flash(f"Profil '{row['nama']}' didorong ke {terkirim} dari {len(cocok)} perangkat yang cocok.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal push profil: {e}", "danger")
    return redirect(url_for("acs_profiles"))


# =========================== ACS > Firmware Catalog ===========================
@app.route("/core-modules/acs/firmware")
@login_required
def acs_firmware():
    db = get_db()
    vendor = request.args.get("vendor", "").strip()
    query = "SELECT * FROM acs_firmware WHERE 1=1"
    params = []
    if vendor:
        query += " AND vendor=?"
        params.append(vendor)
    query += " ORDER BY id DESC"
    daftar = db.execute(query, params).fetchall()
    daftar_vendor = db.execute(
        "SELECT DISTINCT vendor FROM acs_firmware WHERE vendor IS NOT NULL AND vendor<>'' ORDER BY vendor").fetchall()
    return render_template(
        "acs_firmware.html", daftar=daftar, vendor=vendor, daftar_vendor=[v["vendor"] for v in daftar_vendor],
    )


@app.route("/core-modules/acs/firmware/simpan", methods=["POST"])
@login_required
def acs_firmware_simpan():
    db = get_db()
    nama = request.form.get("nama", "").strip()
    versi = request.form.get("versi", "").strip()
    vendor = request.form.get("vendor", "").strip()
    model = request.form.get("model", "").strip()
    status = request.form.get("status", "aktif").strip()
    tanggal_rilis = request.form.get("tanggal_rilis", "").strip()

    if not nama or not versi:
        flash("Nama dan Versi firmware wajib diisi.", "danger")
        return redirect(url_for("acs_firmware"))

    file_path = None
    file_size = 0
    berkas = request.files.get("berkas")
    if berkas and berkas.filename:
        ekstensi = berkas.filename.rsplit(".", 1)[-1].lower() if "." in berkas.filename else ""
        if ekstensi not in EKSTENSI_FIRMWARE_DIIZINKAN:
            flash("Format file firmware tidak didukung (gunakan .bin/.img/.tar/.pkg/.rom/.zip).", "danger")
            return redirect(url_for("acs_firmware"))
        folder_firmware = os.path.join(UPLOAD_FOLDER, "firmware")
        os.makedirs(folder_firmware, exist_ok=True)
        nama_file = secure_filename(f"fw_{secrets.token_hex(6)}_{berkas.filename}")
        tujuan = os.path.join(folder_firmware, nama_file)
        berkas.save(tujuan)
        file_path = os.path.join("firmware", nama_file)
        file_size = os.path.getsize(tujuan)

    db.execute(
        """INSERT INTO acs_firmware (nama, versi, vendor, model, file_path, file_size, status,
           tanggal_rilis, dibuat_pada) VALUES (?,?,?,?,?,?,?,?,?)""",
        (nama, versi, vendor, model, file_path, file_size, status, tanggal_rilis, _sekarang()))
    db.commit()
    flash("Firmware berhasil ditambahkan ke katalog.", "success")
    return redirect(url_for("acs_firmware"))


@app.route("/core-modules/acs/firmware/<int:fid>/hapus", methods=["POST"])
@login_required
def acs_firmware_hapus(fid):
    db = get_db()
    row = db.execute("SELECT * FROM acs_firmware WHERE id=?", (fid,)).fetchone()
    if row and row["file_path"]:
        try:
            os.remove(os.path.join(UPLOAD_FOLDER, row["file_path"]))
        except OSError:
            pass
    db.execute("DELETE FROM acs_firmware WHERE id=?", (fid,))
    db.commit()
    flash("Firmware dihapus dari katalog.", "success")
    return redirect(url_for("acs_firmware"))


@app.route("/core-modules/acs/firmware/<int:fid>/push", methods=["POST"])
@login_required
def acs_firmware_push(fid):
    """Unggah file firmware ke GenieACS Files API lalu kirim task 'download' OTA ke
    semua perangkat yang vendor-nya cocok (kalau vendor kosong berarti semua)."""
    db = get_db()
    row = db.execute("SELECT * FROM acs_firmware WHERE id=?", (fid,)).fetchone()
    if not row or not row["file_path"]:
        flash("Firmware tidak ditemukan atau belum ada file yang diunggah.", "danger")
        return redirect(url_for("acs_firmware"))
    cfg, _ = _acs_get_cfg_aktif(db)
    if not cfg:
        flash("Belum ada koneksi ACS aktif untuk push firmware.", "danger")
        return redirect(url_for("acs_firmware"))
    try:
        lokasi_file = os.path.join(UPLOAD_FOLDER, row["file_path"])
        nama_file_acs = os.path.basename(row["file_path"])
        with open(lokasi_file, "rb") as fh:
            isi = fh.read()
        genieacs_client.unggah_firmware_file(cfg, nama_file_acs, isi, metadata={
            "vendor": row["vendor"], "model": row["model"], "version": row["versi"],
        })
        daftar_device, _total = genieacs_client.daftar_device(cfg, limit=500)
        cocok = [d for d in daftar_device if not row["vendor"] or d["manufacturer"] == row["vendor"]]
        terkirim = 0
        for d in cocok:
            try:
                genieacs_client.kirim_download_firmware(cfg, d["id"], "1 Firmware Upgrade Image", nama_file_acs)
                terkirim += 1
            except genieacs_client.GenieACSError:
                pass
        flash(f"Firmware '{row['nama']}' diunggah ke ACS & dikirim ke {terkirim} dari {len(cocok)} perangkat.", "success")
    except genieacs_client.GenieACSError as e:
        flash(f"Gagal push firmware: {e}", "danger")
    except OSError as e:
        flash(f"Gagal membaca file firmware: {e}", "danger")
    return redirect(url_for("acs_firmware"))


# ---------------------------------------------------------------------------
# Live Chat -- dashboard + 8 fitur: auto-assign, quick reply, chat tags,
# broadcast, chatbot flow, chat analytics, working hours, blacklist nomor.
# ---------------------------------------------------------------------------
LIVE_CHAT_WARNA_VALID = {"purple", "teal", "amber", "red"}
LIVE_CHAT_HARI_URUT = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]


@app.route("/modul-inti/live-chat")
@login_required
def modul_inti_live_chat():
    db = get_db()
    tab = request.args.get("tab", "dashboard")

    auto_assign = db.execute("SELECT * FROM live_chat_auto_assign WHERE id=1").fetchone()
    quick_replies = db.execute("SELECT * FROM live_chat_quick_reply ORDER BY id DESC").fetchall()
    tags = db.execute("SELECT * FROM live_chat_tag ORDER BY id DESC").fetchall()
    broadcasts = db.execute("SELECT * FROM live_chat_broadcast ORDER BY id DESC LIMIT 30").fetchall()
    chatbot_flow = db.execute("SELECT * FROM live_chat_chatbot_flow ORDER BY urutan ASC, id ASC").fetchall()
    working_hours = db.execute("SELECT * FROM live_chat_working_hours").fetchall()
    working_hours_map = {row["hari"]: row for row in working_hours}
    working_hours_urut = [working_hours_map[h] for h in LIVE_CHAT_HARI_URUT if h in working_hours_map]
    working_hours_pesan = db.execute("SELECT pesan FROM live_chat_working_hours_pesan WHERE id=1").fetchone()
    blacklist = db.execute("SELECT * FROM live_chat_blacklist ORDER BY id DESC").fetchall()

    jumlah_pelanggan = db.execute("SELECT COUNT(*) c FROM pelanggan").fetchone()["c"]

    return render_template(
        "live_chat_hub.html",
        tab_aktif=tab,
        auto_assign=auto_assign,
        quick_replies=quick_replies,
        tags=tags,
        warna_tag_valid=sorted(LIVE_CHAT_WARNA_VALID),
        broadcasts=broadcasts,
        chatbot_flow=chatbot_flow,
        working_hours=working_hours_urut,
        working_hours_pesan=working_hours_pesan["pesan"] if working_hours_pesan else "",
        blacklist=blacklist,
        jumlah_pelanggan=jumlah_pelanggan,
    )


@app.route("/modul-inti/live-chat/auto-assign/simpan", methods=["POST"])
@login_required
def live_chat_auto_assign_simpan():
    db = get_db()
    aktif = 1 if request.form.get("aktif") == "on" else 0
    metode = request.form.get("metode", "round_robin")
    try:
        maks_chat = int(request.form.get("maks_chat_per_cs", 8))
    except ValueError:
        maks_chat = 8
    db.execute(
        "UPDATE live_chat_auto_assign SET aktif=?, metode=?, maks_chat_per_cs=? WHERE id=1",
        (aktif, metode, maks_chat),
    )
    db.commit()
    flash("Pengaturan auto-assign disimpan.", "success")
    return redirect(url_for("modul_inti_live_chat", tab="auto-assign"))


@app.route("/modul-inti/live-chat/quick-reply/tambah", methods=["POST"])
@login_required
def live_chat_quick_reply_tambah():
    db = get_db()
    shortcut = (request.form.get("shortcut") or "").strip()
    pesan = (request.form.get("pesan") or "").strip()
    if shortcut and pesan:
        db.execute(
            "INSERT INTO live_chat_quick_reply (shortcut, pesan, dibuat_tanggal) VALUES (?, ?, ?)",
            (shortcut, pesan, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        )
        db.commit()
        flash("Template quick reply ditambahkan.", "success")
    else:
        flash("Isi shortcut dan pesan terlebih dahulu.", "danger")
    return redirect(url_for("modul_inti_live_chat", tab="quick-reply"))


@app.route("/modul-inti/live-chat/quick-reply/hapus/<int:qr_id>", methods=["POST"])
@login_required
def live_chat_quick_reply_hapus(qr_id):
    db = get_db()
    db.execute("DELETE FROM live_chat_quick_reply WHERE id=?", (qr_id,))
    db.commit()
    flash("Template quick reply dihapus.", "success")
    return redirect(url_for("modul_inti_live_chat", tab="quick-reply"))


@app.route("/modul-inti/live-chat/tag/tambah", methods=["POST"])
@login_required
def live_chat_tag_tambah():
    db = get_db()
    nama = (request.form.get("nama") or "").strip()
    warna = request.form.get("warna", "purple")
    if warna not in LIVE_CHAT_WARNA_VALID:
        warna = "purple"
    if nama:
        db.execute("INSERT INTO live_chat_tag (nama, warna) VALUES (?, ?)", (nama, warna))
        db.commit()
        flash("Tag ditambahkan.", "success")
    else:
        flash("Isi nama tag terlebih dahulu.", "danger")
    return redirect(url_for("modul_inti_live_chat", tab="tags"))


@app.route("/modul-inti/live-chat/tag/hapus/<int:tag_id>", methods=["POST"])
@login_required
def live_chat_tag_hapus(tag_id):
    db = get_db()
    db.execute("DELETE FROM live_chat_tag WHERE id=?", (tag_id,))
    db.commit()
    flash("Tag dihapus.", "success")
    return redirect(url_for("modul_inti_live_chat", tab="tags"))


@app.route("/modul-inti/live-chat/broadcast/kirim", methods=["POST"])
@login_required
def live_chat_broadcast_kirim():
    db = get_db()
    target = (request.form.get("target") or "").strip()
    pesan = (request.form.get("pesan") or "").strip()
    jadwal = request.form.get("jadwal", "sekarang")
    if pesan and target:
        status = "terkirim" if jadwal == "sekarang" else "dijadwalkan"
        db.execute(
            "INSERT INTO live_chat_broadcast (target, pesan, status, dibuat_tanggal) VALUES (?, ?, ?, ?)",
            (target, pesan, status, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        )
        db.commit()
        flash("Broadcast diproses.", "success")
    else:
        flash("Isi target dan pesan broadcast terlebih dahulu.", "danger")
    return redirect(url_for("modul_inti_live_chat", tab="broadcast"))


@app.route("/modul-inti/live-chat/chatbot-flow/tambah", methods=["POST"])
@login_required
def live_chat_chatbot_flow_tambah():
    db = get_db()
    trigger_kata_kunci = (request.form.get("trigger_kata_kunci") or "").strip()
    balasan = (request.form.get("balasan") or "").strip()
    if trigger_kata_kunci and balasan:
        urutan_max = db.execute("SELECT COALESCE(MAX(urutan), 0) m FROM live_chat_chatbot_flow").fetchone()["m"]
        db.execute(
            "INSERT INTO live_chat_chatbot_flow (trigger_kata_kunci, balasan, urutan) VALUES (?, ?, ?)",
            (trigger_kata_kunci, balasan, urutan_max + 1),
        )
        db.commit()
        flash("Langkah chatbot flow ditambahkan.", "success")
    else:
        flash("Isi kata kunci dan balasan terlebih dahulu.", "danger")
    return redirect(url_for("modul_inti_live_chat", tab="chatbot-flow"))


@app.route("/modul-inti/live-chat/chatbot-flow/hapus/<int:flow_id>", methods=["POST"])
@login_required
def live_chat_chatbot_flow_hapus(flow_id):
    db = get_db()
    db.execute("DELETE FROM live_chat_chatbot_flow WHERE id=?", (flow_id,))
    db.commit()
    flash("Langkah chatbot flow dihapus.", "success")
    return redirect(url_for("modul_inti_live_chat", tab="chatbot-flow"))


@app.route("/modul-inti/live-chat/working-hours/simpan", methods=["POST"])
@login_required
def live_chat_working_hours_simpan():
    db = get_db()
    for hari in LIVE_CHAT_HARI_URUT:
        aktif = 1 if request.form.get(f"aktif_{hari}") == "on" else 0
        jam_mulai = request.form.get(f"mulai_{hari}", "08:00")
        jam_selesai = request.form.get(f"selesai_{hari}", "20:00")
        db.execute(
            "UPDATE live_chat_working_hours SET aktif=?, jam_mulai=?, jam_selesai=? WHERE hari=?",
            (aktif, jam_mulai, jam_selesai, hari),
        )
    pesan = (request.form.get("pesan_auto_reply") or "").strip()
    if pesan:
        db.execute("UPDATE live_chat_working_hours_pesan SET pesan=? WHERE id=1", (pesan,))
    db.commit()
    flash("Pengaturan jam operasional disimpan.", "success")
    return redirect(url_for("modul_inti_live_chat", tab="working-hours"))


@app.route("/modul-inti/live-chat/blacklist/tambah", methods=["POST"])
@login_required
def live_chat_blacklist_tambah():
    db = get_db()
    nomor = (request.form.get("nomor") or "").strip()
    alasan = (request.form.get("alasan") or "").strip() or "-"
    if nomor:
        db.execute(
            "INSERT INTO live_chat_blacklist (nomor, alasan, dibuat_tanggal) VALUES (?, ?, ?)",
            (nomor, alasan, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        )
        db.commit()
        flash("Nomor diblokir.", "success")
    else:
        flash("Isi nomor terlebih dahulu.", "danger")
    return redirect(url_for("modul_inti_live_chat", tab="blacklist"))


@app.route("/modul-inti/live-chat/blacklist/hapus/<int:bl_id>", methods=["POST"])
@login_required
def live_chat_blacklist_hapus(bl_id):
    db = get_db()
    db.execute("DELETE FROM live_chat_blacklist WHERE id=?", (bl_id,))
    db.commit()
    flash("Nomor dibuka blokirnya.", "success")
    return redirect(url_for("modul_inti_live_chat", tab="blacklist"))


# ---------------------------------------------------------------------------
# Modul Inti -- placeholder untuk menu-menu baru di grup sidebar "Modul Inti"
# (halaman/fiturnya belum ada, jadi sementara tampil sebagai "Segera Hadir")
# ---------------------------------------------------------------------------
MODUL_INTI_PAGES = {
    "modul_inti_klien":        {"url": "/modul-inti/klien",        "judul": "Klien",           "ikon": "bi-people-fill",              "deskripsi": "Kelola data klien/pelanggan inti layanan."},
    "modul_inti_plans_policy": {"url": "/modul-inti/plans-policy", "judul": "Plans & Policy",  "ikon": "bi-layers-fill",              "deskripsi": "Kelola paket layanan beserta kebijakannya."},
    "modul_inti_network":      {"url": "/modul-inti/network",      "judul": "Network",         "ikon": "bi-diagram-3-fill",           "deskripsi": "Kelola perangkat & topologi jaringan."},
    "modul_inti_vpn_akses_pengguna": {"url": "/modul-inti/vpn/akses-pengguna", "judul": "Akses Pengguna", "ikon": "bi-person-check-fill", "deskripsi": "Kelola hak akses pengguna VPN."},
    "modul_inti_snmp":         {"url": "/modul-inti/snmp",         "judul": "SNMP",            "ikon": "bi-sliders",                   "deskripsi": "Kelola monitoring perangkat lewat SNMP."},
}


def _daftar_modul_inti_placeholder(endpoint, sumber_dict):
    info = sumber_dict[endpoint]

    @app.route(info["url"], endpoint=endpoint)
    @login_required
    def _halaman_modul_inti(info=info):
        return render_template(
            "modul_inti_placeholder.html",
            judul_halaman=info["judul"],
            ikon_halaman=info["ikon"],
            deskripsi_halaman=info["deskripsi"],
        )


for _endpoint in MODUL_INTI_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, MODUL_INTI_PAGES)


# ---------------------------------------------------------------------------
# Modul ERP -- placeholder untuk menu-menu baru di grup sidebar "Modul ERP"
# ---------------------------------------------------------------------------
MODUL_ERP_PAGES = {
    "modul_erp_sdm":              {"url": "/modul-erp/sdm",              "judul": "SDM",             "ikon": "bi-person-badge-fill",   "deskripsi": "Kelola data & administrasi sumber daya manusia."},
    "modul_erp_keuangan":         {"url": "/modul-erp/keuangan",         "judul": "Keuangan",        "ikon": "bi-cash-coin",            "deskripsi": "Kelola pembukuan & laporan keuangan perusahaan."},
    "modul_erp_general_affair":   {"url": "/modul-erp/general-affair",   "judul": "General Affair",  "ikon": "bi-building",             "deskripsi": "Kelola urusan umum & operasional perusahaan."},
    "modul_erp_inventaris":       {"url": "/modul-erp/inventaris",       "judul": "Inventaris",      "ikon": "bi-box-seam-fill",        "deskripsi": "Kelola aset & inventaris perusahaan."},
    "modul_erp_vendors":          {"url": "/modul-erp/vendors",          "judul": "Vendors",         "ikon": "bi-house-gear-fill",      "deskripsi": "Kelola data & kerja sama vendor/pemasok."},
}

for _endpoint in MODUL_ERP_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, MODUL_ERP_PAGES)


# ---------------------------------------------------------------------------
# CRM & Konten -- placeholder untuk menu-menu baru di grup sidebar "CRM & Konten"
# ---------------------------------------------------------------------------
CRM_KONTEN_PAGES = {
    "crm_konten_crm":    {"url": "/crm-konten/crm",    "judul": "CRM",     "ikon": "bi-bar-chart-fill",  "deskripsi": "Kelola relasi & interaksi dengan calon pelanggan."},
    "crm_konten_cms":    {"url": "/crm-konten/cms",    "judul": "CMS",     "ikon": "bi-file-earmark-richtext-fill", "deskripsi": "Kelola konten yang tampil di website/portal."},
    "crm_konten_dokumen":{"url": "/crm-konten/dokumen","judul": "Dokumen", "ikon": "bi-file-earmark-text-fill", "deskripsi": "Kelola arsip & dokumen perusahaan."},
}

for _endpoint in CRM_KONTEN_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, CRM_KONTEN_PAGES)


# ---------------------------------------------------------------------------
# Workspace -- placeholder untuk menu-menu baru di grup sidebar "Workspace"
# ---------------------------------------------------------------------------
WORKSPACE_PAGES = {
    "workspace_my_work":    {"url": "/workspace/my-work",    "judul": "My Work",    "ikon": "bi-file-earmark-person-fill", "deskripsi": "Lihat daftar tugas & pekerjaan milikmu."},
    "workspace_projects":   {"url": "/workspace/projects",   "judul": "Projects",   "ikon": "bi-grid-3x3-gap-fill",        "deskripsi": "Kelola proyek & progres tim."},
    "workspace_calendar":   {"url": "/workspace/calendar",   "judul": "Calendar",   "ikon": "bi-calendar3",                "deskripsi": "Lihat jadwal & agenda kerja tim."},
    "workspace_workload":   {"url": "/workspace/workload",   "judul": "Workload",   "ikon": "bi-bar-chart-line-fill",      "deskripsi": "Pantau beban kerja anggota tim."},
    "workspace_utilization":{"url": "/workspace/utilization","judul": "Utilization","ikon": "bi-percent",                  "deskripsi": "Pantau tingkat utilisasi sumber daya tim."},
    "workspace_activity":   {"url": "/workspace/activity",   "judul": "Activity",   "ikon": "bi-clock-history",            "deskripsi": "Lihat riwayat aktivitas terbaru di workspace."},
    "workspace_mentions":   {"url": "/workspace/mentions",   "judul": "Mentions",   "ikon": "bi-at",                       "deskripsi": "Lihat notifikasi & mention yang ditujukan untukmu."},
}

for _endpoint in WORKSPACE_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, WORKSPACE_PAGES)


# ---------------------------------------------------------------------------
# Analitik -- placeholder untuk menu-menu baru di grup sidebar "Analitik"
# ---------------------------------------------------------------------------
ANALITIK_PAGES = {
    "analitik_analytics_reporting": {"url": "/analitik/analytics-reporting", "judul": "Analytics & Reporting", "ikon": "bi-pie-chart-fill", "deskripsi": "Lihat analisis data & laporan performa bisnis."},
}

for _endpoint in ANALITIK_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, ANALITIK_PAGES)


# ---------------------------------------------------------------------------
# Ekstensi -- placeholder untuk menu-menu baru di grup sidebar "Ekstensi"
# ---------------------------------------------------------------------------
EKSTENSI_PAGES = {
    "ekstensi_rka_planning": {"url": "/ekstensi/rka-planning", "judul": "RKA Planning", "ikon": "bi-bar-chart-line-fill", "deskripsi": "Kelola rencana kerja & anggaran (RKA)."},
}

for _endpoint in EKSTENSI_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, EKSTENSI_PAGES)


# ---------------------------------------------------------------------------
# Administrasi -- placeholder untuk menu-menu baru di grup sidebar "Administrasi"
# ---------------------------------------------------------------------------
ADMINISTRASI_PAGES = {
    "administrasi_system_administration": {"url": "/administrasi/system-administration", "judul": "System Administration", "ikon": "bi-gear-wide-connected", "deskripsi": "Kelola pengaturan & konfigurasi sistem secara menyeluruh."},
    "administrasi_partners":              {"url": "/administrasi/partners",              "judul": "Partners",              "ikon": "bi-arrow-left-right",     "deskripsi": "Kelola data & kerja sama mitra/partner."},
    "administrasi_migrasi":               {"url": "/administrasi/migrasi",               "judul": "Migrasi",               "ikon": "bi-box-arrow-in-right",    "deskripsi": "Kelola proses migrasi data pelanggan/sistem."},
}

for _endpoint in ADMINISTRASI_PAGES:
    _daftar_modul_inti_placeholder(_endpoint, ADMINISTRASI_PAGES)


if __name__ == "__main__":
    HOST = os.environ.get("HOST", "0.0.0.0")
    PORT = int(os.environ.get("PORT", "80"))
    MODE_DEBUG = os.environ.get("APP_DEBUG", "0") == "1"

    try:
        init_db()
        print("=" * 60)
        print(" Web Portal Billing Internet")
        print(f" Akses lokal   : http://localhost:{PORT}")
        print(" Login default -> username: admin | password: admin123")
        print(" Tekan CTRL+C di jendela ini untuk menghentikan server.")
        print()
        print(" Mau diakses online dari mana saja? Biarkan jendela ini")
        print(" tetap terbuka, lalu jalankan start_tunnel.bat (Windows)")
        print(" atau start_tunnel.sh (Linux/Mac) di jendela terpisah.")
        print("=" * 60)

        if MODE_DEBUG:
            # mode pengembangan saja: reloader Flask, debugger aktif.
            # JANGAN dipakai saat aplikasi bisa diakses dari internet.
            app.run(host=HOST, port=PORT, debug=True, use_reloader=False)
        else:
            try:
                from waitress import serve
                print(" Menjalankan server produksi (waitress)...")
                print("=" * 60)
                # threads dinaikkan (default waitress cuma 4) supaya request lain (halaman lain,
                # static file, dsb) tidak ikut antre kalau ada request yang lambat -- misalnya
                # panel "Login OLT" / scan ONU yang menunggu balasan SNMP dari OLT yang
                # IP/host-nya belum benar atau sedang tidak bisa dihubungi (blocking sampai timeout).
                serve(app, host=HOST, port=PORT, threads=16)
            except ImportError:
                print(" [Peringatan] Library 'waitress' belum terinstall, memakai")
                print(" server bawaan Flask (cukup untuk pemakaian ringan/lokal).")
                print(" Untuk produksi/online, install dulu: pip install waitress")
                print("=" * 60)
                app.run(host=HOST, port=PORT, debug=False, use_reloader=False)
    except Exception as e:
        import traceback
        print("\n" + "=" * 60)
        print(" TERJADI ERROR SAAT MENJALANKAN SERVER:")
        print("=" * 60)
        traceback.print_exc()
        print("\nPesan di atas menunjukkan penyebab error.")
        print("Kemungkinan umum: library belum terinstall, atau port sudah dipakai.")
    finally:
        input("\nTekan ENTER untuk menutup jendela ini...")
