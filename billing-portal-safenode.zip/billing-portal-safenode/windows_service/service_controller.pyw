"""
BENTANG RADIUS - Service Controller (NOC Edition)
========================================================================
Panel kontrol GUI (tanpa dependency tambahan, cuma pakai library bawaan
Python) untuk mengelola aplikasi billing ini: Start / Stop / Restart /
Auto-Start / lihat status & log -- ditampilkan dengan gaya dashboard
NOC (Network Operations Center): status LED, panel bersekat, log
terminal, dan jam berjalan.

Cara pakai: klik 2x "ServiceController.bat" di folder yang sama
(otomatis minta akses Administrator via UAC, karena kontrol
service/Task Scheduler di Windows memang butuh hak admin).
"""
import os
import sys
import subprocess
import threading
import time
import datetime
import webbrowser
import tkinter as tk
from tkinter import messagebox, scrolledtext

# ======================================================================
#  KONFIGURASI
# ======================================================================
SERVICE_NAME = "BentangRadiusBilling"
APP_URL = "http://127.0.0.1:80"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(BASE_DIR)
LOG_FILE = os.path.join(BASE_DIR, "service.log")
ERR_LOG_FILE = os.path.join(BASE_DIR, "service_error.log")
BOOT_ERR_LOG_FILE = os.path.join(BASE_DIR, "service_boot_error.log")

# --- Mode Sederhana (default): jalankan aplikasi langsung di background,
# TANPA lewat Windows Service/pywin32/SCM. Ini menghindari semua masalah
# registrasi DLL pywin32 yang bikin "not responding to the control
# function" -- karena cara ini persis seperti Mode Debug yang sudah
# terbukti berhasil, cuma tanpa jendela hitam yang harus dibiarkan terbuka.
RUN_SCRIPT = os.path.join(BASE_DIR, "run_background.py")
PID_FILE = os.path.join(BASE_DIR, "background_run.pid")
PYTHONW_EXE = os.path.join(os.path.dirname(BASE_DIR), "venv", "Scripts", "pythonw.exe")
VENV_PYTHON = os.path.join(os.path.dirname(BASE_DIR), "venv", "Scripts", "python.exe")
AUTOSTART_TASK_NAME = "BentangRadiusBillingAutoStart"

# --- Akses Online (Cloudflare Tunnel) -- via Task Scheduler, BUKAN lewat
# Windows Service pywin32 (service lama "BentangRadiusTunnel" kena bug
# "not responding to the control function" dan sudah ditinggalkan).
TUNNEL_INFO_PATH = os.path.join(APP_DIR, "tunnel_info.txt")
SETUP_TUNNEL_BAT = os.path.join(APP_DIR, "setup_tunnel_pertama_kali.bat")
TUNNEL_TASK_NAME = "BentangRadiusTunnelAutoStart"
TUNNEL_LOOP_BAT = os.path.join(BASE_DIR, "tunnel_loop.bat")
TUNNEL_LOOP_VBS = os.path.join(BASE_DIR, "tunnel_loop_hidden.vbs")
TUNNEL_LOOP_LOG = os.path.join(BASE_DIR, "tunnel_loop.log")
OLD_TUNNEL_SERVICE_NAME = "BentangRadiusTunnel"  # peninggalan lama, dibersihkan otomatis
OLD_TUNNEL_LOG_FILE = os.path.join(BASE_DIR, "tunnel_service.log")
OLD_TUNNEL_ERR_LOG_FILE = os.path.join(BASE_DIR, "tunnel_service_error.log")

NO_WINDOW = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0

# --- Palet warna gaya NOC ---
C_BG = "#070b13"           # latar utama, hampir hitam
C_PANEL = "#0e1626"        # latar panel/kartu
C_PANEL_BORDER = "#1c2740"
C_HEADER = "#0a0f1c"
C_TEXT = "#d7dee8"
C_TEXT_DIM = "#6b7791"
C_TEXT_FAINT = "#3d465c"
C_ACCENT_CYAN = "#39f2d0"
C_ACCENT_BLUE = "#2f8fff"
C_OK = "#27e07f"
C_WARN = "#ffb020"
C_DOWN = "#ff4b5c"
C_NEUTRAL = "#5a6478"
C_LOG_BG = "#04070d"
C_LOG_FG = "#39f2a0"


def baca_info_tunnel():
    """Baca tunnel_info.txt. Mengembalikan (hostname, nama_tunnel) atau (None, None)."""
    if not os.path.exists(TUNNEL_INFO_PATH):
        return None, None
    hostname, nama_tunnel = None, None
    try:
        with open(TUNNEL_INFO_PATH, "r", encoding="utf-8") as f:
            for baris in f:
                baris = baris.strip()
                if baris.startswith("HOSTNAME="):
                    hostname = baris.split("=", 1)[1].strip()
                elif baris.startswith("TUNNEL_NAME="):
                    nama_tunnel = baris.split("=", 1)[1].strip()
    except OSError:
        return None, None
    if not hostname or not nama_tunnel:
        return None, None
    return hostname, nama_tunnel


def run_cmd(args, timeout=20):
    """Jalankan perintah Windows dan kembalikan (returncode, stdout, stderr)."""
    try:
        result = subprocess.run(
            args, capture_output=True, text=True, timeout=timeout,
            creationflags=NO_WINDOW, shell=False,
        )
        return result.returncode, result.stdout, result.stderr
    except FileNotFoundError:
        return 1, "", "Perintah tidak ditemukan."
    except subprocess.TimeoutExpired:
        return 1, "", "Waktu tunggu habis."


def get_service_state(service_name=SERVICE_NAME):
    """Mengembalikan salah satu: RUNNING, STOPPED, START_PENDING, STOP_PENDING,
    NOT_INSTALLED, atau UNKNOWN."""
    code, out, err = run_cmd(["sc", "query", service_name])
    if "does not exist" in (err + out).lower() or "1060" in out:
        return "NOT_INSTALLED"
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("STATE"):
            if "RUNNING" in line:
                return "RUNNING"
            if "STOPPED" in line:
                return "STOPPED"
            if "START_PENDING" in line:
                return "START_PENDING"
            if "STOP_PENDING" in line:
                return "STOP_PENDING"
    return "UNKNOWN"


def _baca_pid():
    if not os.path.isfile(PID_FILE):
        return None
    try:
        with open(PID_FILE, "r", encoding="utf-8") as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return None


def _pid_hidup(pid):
    """Cek apakah proses dengan PID itu masih hidup lewat tasklist."""
    if pid is None:
        return False
    code, out, err = run_cmd(["tasklist", "/FI", f"PID eq {pid}", "/NH"])
    return str(pid) in out


def get_app_state():
    """Status aplikasi mode sederhana: RUNNING atau STOPPED, berdasarkan
    apakah proses PID yang tersimpan di background_run.pid masih hidup."""
    return "RUNNING" if _pid_hidup(_baca_pid()) else "STOPPED"


def is_autostart_installed():
    code, out, err = run_cmd(["schtasks", "/Query", "/TN", AUTOSTART_TASK_NAME])
    return code == 0


def get_service_bin_path():
    """Ambil path executable yang terdaftar untuk service ini (lewat 'sc qc'),
    dan kembalikan path exe-nya saja (tanpa argumen, tanpa tanda kutip)."""
    code, out, err = run_cmd(["sc", "qc", SERVICE_NAME])
    for line in out.splitlines():
        line = line.strip()
        if line.upper().startswith("BINARY_PATH_NAME"):
            parts = line.split(":", 1)
            if len(parts) != 2:
                return None
            raw = parts[1].strip()
            if raw.startswith('"'):
                end = raw.find('"', 1)
                return raw[1:end] if end != -1 else raw.strip('"')
            return raw.split(" ")[0]
    return None


def baca_ekor_log(path, n_baris=12):
    """Baca beberapa baris terakhir dari file log, kalau ada."""
    if not os.path.isfile(path):
        return ""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            baris = f.readlines()[-n_baris:]
        return "".join(baris).strip()
    except OSError:
        return ""


def diagnose_not_responding():
    isi_log = baca_ekor_log(ERR_LOG_FILE)
    isi_boot_log = baca_ekor_log(BOOT_ERR_LOG_FILE)
    pesan = (
        "Windows tidak menerima laporan bahwa service ini berhasil menyala.\n\n"
        "Penyebab paling umum:\n"
        "  1. Ada error saat aplikasi mulai jalan (library belum lengkap, "
        "error di app.py, atau init database gagal)\n"
        "  2. Port 80 sudah dipakai proses lain (mis. aplikasi masih "
        "jalan manual lewat start.bat di jendela lain)\n"
        "  3. pywin32 belum ter-registrasi sempurna di virtual environment\n"
    )
    if isi_boot_log:
        pesan += f"\nIsi terbaru service_boot_error.log:\n{isi_boot_log}\n"
    if isi_log:
        pesan += f"\nIsi terbaru service_error.log:\n{isi_log}\n"
    pesan += (
        "\nCara paling akurat melihat penyebab aslinya: klik tombol "
        "'Mode Debug' di bawah, lalu baca pesan error yang muncul di "
        "jendela hitam yang terbuka."
    )
    return pesan


def diagnose_file_not_found():
    bin_path = get_service_bin_path()
    if not bin_path:
        return ("Tidak bisa membaca konfigurasi service (perintah 'sc qc' gagal). "
                "Coba Uninstall lalu Install Service lagi.")
    if not os.path.isfile(bin_path):
        return (
            f"Penyebabnya: Windows mencari file berikut untuk menjalankan service, "
            f"tapi filenya sudah tidak ada di lokasi itu:\n\n{bin_path}\n\n"
            "Ini biasanya terjadi kalau folder aplikasi dipindah/di-rename setelah "
            "service dipasang, atau folder venv terhapus.\n\n"
            "Solusi: klik 'Uninstall Service', lalu klik 'Install Service' lagi "
            "supaya path-nya didaftarkan ulang sesuai lokasi folder saat ini."
        )
    return (
        f"File service ({bin_path}) sebenarnya ada, tapi Windows tetap gagal "
        "menjalankannya. Coba Uninstall lalu Install Service lagi."
    )


# ======================================================================
#  AKSES ONLINE / TUNNEL -- helper (berbasis Task Scheduler)
# ======================================================================
def is_tunnel_autostart_installed():
    code, out, err = run_cmd(["schtasks", "/Query", "/TN", TUNNEL_TASK_NAME])
    return code == 0


def get_cloudflared_pids():
    code, out, err = run_cmd(["tasklist", "/FI", "IMAGENAME eq cloudflared.exe", "/FO", "CSV", "/NH"])
    pids = []
    for line in out.splitlines():
        line = line.strip()
        if not line or "cloudflared.exe" not in line.lower():
            continue
        parts = [p.strip('"') for p in line.split('","')]
        if len(parts) >= 2:
            pids.append(parts[1].strip('"'))
    return pids


def get_tunnel_state():
    """RUNNING kalau proses cloudflared.exe terdeteksi, STOPPED kalau auto-start
    sudah dipasang tapi prosesnya mati, NOT_INSTALLED kalau belum pernah dipasang."""
    if get_cloudflared_pids():
        return "RUNNING"
    if is_tunnel_autostart_installed():
        return "STOPPED"
    return "NOT_INSTALLED"


def cari_cloudflared():
    code, out, err = run_cmd(["where", "cloudflared"])
    if code == 0 and out.strip():
        return out.strip().splitlines()[0].strip()
    kandidat = os.path.join(APP_DIR, "cloudflared.exe")
    if os.path.isfile(kandidat):
        return kandidat
    return None


def tulis_file_loop_tunnel(cloudflared_path, nama_tunnel):
    """Buat tunnel_loop.bat + tunnel_loop_hidden.vbs -- penjaga cloudflared
    yang otomatis nyala lagi kalau putus, tanpa lewat pywin32/SCM sama sekali."""
    isi_bat = (
        "@echo off\r\n"
        f'cd /d "{BASE_DIR}"\r\n'
        ":ulangi\r\n"
        f'echo [%date% %time%] Menyalakan tunnel...>>"{TUNNEL_LOOP_LOG}"\r\n'
        f'"{cloudflared_path}" tunnel run --url http://127.0.0.1:80 {nama_tunnel} >>"{TUNNEL_LOOP_LOG}" 2>&1\r\n'
        f'echo [%date% %time%] Tunnel berhenti, mencoba lagi 5 detik lagi...>>"{TUNNEL_LOOP_LOG}"\r\n'
        "timeout /t 5 /nobreak >nul\r\n"
        "goto :ulangi\r\n"
    )
    with open(TUNNEL_LOOP_BAT, "w", encoding="utf-8") as f:
        f.write(isi_bat)

    isi_vbs = (
        'Set WshShell = CreateObject("WScript.Shell")\r\n'
        f'WshShell.Run """" & "{TUNNEL_LOOP_BAT}" & """", 0, False\r\n'
    )
    with open(TUNNEL_LOOP_VBS, "w", encoding="utf-8") as f:
        f.write(isi_vbs)


def kill_semua_cloudflared():
    run_cmd(["taskkill", "/IM", "cloudflared.exe", "/F"], timeout=15)
    # Hentikan juga proses cmd.exe yang menjalankan loop-nya, supaya tidak
    # otomatis menyalakan cloudflared lagi 5 detik kemudian.
    run_cmd([
        "powershell", "-NoProfile", "-Command",
        "Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" | "
        "Where-Object { $_.CommandLine -like '*tunnel_loop.bat*' } | "
        "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
    ], timeout=20)


class ServiceControllerApp:
    STATE_LABELS = {
        "RUNNING": ("BERJALAN", C_OK),
        "STOPPED": ("BERHENTI", C_DOWN),
        "START_PENDING": ("SEDANG START...", C_WARN),
        "STOP_PENDING": ("SEDANG STOP...", C_WARN),
        "NOT_INSTALLED": ("BELUM TERPASANG", C_NEUTRAL),
        "UNKNOWN": ("TIDAK DIKETAHUI", C_NEUTRAL),
    }

    def __init__(self, root):
        self.root = root
        self.root.title("BENTANG RADIUS \u2014 NOC Console")
        self.root.geometry("640x960")
        self.root.configure(bg=C_BG)
        self.root.resizable(False, False)
        self._busy = False
        self._app_started_at = None
        self._build_ui()
        self._tick_clock()
        self._poll_status()
        self._poll_logs()
        self._bring_to_front()

    def _bring_to_front(self):
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(300, lambda: self.root.attributes("-topmost", False))
            self.root.focus_force()
        except Exception:
            pass

    # ------------------------------------------------------------ Widgets kecil
    def _led(self, parent, size=13):
        cv = tk.Canvas(parent, width=size, height=size, bg=parent["bg"],
                        highlightthickness=0)
        dot = cv.create_oval(1, 1, size - 1, size - 1, fill=C_NEUTRAL, outline="")
        return cv, dot

    def _set_led(self, cv, dot, color):
        cv.itemconfig(dot, fill=color)

    def _panel(self, parent, accent=C_ACCENT_BLUE):
        """Panel/kartu bergaya NOC: strip warna tipis di atas + border halus."""
        outer = tk.Frame(parent, bg=C_PANEL_BORDER)
        outer.pack(fill="x", padx=14, pady=(0, 12))
        strip = tk.Frame(outer, bg=accent, height=2)
        strip.pack(fill="x")
        inner = tk.Frame(outer, bg=C_PANEL)
        inner.pack(fill="x", padx=1, pady=(0, 1))
        return inner

    def _section_title(self, parent, text, accent=C_ACCENT_CYAN):
        row = tk.Frame(parent, bg=C_PANEL)
        row.pack(fill="x", padx=16, pady=(14, 4))
        bar = tk.Frame(row, bg=accent, width=3, height=14)
        bar.pack(side="left", padx=(0, 8))
        tk.Label(row, text=text, bg=C_PANEL, fg=C_TEXT,
                  font=("Consolas", 10, "bold")).pack(side="left")
        return row

    def _metric_row(self, parent, label, value_var_name):
        row = tk.Frame(parent, bg=C_PANEL)
        row.pack(fill="x", padx=16, pady=1)
        tk.Label(row, text=label, bg=C_PANEL, fg=C_TEXT_DIM,
                  font=("Consolas", 9), width=15, anchor="w").pack(side="left")
        val = tk.Label(row, text="-", bg=C_PANEL, fg=C_TEXT,
                        font=("Consolas", 9, "bold"), anchor="w")
        val.pack(side="left", fill="x", expand=True)
        setattr(self, value_var_name, val)
        return val

    def _make_btn(self, parent, text, cmd, color=C_ACCENT_BLUE, width=17):
        b = tk.Button(parent, text=text, command=cmd, bg=color, fg="#04070d",
                      activebackground=color, activeforeground="#04070d",
                      font=("Segoe UI", 9, "bold"), relief="flat", padx=10, pady=7,
                      cursor="hand2", width=width, bd=0,
                      highlightthickness=0)
        return b

    def _make_btn_outline(self, parent, text, cmd, width=17):
        b = tk.Button(parent, text=text, command=cmd, bg=C_PANEL, fg=C_TEXT,
                      activebackground="#182238", activeforeground=C_TEXT,
                      font=("Segoe UI", 9), relief="flat", padx=10, pady=7,
                      cursor="hand2", width=width, bd=1,
                      highlightbackground=C_PANEL_BORDER, highlightthickness=1)
        return b

    # ---------------------------------------------------------- UI utama
    def _build_ui(self):
        # ---------- HEADER ----------
        header = tk.Frame(self.root, bg=C_HEADER, pady=14)
        header.pack(fill="x")
        top_row = tk.Frame(header, bg=C_HEADER)
        top_row.pack(fill="x", padx=18)
        left = tk.Frame(top_row, bg=C_HEADER)
        left.pack(side="left")
        tk.Label(left, text="B E N T A N G   R A D I U S", bg=C_HEADER, fg=C_ACCENT_CYAN,
                  font=("Consolas", 15, "bold")).pack(anchor="w")
        tk.Label(left, text="N E T W O R K   O P E R A T I O N S   C E N T E R",
                  bg=C_HEADER, fg=C_TEXT_DIM, font=("Consolas", 8)).pack(anchor="w", pady=(2, 0))

        right = tk.Frame(top_row, bg=C_HEADER)
        right.pack(side="right")
        self.clock_label = tk.Label(right, text="--:--:--", bg=C_HEADER, fg=C_TEXT,
                                     font=("Consolas", 13, "bold"))
        self.clock_label.pack(anchor="e")
        self.date_label = tk.Label(right, text="-", bg=C_HEADER, fg=C_TEXT_DIM,
                                    font=("Consolas", 8))
        self.date_label.pack(anchor="e")

        sep = tk.Frame(self.root, bg=C_PANEL_BORDER, height=1)
        sep.pack(fill="x")

        # ---------- STRIP LED RINGKASAN ----------
        led_strip = tk.Frame(self.root, bg=C_HEADER, pady=10)
        led_strip.pack(fill="x")
        led_row = tk.Frame(led_strip, bg=C_HEADER)
        led_row.pack()

        def led_group(parent, label):
            g = tk.Frame(parent, bg=C_HEADER)
            g.pack(side="left", padx=18)
            cv, dot = self._led(g, size=12)
            cv.pack(side="left", padx=(0, 6))
            tk.Label(g, text=label, bg=C_HEADER, fg=C_TEXT_DIM,
                      font=("Consolas", 9)).pack(side="left")
            return cv, dot

        self.led_app_cv, self.led_app_dot = led_group(led_row, "APLIKASI")
        self.led_tunnel_cv, self.led_tunnel_dot = led_group(led_row, "AKSES ONLINE")
        self.led_auto_cv, self.led_auto_dot = led_group(led_row, "AUTO-START")

        sep2 = tk.Frame(self.root, bg=C_PANEL_BORDER, height=1)
        sep2.pack(fill="x", pady=(0, 12))

        # Scrollable body (biar muat semua panel + log tanpa kepotong)
        body = tk.Frame(self.root, bg=C_BG)
        body.pack(fill="both", expand=True)

        # ================= PANEL: APLIKASI UTAMA =================
        p1 = self._panel(body, accent=C_ACCENT_BLUE)
        self._section_title(p1, "\u25a0 APLIKASI UTAMA", C_ACCENT_BLUE)

        st_row = tk.Frame(p1, bg=C_PANEL)
        st_row.pack(fill="x", padx=16, pady=(0, 8))
        self.status_cv, self.status_dot = self._led(st_row, size=14)
        self.status_cv.pack(side="left", padx=(0, 8))
        self.status_label = tk.Label(st_row, text="MEMERIKSA...", bg=C_PANEL,
                                      fg=C_TEXT_DIM, font=("Consolas", 13, "bold"))
        self.status_label.pack(side="left")

        self._metric_row(p1, "PID", "m_app_pid")
        self._metric_row(p1, "PORT", "m_app_port")
        self.m_app_port.config(text="80")
        self._metric_row(p1, "URL LOKAL", "m_app_url")
        self.m_app_url.config(text=APP_URL, fg=C_ACCENT_BLUE)
        self._metric_row(p1, "SESI BERJALAN", "m_app_uptime")
        self._metric_row(p1, "AUTO-START BOOT", "m_app_autostart")

        btns1 = tk.Frame(p1, bg=C_PANEL)
        btns1.pack(pady=(10, 4))
        r = tk.Frame(btns1, bg=C_PANEL); r.pack(pady=3)
        self._make_btn(r, "\u25b6 START", self.on_start, C_OK).grid(row=0, column=0, padx=3)
        self._make_btn(r, "\u25a0 STOP", self.on_stop, C_DOWN).grid(row=0, column=1, padx=3)
        self._make_btn(r, "\u27f3 RESTART", self.on_restart, C_WARN).grid(row=0, column=2, padx=3)
        r2 = tk.Frame(btns1, bg=C_PANEL); r2.pack(pady=3)
        self._make_btn_outline(r2, "\U0001f310 Buka Aplikasi", self.on_open_browser).grid(row=0, column=0, padx=3)
        self._make_btn_outline(r2, "\U0001f504 Refresh Status", self.on_refresh).grid(row=0, column=1, padx=3)
        r3 = tk.Frame(btns1, bg=C_PANEL); r3.pack(pady=3)
        self._make_btn_outline(r3, "\u2699 Pasang Auto-Start", self.on_install).grid(row=0, column=0, padx=3)
        self._make_btn_outline(r3, "\U0001f5d1 Hapus Auto-Start", self.on_uninstall).grid(row=0, column=1, padx=3)
        r4 = tk.Frame(btns1, bg=C_PANEL); r4.pack(pady=(3, 12))
        self._make_btn(r4, "\U0001f41e MODE DEBUG (Lihat Error)", self.on_debug, "#7c5cff", width=36).pack()

        # ================= PANEL: AKSES ONLINE / TUNNEL =================
        p2 = self._panel(body, accent=C_ACCENT_CYAN)
        self._section_title(p2, "\u25a0 AKSES ONLINE (CLOUDFLARE TUNNEL)", C_ACCENT_CYAN)

        st_row2 = tk.Frame(p2, bg=C_PANEL)
        st_row2.pack(fill="x", padx=16, pady=(0, 8))
        self.tunnel_cv, self.tunnel_dot = self._led(st_row2, size=14)
        self.tunnel_cv.pack(side="left", padx=(0, 8))
        self.online_status_label = tk.Label(st_row2, text="MEMERIKSA...", bg=C_PANEL,
                                             fg=C_TEXT_DIM, font=("Consolas", 13, "bold"))
        self.online_status_label.pack(side="left")

        self._metric_row(p2, "LINK TETAP", "m_tunnel_url")
        self.m_tunnel_url.config(fg=C_ACCENT_CYAN)
        self._metric_row(p2, "PROSES cloudflared", "m_tunnel_proc")
        self._metric_row(p2, "AUTO-START BOOT", "m_tunnel_autostart")

        btns2 = tk.Frame(p2, bg=C_PANEL)
        btns2.pack(pady=(10, 4))
        ro1 = tk.Frame(btns2, bg=C_PANEL); ro1.pack(pady=3)
        self._make_btn(ro1, "\u25b6 START TUNNEL", self.on_tunnel_start, C_OK).grid(row=0, column=0, padx=3)
        self._make_btn(ro1, "\u25a0 STOP TUNNEL", self.on_tunnel_stop, C_DOWN).grid(row=0, column=1, padx=3)
        ro2 = tk.Frame(btns2, bg=C_PANEL); ro2.pack(pady=3)
        self._make_btn_outline(ro2, "\U0001f527 Setup Pertama Kali", self.on_tunnel_setup).grid(row=0, column=0, padx=3)
        self._make_btn_outline(ro2, "\u2699 Pasang Auto-Start", self.on_tunnel_install).grid(row=0, column=1, padx=3)
        ro3 = tk.Frame(btns2, bg=C_PANEL); ro3.pack(pady=(3, 12))
        self._make_btn_outline(ro3, "\U0001f5d1 Hapus Auto-Start Tunnel", self.on_tunnel_uninstall, width=36).pack()

        # ================= PANEL: LOG =================
        p3 = self._panel(body, accent=C_TEXT_FAINT)
        title_row = self._section_title(p3, "\u25a0 SYSTEM LOG", C_TEXT_FAINT)
        live_dot_cv, live_dot = self._led(title_row, size=9)
        live_dot_cv.pack(side="left", padx=(8, 4))
        self._set_led(live_dot_cv, live_dot, C_OK)
        tk.Label(title_row, text="LIVE", bg=C_PANEL, fg=C_OK,
                  font=("Consolas", 8, "bold")).pack(side="left")

        log_wrap = tk.Frame(p3, bg=C_PANEL)
        log_wrap.pack(fill="both", expand=True, padx=16, pady=(4, 14))
        self.log_box = scrolledtext.ScrolledText(
            log_wrap, height=11, bg=C_LOG_BG, fg=C_LOG_FG, insertbackground=C_LOG_FG,
            font=("Consolas", 8), relief="flat", padx=10, pady=10, state="disabled",
            highlightthickness=1, highlightbackground=C_PANEL_BORDER, highlightcolor=C_PANEL_BORDER,
        )
        self.log_box.pack(fill="both", expand=True)

        self.footer = tk.Label(self.root, text="BENTANG RADIUS Service Controller \u2014 NOC Edition",
                                bg=C_BG, fg=C_TEXT_FAINT, font=("Consolas", 8))
        self.footer.pack(pady=(0, 8))

    # ------------------------------------------------------ Jam & helper
    def _tick_clock(self):
        now = datetime.datetime.now()
        self.clock_label.config(text=now.strftime("%H:%M:%S"))
        hari = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
        bulan = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"]
        teks_tanggal = f"{hari[now.weekday()]}, {now.day} {bulan[now.month - 1]} {now.year}"
        self.date_label.config(text=teks_tanggal)
        self.root.after(1000, self._tick_clock)

    def _set_busy(self, msg):
        self._busy = True
        self.footer.config(text=f"\u23f3 {msg}")

    def _clear_busy(self):
        self._busy = False
        self.root.after(0, lambda: self.footer.config(
            text="BENTANG RADIUS Service Controller \u2014 NOC Edition"))

    def _run_async(self, target):
        threading.Thread(target=target, daemon=True).start()

    # ------------------------------------------------------ Aksi: Aplikasi Utama
    def on_start(self):
        self._set_busy("Menjalankan aplikasi...")
        self._run_async(self._do_start)

    def _do_start(self):
        if get_app_state() == "RUNNING":
            self._clear_busy()
            return
        if not os.path.isfile(PYTHONW_EXE):
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showerror(
                "Virtual Environment Belum Ada",
                "Folder 'venv' belum ada. Jalankan dulu '1_setup.bat' sampai "
                "selesai tanpa error, baru coba lagi."))
            return
        try:
            subprocess.Popen(
                [PYTHONW_EXE, RUN_SCRIPT],
                cwd=BASE_DIR,
                creationflags=(subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS)
                if hasattr(subprocess, "DETACHED_PROCESS") else 0,
            )
        except Exception as e:
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showerror("Gagal Start", str(e)))
            return
        time.sleep(2)
        self._clear_busy()
        if get_app_state() != "RUNNING":
            isi_log = baca_ekor_log(ERR_LOG_FILE)
            msg = "Aplikasi tidak berhasil menyala.\n\n"
            if isi_log:
                msg += f"Isi terbaru service_error.log:\n{isi_log}"
            else:
                msg += ("Belum ada log error tercatat -- kemungkinan port 80 "
                        "sudah dipakai proses lain. Cek 'System Log' di bawah "
                        "untuk info lebih lanjut.")
            self.root.after(0, lambda: messagebox.showerror("Gagal Start", msg))
        self.root.after(0, self._update_status)

    def on_debug(self):
        if not os.path.isfile(VENV_PYTHON):
            messagebox.showerror(
                "Virtual Environment Belum Ada",
                "Folder 'venv' belum ada. Jalankan dulu '1_setup.bat' sampai "
                "selesai tanpa error, baru coba lagi.")
            return
        if get_app_state() == "RUNNING":
            if not messagebox.askyesno(
                    "Aplikasi Sedang Berjalan",
                    "Aplikasi sedang berjalan. Mode Debug butuh port yang sama, "
                    "jadi yang sedang berjalan sekarang akan dihentikan dulu. "
                    "Lanjutkan?"):
                return
            self._do_stop()
        try:
            debug_bat = os.path.join(BASE_DIR, "_mode_debug_temp.bat")
            with open(debug_bat, "w", encoding="utf-8") as f:
                f.write("@echo off\r\n")
                f.write(f'"{VENV_PYTHON}" "{RUN_SCRIPT}"\r\n')
                f.write("echo.\r\n")
                f.write("pause\r\n")
            subprocess.Popen(["cmd", "/k", debug_bat], cwd=BASE_DIR)
        except Exception as e:
            messagebox.showerror("Gagal Membuka Mode Debug", str(e))
            return
        messagebox.showinfo(
            "Mode Debug Dibuka",
            "Jendela hitam (cmd) sudah terbuka dan menjalankan aplikasi "
            "langsung. Kalau ada error, pesannya akan langsung tercetak di "
            "jendela itu -- baca dari situ untuk tahu penyebab pastinya.\n\n"
            "Setelah selesai lihat error-nya, tutup jendela itu (atau tekan "
            "CTRL+C), lalu kamu bisa coba Start lagi dari sini seperti biasa.")

    def on_stop(self):
        self._set_busy("Menghentikan aplikasi...")
        self._run_async(self._do_stop)

    def _do_stop(self):
        pid = _baca_pid()
        if not _pid_hidup(pid):
            self._clear_busy()
            if os.path.isfile(PID_FILE):
                try:
                    os.remove(PID_FILE)
                except OSError:
                    pass
            self.root.after(0, self._update_status)
            return
        run_cmd(["taskkill", "/PID", str(pid), "/T", "/F"])
        time.sleep(1)
        try:
            if os.path.isfile(PID_FILE):
                os.remove(PID_FILE)
        except OSError:
            pass
        self._clear_busy()
        self.root.after(0, self._update_status)

    def on_restart(self):
        self._set_busy("Merestart aplikasi...")
        self._run_async(self._do_restart)

    def _do_restart(self):
        self._do_stop()
        time.sleep(1)
        self._do_start()

    def on_open_browser(self):
        webbrowser.open(APP_URL)

    def on_refresh(self):
        self._update_status()
        self._update_online_status()

    def on_install(self):
        if not os.path.isfile(PYTHONW_EXE):
            messagebox.showerror(
                "Virtual Environment Belum Ada",
                "Folder 'venv' belum ada, padahal wajib ada untuk memasang "
                "auto-start.\n\nJalankan dulu '1_setup.bat' sampai selesai "
                "tanpa error, lalu coba lagi.")
            return
        if not messagebox.askyesno("Pasang Auto-Start",
                "Ini akan membuat aplikasi otomatis menyala setiap kali Windows "
                "dinyalakan/restart (lewat Task Scheduler, butuh hak "
                "Administrator, sudah kamu berikan sekarang).\n\nLanjutkan?"):
            return
        self._set_busy("Memasang auto-start...")
        self._run_async(self._do_install)

    def _do_install(self):
        code, out, err = run_cmd([
            "schtasks", "/Create", "/TN", AUTOSTART_TASK_NAME,
            "/TR", f'"{PYTHONW_EXE}" "{RUN_SCRIPT}"',
            "/SC", "ONSTART", "/RU", "SYSTEM", "/RL", "HIGHEST", "/F",
        ], timeout=30)
        self._clear_busy()
        if code != 0:
            self.root.after(0, lambda: messagebox.showerror(
                "Pasang Auto-Start Gagal", f"{out}{err}"))
        else:
            self.root.after(0, lambda: messagebox.showinfo(
                "Auto-Start Terpasang",
                "Aplikasi akan otomatis menyala tiap kali Windows dinyalakan."))
        self.root.after(0, self._update_status)

    def on_uninstall(self):
        if not messagebox.askyesno("Hapus Auto-Start",
                "Ini akan menghapus jadwal auto-start dari Windows Task "
                "Scheduler. Data (database) TIDAK akan terhapus. Lanjutkan?"):
            return
        self._set_busy("Menghapus auto-start...")
        self._run_async(self._do_uninstall)

    def _do_uninstall(self):
        code, out, err = run_cmd(["schtasks", "/Delete", "/TN", AUTOSTART_TASK_NAME, "/F"], timeout=30)
        self._clear_busy()
        self.root.after(0, lambda: messagebox.showinfo("Auto-Start Dihapus", out or "Selesai."))
        self.root.after(0, self._update_status)

    # ------------------------------------------------------ Aksi: Akses Online / Tunnel
    def on_tunnel_setup(self):
        if not os.path.isfile(SETUP_TUNNEL_BAT):
            messagebox.showerror("File Tidak Ditemukan", f"Tidak ketemu:\n{SETUP_TUNNEL_BAT}")
            return
        if not messagebox.askyesno("Setup Pertama Kali",
                "Ini akan membuka jendela terminal baru untuk setup akses online "
                "(login Cloudflare di browser + memasukkan subdomain kamu).\n\n"
                "Ikuti instruksi di jendela terminal yang terbuka. Setelah selesai, "
                "kembali ke sini dan klik 'Pasang Auto-Start' di bagian Akses Online.\n\n"
                "Lanjutkan?"):
            return
        try:
            subprocess.Popen(["cmd", "/c", "start", "", SETUP_TUNNEL_BAT], cwd=APP_DIR)
        except Exception as e:
            messagebox.showerror("Gagal Membuka Setup", str(e))

    def on_tunnel_install(self):
        if not messagebox.askyesno("Pasang Auto-Start Tunnel",
                "Ini akan:\n"
                "  1. Membersihkan Windows Service tunnel lama yang bermasalah\n"
                "  2. Membuat jadwal Task Scheduler yang menjaga tunnel tetap "
                "menyala 24 jam, otomatis nyala lagi kalau terputus\n"
                "  3. Langsung menyalakan tunnel sekarang juga\n\n"
                "Butuh hak Administrator (sudah kamu berikan sekarang). Lanjutkan?"):
            return
        self._set_busy("Memasang auto-start tunnel...")
        self._run_async(self._do_tunnel_install)

    def _do_tunnel_install(self):
        hostname, nama_tunnel = baca_info_tunnel()
        if not hostname:
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showwarning(
                "Link Online Belum Disetel",
                "tunnel_info.txt belum ada -- jalankan dulu 'Setup Pertama Kali'."))
            return
        cloudflared = cari_cloudflared()
        if not cloudflared:
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showerror(
                "cloudflared Tidak Ditemukan",
                "cloudflared belum terinstall di komputer ini. Install dulu lewat:\n"
                "winget install --id Cloudflare.cloudflared"))
            return

        # Bersihkan Windows Service lama yang bermasalah (best-effort).
        run_cmd(["net", "stop", OLD_TUNNEL_SERVICE_NAME], timeout=15)
        run_cmd(["sc", "delete", OLD_TUNNEL_SERVICE_NAME], timeout=15)

        try:
            tulis_file_loop_tunnel(cloudflared, nama_tunnel)
        except OSError as e:
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showerror("Gagal Menulis File", str(e)))
            return

        code, out, err = run_cmd([
            "schtasks", "/Create", "/TN", TUNNEL_TASK_NAME,
            "/TR", f'wscript.exe "{TUNNEL_LOOP_VBS}"',
            "/SC", "ONSTART", "/RU", "SYSTEM", "/RL", "HIGHEST", "/F",
        ], timeout=30)
        if code != 0:
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showerror(
                "Pasang Auto-Start Tunnel Gagal", f"{out}{err}"))
            self.root.after(0, self._update_online_status)
            return

        kill_semua_cloudflared()
        run_cmd(["schtasks", "/Run", "/TN", TUNNEL_TASK_NAME], timeout=20)
        time.sleep(3)
        self._clear_busy()
        self.root.after(0, lambda: messagebox.showinfo(
            "Auto-Start Tunnel Terpasang",
            f"Tunnel akan otomatis menyala tiap kali Windows dinyalakan.\n\n"
            f"Link online kamu: https://{hostname}\n\n"
            "Tunggu beberapa detik, lalu cek LED 'AKSES ONLINE' di atas."))
        self.root.after(0, self._update_online_status)

    def on_tunnel_start(self):
        self._set_busy("Menjalankan tunnel...")
        self._run_async(self._do_tunnel_start)

    def _do_tunnel_start(self):
        if not is_tunnel_autostart_installed():
            self._clear_busy()
            self.root.after(0, lambda: messagebox.showwarning(
                "Auto-Start Tunnel Belum Terpasang",
                "Klik dulu 'Pasang Auto-Start' di bagian Akses Online "
                "(setelah 'Setup Pertama Kali' selesai)."))
            return
        kill_semua_cloudflared()
        run_cmd(["schtasks", "/Run", "/TN", TUNNEL_TASK_NAME], timeout=20)
        time.sleep(3)
        self._clear_busy()
        self.root.after(0, self._update_online_status)

    def on_tunnel_stop(self):
        self._set_busy("Menghentikan tunnel...")
        self._run_async(self._do_tunnel_stop)

    def _do_tunnel_stop(self):
        kill_semua_cloudflared()
        time.sleep(1)
        self._clear_busy()
        self.root.after(0, self._update_online_status)

    def on_tunnel_uninstall(self):
        if not messagebox.askyesno("Hapus Auto-Start Tunnel",
                "Ini akan menghapus jadwal auto-start tunnel dan mematikan "
                "tunnel yang sedang berjalan. Pengaturan (tunnel_info.txt) "
                "TIDAK akan terhapus. Lanjutkan?"):
            return
        self._set_busy("Menghapus auto-start tunnel...")
        self._run_async(self._do_tunnel_uninstall)

    def _do_tunnel_uninstall(self):
        run_cmd(["schtasks", "/Delete", "/TN", TUNNEL_TASK_NAME, "/F"], timeout=30)
        kill_semua_cloudflared()
        self._clear_busy()
        self.root.after(0, lambda: messagebox.showinfo("Auto-Start Tunnel Dihapus", "Selesai."))
        self.root.after(0, self._update_online_status)

    # ------------------------------------------------------ Polling
    def _update_status(self):
        state = get_app_state()
        text, color = self.STATE_LABELS.get(state, ("TIDAK DIKETAHUI", C_NEUTRAL))
        self.status_label.config(text=text, fg=color)
        self._set_led(self.status_cv, self.status_dot, color)
        self._set_led(self.led_app_cv, self.led_app_dot, color)

        pid = _baca_pid()
        if state == "RUNNING" and pid:
            self.m_app_pid.config(text=str(pid))
            if self._app_started_at is None:
                self._app_started_at = time.time()
        else:
            self.m_app_pid.config(text="-")
            self._app_started_at = None

        if self._app_started_at:
            durasi = int(time.time() - self._app_started_at)
            jam, sisa = divmod(durasi, 3600)
            menit, detik = divmod(sisa, 60)
            self.m_app_uptime.config(text=f"{jam:02d}:{menit:02d}:{detik:02d}")
        else:
            self.m_app_uptime.config(text="-")

        auto_on = is_autostart_installed()
        self.m_app_autostart.config(
            text="TERPASANG" if auto_on else "BELUM TERPASANG",
            fg=C_OK if auto_on else C_TEXT_DIM)
        self._set_led(self.led_auto_cv, self.led_auto_dot, C_OK if auto_on else C_NEUTRAL)

    def _update_online_status(self):
        hostname, _ = baca_info_tunnel()
        if not hostname:
            self.m_tunnel_url.config(text="Belum disetel - klik 'Setup Pertama Kali'", fg=C_TEXT_DIM)
        else:
            self.m_tunnel_url.config(text=f"https://{hostname}", fg=C_ACCENT_CYAN)

        state = get_tunnel_state()
        text, color = self.STATE_LABELS.get(state, ("TIDAK DIKETAHUI", C_NEUTRAL))
        self.online_status_label.config(text=text, fg=color)
        self._set_led(self.tunnel_cv, self.tunnel_dot, color)
        self._set_led(self.led_tunnel_cv, self.led_tunnel_dot, color)

        pids = get_cloudflared_pids()
        if pids:
            self.m_tunnel_proc.config(text=f"BERJALAN ({len(pids)} proses)", fg=C_OK)
        else:
            self.m_tunnel_proc.config(text="TIDAK BERJALAN", fg=C_DOWN)

        tunnel_auto_on = is_tunnel_autostart_installed()
        self.m_tunnel_autostart.config(
            text="TERPASANG" if tunnel_auto_on else "BELUM TERPASANG",
            fg=C_OK if tunnel_auto_on else C_TEXT_DIM)

    def _poll_status(self):
        if not self._busy:
            self._update_status()
            self._update_online_status()
        self.root.after(3000, self._poll_status)

    def _poll_logs(self):
        lines = []
        for path in (BOOT_ERR_LOG_FILE, ERR_LOG_FILE, LOG_FILE,
                     TUNNEL_LOOP_LOG, OLD_TUNNEL_ERR_LOG_FILE, OLD_TUNNEL_LOG_FILE):
            if os.path.isfile(path):
                try:
                    with open(path, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.readlines()[-15:]
                        lines.extend(content)
                except Exception:
                    pass
        self.log_box.config(state="normal")
        self.log_box.delete("1.0", tk.END)
        self.log_box.insert(tk.END, "".join(lines) if lines else "(belum ada log)")
        self.log_box.see(tk.END)
        self.log_box.config(state="disabled")
        self.root.after(5000, self._poll_logs)


def is_admin():
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def relaunch_as_admin():
    try:
        import ctypes
        script_path = os.path.abspath(__file__)
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            candidate = exe[:-len("python.exe")] + "pythonw.exe"
            if os.path.isfile(candidate):
                exe = candidate
        ret = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", exe, f'"{script_path}"', BASE_DIR, 1)
        return ret > 32
    except Exception:
        return False


def _main():
    if os.name != "nt":
        print("Service Controller ini hanya untuk Windows.")
        sys.exit(1)

    if not is_admin():
        if relaunch_as_admin():
            sys.exit(0)
        _root = tk.Tk()
        _root.withdraw()
        messagebox.showerror(
            "Tidak Bisa Mendapat Akses Administrator",
            "Kontrol service/Task Scheduler Windows butuh hak Administrator, "
            "tapi permintaan akses (jendela UAC) dibatalkan atau gagal muncul.\n\n"
            "Silakan buka lagi aplikasi ini dan klik 'Yes' saat jendela UAC muncul."
        )
        sys.exit(1)

    root = tk.Tk()
    app = ServiceControllerApp(root)
    root.mainloop()


if __name__ == "__main__":
    try:
        _main()
    except SystemExit:
        raise
    except Exception:
        import traceback
        crash_log = os.path.join(BASE_DIR, "service_controller_crash.log")
        try:
            with open(crash_log, "a", encoding="utf-8") as f:
                f.write("\n==== " + time.strftime("%Y-%m-%d %H:%M:%S") + " ====\n")
                f.write(traceback.format_exc())
        except Exception:
            pass
        try:
            _err_root = tk.Tk()
            _err_root.withdraw()
            messagebox.showerror(
                "Service Controller Gagal Dibuka",
                "Terjadi error tak terduga saat membuka aplikasi.\n\n"
                f"Detail lengkapnya sudah disimpan ke file:\n{crash_log}\n\n"
                "Silakan kirimkan isi file itu untuk dibantu diagnosis lebih lanjut."
            )
        except Exception:
            pass
        sys.exit(1)
