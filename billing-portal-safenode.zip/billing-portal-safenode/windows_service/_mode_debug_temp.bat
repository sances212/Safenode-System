@echo off
"F:\billing-portal-fixed-service\billing-portal\venv\Scripts\python.exe" "F:\billing-portal-fixed-service\billing-portal\windows_service\run_background.py"
echo.
pause
