@echo off
REM ============================================================
REM  BENTANG RADIUS - Buka Service Controller (GUI)
REM  Otomatis minta akses Administrator lewat UAC (wajib, karena
REM  start/stop/install Windows Service butuh hak admin).
REM ============================================================
setlocal
set APP_DIR=%~dp0..
set SCRIPT=%~dp0service_controller.pyw

REM Cek apakah sudah admin, kalau belum, jalankan ulang dengan elevasi
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Meminta akses Administrator...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

REM Pakai pythonw dari virtual environment kalau ada (tanpa jendela hitam),
REM kalau tidak ada, pakai python biasa dari sistem.
if exist "%APP_DIR%\venv\Scripts\pythonw.exe" (
    "%APP_DIR%\venv\Scripts\pythonw.exe" "%SCRIPT%"
) else (
    where pythonw >nul 2>&1
    if %errorlevel% equ 0 (
        pythonw "%SCRIPT%"
    ) else (
        python "%SCRIPT%"
    )
)
