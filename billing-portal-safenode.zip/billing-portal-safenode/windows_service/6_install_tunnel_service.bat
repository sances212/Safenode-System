@echo off
REM ============================================================
REM  BENTANG RADIUS - Pasang "Akses Online" sebagai Windows Service
REM  WAJIB dijalankan sebagai Administrator.
REM  Service ini menjaga Cloudflare Tunnel tetap menyala 24 jam,
REM  otomatis nyala lagi kalau tunnel putus sendiri.
REM
REM  PENTING: jalankan setup_tunnel_pertama_kali.bat DULU (di folder
REM  utama aplikasi) sebelum ini, supaya link online sudah disetel.
REM ============================================================
setlocal EnableDelayedExpansion
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Meminta akses Administrator...
    set "VBS=%temp%\bentang_getadmin_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "", "", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)

set SERVICE_NAME=BentangRadiusTunnel
pushd "%~dp0.."
set APP_DIR=%CD%
popd
set PYTHON_EXE=%APP_DIR%\venv\Scripts\python.exe
set SERVICE_SCRIPT=%APP_DIR%\windows_service\bentang_tunnel_service.py

if not exist "%PYTHON_EXE%" (
    echo GAGAL: %PYTHON_EXE% tidak ditemukan.
    echo Jalankan dulu 1_setup.bat untuk membuat virtual environment ^(venv^).
    pause
    exit /b 1
)

if not exist "%APP_DIR%\tunnel_info.txt" (
    echo.
    echo [PERINGATAN] tunnel_info.txt belum ada -- link online belum disetel.
    echo Service tetap akan dipasang, tapi TIDAK akan menyalakan tunnel apa pun
    echo sampai kamu menjalankan setup_tunnel_pertama_kali.bat ^(di folder
    echo utama aplikasi^) dan servicenya di-restart / komputer dinyalakan ulang.
    echo.
)

sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel% equ 0 (
    echo Service lama terdeteksi, menghapus dulu supaya path diperbarui...
    net stop %SERVICE_NAME% >nul 2>&1
    "%PYTHON_EXE%" "%SERVICE_SCRIPT%" remove >nul 2>&1
)

echo Memasang service "%SERVICE_NAME%" ...
"%PYTHON_EXE%" "%SERVICE_SCRIPT%" --startup auto install
if errorlevel 1 (
    echo.
    echo GAGAL memasang service. Lihat pesan error di atas.
    pause
    exit /b 1
)

net start %SERVICE_NAME%

echo.
echo ==================================================
echo  Service "%SERVICE_NAME%" terpasang dan berjalan.
echo  Kalau tunnel_info.txt sudah ada, link online kamu akan
echo  aktif dalam beberapa detik. Cek lewat ServiceController.bat.
echo ==================================================
pause
