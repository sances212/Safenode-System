@echo off
REM ============================================================
REM  BENTANG RADIUS - Pasang sebagai Windows Service
REM  WAJIB dijalankan sebagai Administrator (klik kanan > Run as administrator)
REM  Tidak butuh file tambahan apa pun (pakai pywin32, sudah otomatis
REM  terpasang lewat 1_setup.bat).
REM ============================================================
setlocal EnableDelayedExpansion
REM Cek apakah sudah admin, kalau belum, jalankan ulang dengan elevasi UAC
REM otomatis lewat VBScript sementara (supaya tahan folder yang namanya
REM mengandung spasi, tidak seperti trik PowerShell yang gampang gagal).
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Meminta akses Administrator...
    set "VBS=%temp%\bentang_getadmin_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "", "", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)

set SERVICE_NAME=BentangRadiusBilling
REM Resolve ke path absolut yang bersih (bukan "...\windows_service\..")
REM supaya kalau folder ini nanti dipindah, path yang terdaftar di Windows
REM tetap benar (dihitung ulang tiap kali install dijalankan).
pushd "%~dp0.."
set APP_DIR=%CD%
popd
set PYTHON_EXE=%APP_DIR%\venv\Scripts\python.exe
set SERVICE_SCRIPT=%APP_DIR%\windows_service\bentang_service.py

if not exist "%PYTHON_EXE%" (
    echo GAGAL: %PYTHON_EXE% tidak ditemukan.
    echo Jalankan dulu 1_setup.bat untuk membuat virtual environment ^(venv^).
    pause
    exit /b 1
)

if not exist "%SERVICE_SCRIPT%" (
    echo GAGAL: %SERVICE_SCRIPT% tidak ditemukan.
    echo Pastikan folder aplikasi tidak ada file yang hilang/terhapus.
    pause
    exit /b 1
)

REM Kalau service sudah pernah terpasang sebelumnya (mis. dari lokasi folder
REM lama), hapus dulu supaya path yang lama tidak nyangkut.
sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel% equ 0 (
    echo Service lama terdeteksi, menghapus dulu supaya path diperbarui...
    net stop %SERVICE_NAME% >nul 2>&1
    "%PYTHON_EXE%" "%SERVICE_SCRIPT%" remove >nul 2>&1
)

echo Memasang service "%SERVICE_NAME%" ...
"%PYTHON_EXE%" "%SERVICE_SCRIPT%" --startup auto install
if errorlevel 1 (
    echo.
    echo GAGAL memasang service. Lihat pesan error di atas.
    echo Pastikan aplikasi ini dijalankan sebagai Administrator dan
    echo 1_setup.bat sudah dijalankan sampai selesai tanpa error.
    pause
    exit /b 1
)

net start %SERVICE_NAME%

echo.
echo ==================================================
echo  Service "%SERVICE_NAME%" terpasang dan berjalan.
echo  Buka browser: http://127.0.0.1:80
echo  Kontrol lewat 3_start.bat / 4_stop.bat / 5_uninstall.bat
echo  atau lewat aplikasi Windows "Services" ^(services.msc^)
echo  atau lewat ServiceController.bat ^(GUI^)
echo ==================================================
pause
