@echo off
REM ============================================================
REM  BENTANG RADIUS - Hapus "Akses Online" dari Windows Service
REM ============================================================
setlocal EnableDelayedExpansion
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Meminta akses Administrator...
    set "VBS=%temp%\bentang_getadmin_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "", "", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)

set SERVICE_NAME=BentangRadiusTunnel
pushd "%~dp0.."
set APP_DIR=%CD%
popd
set PYTHON_EXE=%APP_DIR%\venv\Scripts\python.exe
set SERVICE_SCRIPT=%APP_DIR%\windows_service\bentang_tunnel_service.py

net stop %SERVICE_NAME% >nul 2>&1

if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" "%SERVICE_SCRIPT%" remove
) else (
    sc delete %SERVICE_NAME%
)

echo Service %SERVICE_NAME% telah dihapus. Link online tidak akan aktif lagi
echo sampai service ini dipasang ulang.
pause
