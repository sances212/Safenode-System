@echo off
cd /d "F:\billing-portal-fixed-service\billing-portal\windows_service"
:ulangi
echo [%date% %time%] Menyalakan tunnel...>>"F:\billing-portal-fixed-service\billing-portal\windows_service\tunnel_loop.log"
"C:\Program Files (x86)\cloudflared\cloudflared.exe" tunnel run --url http://127.0.0.1:80 sysai-tunnel >>"F:\billing-portal-fixed-service\billing-portal\windows_service\tunnel_loop.log" 2>&1
echo [%date% %time%] Tunnel berhenti, mencoba lagi dalam 5 detik...>>"F:\billing-portal-fixed-service\billing-portal\windows_service\tunnel_loop.log"
timeout /t 5 /nobreak >nul
goto :ulangi
