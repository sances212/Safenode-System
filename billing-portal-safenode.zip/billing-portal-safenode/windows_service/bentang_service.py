"""
BENTANG RADIUS - Windows Service (pakai pywin32)
=====================================================
Mendaftarkan aplikasi billing portal langsung ke Windows sebagai Service
Control Handler asli, tanpa perlu download/salin exe pihak ketiga apa pun
(tidak pakai NSSM) -- cukup pip install pywin32.

Cara pakai (semua ini dijalankan otomatis oleh file .bat di folder ini,
tidak perlu diketik manual):
    python bentang_service.py install     -> daftarkan service
    python bentang_service.py remove      -> hapus service
    python bentang_service.py start       -> jalankan service
    python bentang_service.py stop        -> hentikan service

Catatan: HARUS dijalankan pakai python.exe dari virtual environment
(venv\\Scripts\\python.exe) supaya modul pywin32, Flask, waitress, dll
semuanya ketemu.
"""
import logging
import os
import sys
import threading
import traceback

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(BASE_DIR)
LOG_FILE = os.path.join(BASE_DIR, "service.log")
ERR_LOG_FILE = os.path.join(BASE_DIR, "service_error.log")
# File paling awal yang ditulis, pakai fungsi bawaan Python saja (tanpa
# 'logging', tanpa pywin32) -- supaya kalau IMPORT pywin32 sendiri yang
# gagal (penyebab paling umum "not responding to control function" TANPA
# log sama sekali), penyebabnya tetap tercatat di sini.
BOOT_CRASH_FILE = os.path.join(BASE_DIR, "service_boot_error.log")


def _catat_boot_crash(judul, exc=None):
    """Tulis error paling awal (sebelum logging/pywin32 siap) ke file biasa,
    supaya tetap ada jejaknya walau proses berhenti total sesaat lagi."""
    try:
        with open(BOOT_CRASH_FILE, "a", encoding="utf-8") as f:
            f.write("\n==== " + judul + " ====\n")
            f.write(f"Python: {sys.executable}\n")
            f.write(f"sys.path[0]: {sys.path[0] if sys.path else ''}\n")
            if exc is not None:
                f.write(traceback.format_exc())
    except Exception:
        pass  # kalau menulis log pun gagal (mis. folder read-only), jangan sampai ikut crash


# Supaya "from app import app" bisa ditemukan, dan supaya path relatif
# (mis. database sqlite billing.db) konsisten dengan saat dijalankan manual
# lewat start.bat.
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)
os.chdir(APP_DIR)

try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager
except Exception:
    # INI penyebab paling umum dari "service not responding to the control
    # function" TANPA log sama sekali: modul pywin32 gagal diimport (belum
    # ter-registrasi sempurna di venv ini, atau DLL pywintypes/pythoncom
    # tidak ketemu). Proses akan langsung mati sebelum sempat lapor apa pun
    # ke Windows -- makanya sebelumnya tidak ada log.
    _catat_boot_crash(
        "GAGAL IMPORT PYWIN32 -- service tidak bisa jalan sama sekali. "
        "Solusi: jalankan ulang (sebagai Administrator) "
        "'venv\\Scripts\\python.exe venv\\Scripts\\pywin32_postinstall.py -install', "
        "lalu Install Service lagi.",
        exc=True,
    )
    raise


def _setup_logging():
    """Semua print/error diarahkan ke file log (service tidak punya console),
    supaya bisa dilihat lewat Service Controller GUI atau dibuka manual."""
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)

    eh = logging.FileHandler(ERR_LOG_FILE, encoding="utf-8")
    eh.setLevel(logging.ERROR)
    eh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(eh)


class BentangRadiusService(win32serviceutil.ServiceFramework):
    _svc_name_ = "BentangRadiusBilling"
    _svc_display_name_ = "BENTANG RADIUS Billing Portal"
    _svc_description_ = "Web Portal Billing Internet BENTANG RADIUS (Flask + waitress)"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.server = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        logging.info("Menerima perintah stop, menghentikan server...")
        try:
            if self.server is not None:
                self.server.close()
        except Exception:
            logging.exception("Gagal menutup server dengan bersih")
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        # PENTING: lapor RUNNING ke Windows SECEPATNYA, sebelum melakukan apa
        # pun yang berat (import app.py yang besar, buka koneksi database,
        # bind port, dsb). Kalau proses "diam" terlalu lama sebelum lapor
        # status ke Service Control Manager, Windows akan timeout dan
        # menampilkan error "The service is not responding to the control
        # function" (net helpmsg 2186) -- padahal service-nya sendiri baik-
        # baik saja, cuma belum sempat lapor.
        try:
            self.ReportServiceStatus(win32service.SERVICE_RUNNING)
        except Exception:
            pass

        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ""),
        )
        _setup_logging()
        try:
            self._run_app()
        except Exception:
            logging.exception("Service crash saat menjalankan aplikasi")
            servicemanager.LogErrorMsg(
                "BentangRadiusBilling service berhenti karena error. "
                "Cek file service_error.log untuk detailnya."
            )
        finally:
            # Pastikan Windows selalu dapat laporan status akhir yang jelas,
            # supaya SCM tidak "menunggu" service yang sebenarnya sudah mati.
            try:
                self.ReportServiceStatus(win32service.SERVICE_STOPPED)
            except Exception:
                pass

    def _run_app(self):
        # init_db() aman dipanggil berulang kali (semua CREATE TABLE pakai
        # "IF NOT EXISTS"), jadi dipanggil eksplisit di sini karena saat
        # service meng-import app.py, blok "if __name__ == '__main__'" di
        # app.py (yang biasanya memanggil init_db saat dijalankan manual
        # lewat start.bat) TIDAK ikut dieksekusi.
        logging.info("Mengimpor aplikasi (app.py)...")
        try:
            from app import app, init_db
        except Exception:
            logging.exception(
                "Gagal mengimpor app.py. Biasanya karena ada library yang "
                "belum terinstall di venv, atau ada error syntax/import di "
                "app.py. Coba jalankan manual untuk melihat detail error:\n"
                "  venv\\Scripts\\python.exe windows_service\\bentang_service.py debug"
            )
            raise

        try:
            from waitress import create_server
        except Exception:
            logging.exception(
                "Gagal mengimpor waitress. Jalankan: "
                "venv\\Scripts\\pip install waitress"
            )
            raise

        try:
            init_db()
        except Exception:
            logging.exception("Gagal inisialisasi database (init_db).")
            raise

        HOST = os.environ.get("HOST", "0.0.0.0")
        PORT = int(os.environ.get("PORT", "80"))

        try:
            self.server = create_server(app, host=HOST, port=PORT, threads=16)
        except OSError:
            logging.exception(
                f"Gagal membuka port {PORT}. Kemungkinan besar port ini "
                "sudah dipakai proses lain (mis. aplikasi dijalankan manual "
                "lewat start.bat di jendela lain, atau service ini sendiri "
                "sudah berjalan). Hentikan proses lain itu dulu, lalu coba "
                "Start lagi."
            )
            raise

        logging.info(f"BENTANG RADIUS mulai berjalan di http://127.0.0.1:{PORT}")

        # create_server(...).run() itu blocking, jalankan di thread terpisah
        # supaya thread utama bisa menunggu sinyal stop dari Windows dengan bersih.
        worker = threading.Thread(target=self.server.run, daemon=True)
        worker.start()

        win32event.WaitForSingleObject(self.hWaitStop, win32event.INFINITE)
        logging.info("Service berhenti.")


if __name__ == "__main__":
    if len(sys.argv) == 1:
        # Dipanggil oleh Windows Service Control Manager (tanpa argumen)
        try:
            servicemanager.Initialize()
            servicemanager.PrepareToHostSingle(BentangRadiusService)
            servicemanager.StartServiceCtrlDispatcher()
        except Exception:
            _catat_boot_crash(
                "GAGAL saat StartServiceCtrlDispatcher -- proses berhenti "
                "sebelum service sempat lapor status apa pun ke Windows.",
                exc=True,
            )
            raise
    else:
        # Dipanggil manual: install / remove / start / stop / restart / debug
        win32serviceutil.HandleCommandLine(BentangRadiusService)
