Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """"& "F:\billing-portal-fixed-service\billing-portal\windows_service\tunnel_loop.bat" &"""", 0, False
