@echo off
setlocal EnableDelayedExpansion
REM Otomatis minta akses Administrator lewat VBScript sementara
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Meminta akses Administrator...
    set "VBS=%temp%\bentang_getadmin_%RANDOM%.vbs"
    (
        echo Set UAC = CreateObject^("Shell.Application"^)
        echo UAC.ShellExecute "%~f0", "", "", "runas", 1
    ) > "!VBS!"
    cscript //nologo "!VBS!"
    del "!VBS!" >nul 2>&1
    exit /b
)
net start BentangRadiusBilling
pause
