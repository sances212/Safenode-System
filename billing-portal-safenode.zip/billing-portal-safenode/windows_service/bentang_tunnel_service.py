"""
BENTANG RADIUS - Windows Service untuk Akses Online (Cloudflare Named Tunnel)
==============================================================================
Service TERPISAH dari service utama (bentang_service.py). Tugasnya cuma
menjaga proses `cloudflared tunnel run` tetap menyala terus-menerus di
background -- termasuk otomatis nyala lagi kalau tunnel putus sendiri
(mis. koneksi internet sempat terputus) -- supaya link online kamu
(https://<subdomain-kamu>) selalu bisa diakses tanpa perlu ada jendela
apa pun yang dibiarkan terbuka.

Syarat sebelum service ini berguna:
  1. cloudflared sudah terinstall di komputer ini (lihat
     setup_tunnel_pertama_kali.bat).
  2. setup_tunnel_pertama_kali.bat sudah pernah dijalankan sampai selesai
     (menghasilkan file tunnel_info.txt di folder utama aplikasi).

Kalau salah satu syarat di atas belum terpenuhi, service ini akan tetap
berstatus RUNNING di Windows (supaya tidak dianggap "crash" oleh Service
Control Manager) tapi hanya menunggu & mengecek ulang tiap 30 detik --
begitu tunnel_info.txt sudah ada dan cloudflared ketemu, tunnel otomatis
langsung dinyalakan tanpa perlu restart service manual.

Cara pakai (dijalankan otomatis oleh file .bat di folder ini):
    python bentang_tunnel_service.py install
    python bentang_tunnel_service.py remove
    python bentang_tunnel_service.py start
    python bentang_tunnel_service.py stop
"""
import logging
import os
import shutil
import subprocess
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(BASE_DIR)
LOG_FILE = os.path.join(BASE_DIR, "tunnel_service.log")
ERR_LOG_FILE = os.path.join(BASE_DIR, "tunnel_service_error.log")
TUNNEL_INFO_PATH = os.path.join(APP_DIR, "tunnel_info.txt")
LOCAL_URL = "http://127.0.0.1:80"

import win32serviceutil
import win32service
import win32event
import servicemanager


def _setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)

    eh = logging.FileHandler(ERR_LOG_FILE, encoding="utf-8")
    eh.setLevel(logging.ERROR)
    eh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(eh)


def _baca_info_tunnel():
    """Baca tunnel_info.txt (dibuat oleh setup_tunnel_pertama_kali). Mengembalikan
    (hostname, nama_tunnel) atau (None, None) kalau belum disetel/tidak lengkap."""
    if not os.path.exists(TUNNEL_INFO_PATH):
        return None, None
    hostname, nama_tunnel = None, None
    try:
        with open(TUNNEL_INFO_PATH, "r", encoding="utf-8") as f:
            for baris in f:
                baris = baris.strip()
                if baris.startswith("HOSTNAME="):
                    hostname = baris.split("=", 1)[1].strip()
                elif baris.startswith("TUNNEL_NAME="):
                    nama_tunnel = baris.split("=", 1)[1].strip()
    except OSError:
        return None, None
    if not hostname or not nama_tunnel:
        return None, None
    return hostname, nama_tunnel


def _cari_cloudflared():
    """Cari executable cloudflared: di PATH sistem, atau di folder utama aplikasi
    (cloudflared.exe / cloudflared)."""
    ditemukan = shutil.which("cloudflared")
    if ditemukan:
        return ditemukan
    for nama in ("cloudflared.exe", "cloudflared"):
        kandidat = os.path.join(APP_DIR, nama)
        if os.path.isfile(kandidat):
            return kandidat
    return None


class BentangRadiusTunnelService(win32serviceutil.ServiceFramework):
    _svc_name_ = "BentangRadiusTunnel"
    _svc_display_name_ = "BENTANG RADIUS Akses Online (Cloudflare Tunnel)"
    _svc_description_ = ("Menjaga link online tetap (Cloudflare Named Tunnel) untuk "
                          "BENTANG RADIUS Billing Portal tetap menyala 24 jam.")

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self._berhenti = False
        self.proses = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self._berhenti = True
        logging.info("Menerima perintah stop.")
        try:
            if self.proses is not None and self.proses.poll() is None:
                self.proses.terminate()
        except Exception:
            logging.exception("Gagal menghentikan proses cloudflared dengan bersih")
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ""),
        )
        _setup_logging()
        try:
            self._loop()
        except Exception:
            logging.exception("Service tunnel crash")
            servicemanager.LogErrorMsg(
                "BentangRadiusTunnel berhenti karena error. "
                "Cek file tunnel_service_error.log untuk detailnya."
            )

    def _tunggu(self, milidetik):
        """Tunggu sampai durasi tertentu ATAU sinyal stop datang duluan.
        Return True kalau sinyal stop diterima."""
        if win32event.WaitForSingleObject(self.hWaitStop, milidetik) == win32event.WAIT_OBJECT_0:
            self._berhenti = True
            return True
        return False

    def _loop(self):
        no_window = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
        while not self._berhenti:
            hostname, nama_tunnel = _baca_info_tunnel()
            cloudflared = _cari_cloudflared()

            if not hostname or not nama_tunnel:
                logging.info("Belum disetel (tunnel_info.txt belum ada). Jalankan "
                              "setup_tunnel_pertama_kali dulu. Cek lagi dalam 30 detik...")
                if self._tunggu(30000):
                    break
                continue

            if not cloudflared:
                logging.info("cloudflared belum ditemukan di PATH / folder aplikasi. "
                              "Cek lagi dalam 30 detik...")
                if self._tunggu(30000):
                    break
                continue

            logging.info(f"Menyalakan tunnel ke https://{hostname} ...")
            try:
                self.proses = subprocess.Popen(
                    [cloudflared, "tunnel", "run", "--url", LOCAL_URL, nama_tunnel],
                    cwd=APP_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    creationflags=no_window)
            except Exception:
                logging.exception("Gagal menyalakan cloudflared")
                if self._tunggu(30000):
                    break
                continue

            # Tunggu sampai proses cloudflared berhenti sendiri ATAU sinyal stop datang.
            kode = None
            while True:
                kode = self.proses.poll()
                if kode is not None:
                    break
                if self._tunggu(2000):
                    break

            if self._berhenti:
                break

            logging.warning(f"Tunnel berhenti sendiri (kode={kode}). "
                             "Menyambungkan lagi dalam 5 detik...")
            if self._tunggu(5000):
                break

        logging.info("Service tunnel berhenti.")


if __name__ == "__main__":
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(BentangRadiusTunnelService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(BentangRadiusTunnelService)
