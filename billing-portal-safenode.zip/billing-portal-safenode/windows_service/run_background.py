"""
BENTANG RADIUS - Mode Sederhana (tanpa Windows Service / pywin32)
====================================================================
Menjalankan aplikasi billing langsung di background -- persis seperti
Mode Debug yang sudah terbukti berhasil -- tapi TANPA jendela hitam yang
harus dibiarkan terbuka, dan TANPA lewat mekanisme Windows Service (SCM)
yang butuh pywin32 & DLL teregistrasi sempurna (sumber masalah "not
responding to the control function" sebelumnya).

Cara kerja:
- Dijalankan lewat pythonw.exe (tidak ada jendela sama sekali) oleh
  Service Controller saat tombol "Start" ditekan.
- PID proses ini disimpan ke background_run.pid, supaya Service Controller
  tahu proses mana yang harus dihentikan saat "Stop" ditekan (lewat
  taskkill), dan tahu apakah aplikasi masih hidup atau tidak.
- Semua log/error ditulis ke file yang sama seperti sebelumnya
  (service.log / service_error.log) supaya cara diagnosisnya tetap sama.
"""
import logging
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(BASE_DIR)
LOG_FILE = os.path.join(BASE_DIR, "service.log")
ERR_LOG_FILE = os.path.join(BASE_DIR, "service_error.log")
PID_FILE = os.path.join(BASE_DIR, "background_run.pid")

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)
os.chdir(APP_DIR)


def _setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    eh = logging.FileHandler(ERR_LOG_FILE, encoding="utf-8")
    eh.setLevel(logging.ERROR)
    eh.setFormatter(fmt)
    logger.addHandler(eh)

    # Kalau dijalankan lewat python.exe biasa di jendela cmd (mis. dari
    # tombol "Mode Debug"), tampilkan juga di layar -- tapi kalau dijalankan
    # lewat pythonw.exe (Start biasa, tanpa jendela), sys.stdout adalah None,
    # jadi dilewati saja supaya tidak error.
    if sys.stdout is not None:
        try:
            sh = logging.StreamHandler(sys.stdout)
            sh.setFormatter(fmt)
            logger.addHandler(sh)
        except Exception:
            pass


def main():
    _setup_logging()
    try:
        with open(PID_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except Exception:
        logging.exception("Gagal menyimpan file PID")

    logging.info(f"BENTANG RADIUS (mode sederhana) mulai, PID={os.getpid()}...")
    try:
        from app import app, init_db
        from waitress import create_server

        init_db()

        HOST = os.environ.get("HOST", "0.0.0.0")
        PORT = int(os.environ.get("PORT", "80"))

        try:
            server = create_server(app, host=HOST, port=PORT, threads=16)
        except OSError:
            logging.exception(
                f"Gagal membuka port {PORT}. Kemungkinan besar port ini sudah "
                "dipakai proses lain (aplikasi mungkin sudah berjalan di jendela "
                "lain). Hentikan proses lain itu dulu, lalu coba Start lagi."
            )
            raise

        logging.info(f"BENTANG RADIUS berjalan di http://127.0.0.1:{PORT}")
        server.run()  # blocking -- jalan terus sampai proses dihentikan (Stop)
        logging.info("Server berhenti.")
    except Exception:
        logging.exception("Aplikasi berhenti karena error")
    finally:
        try:
            if os.path.isfile(PID_FILE):
                os.remove(PID_FILE)
        except Exception:
            pass


if __name__ == "__main__":
    main()
