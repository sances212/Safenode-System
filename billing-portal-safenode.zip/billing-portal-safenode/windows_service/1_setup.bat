@echo off
REM ============================================================
REM  BENTANG RADIUS - Setup awal untuk Windows
REM  Jalankan file ini SEKALI saja (klik 2x atau lewat CMD)
REM ============================================================
cd /d "%~dp0\.."

echo [1/4] Membuat virtual environment...
python -m venv venv
if errorlevel 1 (
    echo GAGAL: pastikan Python sudah terinstall dan tercentang "Add to PATH" saat install.
    pause
    exit /b 1
)

echo [2/4] Mengaktifkan virtual environment dan install dependencies...
call venv\Scripts\activate.bat
pip install --upgrade pip
pip install -r requirements.txt
pip install pywin32
if errorlevel 1 (
    echo.
    echo GAGAL: instalasi library lewat pip tidak berhasil ^(lihat pesan
    echo error merah di atas^). Setup dihentikan supaya tidak lanjut dengan
    echo library yang belum lengkap.
    pause
    exit /b 1
)

echo [3/4] Menyiapkan pywin32 (dibutuhkan untuk Windows Service)...
if exist venv\Scripts\pywin32_postinstall.py (
    venv\Scripts\python.exe venv\Scripts\pywin32_postinstall.py -install -quiet
) else (
    echo   (dilewati: pywin32_postinstall.py tidak ada, kemungkinan pywin32
    echo   tidak terpasang lewat pip biasa - install service tetap bisa
    echo   dicoba, tapi kalau nanti gagal, install manual dengan:
    echo   venv\Scripts\pip install pywin32^)
)

echo [4/4] Setup selesai.
echo.
echo ==================================================
echo  Login default -> username: admin ^| password: admin123
echo  Lanjutkan dengan 2_install_service.bat untuk memasang
echo  aplikasi sebagai Windows Service, ATAU jalankan
echo  langsung dengan: venv\Scripts\python app.py
echo ==================================================
pause
