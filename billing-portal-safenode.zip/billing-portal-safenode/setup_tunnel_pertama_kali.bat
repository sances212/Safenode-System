@echo off
setlocal enabledelayedexpansion
title BENTANG RADIUS - Setup Akses Online (Sekali Saja)
cd /d "%~dp0"

echo ============================================================
echo  BENTANG RADIUS - Setup Akses Online Permanen (Named Tunnel)
echo ============================================================
echo.
echo Script ini HANYA perlu dijalankan SATU KALI. Setelah ini, link
echo online kamu akan TETAP SAMA selamanya (tidak acak/berubah-ubah
echo seperti punya start_tunnel.bat yang lama).
echo.
echo SYARAT sebelum lanjut:
echo   1. Kamu punya domain sendiri (mis. msradius2.com) yang sudah
echo      terdaftar di akun Cloudflare kamu (gratis, tinggal daftar
echo      di https://dash.cloudflare.com kalau belum, lalu arahkan
echo      nameserver domainnya ke Cloudflare).
echo   2. cloudflared sudah terinstall di komputer ini.
echo.
pause

set "CLOUDFLARED="
where cloudflared >nul 2>nul
if not errorlevel 1 (
    set "CLOUDFLARED=cloudflared"
    goto :ketemu
)
if exist "%~dp0cloudflared.exe" (
    set "CLOUDFLARED=%~dp0cloudflared.exe"
    goto :ketemu
)

echo.
echo [ERROR] cloudflared belum ditemukan di komputer ini.
echo Install dulu salah satu cara ini:
echo   1^) winget install --id Cloudflare.cloudflared
echo   2^) Download manual: https://github.com/cloudflare/cloudflared/releases/latest
echo      ^(pilih cloudflared-windows-amd64.exe, rename jadi cloudflared.exe,
echo      taruh di folder yang sama dengan file ini^)
echo.
echo Setelah terinstall, jalankan lagi setup_tunnel_pertama_kali.bat ini.
pause
exit /b 1

:ketemu
echo.
echo Ditemukan: %CLOUDFLARED%
echo.
echo ------------------------------------------------------------
echo  LANGKAH 1/4 - Login ke akun Cloudflare kamu
echo ------------------------------------------------------------
echo Browser akan terbuka. Login, lalu PILIH domain yang mau dipakai
echo ^(mis. msradius2.com^). Kalau sudah selesai di browser, kembali
echo ke jendela ini.
echo.
pause
"%CLOUDFLARED%" tunnel login
if errorlevel 1 (
    echo [ERROR] Login gagal/dibatalkan. Jalankan ulang script ini.
    pause
    exit /b 1
)

echo.
set /p HOSTNAME="Masukkan subdomain lengkap yang mau dipakai (contoh: billing.msradius2.com): "
if "%HOSTNAME%"=="" (
    echo [ERROR] Subdomain tidak boleh kosong.
    pause
    exit /b 1
)

set "NAMA_TUNNEL=bentangradius-billing"

echo.
echo ------------------------------------------------------------
echo  LANGKAH 2/4 - Membuat tunnel "%NAMA_TUNNEL%"
echo ------------------------------------------------------------
"%CLOUDFLARED%" tunnel create %NAMA_TUNNEL%
echo ^(Kalau muncul pesan "tunnel already exists", itu tidak apa-apa
echo  -- berarti tunnel dari percobaan setup sebelumnya masih ada,
echo  lanjut saja ke langkah berikutnya.^)

echo.
echo ------------------------------------------------------------
echo  LANGKAH 3/4 - Menghubungkan %HOSTNAME% ke tunnel ini
echo ------------------------------------------------------------
"%CLOUDFLARED%" tunnel route dns %NAMA_TUNNEL% %HOSTNAME%
if errorlevel 1 (
    echo.
    echo [ERROR] Gagal menghubungkan domain. Pastikan domain %HOSTNAME%
    echo memang ada di akun Cloudflare yang tadi kamu login.
    pause
    exit /b 1
)

echo.
echo ------------------------------------------------------------
echo  LANGKAH 4/4 - Menyimpan pengaturan
echo ------------------------------------------------------------
(
    echo HOSTNAME=%HOSTNAME%
    echo TUNNEL_NAME=%NAMA_TUNNEL%
) > "%~dp0tunnel_info.txt"
echo Tersimpan di tunnel_info.txt

echo.
echo ============================================================
echo  SELESAI! Link online tetap kamu:
echo  https://%HOSTNAME%
echo.
echo  Link ini TIDAK AKAN BERUBAH lagi mulai sekarang, walau
echo  komputer/tunnel dinyalakan-matikan berkali-kali.
echo.
echo  Buka Service Controller (ServiceController.bat) -- tunnel
echo  online akan otomatis nyala bareng server lokal. Atau jalankan
echo  manual lewat start_tunnel.bat.
echo ============================================================
pause
