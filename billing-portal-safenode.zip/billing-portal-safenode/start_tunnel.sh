#!/bin/bash
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "============================================================"
echo " BENTANG RADIUS - Membuka akses online lewat Cloudflare Tunnel"
echo "============================================================"
echo ""
echo "PENTING: pastikan start.sh sudah dijalankan dulu di terminal"
echo "lain, dan server lokal sudah aktif di http://localhost:80"
echo ""

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLOUDFLARED=""

if command -v cloudflared &> /dev/null; then
    CLOUDFLARED="cloudflared"
elif [ -x "$DIR/cloudflared" ]; then
    CLOUDFLARED="$DIR/cloudflared"
fi

if [ -z "$CLOUDFLARED" ]; then
    echo "[ERROR] cloudflared belum ditemukan di komputer ini."
    echo ""
    echo "Cara install (pilih salah satu):"
    echo "  1) Mac (Homebrew): brew install cloudflared"
    echo "  2) Linux (Debian/Ubuntu), lihat paket resmi di:"
    echo "     https://pkg.cloudflare.com/index.html"
    echo "  3) Manual: download binary dari"
    echo "     https://github.com/cloudflare/cloudflared/releases/latest"
    echo "     lalu taruh di folder yang sama dengan script ini dengan nama"
    echo "     'cloudflared', dan beri izin eksekusi: chmod +x cloudflared"
    echo ""
    echo "Setelah terinstall, jalankan lagi ./start_tunnel.sh ini."
    echo ""
    read -p "Tekan ENTER untuk keluar..."
    exit 1
fi

if [ ! -f "$DIR/tunnel_info.txt" ]; then
    echo ""
    echo "============================================================"
    echo " Akses online BELUM disetel."
    echo "============================================================"
    echo ""
    echo "Jalankan dulu ./setup_tunnel_pertama_kali.sh (SEKALI SAJA)"
    echo "untuk membuat link online TETAP yang tidak berubah-ubah."
    echo "Setelah itu, start_tunnel.sh ini akan otomatis memakai link"
    echo "tersebut."
    echo ""
    read -p "Tekan ENTER untuk keluar..."
    exit 1
fi

HOSTNAME_TETAP="$(grep '^HOSTNAME=' "$DIR/tunnel_info.txt" | cut -d= -f2-)"
TUNNEL_NAME="$(grep '^TUNNEL_NAME=' "$DIR/tunnel_info.txt" | cut -d= -f2-)"

if [ -z "$HOSTNAME_TETAP" ] || [ -z "$TUNNEL_NAME" ]; then
    echo "[ERROR] tunnel_info.txt rusak/tidak lengkap. Jalankan ulang"
    echo "./setup_tunnel_pertama_kali.sh"
    read -p "Tekan ENTER untuk keluar..."
    exit 1
fi

echo ""
echo "Link online tetap kamu: https://$HOSTNAME_TETAP"
echo "Link ini TIDAK BERUBAH walau tunnel ini dinyalakan-matikan"
echo "berkali-kali. Jangan tutup terminal ini selama masih ingin online."
echo "============================================================"
echo ""

"$CLOUDFLARED" tunnel run --url http://localhost:80 "$TUNNEL_NAME"

echo ""
echo "============================================================"
echo " Tunnel berhenti / terjadi error (lihat pesan di atas)."
echo "============================================================"
read -p "Tekan ENTER untuk keluar..."
