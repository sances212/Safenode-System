"""
olt_ssh.py - Sinkronisasi status ONU lewat SSH, untuk OLT yang OID SNMP privatnya
tidak diketahui / tidak bisa diakses (umum terjadi di OLT EPON clone/HIOSO/SMI dkk yang
tidak mempublikasikan MIB-nya).

Menyambung ke OLT pakai SSH, menjalankan perintah tabel MAC/bridge (command-nya bisa diatur
admin karena beda-beda tiap merk/firmware), lalu hasil teksnya di-parse dengan parser yang
sama dipakai fitur "Import dari SSH" manual (lihat _parse_tabel_mac_onu di app.py) --
jadi hasilnya konsisten baik lewat sync otomatis maupun paste manual.
"""

import time


class SSHSyncError(Exception):
    pass


def ambil_tabel_mac_ssh(cfg, timeout=15):
    """cfg: dict dengan keys host, ssh_port, ssh_username, ssh_password, ssh_command.
    Return teks mentah hasil command. Raise SSHSyncError kalau gagal konek/autentikasi/
    command tidak jalan -- pesan errornya dibuat cukup jelas untuk ditampilkan ke admin
    (bukan traceback mentah), karena ini dipanggil dari route API yang meneruskan pesan
    ke tombol "Sync via SSH" di halaman ONU."""
    try:
        import paramiko
    except ImportError:
        raise SSHSyncError(
            "Modul 'paramiko' belum terinstall di server ini. Buka terminal/CMD di folder "
            "aplikasi lalu jalankan: pip install paramiko (atau pip install paramiko "
            "--break-system-packages), setelah itu restart aplikasinya."
        )

    if not cfg.get("host"):
        raise SSHSyncError("Host/IP OLT belum diisi.")
    if not cfg.get("ssh_username"):
        raise SSHSyncError("Username SSH OLT belum diisi (lengkapi lewat menu Edit OLT).")

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=cfg["host"],
            port=int(cfg.get("ssh_port") or 22),
            username=cfg.get("ssh_username") or "",
            password=cfg.get("ssh_password") or "",
            timeout=timeout,
            banner_timeout=timeout,
            auth_timeout=timeout,
            look_for_keys=False,
            allow_agent=False,
        )
    except paramiko.AuthenticationException:
        raise SSHSyncError("Login SSH ditolak. Cek lagi Username/Password SSH OLT.")
    except Exception as e:
        raise SSHSyncError(f"Tidak bisa konek SSH ke OLT ({cfg['host']}): {e}")

    perintah = (cfg.get("ssh_command") or "show mac address-table").strip()
    try:
        # Banyak OLT clone (gaya Cisco CLI) butuh sesi shell interaktif supaya command-nya
        # dikenali -- exec_command biasa sering ditolak/kosong di firmware seperti ini.
        # Kirim command lewat invoke_shell(), lalu baca outputnya sampai kembali ke prompt
        # (biasanya diakhiri '#' atau '>') atau sampai timeout.
        shell = client.invoke_shell()
        time.sleep(1)
        if shell.recv_ready():
            shell.recv(65535)  # buang banner/MOTD awal sesi

        shell.send(perintah + "\n")
        time.sleep(2)

        output = ""
        batas_waktu = time.time() + timeout
        diam_sejak = time.time()
        while time.time() < batas_waktu:
            if shell.recv_ready():
                bagian = shell.recv(65535).decode("utf-8", errors="ignore")
                output += bagian
                diam_sejak = time.time()
            else:
                # kalau sudah tidak ada data baru selama >1.5 detik, anggap output selesai
                if time.time() - diam_sejak > 1.5 and output:
                    break
                time.sleep(0.2)
        if not output.strip():
            raise SSHSyncError(
                "Konek SSH berhasil tapi tidak ada balasan untuk perintah "
                f"'{perintah}'. Cek lagi 'Perintah SSH' di pengaturan OLT.")
        return output
    except SSHSyncError:
        raise
    except Exception as e:
        raise SSHSyncError(f"Gagal menjalankan perintah lewat SSH: {e}")
    finally:
        client.close()
