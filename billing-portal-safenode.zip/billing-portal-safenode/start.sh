#!/bin/bash
echo "============================================================"
echo " BENTANG RADIUS - Menyiapkan server..."
echo "============================================================"

if ! command -v python3 &> /dev/null; then
    echo ""
    echo "[ERROR] Python3 tidak ditemukan di komputer ini."
    echo "Silakan install Python dulu dari https://www.python.org/downloads/"
    read -p "Tekan ENTER untuk keluar..."
    exit 1
fi

echo ""
echo "Menginstall library yang dibutuhkan (Flask, Pillow, waitress)..."
python3 -m pip install -r requirements.txt

echo ""
echo "============================================================"
echo " Menjalankan server... Jangan tutup terminal ini."
echo " Buka browser lalu akses: http://localhost:80"
echo " Mau diakses online dari mana saja? Lihat start_tunnel.sh"
echo "============================================================"
echo ""

python3 app.py

echo ""
echo "============================================================"
echo " Server berhenti / terjadi error (lihat pesan di atas)."
echo "============================================================"
read -p "Tekan ENTER untuk keluar..."
