"""
uptimerobot_client.py - Klien sederhana untuk UptimeRobot API v2.

Dipakai oleh menu "Sistem" (Status Sistem) supaya admin bisa memantau status
monitor UptimeRobot (mis. status server billing ini, tunnel, atau layanan lain
yang dipantau) langsung dari dashboard admin, tanpa perlu buka situs
UptimeRobot secara terpisah.

Referensi resmi: https://uptimerobot.com/api/
"""

import json
import urllib.request
import urllib.parse
import urllib.error

TIMEOUT_DETIK = 10
API_URL = "https://api.uptimerobot.com/v2"

# Kode status monitor sesuai dokumentasi UptimeRobot.
STATUS_LABEL = {
    0: ("Paused", "secondary"),
    1: ("Belum Pernah Dicek", "secondary"),
    2: ("Up", "success"),
    8: ("Seems Down", "warning"),
    9: ("Down", "danger"),
}


class UptimeRobotError(Exception):
    pass


def _panggil(api_key, endpoint, extra_params=None):
    if not api_key:
        raise UptimeRobotError("API Key UptimeRobot belum diisi.")
    params = {"api_key": api_key, "format": "json"}
    if extra_params:
        params.update(extra_params)
    body = urllib.parse.urlencode(params).encode("utf-8")
    req = urllib.request.Request(
        f"{API_URL}/{endpoint}",
        data=body,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Cache-Control": "no-cache",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_DETIK) as resp:
            mentah = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise UptimeRobotError(f"UptimeRobot membalas error HTTP {e.code}: {e.reason}")
    except urllib.error.URLError as e:
        raise UptimeRobotError(f"Tidak bisa terhubung ke UptimeRobot: {e.reason}")
    except Exception as e:
        raise UptimeRobotError(f"Gagal menghubungi UptimeRobot: {e}")

    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise UptimeRobotError("Balasan UptimeRobot tidak valid (bukan JSON).")

    if hasil.get("stat") != "ok":
        pesan = (hasil.get("error") or {}).get("message", "Permintaan ditolak UptimeRobot.")
        raise UptimeRobotError(pesan)
    return hasil


def ambil_monitors(api_key):
    """Ambil daftar seluruh monitor beserta status terkininya. Return list of dict:
    [{id, nama, url, status_kode, status_label, status_warna, uptime_persen}, ...]"""
    hasil = _panggil(api_key, "getMonitors", {
        "custom_uptime_ratios": "30",
        "logs": "0",
    })
    daftar = []
    for m in hasil.get("monitors", []):
        kode = m.get("status", 0)
        label, warna = STATUS_LABEL.get(kode, ("Tidak Diketahui", "secondary"))
        daftar.append({
            "id": m.get("id"),
            "nama": m.get("friendly_name", "-"),
            "url": m.get("url", ""),
            "status_kode": kode,
            "status_label": label,
            "status_warna": warna,
            "uptime_persen": m.get("custom_uptime_ratio", "-"),
        })
    return daftar


def tes_koneksi(api_key):
    """Panggil getAccountDetails untuk memastikan API Key valid. Return dict ringkas
    berisi jumlah monitor & sisa kuota, atau raise UptimeRobotError kalau gagal."""
    hasil = _panggil(api_key, "getAccountDetails")
    akun = hasil.get("account", {})
    return {
        "monitor_limit": akun.get("monitor_limit"),
        "monitor_terpakai": akun.get("up_monitors", 0) + akun.get("down_monitors", 0) + akun.get("paused_monitors", 0),
    }
