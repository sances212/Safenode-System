# -*- coding: utf-8 -*-
"""
telegram_gateway.py - Klien sederhana untuk Telegram Bot API.

Dipakai untuk:
- Mengirim pesan notifikasi lewat Telegram (mis. notifikasi tagihan/reminder,
  atau notifikasi internal ke admin/grup)
- Tes koneksi/autentikasi bot yang dikonfigurasi (getMe)

Referensi resmi: https://core.telegram.org/bots/api
Ditulis pakai urllib bawaan Python supaya tidak perlu tambahan dependency,
mengikuti pola yang sama dengan wa_gateway.py & tripay_gateway.py.

Catatan: berbeda dengan WA Gateway (Wablas) yang server-nya per-akun, Telegram
Bot API selalu di domain resmi https://api.telegram.org -- yang perlu disimpan
per-instalasi cuma Bot Token (dari @BotFather) & Chat ID tujuan default.
"""

import json
import urllib.request
import urllib.parse
import urllib.error

TIMEOUT_DETIK = 20
BASE_URL = "https://api.telegram.org"


class TelegramError(Exception):
    """Dilempar kalau request ke Telegram Bot API gagal atau dibalas error."""
    pass


def _request(method_api, cfg, data=None):
    token = (cfg.get("bot_token") or "").strip()
    if not token:
        raise TelegramError("Bot Token Telegram belum diisi.")

    url = f"{BASE_URL}/bot{token}/{method_api}"
    body = urllib.parse.urlencode(data or {}).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_DETIK) as resp:
            mentah = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        try:
            mentah = e.read().decode("utf-8")
        except Exception:
            raise TelegramError(f"Gagal menghubungi Telegram (HTTP {e.code}).")
    except urllib.error.URLError as e:
        raise TelegramError(f"Tidak bisa terhubung ke server Telegram: {e.reason}")
    except Exception as e:
        raise TelegramError(f"Gagal menghubungi Telegram: {e}")

    try:
        hasil = json.loads(mentah)
    except ValueError:
        raise TelegramError("Balasan Telegram tidak bisa dibaca (bukan JSON valid).")

    if isinstance(hasil, dict) and hasil.get("ok") is False:
        pesan = hasil.get("description") or "Telegram menolak permintaan tanpa pesan error."
        raise TelegramError(pesan)

    return hasil.get("result") if isinstance(hasil, dict) else hasil


def cek_bot(cfg):
    """Tes koneksi/autentikasi: ambil info bot (username, dsb) lewat getMe
    (dipakai buat tombol 'Tes Koneksi' di halaman pengaturan)."""
    return _request("getMe", cfg)


def kirim_pesan(cfg, chat_id, pesan):
    """Kirim satu pesan teks lewat bot Telegram ke chat_id tertentu.
    cfg: dict berisi bot_token. Kalau chat_id kosong, pakai chat_id_default dari cfg."""
    tujuan = (chat_id or cfg.get("chat_id_default") or "").strip()
    if not tujuan:
        raise TelegramError("Chat ID tujuan belum diisi.")
    payload = {"chat_id": tujuan, "text": pesan}
    return _request("sendMessage", cfg, payload)


def ambil_pesan_masuk(cfg, limit=20):
    """Ambil pesan masuk terbaru ke bot lewat getUpdates (endpoint resmi Telegram Bot
    API, dokumentasi: https://core.telegram.org/bots/api#getupdates). Dipakai supaya
    balasan pelanggan bisa langsung dilihat di halaman Telegram Gateway aplikasi ini,
    tanpa perlu buka Telegram/API pihak ketiga secara manual.

    Catatan: getUpdates cuma membalas pesan yang BELUM pernah "ditandai terbaca" lewat
    parameter offset. Karena aplikasi ini tidak menyimpan offset (biar pesan yang sama
    tetap kelihatan tiap halaman dibuka, bukan cuma sekali), dipakai trik: ambil update
    tanpa offset dulu buat tahu update_id terakhir, tidak di-advance -- jadi Telegram
    akan tetap mengembalikan riwayat pesan yang sama tiap dipanggil (selama belum ada
    proses lain yang meng-advance offset, mis. Webhook aktif di bot yang sama)."""
    hasil = _request("getUpdates", cfg, {"limit": limit})
    if not isinstance(hasil, list):
        return []

    pesan_list = []
    for update in hasil:
        msg = update.get("message") or update.get("edited_message")
        if not msg or "text" not in msg:
            continue
        pengirim = msg.get("from") or {}
        nama = pengirim.get("username") or pengirim.get("first_name") or "-"
        pesan_list.append({
            "chat_id": (msg.get("chat") or {}).get("id"),
            "dari": nama,
            "teks": msg.get("text"),
            "waktu_unix": msg.get("date"),
        })
    pesan_list.sort(key=lambda p: p.get("waktu_unix") or 0, reverse=True)
    return pesan_list
