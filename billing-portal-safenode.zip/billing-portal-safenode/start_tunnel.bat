@echo off
title BENTANG RADIUS - Akses Online (Cloudflare Tunnel)
cd /d "%~dp0"
echo ============================================================
echo  BENTANG RADIUS - Membuka akses online lewat Cloudflare Tunnel
echo ============================================================
echo.
echo PENTING: pastikan start.bat sudah dijalankan dulu di jendela
echo lain, dan server lokal sudah aktif di http://localhost:80
echo.

set "CLOUDFLARED="

where cloudflared >nul 2>nul
if not errorlevel 1 (
    set "CLOUDFLARED=cloudflared"
    goto :ketemu
)

if exist "%~dp0cloudflared.exe" (
    set "CLOUDFLARED=%~dp0cloudflared.exe"
    goto :ketemu
)

goto :tidak_ketemu

:tidak_ketemu
echo [ERROR] cloudflared belum ditemukan di komputer ini.
echo.
echo Cara install (pilih salah satu):
echo   1^) Lewat winget (disarankan):
echo      winget install --id Cloudflare.cloudflared
echo   2^) Manual: download dari
echo      https://github.com/cloudflare/cloudflared/releases/latest
echo      (pilih file cloudflared-windows-amd64.exe), lalu rename jadi
echo      cloudflared.exe dan taruh di folder yang sama dengan file ini.
echo.
echo Setelah terinstall, jalankan lagi start_tunnel.bat ini.
echo.
pause
exit /b 1

:ketemu
if not exist "%~dp0tunnel_info.txt" goto :belum_disetel

set "HOSTNAME="
set "TUNNEL_NAME="
for /f "tokens=1,2 delims==" %%a in (%~dp0tunnel_info.txt) do (
    if "%%a"=="HOSTNAME" set "HOSTNAME=%%b"
    if "%%a"=="TUNNEL_NAME" set "TUNNEL_NAME=%%b"
)
if "%HOSTNAME%"=="" goto :belum_disetel
if "%TUNNEL_NAME%"=="" goto :belum_disetel

echo.
echo Link online tetap kamu: https://%HOSTNAME%
echo Link ini TIDAK BERUBAH walau tunnel ini dinyalakan-matikan
echo berkali-kali. Jangan tutup jendela ini selama masih ingin online.
echo ============================================================

set /a PERCOBAAN=0

:ulangi_tunnel
set /a PERCOBAAN+=1
echo.
echo ------------------------------------------------------------
echo  Percobaan ke-%PERCOBAAN% dari 5...
echo ------------------------------------------------------------
echo.

"%CLOUDFLARED%" tunnel run --url http://localhost:80 %TUNNEL_NAME%
set HASIL_TUNNEL=%errorlevel%

if %HASIL_TUNNEL% equ 0 goto :selesai_normal

if %PERCOBAAN% geq 5 goto :gagal_total

echo.
echo [PERINGATAN] Tunnel terhenti/gagal (kemungkinan gangguan sesaat
echo di server Cloudflare). Mencoba lagi dalam 5 detik...
timeout /t 5 /nobreak >nul
goto :ulangi_tunnel

:gagal_total
echo.
echo ============================================================
echo  Sudah dicoba 5 kali tapi tunnel tetap gagal terbentuk.
echo ============================================================
echo.
echo Kemungkinan penyebab dan solusinya:
echo   1^) cloudflared versi lama - update dengan:
echo      winget install --id Cloudflare.cloudflared
echo      (atau download ulang versi terbaru dari GitHub cloudflared)
echo   2^) Ada firewall/antivirus yang memblokir cloudflared.exe
echo      mengakses internet - izinkan aplikasi ini di antivirus Anda.
echo   3^) Layanan Cloudflare sedang gangguan (bukan masalah di
echo      komputer Anda) - coba lagi beberapa menit lagi, atau cek
echo      status di https://www.cloudflarestatus.com
echo.
pause
exit /b 1

:selesai_normal
echo.
echo ============================================================
echo  Tunnel berhenti (ditutup secara normal).
echo ============================================================
pause
exit /b 0

:belum_disetel
echo.
echo ============================================================
echo  Akses online BELUM disetel.
echo ============================================================
echo.
echo Jalankan dulu setup_tunnel_pertama_kali.bat (SEKALI SAJA) untuk
echo membuat link online TETAP yang tidak berubah-ubah. Setelah itu,
echo start_tunnel.bat ini akan otomatis memakai link tersebut.
echo.
pause
exit /b 1

